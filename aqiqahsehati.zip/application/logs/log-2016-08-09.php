<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-09 04:03:24 --> Config Class Initialized
INFO - 2016-08-09 04:03:24 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:24 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:24 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:24 --> URI Class Initialized
INFO - 2016-08-09 04:03:24 --> Router Class Initialized
INFO - 2016-08-09 04:03:24 --> Output Class Initialized
INFO - 2016-08-09 04:03:24 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:24 --> Input Class Initialized
INFO - 2016-08-09 04:03:24 --> Language Class Initialized
INFO - 2016-08-09 04:03:25 --> Loader Class Initialized
INFO - 2016-08-09 04:03:25 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:25 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:25 --> Email Class Initialized
INFO - 2016-08-09 04:03:25 --> Model Class Initialized
INFO - 2016-08-09 04:03:25 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:25 --> Model Class Initialized
INFO - 2016-08-09 04:03:25 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:25 --> Config Class Initialized
INFO - 2016-08-09 04:03:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:25 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:25 --> URI Class Initialized
INFO - 2016-08-09 04:03:25 --> Router Class Initialized
INFO - 2016-08-09 04:03:25 --> Output Class Initialized
INFO - 2016-08-09 04:03:25 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:25 --> Input Class Initialized
INFO - 2016-08-09 04:03:25 --> Language Class Initialized
INFO - 2016-08-09 04:03:25 --> Loader Class Initialized
INFO - 2016-08-09 04:03:25 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:25 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:25 --> Email Class Initialized
INFO - 2016-08-09 04:03:25 --> Model Class Initialized
INFO - 2016-08-09 04:03:25 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:25 --> Model Class Initialized
INFO - 2016-08-09 04:03:26 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:26 --> Helper loaded: form_helper
INFO - 2016-08-09 04:03:26 --> Form Validation Class Initialized
INFO - 2016-08-09 04:03:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 04:03:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-09 04:03:26 --> Final output sent to browser
DEBUG - 2016-08-09 04:03:26 --> Total execution time: 0.4322
INFO - 2016-08-09 04:03:36 --> Config Class Initialized
INFO - 2016-08-09 04:03:36 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:36 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:36 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:36 --> URI Class Initialized
INFO - 2016-08-09 04:03:36 --> Router Class Initialized
INFO - 2016-08-09 04:03:36 --> Output Class Initialized
INFO - 2016-08-09 04:03:36 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:36 --> Input Class Initialized
INFO - 2016-08-09 04:03:36 --> Language Class Initialized
INFO - 2016-08-09 04:03:36 --> Loader Class Initialized
INFO - 2016-08-09 04:03:36 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:36 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:36 --> Email Class Initialized
INFO - 2016-08-09 04:03:36 --> Model Class Initialized
INFO - 2016-08-09 04:03:36 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:36 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:36 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:36 --> Model Class Initialized
INFO - 2016-08-09 04:03:36 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:36 --> Helper loaded: form_helper
INFO - 2016-08-09 04:03:36 --> Form Validation Class Initialized
INFO - 2016-08-09 04:03:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 04:03:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-09 04:03:36 --> Config Class Initialized
INFO - 2016-08-09 04:03:36 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:36 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:36 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:36 --> URI Class Initialized
INFO - 2016-08-09 04:03:36 --> Router Class Initialized
INFO - 2016-08-09 04:03:36 --> Output Class Initialized
INFO - 2016-08-09 04:03:36 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:36 --> Input Class Initialized
INFO - 2016-08-09 04:03:36 --> Language Class Initialized
INFO - 2016-08-09 04:03:36 --> Loader Class Initialized
INFO - 2016-08-09 04:03:36 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:36 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:36 --> Email Class Initialized
INFO - 2016-08-09 04:03:37 --> Model Class Initialized
INFO - 2016-08-09 04:03:37 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:37 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:37 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:37 --> Model Class Initialized
INFO - 2016-08-09 04:03:37 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:03:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:03:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:03:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 04:03:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:03:37 --> Final output sent to browser
DEBUG - 2016-08-09 04:03:37 --> Total execution time: 0.3597
INFO - 2016-08-09 04:03:42 --> Config Class Initialized
INFO - 2016-08-09 04:03:42 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:42 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:42 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:42 --> URI Class Initialized
INFO - 2016-08-09 04:03:42 --> Router Class Initialized
INFO - 2016-08-09 04:03:42 --> Output Class Initialized
INFO - 2016-08-09 04:03:42 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:42 --> Input Class Initialized
INFO - 2016-08-09 04:03:42 --> Language Class Initialized
INFO - 2016-08-09 04:03:42 --> Loader Class Initialized
INFO - 2016-08-09 04:03:42 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:42 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:42 --> Email Class Initialized
INFO - 2016-08-09 04:03:42 --> Model Class Initialized
INFO - 2016-08-09 04:03:42 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:42 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:42 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:42 --> Model Class Initialized
INFO - 2016-08-09 04:03:42 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:03:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:03:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:03:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-09 04:03:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:03:42 --> Final output sent to browser
DEBUG - 2016-08-09 04:03:42 --> Total execution time: 0.3183
INFO - 2016-08-09 04:03:45 --> Config Class Initialized
INFO - 2016-08-09 04:03:45 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:45 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:45 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:45 --> URI Class Initialized
INFO - 2016-08-09 04:03:45 --> Router Class Initialized
INFO - 2016-08-09 04:03:45 --> Output Class Initialized
INFO - 2016-08-09 04:03:45 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:45 --> Input Class Initialized
INFO - 2016-08-09 04:03:45 --> Language Class Initialized
INFO - 2016-08-09 04:03:45 --> Loader Class Initialized
INFO - 2016-08-09 04:03:45 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:45 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:45 --> Email Class Initialized
INFO - 2016-08-09 04:03:45 --> Model Class Initialized
INFO - 2016-08-09 04:03:45 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:45 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:45 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:45 --> Model Class Initialized
INFO - 2016-08-09 04:03:45 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:03:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:03:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:03:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:03:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:03:46 --> Final output sent to browser
DEBUG - 2016-08-09 04:03:46 --> Total execution time: 0.3301
INFO - 2016-08-09 04:03:49 --> Config Class Initialized
INFO - 2016-08-09 04:03:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:03:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:03:49 --> Utf8 Class Initialized
INFO - 2016-08-09 04:03:49 --> URI Class Initialized
INFO - 2016-08-09 04:03:49 --> Router Class Initialized
INFO - 2016-08-09 04:03:49 --> Output Class Initialized
INFO - 2016-08-09 04:03:49 --> Security Class Initialized
DEBUG - 2016-08-09 04:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:03:49 --> Input Class Initialized
INFO - 2016-08-09 04:03:49 --> Language Class Initialized
INFO - 2016-08-09 04:03:49 --> Loader Class Initialized
INFO - 2016-08-09 04:03:49 --> Helper loaded: url_helper
INFO - 2016-08-09 04:03:49 --> Database Driver Class Initialized
INFO - 2016-08-09 04:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:03:49 --> Email Class Initialized
INFO - 2016-08-09 04:03:49 --> Model Class Initialized
INFO - 2016-08-09 04:03:49 --> Controller Class Initialized
DEBUG - 2016-08-09 04:03:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:03:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:03:49 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:03:49 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:03:49 --> Model Class Initialized
INFO - 2016-08-09 04:03:49 --> Helper loaded: date_helper
INFO - 2016-08-09 04:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:03:49 --> Final output sent to browser
DEBUG - 2016-08-09 04:03:49 --> Total execution time: 0.3036
INFO - 2016-08-09 04:04:22 --> Config Class Initialized
INFO - 2016-08-09 04:04:22 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:04:22 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:04:22 --> Utf8 Class Initialized
INFO - 2016-08-09 04:04:22 --> URI Class Initialized
INFO - 2016-08-09 04:04:22 --> Router Class Initialized
INFO - 2016-08-09 04:04:22 --> Output Class Initialized
INFO - 2016-08-09 04:04:22 --> Security Class Initialized
DEBUG - 2016-08-09 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:04:22 --> Input Class Initialized
INFO - 2016-08-09 04:04:22 --> Language Class Initialized
INFO - 2016-08-09 04:04:22 --> Loader Class Initialized
INFO - 2016-08-09 04:04:22 --> Helper loaded: url_helper
INFO - 2016-08-09 04:04:22 --> Database Driver Class Initialized
INFO - 2016-08-09 04:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:04:22 --> Email Class Initialized
INFO - 2016-08-09 04:04:22 --> Model Class Initialized
INFO - 2016-08-09 04:04:22 --> Controller Class Initialized
DEBUG - 2016-08-09 04:04:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:04:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:04:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:04:22 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:04:22 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:04:22 --> Model Class Initialized
INFO - 2016-08-09 04:04:22 --> Helper loaded: date_helper
INFO - 2016-08-09 04:04:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:04:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:04:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 04:04:22 --> Severity: Notice --> Undefined variable: linksocial D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
ERROR - 2016-08-09 04:04:22 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
INFO - 2016-08-09 04:05:05 --> Config Class Initialized
INFO - 2016-08-09 04:05:05 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:05:05 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:05:05 --> Utf8 Class Initialized
INFO - 2016-08-09 04:05:05 --> URI Class Initialized
INFO - 2016-08-09 04:05:05 --> Router Class Initialized
INFO - 2016-08-09 04:05:05 --> Output Class Initialized
INFO - 2016-08-09 04:05:05 --> Security Class Initialized
DEBUG - 2016-08-09 04:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:05:05 --> Input Class Initialized
INFO - 2016-08-09 04:05:05 --> Language Class Initialized
INFO - 2016-08-09 04:05:05 --> Loader Class Initialized
INFO - 2016-08-09 04:05:05 --> Helper loaded: url_helper
INFO - 2016-08-09 04:05:05 --> Database Driver Class Initialized
INFO - 2016-08-09 04:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:05:05 --> Email Class Initialized
INFO - 2016-08-09 04:05:05 --> Model Class Initialized
INFO - 2016-08-09 04:05:05 --> Controller Class Initialized
DEBUG - 2016-08-09 04:05:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:05:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:05:05 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:05:05 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:05 --> Model Class Initialized
INFO - 2016-08-09 04:05:05 --> Helper loaded: date_helper
INFO - 2016-08-09 04:05:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:05:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:05:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 04:05:05 --> Severity: Notice --> Undefined variable: linksocial D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
ERROR - 2016-08-09 04:05:05 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
INFO - 2016-08-09 04:05:53 --> Config Class Initialized
INFO - 2016-08-09 04:05:53 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:05:53 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:05:53 --> Utf8 Class Initialized
INFO - 2016-08-09 04:05:53 --> URI Class Initialized
INFO - 2016-08-09 04:05:53 --> Router Class Initialized
INFO - 2016-08-09 04:05:53 --> Output Class Initialized
INFO - 2016-08-09 04:05:53 --> Security Class Initialized
DEBUG - 2016-08-09 04:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:05:53 --> Input Class Initialized
INFO - 2016-08-09 04:05:53 --> Language Class Initialized
INFO - 2016-08-09 04:05:53 --> Loader Class Initialized
INFO - 2016-08-09 04:05:53 --> Helper loaded: url_helper
INFO - 2016-08-09 04:05:53 --> Database Driver Class Initialized
INFO - 2016-08-09 04:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:05:53 --> Email Class Initialized
INFO - 2016-08-09 04:05:53 --> Model Class Initialized
INFO - 2016-08-09 04:05:53 --> Controller Class Initialized
DEBUG - 2016-08-09 04:05:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:05:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:05:53 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:05:53 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:53 --> Model Class Initialized
INFO - 2016-08-09 04:05:53 --> Helper loaded: date_helper
INFO - 2016-08-09 04:05:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:05:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:05:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 04:05:53 --> Severity: Notice --> Undefined variable: linksocial D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
ERROR - 2016-08-09 04:05:53 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
INFO - 2016-08-09 04:05:56 --> Config Class Initialized
INFO - 2016-08-09 04:05:56 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:05:56 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:05:56 --> Utf8 Class Initialized
INFO - 2016-08-09 04:05:56 --> URI Class Initialized
INFO - 2016-08-09 04:05:56 --> Router Class Initialized
INFO - 2016-08-09 04:05:56 --> Output Class Initialized
INFO - 2016-08-09 04:05:56 --> Security Class Initialized
DEBUG - 2016-08-09 04:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:05:56 --> Input Class Initialized
INFO - 2016-08-09 04:05:56 --> Language Class Initialized
INFO - 2016-08-09 04:05:56 --> Loader Class Initialized
INFO - 2016-08-09 04:05:56 --> Helper loaded: url_helper
INFO - 2016-08-09 04:05:56 --> Database Driver Class Initialized
INFO - 2016-08-09 04:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:05:56 --> Email Class Initialized
INFO - 2016-08-09 04:05:56 --> Model Class Initialized
INFO - 2016-08-09 04:05:56 --> Controller Class Initialized
DEBUG - 2016-08-09 04:05:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:05:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:05:56 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:05:56 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:05:56 --> Model Class Initialized
INFO - 2016-08-09 04:05:56 --> Helper loaded: date_helper
INFO - 2016-08-09 04:05:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:05:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:05:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 04:05:56 --> Severity: Notice --> Undefined variable: linksocial D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
ERROR - 2016-08-09 04:05:56 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\linksocial\update_linksocial.php 26
INFO - 2016-08-09 04:06:16 --> Config Class Initialized
INFO - 2016-08-09 04:06:16 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:16 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:16 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:16 --> URI Class Initialized
INFO - 2016-08-09 04:06:16 --> Router Class Initialized
INFO - 2016-08-09 04:06:16 --> Output Class Initialized
INFO - 2016-08-09 04:06:16 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:16 --> Input Class Initialized
INFO - 2016-08-09 04:06:16 --> Language Class Initialized
INFO - 2016-08-09 04:06:16 --> Loader Class Initialized
INFO - 2016-08-09 04:06:16 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:16 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:16 --> Email Class Initialized
INFO - 2016-08-09 04:06:16 --> Model Class Initialized
INFO - 2016-08-09 04:06:16 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:16 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:16 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:16 --> Model Class Initialized
INFO - 2016-08-09 04:06:16 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:06:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:16 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:16 --> Total execution time: 0.3142
INFO - 2016-08-09 04:06:23 --> Config Class Initialized
INFO - 2016-08-09 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:23 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:23 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:23 --> URI Class Initialized
INFO - 2016-08-09 04:06:23 --> Router Class Initialized
INFO - 2016-08-09 04:06:23 --> Output Class Initialized
INFO - 2016-08-09 04:06:23 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:23 --> Input Class Initialized
INFO - 2016-08-09 04:06:23 --> Language Class Initialized
INFO - 2016-08-09 04:06:23 --> Loader Class Initialized
INFO - 2016-08-09 04:06:23 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:23 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:23 --> Email Class Initialized
INFO - 2016-08-09 04:06:23 --> Model Class Initialized
INFO - 2016-08-09 04:06:23 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:23 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:23 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:23 --> Model Class Initialized
INFO - 2016-08-09 04:06:23 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:06:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:23 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:23 --> Total execution time: 0.3161
INFO - 2016-08-09 04:06:25 --> Config Class Initialized
INFO - 2016-08-09 04:06:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:25 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:25 --> URI Class Initialized
INFO - 2016-08-09 04:06:25 --> Router Class Initialized
INFO - 2016-08-09 04:06:25 --> Output Class Initialized
INFO - 2016-08-09 04:06:25 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:25 --> Input Class Initialized
INFO - 2016-08-09 04:06:25 --> Language Class Initialized
INFO - 2016-08-09 04:06:25 --> Loader Class Initialized
INFO - 2016-08-09 04:06:25 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:25 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:25 --> Email Class Initialized
INFO - 2016-08-09 04:06:25 --> Model Class Initialized
INFO - 2016-08-09 04:06:25 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:25 --> Model Class Initialized
INFO - 2016-08-09 04:06:25 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:06:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:26 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:26 --> Total execution time: 0.3105
INFO - 2016-08-09 04:06:27 --> Config Class Initialized
INFO - 2016-08-09 04:06:27 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:27 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:27 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:27 --> URI Class Initialized
INFO - 2016-08-09 04:06:27 --> Router Class Initialized
INFO - 2016-08-09 04:06:27 --> Output Class Initialized
INFO - 2016-08-09 04:06:27 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:27 --> Input Class Initialized
INFO - 2016-08-09 04:06:27 --> Language Class Initialized
INFO - 2016-08-09 04:06:27 --> Loader Class Initialized
INFO - 2016-08-09 04:06:27 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:27 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:27 --> Email Class Initialized
INFO - 2016-08-09 04:06:27 --> Model Class Initialized
INFO - 2016-08-09 04:06:27 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:27 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:27 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:27 --> Model Class Initialized
INFO - 2016-08-09 04:06:27 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:06:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:28 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:28 --> Total execution time: 0.3577
INFO - 2016-08-09 04:06:44 --> Config Class Initialized
INFO - 2016-08-09 04:06:44 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:44 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:44 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:44 --> URI Class Initialized
INFO - 2016-08-09 04:06:44 --> Router Class Initialized
INFO - 2016-08-09 04:06:44 --> Output Class Initialized
INFO - 2016-08-09 04:06:44 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:44 --> Input Class Initialized
INFO - 2016-08-09 04:06:44 --> Language Class Initialized
INFO - 2016-08-09 04:06:44 --> Loader Class Initialized
INFO - 2016-08-09 04:06:44 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:44 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:44 --> Email Class Initialized
INFO - 2016-08-09 04:06:44 --> Model Class Initialized
INFO - 2016-08-09 04:06:44 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:44 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:44 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:44 --> Model Class Initialized
INFO - 2016-08-09 04:06:44 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:06:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:44 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:44 --> Total execution time: 0.3268
INFO - 2016-08-09 04:06:46 --> Config Class Initialized
INFO - 2016-08-09 04:06:46 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:46 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:46 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:46 --> URI Class Initialized
INFO - 2016-08-09 04:06:46 --> Router Class Initialized
INFO - 2016-08-09 04:06:46 --> Output Class Initialized
INFO - 2016-08-09 04:06:46 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:46 --> Input Class Initialized
INFO - 2016-08-09 04:06:46 --> Language Class Initialized
INFO - 2016-08-09 04:06:46 --> Loader Class Initialized
INFO - 2016-08-09 04:06:46 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:46 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:46 --> Email Class Initialized
INFO - 2016-08-09 04:06:46 --> Model Class Initialized
INFO - 2016-08-09 04:06:46 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:46 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:46 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:46 --> Model Class Initialized
INFO - 2016-08-09 04:06:46 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:46 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:46 --> Total execution time: 0.3237
INFO - 2016-08-09 04:06:48 --> Config Class Initialized
INFO - 2016-08-09 04:06:48 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:48 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:48 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:48 --> URI Class Initialized
INFO - 2016-08-09 04:06:48 --> Router Class Initialized
INFO - 2016-08-09 04:06:48 --> Output Class Initialized
INFO - 2016-08-09 04:06:48 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:48 --> Input Class Initialized
INFO - 2016-08-09 04:06:48 --> Language Class Initialized
INFO - 2016-08-09 04:06:48 --> Loader Class Initialized
INFO - 2016-08-09 04:06:48 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:48 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:48 --> Email Class Initialized
INFO - 2016-08-09 04:06:48 --> Model Class Initialized
INFO - 2016-08-09 04:06:48 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:48 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:48 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:48 --> Model Class Initialized
INFO - 2016-08-09 04:06:48 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:06:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:48 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:48 --> Total execution time: 0.3275
INFO - 2016-08-09 04:06:49 --> Config Class Initialized
INFO - 2016-08-09 04:06:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:06:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:06:49 --> Utf8 Class Initialized
INFO - 2016-08-09 04:06:49 --> URI Class Initialized
INFO - 2016-08-09 04:06:49 --> Router Class Initialized
INFO - 2016-08-09 04:06:49 --> Output Class Initialized
INFO - 2016-08-09 04:06:49 --> Security Class Initialized
DEBUG - 2016-08-09 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:06:49 --> Input Class Initialized
INFO - 2016-08-09 04:06:49 --> Language Class Initialized
INFO - 2016-08-09 04:06:49 --> Loader Class Initialized
INFO - 2016-08-09 04:06:49 --> Helper loaded: url_helper
INFO - 2016-08-09 04:06:49 --> Database Driver Class Initialized
INFO - 2016-08-09 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:06:49 --> Email Class Initialized
INFO - 2016-08-09 04:06:49 --> Model Class Initialized
INFO - 2016-08-09 04:06:49 --> Controller Class Initialized
DEBUG - 2016-08-09 04:06:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:06:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:06:50 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:06:50 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:06:50 --> Model Class Initialized
INFO - 2016-08-09 04:06:50 --> Helper loaded: date_helper
INFO - 2016-08-09 04:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:06:50 --> Final output sent to browser
DEBUG - 2016-08-09 04:06:50 --> Total execution time: 0.3244
INFO - 2016-08-09 04:07:46 --> Config Class Initialized
INFO - 2016-08-09 04:07:46 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:07:46 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:07:46 --> Utf8 Class Initialized
INFO - 2016-08-09 04:07:46 --> URI Class Initialized
INFO - 2016-08-09 04:07:46 --> Router Class Initialized
INFO - 2016-08-09 04:07:46 --> Output Class Initialized
INFO - 2016-08-09 04:07:46 --> Security Class Initialized
DEBUG - 2016-08-09 04:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:07:46 --> Input Class Initialized
INFO - 2016-08-09 04:07:46 --> Language Class Initialized
INFO - 2016-08-09 04:07:46 --> Loader Class Initialized
INFO - 2016-08-09 04:07:46 --> Helper loaded: url_helper
INFO - 2016-08-09 04:07:46 --> Database Driver Class Initialized
INFO - 2016-08-09 04:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:07:46 --> Email Class Initialized
INFO - 2016-08-09 04:07:46 --> Model Class Initialized
INFO - 2016-08-09 04:07:46 --> Controller Class Initialized
DEBUG - 2016-08-09 04:07:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:07:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:07:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:07:46 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:07:46 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:07:46 --> Model Class Initialized
INFO - 2016-08-09 04:07:46 --> Helper loaded: date_helper
INFO - 2016-08-09 04:07:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:07:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:07:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:07:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:07:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:07:46 --> Final output sent to browser
DEBUG - 2016-08-09 04:07:46 --> Total execution time: 0.3239
INFO - 2016-08-09 04:07:56 --> Config Class Initialized
INFO - 2016-08-09 04:07:56 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:07:56 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:07:56 --> Utf8 Class Initialized
INFO - 2016-08-09 04:07:56 --> URI Class Initialized
INFO - 2016-08-09 04:07:56 --> Router Class Initialized
INFO - 2016-08-09 04:07:56 --> Output Class Initialized
INFO - 2016-08-09 04:07:56 --> Security Class Initialized
DEBUG - 2016-08-09 04:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:07:56 --> Input Class Initialized
INFO - 2016-08-09 04:07:56 --> Language Class Initialized
INFO - 2016-08-09 04:07:56 --> Loader Class Initialized
INFO - 2016-08-09 04:07:56 --> Helper loaded: url_helper
INFO - 2016-08-09 04:07:56 --> Database Driver Class Initialized
INFO - 2016-08-09 04:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:07:56 --> Email Class Initialized
INFO - 2016-08-09 04:07:56 --> Model Class Initialized
INFO - 2016-08-09 04:07:56 --> Controller Class Initialized
DEBUG - 2016-08-09 04:07:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:07:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:07:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:07:56 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:07:56 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:07:56 --> Model Class Initialized
INFO - 2016-08-09 04:07:56 --> Helper loaded: date_helper
INFO - 2016-08-09 04:07:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:07:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:07:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:07:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:07:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:07:56 --> Final output sent to browser
DEBUG - 2016-08-09 04:07:56 --> Total execution time: 0.3313
INFO - 2016-08-09 04:08:24 --> Config Class Initialized
INFO - 2016-08-09 04:08:24 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:24 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:24 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:24 --> URI Class Initialized
INFO - 2016-08-09 04:08:24 --> Router Class Initialized
INFO - 2016-08-09 04:08:24 --> Output Class Initialized
INFO - 2016-08-09 04:08:24 --> Security Class Initialized
DEBUG - 2016-08-09 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:24 --> Input Class Initialized
INFO - 2016-08-09 04:08:24 --> Language Class Initialized
INFO - 2016-08-09 04:08:24 --> Loader Class Initialized
INFO - 2016-08-09 04:08:24 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:24 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:24 --> Email Class Initialized
INFO - 2016-08-09 04:08:24 --> Model Class Initialized
INFO - 2016-08-09 04:08:24 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:24 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:24 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:24 --> Model Class Initialized
INFO - 2016-08-09 04:08:24 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:08:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:24 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:24 --> Total execution time: 0.3425
INFO - 2016-08-09 04:08:26 --> Config Class Initialized
INFO - 2016-08-09 04:08:26 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:26 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:26 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:26 --> URI Class Initialized
INFO - 2016-08-09 04:08:26 --> Router Class Initialized
INFO - 2016-08-09 04:08:27 --> Output Class Initialized
INFO - 2016-08-09 04:08:27 --> Security Class Initialized
DEBUG - 2016-08-09 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:27 --> Input Class Initialized
INFO - 2016-08-09 04:08:27 --> Language Class Initialized
INFO - 2016-08-09 04:08:27 --> Loader Class Initialized
INFO - 2016-08-09 04:08:27 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:27 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:27 --> Email Class Initialized
INFO - 2016-08-09 04:08:27 --> Model Class Initialized
INFO - 2016-08-09 04:08:27 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:27 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:27 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:27 --> Model Class Initialized
INFO - 2016-08-09 04:08:27 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:08:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:27 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:27 --> Total execution time: 0.3364
INFO - 2016-08-09 04:08:29 --> Config Class Initialized
INFO - 2016-08-09 04:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:29 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:29 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:29 --> URI Class Initialized
INFO - 2016-08-09 04:08:29 --> Router Class Initialized
INFO - 2016-08-09 04:08:29 --> Output Class Initialized
INFO - 2016-08-09 04:08:29 --> Security Class Initialized
DEBUG - 2016-08-09 04:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:29 --> Input Class Initialized
INFO - 2016-08-09 04:08:29 --> Language Class Initialized
INFO - 2016-08-09 04:08:29 --> Loader Class Initialized
INFO - 2016-08-09 04:08:29 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:29 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:29 --> Email Class Initialized
INFO - 2016-08-09 04:08:29 --> Model Class Initialized
INFO - 2016-08-09 04:08:29 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:29 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:29 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:29 --> Model Class Initialized
INFO - 2016-08-09 04:08:29 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:08:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:29 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:29 --> Total execution time: 0.3298
INFO - 2016-08-09 04:08:30 --> Config Class Initialized
INFO - 2016-08-09 04:08:30 --> Hooks Class Initialized
INFO - 2016-08-09 04:08:30 --> Config Class Initialized
INFO - 2016-08-09 04:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:30 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-09 04:08:30 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:30 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:30 --> URI Class Initialized
INFO - 2016-08-09 04:08:30 --> URI Class Initialized
INFO - 2016-08-09 04:08:30 --> Router Class Initialized
INFO - 2016-08-09 04:08:30 --> Router Class Initialized
INFO - 2016-08-09 04:08:30 --> Output Class Initialized
INFO - 2016-08-09 04:08:30 --> Security Class Initialized
INFO - 2016-08-09 04:08:30 --> Output Class Initialized
DEBUG - 2016-08-09 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:30 --> Security Class Initialized
INFO - 2016-08-09 04:08:30 --> Input Class Initialized
DEBUG - 2016-08-09 04:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:30 --> Input Class Initialized
INFO - 2016-08-09 04:08:30 --> Language Class Initialized
INFO - 2016-08-09 04:08:30 --> Language Class Initialized
INFO - 2016-08-09 04:08:30 --> Loader Class Initialized
INFO - 2016-08-09 04:08:30 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:30 --> Loader Class Initialized
INFO - 2016-08-09 04:08:30 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:30 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:30 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:30 --> Email Class Initialized
INFO - 2016-08-09 04:08:30 --> Model Class Initialized
INFO - 2016-08-09 04:08:30 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:30 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:30 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:30 --> Model Class Initialized
INFO - 2016-08-09 04:08:30 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:31 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:31 --> Total execution time: 0.3361
INFO - 2016-08-09 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:31 --> Email Class Initialized
INFO - 2016-08-09 04:08:31 --> Model Class Initialized
INFO - 2016-08-09 04:08:31 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:31 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:31 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:31 --> Model Class Initialized
INFO - 2016-08-09 04:08:31 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:31 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:31 --> Total execution time: 0.5215
INFO - 2016-08-09 04:08:32 --> Config Class Initialized
INFO - 2016-08-09 04:08:32 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:32 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:32 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:32 --> URI Class Initialized
INFO - 2016-08-09 04:08:32 --> Router Class Initialized
INFO - 2016-08-09 04:08:32 --> Output Class Initialized
INFO - 2016-08-09 04:08:32 --> Security Class Initialized
DEBUG - 2016-08-09 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:32 --> Input Class Initialized
INFO - 2016-08-09 04:08:32 --> Language Class Initialized
INFO - 2016-08-09 04:08:32 --> Loader Class Initialized
INFO - 2016-08-09 04:08:32 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:32 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:32 --> Email Class Initialized
INFO - 2016-08-09 04:08:32 --> Model Class Initialized
INFO - 2016-08-09 04:08:32 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:32 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:32 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:32 --> Model Class Initialized
INFO - 2016-08-09 04:08:32 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:08:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:32 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:32 --> Total execution time: 0.3381
INFO - 2016-08-09 04:08:34 --> Config Class Initialized
INFO - 2016-08-09 04:08:34 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:08:34 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:08:34 --> Utf8 Class Initialized
INFO - 2016-08-09 04:08:34 --> URI Class Initialized
INFO - 2016-08-09 04:08:34 --> Router Class Initialized
INFO - 2016-08-09 04:08:34 --> Output Class Initialized
INFO - 2016-08-09 04:08:34 --> Security Class Initialized
DEBUG - 2016-08-09 04:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:08:34 --> Input Class Initialized
INFO - 2016-08-09 04:08:34 --> Language Class Initialized
INFO - 2016-08-09 04:08:34 --> Loader Class Initialized
INFO - 2016-08-09 04:08:34 --> Helper loaded: url_helper
INFO - 2016-08-09 04:08:34 --> Database Driver Class Initialized
INFO - 2016-08-09 04:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:08:34 --> Email Class Initialized
INFO - 2016-08-09 04:08:34 --> Model Class Initialized
INFO - 2016-08-09 04:08:34 --> Controller Class Initialized
DEBUG - 2016-08-09 04:08:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:08:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:08:34 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:08:34 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:08:34 --> Model Class Initialized
INFO - 2016-08-09 04:08:34 --> Helper loaded: date_helper
INFO - 2016-08-09 04:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:08:34 --> Final output sent to browser
DEBUG - 2016-08-09 04:08:34 --> Total execution time: 0.3418
INFO - 2016-08-09 04:09:04 --> Config Class Initialized
INFO - 2016-08-09 04:09:04 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:04 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:04 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:04 --> URI Class Initialized
INFO - 2016-08-09 04:09:04 --> Router Class Initialized
INFO - 2016-08-09 04:09:04 --> Output Class Initialized
INFO - 2016-08-09 04:09:04 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:04 --> Input Class Initialized
INFO - 2016-08-09 04:09:04 --> Language Class Initialized
INFO - 2016-08-09 04:09:04 --> Loader Class Initialized
INFO - 2016-08-09 04:09:04 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:04 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:04 --> Email Class Initialized
INFO - 2016-08-09 04:09:04 --> Model Class Initialized
INFO - 2016-08-09 04:09:04 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:04 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:04 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:04 --> Model Class Initialized
INFO - 2016-08-09 04:09:04 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:09:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:05 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:05 --> Total execution time: 0.3727
INFO - 2016-08-09 04:09:10 --> Config Class Initialized
INFO - 2016-08-09 04:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:10 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:10 --> URI Class Initialized
INFO - 2016-08-09 04:09:10 --> Router Class Initialized
INFO - 2016-08-09 04:09:10 --> Output Class Initialized
INFO - 2016-08-09 04:09:10 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:10 --> Input Class Initialized
INFO - 2016-08-09 04:09:10 --> Language Class Initialized
INFO - 2016-08-09 04:09:10 --> Loader Class Initialized
INFO - 2016-08-09 04:09:10 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:10 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:10 --> Email Class Initialized
INFO - 2016-08-09 04:09:10 --> Model Class Initialized
INFO - 2016-08-09 04:09:10 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:10 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:10 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:10 --> Model Class Initialized
INFO - 2016-08-09 04:09:10 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:09:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:10 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:10 --> Total execution time: 0.3593
INFO - 2016-08-09 04:09:26 --> Config Class Initialized
INFO - 2016-08-09 04:09:26 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:26 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:26 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:26 --> URI Class Initialized
INFO - 2016-08-09 04:09:26 --> Router Class Initialized
INFO - 2016-08-09 04:09:26 --> Output Class Initialized
INFO - 2016-08-09 04:09:26 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:26 --> Input Class Initialized
INFO - 2016-08-09 04:09:26 --> Language Class Initialized
INFO - 2016-08-09 04:09:26 --> Loader Class Initialized
INFO - 2016-08-09 04:09:26 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:26 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:26 --> Email Class Initialized
INFO - 2016-08-09 04:09:26 --> Model Class Initialized
INFO - 2016-08-09 04:09:26 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:26 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:26 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:26 --> Model Class Initialized
INFO - 2016-08-09 04:09:26 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:09:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:26 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:26 --> Total execution time: 0.3553
INFO - 2016-08-09 04:09:28 --> Config Class Initialized
INFO - 2016-08-09 04:09:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:28 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:28 --> URI Class Initialized
INFO - 2016-08-09 04:09:28 --> Router Class Initialized
INFO - 2016-08-09 04:09:28 --> Output Class Initialized
INFO - 2016-08-09 04:09:28 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:28 --> Input Class Initialized
INFO - 2016-08-09 04:09:28 --> Language Class Initialized
INFO - 2016-08-09 04:09:28 --> Loader Class Initialized
INFO - 2016-08-09 04:09:28 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:28 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:28 --> Email Class Initialized
INFO - 2016-08-09 04:09:28 --> Model Class Initialized
INFO - 2016-08-09 04:09:28 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:28 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:28 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:28 --> Model Class Initialized
INFO - 2016-08-09 04:09:28 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:09:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:29 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:29 --> Total execution time: 0.3717
INFO - 2016-08-09 04:09:31 --> Config Class Initialized
INFO - 2016-08-09 04:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:31 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:31 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:31 --> URI Class Initialized
INFO - 2016-08-09 04:09:31 --> Router Class Initialized
INFO - 2016-08-09 04:09:31 --> Output Class Initialized
INFO - 2016-08-09 04:09:31 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:31 --> Input Class Initialized
INFO - 2016-08-09 04:09:31 --> Language Class Initialized
INFO - 2016-08-09 04:09:31 --> Loader Class Initialized
INFO - 2016-08-09 04:09:31 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:31 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:31 --> Email Class Initialized
INFO - 2016-08-09 04:09:31 --> Model Class Initialized
INFO - 2016-08-09 04:09:31 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:31 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:31 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:31 --> Model Class Initialized
INFO - 2016-08-09 04:09:31 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:31 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:31 --> Total execution time: 0.3784
INFO - 2016-08-09 04:09:35 --> Config Class Initialized
INFO - 2016-08-09 04:09:35 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:35 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:35 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:35 --> URI Class Initialized
INFO - 2016-08-09 04:09:35 --> Router Class Initialized
INFO - 2016-08-09 04:09:35 --> Output Class Initialized
INFO - 2016-08-09 04:09:35 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:35 --> Input Class Initialized
INFO - 2016-08-09 04:09:35 --> Language Class Initialized
INFO - 2016-08-09 04:09:35 --> Loader Class Initialized
INFO - 2016-08-09 04:09:35 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:35 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:35 --> Email Class Initialized
INFO - 2016-08-09 04:09:35 --> Model Class Initialized
INFO - 2016-08-09 04:09:35 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:35 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:35 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:35 --> Model Class Initialized
INFO - 2016-08-09 04:09:35 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:35 --> Config Class Initialized
INFO - 2016-08-09 04:09:35 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:35 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:35 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:35 --> URI Class Initialized
INFO - 2016-08-09 04:09:35 --> Router Class Initialized
INFO - 2016-08-09 04:09:35 --> Output Class Initialized
INFO - 2016-08-09 04:09:35 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:36 --> Input Class Initialized
INFO - 2016-08-09 04:09:36 --> Language Class Initialized
INFO - 2016-08-09 04:09:36 --> Loader Class Initialized
INFO - 2016-08-09 04:09:36 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:36 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:36 --> Email Class Initialized
INFO - 2016-08-09 04:09:36 --> Model Class Initialized
INFO - 2016-08-09 04:09:36 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:36 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:36 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:36 --> Model Class Initialized
INFO - 2016-08-09 04:09:36 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:09:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:36 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:36 --> Total execution time: 0.3765
INFO - 2016-08-09 04:09:41 --> Config Class Initialized
INFO - 2016-08-09 04:09:41 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:41 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:41 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:41 --> URI Class Initialized
INFO - 2016-08-09 04:09:41 --> Router Class Initialized
INFO - 2016-08-09 04:09:41 --> Output Class Initialized
INFO - 2016-08-09 04:09:41 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:41 --> Input Class Initialized
INFO - 2016-08-09 04:09:41 --> Language Class Initialized
INFO - 2016-08-09 04:09:41 --> Loader Class Initialized
INFO - 2016-08-09 04:09:41 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:41 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:41 --> Email Class Initialized
INFO - 2016-08-09 04:09:41 --> Model Class Initialized
INFO - 2016-08-09 04:09:41 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:41 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:41 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:41 --> Model Class Initialized
INFO - 2016-08-09 04:09:41 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:09:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:41 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:41 --> Total execution time: 0.3647
INFO - 2016-08-09 04:09:43 --> Config Class Initialized
INFO - 2016-08-09 04:09:43 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:09:43 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:09:43 --> Utf8 Class Initialized
INFO - 2016-08-09 04:09:43 --> URI Class Initialized
INFO - 2016-08-09 04:09:43 --> Router Class Initialized
INFO - 2016-08-09 04:09:43 --> Output Class Initialized
INFO - 2016-08-09 04:09:43 --> Security Class Initialized
DEBUG - 2016-08-09 04:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:09:43 --> Input Class Initialized
INFO - 2016-08-09 04:09:43 --> Language Class Initialized
INFO - 2016-08-09 04:09:43 --> Loader Class Initialized
INFO - 2016-08-09 04:09:43 --> Helper loaded: url_helper
INFO - 2016-08-09 04:09:43 --> Database Driver Class Initialized
INFO - 2016-08-09 04:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:09:43 --> Email Class Initialized
INFO - 2016-08-09 04:09:43 --> Model Class Initialized
INFO - 2016-08-09 04:09:43 --> Controller Class Initialized
DEBUG - 2016-08-09 04:09:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:09:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:09:43 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:09:43 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:09:43 --> Model Class Initialized
INFO - 2016-08-09 04:09:43 --> Helper loaded: date_helper
INFO - 2016-08-09 04:09:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:09:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:09:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:09:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:09:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:09:43 --> Final output sent to browser
DEBUG - 2016-08-09 04:09:43 --> Total execution time: 0.3662
INFO - 2016-08-09 04:14:22 --> Config Class Initialized
INFO - 2016-08-09 04:14:22 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:14:22 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:14:22 --> Utf8 Class Initialized
INFO - 2016-08-09 04:14:22 --> URI Class Initialized
INFO - 2016-08-09 04:14:22 --> Router Class Initialized
INFO - 2016-08-09 04:14:22 --> Output Class Initialized
INFO - 2016-08-09 04:14:22 --> Security Class Initialized
DEBUG - 2016-08-09 04:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:14:22 --> Input Class Initialized
INFO - 2016-08-09 04:14:22 --> Language Class Initialized
INFO - 2016-08-09 04:14:22 --> Loader Class Initialized
INFO - 2016-08-09 04:14:22 --> Helper loaded: url_helper
INFO - 2016-08-09 04:14:22 --> Database Driver Class Initialized
INFO - 2016-08-09 04:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:14:22 --> Email Class Initialized
INFO - 2016-08-09 04:14:22 --> Model Class Initialized
INFO - 2016-08-09 04:14:22 --> Controller Class Initialized
DEBUG - 2016-08-09 04:14:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:14:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:14:22 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:14:22 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:22 --> Model Class Initialized
INFO - 2016-08-09 04:14:22 --> Helper loaded: date_helper
INFO - 2016-08-09 04:14:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:14:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:14:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:14:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:14:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:14:22 --> Final output sent to browser
DEBUG - 2016-08-09 04:14:22 --> Total execution time: 0.3739
INFO - 2016-08-09 04:14:28 --> Config Class Initialized
INFO - 2016-08-09 04:14:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:14:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:14:28 --> Utf8 Class Initialized
INFO - 2016-08-09 04:14:28 --> URI Class Initialized
INFO - 2016-08-09 04:14:28 --> Router Class Initialized
INFO - 2016-08-09 04:14:28 --> Output Class Initialized
INFO - 2016-08-09 04:14:28 --> Security Class Initialized
DEBUG - 2016-08-09 04:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:14:28 --> Input Class Initialized
INFO - 2016-08-09 04:14:28 --> Language Class Initialized
INFO - 2016-08-09 04:14:28 --> Loader Class Initialized
INFO - 2016-08-09 04:14:28 --> Helper loaded: url_helper
INFO - 2016-08-09 04:14:28 --> Database Driver Class Initialized
INFO - 2016-08-09 04:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:14:28 --> Email Class Initialized
INFO - 2016-08-09 04:14:28 --> Model Class Initialized
INFO - 2016-08-09 04:14:28 --> Controller Class Initialized
DEBUG - 2016-08-09 04:14:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:14:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:14:28 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:14:28 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:28 --> Model Class Initialized
INFO - 2016-08-09 04:14:28 --> Helper loaded: date_helper
INFO - 2016-08-09 04:14:28 --> Config Class Initialized
INFO - 2016-08-09 04:14:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:14:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:14:28 --> Utf8 Class Initialized
INFO - 2016-08-09 04:14:28 --> URI Class Initialized
INFO - 2016-08-09 04:14:28 --> Router Class Initialized
INFO - 2016-08-09 04:14:28 --> Output Class Initialized
INFO - 2016-08-09 04:14:28 --> Security Class Initialized
DEBUG - 2016-08-09 04:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:14:28 --> Input Class Initialized
INFO - 2016-08-09 04:14:28 --> Language Class Initialized
INFO - 2016-08-09 04:14:28 --> Loader Class Initialized
INFO - 2016-08-09 04:14:28 --> Helper loaded: url_helper
INFO - 2016-08-09 04:14:28 --> Database Driver Class Initialized
INFO - 2016-08-09 04:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:14:28 --> Email Class Initialized
INFO - 2016-08-09 04:14:28 --> Model Class Initialized
INFO - 2016-08-09 04:14:28 --> Controller Class Initialized
DEBUG - 2016-08-09 04:14:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:14:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:14:28 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:14:28 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:28 --> Model Class Initialized
INFO - 2016-08-09 04:14:28 --> Helper loaded: date_helper
INFO - 2016-08-09 04:14:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:14:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:14:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:14:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:14:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:14:28 --> Final output sent to browser
DEBUG - 2016-08-09 04:14:29 --> Total execution time: 0.3767
INFO - 2016-08-09 04:14:55 --> Config Class Initialized
INFO - 2016-08-09 04:14:55 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:14:55 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:14:55 --> Utf8 Class Initialized
INFO - 2016-08-09 04:14:55 --> URI Class Initialized
INFO - 2016-08-09 04:14:55 --> Router Class Initialized
INFO - 2016-08-09 04:14:55 --> Output Class Initialized
INFO - 2016-08-09 04:14:55 --> Security Class Initialized
DEBUG - 2016-08-09 04:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:14:55 --> Input Class Initialized
INFO - 2016-08-09 04:14:55 --> Language Class Initialized
INFO - 2016-08-09 04:14:55 --> Loader Class Initialized
INFO - 2016-08-09 04:14:55 --> Helper loaded: url_helper
INFO - 2016-08-09 04:14:55 --> Database Driver Class Initialized
INFO - 2016-08-09 04:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:14:55 --> Email Class Initialized
INFO - 2016-08-09 04:14:55 --> Model Class Initialized
INFO - 2016-08-09 04:14:55 --> Controller Class Initialized
DEBUG - 2016-08-09 04:14:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:14:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:14:55 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:14:55 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:14:55 --> Model Class Initialized
INFO - 2016-08-09 04:14:55 --> Helper loaded: date_helper
INFO - 2016-08-09 04:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:14:55 --> Final output sent to browser
DEBUG - 2016-08-09 04:14:55 --> Total execution time: 0.3792
INFO - 2016-08-09 04:15:11 --> Config Class Initialized
INFO - 2016-08-09 04:15:11 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:11 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:11 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:11 --> URI Class Initialized
INFO - 2016-08-09 04:15:11 --> Router Class Initialized
INFO - 2016-08-09 04:15:11 --> Output Class Initialized
INFO - 2016-08-09 04:15:11 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:12 --> Input Class Initialized
INFO - 2016-08-09 04:15:12 --> Language Class Initialized
INFO - 2016-08-09 04:15:12 --> Loader Class Initialized
INFO - 2016-08-09 04:15:12 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:12 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:12 --> Email Class Initialized
INFO - 2016-08-09 04:15:12 --> Model Class Initialized
INFO - 2016-08-09 04:15:12 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:12 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:12 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:12 --> Model Class Initialized
INFO - 2016-08-09 04:15:12 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:12 --> Config Class Initialized
INFO - 2016-08-09 04:15:12 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:12 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:12 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:12 --> URI Class Initialized
INFO - 2016-08-09 04:15:12 --> Router Class Initialized
INFO - 2016-08-09 04:15:12 --> Output Class Initialized
INFO - 2016-08-09 04:15:12 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:12 --> Input Class Initialized
INFO - 2016-08-09 04:15:12 --> Language Class Initialized
INFO - 2016-08-09 04:15:12 --> Loader Class Initialized
INFO - 2016-08-09 04:15:12 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:12 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:12 --> Email Class Initialized
INFO - 2016-08-09 04:15:12 --> Model Class Initialized
INFO - 2016-08-09 04:15:12 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:12 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:12 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:12 --> Model Class Initialized
INFO - 2016-08-09 04:15:12 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:15:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:15:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:15:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:15:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:15:12 --> Final output sent to browser
DEBUG - 2016-08-09 04:15:12 --> Total execution time: 0.3982
INFO - 2016-08-09 04:15:40 --> Config Class Initialized
INFO - 2016-08-09 04:15:40 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:40 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:40 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:40 --> URI Class Initialized
INFO - 2016-08-09 04:15:40 --> Router Class Initialized
INFO - 2016-08-09 04:15:40 --> Output Class Initialized
INFO - 2016-08-09 04:15:40 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:40 --> Input Class Initialized
INFO - 2016-08-09 04:15:40 --> Language Class Initialized
INFO - 2016-08-09 04:15:40 --> Loader Class Initialized
INFO - 2016-08-09 04:15:40 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:40 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:40 --> Email Class Initialized
INFO - 2016-08-09 04:15:41 --> Model Class Initialized
INFO - 2016-08-09 04:15:41 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:41 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:41 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:41 --> Model Class Initialized
INFO - 2016-08-09 04:15:41 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:15:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:15:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:15:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:15:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:15:41 --> Final output sent to browser
DEBUG - 2016-08-09 04:15:41 --> Total execution time: 0.3791
INFO - 2016-08-09 04:15:44 --> Config Class Initialized
INFO - 2016-08-09 04:15:44 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:44 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:44 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:44 --> URI Class Initialized
INFO - 2016-08-09 04:15:44 --> Router Class Initialized
INFO - 2016-08-09 04:15:44 --> Output Class Initialized
INFO - 2016-08-09 04:15:44 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:44 --> Input Class Initialized
INFO - 2016-08-09 04:15:44 --> Language Class Initialized
INFO - 2016-08-09 04:15:44 --> Loader Class Initialized
INFO - 2016-08-09 04:15:44 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:44 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:45 --> Email Class Initialized
INFO - 2016-08-09 04:15:45 --> Model Class Initialized
INFO - 2016-08-09 04:15:45 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:45 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:45 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:45 --> Model Class Initialized
INFO - 2016-08-09 04:15:45 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:45 --> Config Class Initialized
INFO - 2016-08-09 04:15:45 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:45 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:45 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:45 --> URI Class Initialized
INFO - 2016-08-09 04:15:45 --> Router Class Initialized
INFO - 2016-08-09 04:15:45 --> Output Class Initialized
INFO - 2016-08-09 04:15:45 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:45 --> Input Class Initialized
INFO - 2016-08-09 04:15:45 --> Language Class Initialized
INFO - 2016-08-09 04:15:45 --> Loader Class Initialized
INFO - 2016-08-09 04:15:45 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:45 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:45 --> Email Class Initialized
INFO - 2016-08-09 04:15:45 --> Model Class Initialized
INFO - 2016-08-09 04:15:45 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:45 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:45 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:45 --> Model Class Initialized
INFO - 2016-08-09 04:15:45 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:15:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:15:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:15:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:15:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:15:45 --> Final output sent to browser
DEBUG - 2016-08-09 04:15:45 --> Total execution time: 0.3880
INFO - 2016-08-09 04:15:48 --> Config Class Initialized
INFO - 2016-08-09 04:15:48 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:15:48 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:15:48 --> Utf8 Class Initialized
INFO - 2016-08-09 04:15:48 --> URI Class Initialized
INFO - 2016-08-09 04:15:48 --> Router Class Initialized
INFO - 2016-08-09 04:15:48 --> Output Class Initialized
INFO - 2016-08-09 04:15:48 --> Security Class Initialized
DEBUG - 2016-08-09 04:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:15:48 --> Input Class Initialized
INFO - 2016-08-09 04:15:48 --> Language Class Initialized
INFO - 2016-08-09 04:15:48 --> Loader Class Initialized
INFO - 2016-08-09 04:15:48 --> Helper loaded: url_helper
INFO - 2016-08-09 04:15:48 --> Database Driver Class Initialized
INFO - 2016-08-09 04:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:15:48 --> Email Class Initialized
INFO - 2016-08-09 04:15:48 --> Model Class Initialized
INFO - 2016-08-09 04:15:48 --> Controller Class Initialized
DEBUG - 2016-08-09 04:15:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:15:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:15:48 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:15:48 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:15:48 --> Model Class Initialized
INFO - 2016-08-09 04:15:48 --> Helper loaded: date_helper
INFO - 2016-08-09 04:15:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:15:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:15:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:15:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/update_linksocial.php
INFO - 2016-08-09 04:15:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:15:48 --> Final output sent to browser
DEBUG - 2016-08-09 04:15:48 --> Total execution time: 0.3983
INFO - 2016-08-09 04:16:00 --> Config Class Initialized
INFO - 2016-08-09 04:16:00 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:16:00 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:16:00 --> Utf8 Class Initialized
INFO - 2016-08-09 04:16:00 --> URI Class Initialized
INFO - 2016-08-09 04:16:00 --> Router Class Initialized
INFO - 2016-08-09 04:16:00 --> Output Class Initialized
INFO - 2016-08-09 04:16:00 --> Security Class Initialized
DEBUG - 2016-08-09 04:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:16:00 --> Input Class Initialized
INFO - 2016-08-09 04:16:00 --> Language Class Initialized
INFO - 2016-08-09 04:16:00 --> Loader Class Initialized
INFO - 2016-08-09 04:16:00 --> Helper loaded: url_helper
INFO - 2016-08-09 04:16:00 --> Database Driver Class Initialized
INFO - 2016-08-09 04:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:16:00 --> Email Class Initialized
INFO - 2016-08-09 04:16:00 --> Model Class Initialized
INFO - 2016-08-09 04:16:00 --> Controller Class Initialized
DEBUG - 2016-08-09 04:16:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:16:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:16:00 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:16:00 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:00 --> Model Class Initialized
INFO - 2016-08-09 04:16:00 --> Helper loaded: date_helper
INFO - 2016-08-09 04:16:00 --> Config Class Initialized
INFO - 2016-08-09 04:16:00 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:16:00 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:16:01 --> Utf8 Class Initialized
INFO - 2016-08-09 04:16:01 --> URI Class Initialized
INFO - 2016-08-09 04:16:01 --> Router Class Initialized
INFO - 2016-08-09 04:16:01 --> Output Class Initialized
INFO - 2016-08-09 04:16:01 --> Security Class Initialized
DEBUG - 2016-08-09 04:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:16:01 --> Input Class Initialized
INFO - 2016-08-09 04:16:01 --> Language Class Initialized
INFO - 2016-08-09 04:16:01 --> Loader Class Initialized
INFO - 2016-08-09 04:16:01 --> Helper loaded: url_helper
INFO - 2016-08-09 04:16:01 --> Database Driver Class Initialized
INFO - 2016-08-09 04:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:16:01 --> Email Class Initialized
INFO - 2016-08-09 04:16:01 --> Model Class Initialized
INFO - 2016-08-09 04:16:01 --> Controller Class Initialized
DEBUG - 2016-08-09 04:16:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:16:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:16:01 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:16:01 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:01 --> Model Class Initialized
INFO - 2016-08-09 04:16:01 --> Helper loaded: date_helper
INFO - 2016-08-09 04:16:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:16:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:16:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:16:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:16:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:16:01 --> Final output sent to browser
DEBUG - 2016-08-09 04:16:01 --> Total execution time: 0.3844
INFO - 2016-08-09 04:16:41 --> Config Class Initialized
INFO - 2016-08-09 04:16:41 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:16:41 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:16:41 --> Utf8 Class Initialized
INFO - 2016-08-09 04:16:41 --> URI Class Initialized
INFO - 2016-08-09 04:16:41 --> Router Class Initialized
INFO - 2016-08-09 04:16:41 --> Output Class Initialized
INFO - 2016-08-09 04:16:41 --> Security Class Initialized
DEBUG - 2016-08-09 04:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:16:41 --> Input Class Initialized
INFO - 2016-08-09 04:16:41 --> Language Class Initialized
INFO - 2016-08-09 04:16:41 --> Loader Class Initialized
INFO - 2016-08-09 04:16:41 --> Helper loaded: url_helper
INFO - 2016-08-09 04:16:41 --> Database Driver Class Initialized
INFO - 2016-08-09 04:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:16:41 --> Email Class Initialized
INFO - 2016-08-09 04:16:41 --> Model Class Initialized
INFO - 2016-08-09 04:16:41 --> Controller Class Initialized
DEBUG - 2016-08-09 04:16:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:16:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:16:41 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:16:41 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:16:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:41 --> Model Class Initialized
INFO - 2016-08-09 04:16:41 --> Helper loaded: date_helper
INFO - 2016-08-09 04:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-09 04:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:16:41 --> Final output sent to browser
DEBUG - 2016-08-09 04:16:41 --> Total execution time: 0.3896
INFO - 2016-08-09 04:16:45 --> Config Class Initialized
INFO - 2016-08-09 04:16:45 --> Hooks Class Initialized
DEBUG - 2016-08-09 04:16:45 --> UTF-8 Support Enabled
INFO - 2016-08-09 04:16:45 --> Utf8 Class Initialized
INFO - 2016-08-09 04:16:45 --> URI Class Initialized
INFO - 2016-08-09 04:16:45 --> Router Class Initialized
INFO - 2016-08-09 04:16:45 --> Output Class Initialized
INFO - 2016-08-09 04:16:45 --> Security Class Initialized
DEBUG - 2016-08-09 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 04:16:45 --> Input Class Initialized
INFO - 2016-08-09 04:16:45 --> Language Class Initialized
INFO - 2016-08-09 04:16:45 --> Loader Class Initialized
INFO - 2016-08-09 04:16:45 --> Helper loaded: url_helper
INFO - 2016-08-09 04:16:45 --> Database Driver Class Initialized
INFO - 2016-08-09 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 04:16:45 --> Email Class Initialized
INFO - 2016-08-09 04:16:45 --> Model Class Initialized
INFO - 2016-08-09 04:16:45 --> Controller Class Initialized
DEBUG - 2016-08-09 04:16:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 04:16:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 04:16:45 --> Helper loaded: cookie_helper
INFO - 2016-08-09 04:16:45 --> Helper loaded: language_helper
DEBUG - 2016-08-09 04:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 04:16:45 --> Model Class Initialized
INFO - 2016-08-09 04:16:45 --> Helper loaded: date_helper
INFO - 2016-08-09 04:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 04:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 04:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 04:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 04:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 04:16:45 --> Final output sent to browser
DEBUG - 2016-08-09 04:16:45 --> Total execution time: 0.3985
INFO - 2016-08-09 09:16:32 --> Config Class Initialized
INFO - 2016-08-09 09:16:32 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:16:33 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:16:33 --> Utf8 Class Initialized
INFO - 2016-08-09 09:16:33 --> URI Class Initialized
INFO - 2016-08-09 09:16:33 --> Router Class Initialized
INFO - 2016-08-09 09:16:33 --> Output Class Initialized
INFO - 2016-08-09 09:16:33 --> Security Class Initialized
DEBUG - 2016-08-09 09:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:16:33 --> Input Class Initialized
INFO - 2016-08-09 09:16:33 --> Language Class Initialized
INFO - 2016-08-09 09:16:33 --> Loader Class Initialized
INFO - 2016-08-09 09:16:33 --> Helper loaded: url_helper
INFO - 2016-08-09 09:16:33 --> Database Driver Class Initialized
INFO - 2016-08-09 09:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:16:34 --> Email Class Initialized
INFO - 2016-08-09 09:16:34 --> Model Class Initialized
INFO - 2016-08-09 09:16:34 --> Controller Class Initialized
DEBUG - 2016-08-09 09:16:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:16:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:16:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:16:34 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:16:34 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:16:34 --> Model Class Initialized
INFO - 2016-08-09 09:16:34 --> Helper loaded: date_helper
INFO - 2016-08-09 09:16:34 --> Config Class Initialized
INFO - 2016-08-09 09:16:34 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:16:34 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:16:34 --> Utf8 Class Initialized
INFO - 2016-08-09 09:16:34 --> URI Class Initialized
INFO - 2016-08-09 09:16:34 --> Router Class Initialized
INFO - 2016-08-09 09:16:34 --> Output Class Initialized
INFO - 2016-08-09 09:16:34 --> Security Class Initialized
DEBUG - 2016-08-09 09:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:16:34 --> Input Class Initialized
INFO - 2016-08-09 09:16:34 --> Language Class Initialized
INFO - 2016-08-09 09:16:35 --> Loader Class Initialized
INFO - 2016-08-09 09:16:35 --> Helper loaded: url_helper
INFO - 2016-08-09 09:16:35 --> Database Driver Class Initialized
INFO - 2016-08-09 09:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:16:35 --> Email Class Initialized
INFO - 2016-08-09 09:16:35 --> Model Class Initialized
INFO - 2016-08-09 09:16:35 --> Controller Class Initialized
DEBUG - 2016-08-09 09:16:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:16:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:16:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:16:35 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:16:35 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:16:35 --> Model Class Initialized
INFO - 2016-08-09 09:16:35 --> Helper loaded: date_helper
INFO - 2016-08-09 09:16:35 --> Helper loaded: form_helper
INFO - 2016-08-09 09:16:35 --> Form Validation Class Initialized
INFO - 2016-08-09 09:16:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 09:16:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-09 09:16:35 --> Final output sent to browser
DEBUG - 2016-08-09 09:16:35 --> Total execution time: 1.0768
INFO - 2016-08-09 09:17:49 --> Config Class Initialized
INFO - 2016-08-09 09:17:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:17:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:17:49 --> Utf8 Class Initialized
INFO - 2016-08-09 09:17:49 --> URI Class Initialized
INFO - 2016-08-09 09:17:49 --> Router Class Initialized
INFO - 2016-08-09 09:17:49 --> Output Class Initialized
INFO - 2016-08-09 09:17:49 --> Security Class Initialized
DEBUG - 2016-08-09 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:17:49 --> Input Class Initialized
INFO - 2016-08-09 09:17:49 --> Language Class Initialized
INFO - 2016-08-09 09:17:49 --> Loader Class Initialized
INFO - 2016-08-09 09:17:49 --> Helper loaded: url_helper
INFO - 2016-08-09 09:17:49 --> Database Driver Class Initialized
INFO - 2016-08-09 09:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:17:49 --> Email Class Initialized
INFO - 2016-08-09 09:17:49 --> Model Class Initialized
INFO - 2016-08-09 09:17:49 --> Controller Class Initialized
DEBUG - 2016-08-09 09:17:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:17:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:17:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:17:49 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:17:49 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:17:49 --> Model Class Initialized
INFO - 2016-08-09 09:17:49 --> Helper loaded: date_helper
INFO - 2016-08-09 09:17:49 --> Helper loaded: form_helper
INFO - 2016-08-09 09:17:49 --> Form Validation Class Initialized
INFO - 2016-08-09 09:17:49 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 09:17:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-09 09:17:50 --> Config Class Initialized
INFO - 2016-08-09 09:17:50 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:17:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:17:50 --> Utf8 Class Initialized
INFO - 2016-08-09 09:17:50 --> URI Class Initialized
INFO - 2016-08-09 09:17:50 --> Router Class Initialized
INFO - 2016-08-09 09:17:50 --> Output Class Initialized
INFO - 2016-08-09 09:17:50 --> Security Class Initialized
DEBUG - 2016-08-09 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:17:50 --> Input Class Initialized
INFO - 2016-08-09 09:17:50 --> Language Class Initialized
INFO - 2016-08-09 09:17:50 --> Loader Class Initialized
INFO - 2016-08-09 09:17:50 --> Helper loaded: url_helper
INFO - 2016-08-09 09:17:50 --> Database Driver Class Initialized
INFO - 2016-08-09 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:17:50 --> Email Class Initialized
INFO - 2016-08-09 09:17:50 --> Model Class Initialized
INFO - 2016-08-09 09:17:50 --> Controller Class Initialized
DEBUG - 2016-08-09 09:17:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:17:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:17:50 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:17:50 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:17:50 --> Model Class Initialized
INFO - 2016-08-09 09:17:50 --> Helper loaded: date_helper
INFO - 2016-08-09 09:17:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:17:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:17:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:17:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 09:17:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:17:51 --> Final output sent to browser
DEBUG - 2016-08-09 09:17:51 --> Total execution time: 0.4590
INFO - 2016-08-09 09:18:56 --> Config Class Initialized
INFO - 2016-08-09 09:18:56 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:18:56 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:18:56 --> Utf8 Class Initialized
INFO - 2016-08-09 09:18:56 --> URI Class Initialized
INFO - 2016-08-09 09:18:56 --> Router Class Initialized
INFO - 2016-08-09 09:18:56 --> Output Class Initialized
INFO - 2016-08-09 09:18:56 --> Security Class Initialized
DEBUG - 2016-08-09 09:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:18:56 --> Input Class Initialized
INFO - 2016-08-09 09:18:56 --> Language Class Initialized
INFO - 2016-08-09 09:18:56 --> Loader Class Initialized
INFO - 2016-08-09 09:18:56 --> Helper loaded: url_helper
INFO - 2016-08-09 09:18:56 --> Database Driver Class Initialized
INFO - 2016-08-09 09:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:18:56 --> Email Class Initialized
INFO - 2016-08-09 09:18:56 --> Model Class Initialized
INFO - 2016-08-09 09:18:56 --> Controller Class Initialized
DEBUG - 2016-08-09 09:18:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:18:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:18:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:18:56 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:18:56 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:18:56 --> Model Class Initialized
INFO - 2016-08-09 09:18:56 --> Helper loaded: date_helper
INFO - 2016-08-09 09:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 09:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:18:56 --> Final output sent to browser
DEBUG - 2016-08-09 09:18:56 --> Total execution time: 0.3819
INFO - 2016-08-09 09:19:06 --> Config Class Initialized
INFO - 2016-08-09 09:19:06 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:19:06 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:19:06 --> Utf8 Class Initialized
INFO - 2016-08-09 09:19:06 --> URI Class Initialized
INFO - 2016-08-09 09:19:06 --> Router Class Initialized
INFO - 2016-08-09 09:19:06 --> Output Class Initialized
INFO - 2016-08-09 09:19:06 --> Security Class Initialized
DEBUG - 2016-08-09 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:19:06 --> Input Class Initialized
INFO - 2016-08-09 09:19:06 --> Language Class Initialized
INFO - 2016-08-09 09:19:06 --> Loader Class Initialized
INFO - 2016-08-09 09:19:06 --> Helper loaded: url_helper
INFO - 2016-08-09 09:19:06 --> Database Driver Class Initialized
INFO - 2016-08-09 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:19:06 --> Email Class Initialized
INFO - 2016-08-09 09:19:06 --> Model Class Initialized
INFO - 2016-08-09 09:19:06 --> Controller Class Initialized
DEBUG - 2016-08-09 09:19:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:19:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:19:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:19:06 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:19:06 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:19:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:19:06 --> Model Class Initialized
INFO - 2016-08-09 09:19:06 --> Helper loaded: date_helper
INFO - 2016-08-09 09:19:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:19:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:19:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:19:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 09:19:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:19:06 --> Final output sent to browser
DEBUG - 2016-08-09 09:19:06 --> Total execution time: 0.3926
INFO - 2016-08-09 09:26:44 --> Config Class Initialized
INFO - 2016-08-09 09:26:44 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:26:44 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:26:44 --> Utf8 Class Initialized
INFO - 2016-08-09 09:26:44 --> URI Class Initialized
INFO - 2016-08-09 09:26:44 --> Router Class Initialized
INFO - 2016-08-09 09:26:44 --> Output Class Initialized
INFO - 2016-08-09 09:26:44 --> Security Class Initialized
DEBUG - 2016-08-09 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:26:44 --> Input Class Initialized
INFO - 2016-08-09 09:26:44 --> Language Class Initialized
INFO - 2016-08-09 09:26:44 --> Loader Class Initialized
INFO - 2016-08-09 09:26:44 --> Helper loaded: url_helper
INFO - 2016-08-09 09:26:44 --> Database Driver Class Initialized
INFO - 2016-08-09 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:26:44 --> Email Class Initialized
INFO - 2016-08-09 09:26:44 --> Model Class Initialized
INFO - 2016-08-09 09:26:44 --> Controller Class Initialized
DEBUG - 2016-08-09 09:26:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:26:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:26:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:26:44 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:26:44 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:26:44 --> Model Class Initialized
INFO - 2016-08-09 09:26:44 --> Helper loaded: date_helper
INFO - 2016-08-09 09:26:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:26:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:26:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 09:26:45 --> Severity: Notice --> Undefined variable: linksocial D:\xampp\htdocs\aqiqahsehati\application\views\admin\identitas\view_identitas.php 26
ERROR - 2016-08-09 09:26:45 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\identitas\view_identitas.php 26
INFO - 2016-08-09 09:28:00 --> Config Class Initialized
INFO - 2016-08-09 09:28:00 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:28:00 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:28:00 --> Utf8 Class Initialized
INFO - 2016-08-09 09:28:00 --> URI Class Initialized
INFO - 2016-08-09 09:28:00 --> Router Class Initialized
INFO - 2016-08-09 09:28:00 --> Output Class Initialized
INFO - 2016-08-09 09:28:00 --> Security Class Initialized
DEBUG - 2016-08-09 09:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:28:00 --> Input Class Initialized
INFO - 2016-08-09 09:28:00 --> Language Class Initialized
INFO - 2016-08-09 09:28:00 --> Loader Class Initialized
INFO - 2016-08-09 09:28:00 --> Helper loaded: url_helper
INFO - 2016-08-09 09:28:00 --> Database Driver Class Initialized
INFO - 2016-08-09 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:28:00 --> Email Class Initialized
INFO - 2016-08-09 09:28:00 --> Model Class Initialized
INFO - 2016-08-09 09:28:00 --> Controller Class Initialized
DEBUG - 2016-08-09 09:28:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:28:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:28:00 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:28:00 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:00 --> Model Class Initialized
INFO - 2016-08-09 09:28:00 --> Helper loaded: date_helper
INFO - 2016-08-09 09:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 09:28:00 --> Severity: Notice --> Undefined property: stdClass::$keterangan D:\xampp\htdocs\aqiqahsehati\application\views\admin\identitas\view_identitas.php 31
INFO - 2016-08-09 09:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:28:00 --> Final output sent to browser
DEBUG - 2016-08-09 09:28:00 --> Total execution time: 0.4059
INFO - 2016-08-09 09:28:28 --> Config Class Initialized
INFO - 2016-08-09 09:28:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:28:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:28:28 --> Utf8 Class Initialized
INFO - 2016-08-09 09:28:28 --> URI Class Initialized
INFO - 2016-08-09 09:28:28 --> Router Class Initialized
INFO - 2016-08-09 09:28:28 --> Output Class Initialized
INFO - 2016-08-09 09:28:28 --> Security Class Initialized
DEBUG - 2016-08-09 09:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:28:28 --> Input Class Initialized
INFO - 2016-08-09 09:28:28 --> Language Class Initialized
INFO - 2016-08-09 09:28:28 --> Loader Class Initialized
INFO - 2016-08-09 09:28:28 --> Helper loaded: url_helper
INFO - 2016-08-09 09:28:28 --> Database Driver Class Initialized
INFO - 2016-08-09 09:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:28:28 --> Email Class Initialized
INFO - 2016-08-09 09:28:28 --> Model Class Initialized
INFO - 2016-08-09 09:28:28 --> Controller Class Initialized
DEBUG - 2016-08-09 09:28:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:28:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:28:28 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:28:28 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:28 --> Model Class Initialized
INFO - 2016-08-09 09:28:28 --> Helper loaded: date_helper
INFO - 2016-08-09 09:28:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:28:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:28:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:28:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:28:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:28:28 --> Final output sent to browser
DEBUG - 2016-08-09 09:28:28 --> Total execution time: 0.6195
INFO - 2016-08-09 09:28:47 --> Config Class Initialized
INFO - 2016-08-09 09:28:47 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:28:47 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:28:47 --> Utf8 Class Initialized
INFO - 2016-08-09 09:28:47 --> URI Class Initialized
INFO - 2016-08-09 09:28:47 --> Router Class Initialized
INFO - 2016-08-09 09:28:47 --> Output Class Initialized
INFO - 2016-08-09 09:28:47 --> Security Class Initialized
DEBUG - 2016-08-09 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:28:47 --> Input Class Initialized
INFO - 2016-08-09 09:28:47 --> Language Class Initialized
INFO - 2016-08-09 09:28:47 --> Loader Class Initialized
INFO - 2016-08-09 09:28:47 --> Helper loaded: url_helper
INFO - 2016-08-09 09:28:47 --> Database Driver Class Initialized
INFO - 2016-08-09 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:28:47 --> Email Class Initialized
INFO - 2016-08-09 09:28:47 --> Model Class Initialized
INFO - 2016-08-09 09:28:47 --> Controller Class Initialized
DEBUG - 2016-08-09 09:28:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:28:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:28:47 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:28:47 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:28:47 --> Model Class Initialized
INFO - 2016-08-09 09:28:47 --> Helper loaded: date_helper
INFO - 2016-08-09 09:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:28:47 --> Final output sent to browser
DEBUG - 2016-08-09 09:28:47 --> Total execution time: 0.4102
INFO - 2016-08-09 09:29:12 --> Config Class Initialized
INFO - 2016-08-09 09:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:29:12 --> Utf8 Class Initialized
INFO - 2016-08-09 09:29:12 --> URI Class Initialized
INFO - 2016-08-09 09:29:12 --> Router Class Initialized
INFO - 2016-08-09 09:29:12 --> Output Class Initialized
INFO - 2016-08-09 09:29:12 --> Security Class Initialized
DEBUG - 2016-08-09 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:29:12 --> Input Class Initialized
INFO - 2016-08-09 09:29:12 --> Language Class Initialized
INFO - 2016-08-09 09:29:12 --> Loader Class Initialized
INFO - 2016-08-09 09:29:12 --> Helper loaded: url_helper
INFO - 2016-08-09 09:29:12 --> Database Driver Class Initialized
INFO - 2016-08-09 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:29:12 --> Email Class Initialized
INFO - 2016-08-09 09:29:12 --> Model Class Initialized
INFO - 2016-08-09 09:29:12 --> Controller Class Initialized
DEBUG - 2016-08-09 09:29:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:29:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:29:12 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:29:12 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:29:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:12 --> Model Class Initialized
INFO - 2016-08-09 09:29:12 --> Helper loaded: date_helper
INFO - 2016-08-09 09:29:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:29:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:29:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:29:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:29:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:29:12 --> Final output sent to browser
DEBUG - 2016-08-09 09:29:12 --> Total execution time: 0.6218
INFO - 2016-08-09 09:29:19 --> Config Class Initialized
INFO - 2016-08-09 09:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:29:19 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:29:19 --> Utf8 Class Initialized
INFO - 2016-08-09 09:29:19 --> URI Class Initialized
INFO - 2016-08-09 09:29:19 --> Router Class Initialized
INFO - 2016-08-09 09:29:19 --> Output Class Initialized
INFO - 2016-08-09 09:29:19 --> Security Class Initialized
DEBUG - 2016-08-09 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:29:19 --> Input Class Initialized
INFO - 2016-08-09 09:29:19 --> Language Class Initialized
INFO - 2016-08-09 09:29:19 --> Loader Class Initialized
INFO - 2016-08-09 09:29:19 --> Helper loaded: url_helper
INFO - 2016-08-09 09:29:19 --> Database Driver Class Initialized
INFO - 2016-08-09 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:29:19 --> Email Class Initialized
INFO - 2016-08-09 09:29:19 --> Model Class Initialized
INFO - 2016-08-09 09:29:19 --> Controller Class Initialized
DEBUG - 2016-08-09 09:29:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:29:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:29:19 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:29:19 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:19 --> Model Class Initialized
INFO - 2016-08-09 09:29:19 --> Helper loaded: date_helper
INFO - 2016-08-09 09:29:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:29:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:29:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:29:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:29:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:29:19 --> Final output sent to browser
DEBUG - 2016-08-09 09:29:19 --> Total execution time: 0.4408
INFO - 2016-08-09 09:29:29 --> Config Class Initialized
INFO - 2016-08-09 09:29:29 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:29:29 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:29:29 --> Utf8 Class Initialized
INFO - 2016-08-09 09:29:29 --> URI Class Initialized
INFO - 2016-08-09 09:29:29 --> Router Class Initialized
INFO - 2016-08-09 09:29:29 --> Output Class Initialized
INFO - 2016-08-09 09:29:29 --> Security Class Initialized
DEBUG - 2016-08-09 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:29:29 --> Input Class Initialized
INFO - 2016-08-09 09:29:29 --> Language Class Initialized
INFO - 2016-08-09 09:29:29 --> Loader Class Initialized
INFO - 2016-08-09 09:29:29 --> Helper loaded: url_helper
INFO - 2016-08-09 09:29:29 --> Database Driver Class Initialized
INFO - 2016-08-09 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:29:29 --> Email Class Initialized
INFO - 2016-08-09 09:29:29 --> Model Class Initialized
INFO - 2016-08-09 09:29:29 --> Controller Class Initialized
DEBUG - 2016-08-09 09:29:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:29:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:29:29 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:29:29 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:29:29 --> Model Class Initialized
INFO - 2016-08-09 09:29:29 --> Helper loaded: date_helper
INFO - 2016-08-09 09:29:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:29:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:29:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:29:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:29:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:29:29 --> Final output sent to browser
DEBUG - 2016-08-09 09:29:29 --> Total execution time: 0.4021
INFO - 2016-08-09 09:36:16 --> Config Class Initialized
INFO - 2016-08-09 09:36:16 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:36:16 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:36:16 --> Utf8 Class Initialized
INFO - 2016-08-09 09:36:16 --> URI Class Initialized
INFO - 2016-08-09 09:36:16 --> Router Class Initialized
INFO - 2016-08-09 09:36:16 --> Output Class Initialized
INFO - 2016-08-09 09:36:16 --> Security Class Initialized
DEBUG - 2016-08-09 09:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:36:16 --> Input Class Initialized
INFO - 2016-08-09 09:36:16 --> Language Class Initialized
INFO - 2016-08-09 09:36:16 --> Loader Class Initialized
INFO - 2016-08-09 09:36:16 --> Helper loaded: url_helper
INFO - 2016-08-09 09:36:16 --> Database Driver Class Initialized
INFO - 2016-08-09 09:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:36:16 --> Email Class Initialized
INFO - 2016-08-09 09:36:16 --> Model Class Initialized
INFO - 2016-08-09 09:36:16 --> Controller Class Initialized
DEBUG - 2016-08-09 09:36:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:36:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:36:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:36:16 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:36:16 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:36:16 --> Model Class Initialized
INFO - 2016-08-09 09:36:16 --> Helper loaded: date_helper
INFO - 2016-08-09 09:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:36:16 --> Final output sent to browser
DEBUG - 2016-08-09 09:36:16 --> Total execution time: 0.4344
INFO - 2016-08-09 09:36:45 --> Config Class Initialized
INFO - 2016-08-09 09:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:36:45 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:36:45 --> Utf8 Class Initialized
INFO - 2016-08-09 09:36:45 --> URI Class Initialized
INFO - 2016-08-09 09:36:45 --> Router Class Initialized
INFO - 2016-08-09 09:36:45 --> Output Class Initialized
INFO - 2016-08-09 09:36:45 --> Security Class Initialized
DEBUG - 2016-08-09 09:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:36:45 --> Input Class Initialized
INFO - 2016-08-09 09:36:45 --> Language Class Initialized
INFO - 2016-08-09 09:36:46 --> Loader Class Initialized
INFO - 2016-08-09 09:36:46 --> Helper loaded: url_helper
INFO - 2016-08-09 09:36:46 --> Database Driver Class Initialized
INFO - 2016-08-09 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:36:46 --> Email Class Initialized
INFO - 2016-08-09 09:36:46 --> Model Class Initialized
INFO - 2016-08-09 09:36:46 --> Controller Class Initialized
DEBUG - 2016-08-09 09:36:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:36:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:36:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:36:46 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:36:46 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:36:46 --> Model Class Initialized
INFO - 2016-08-09 09:36:46 --> Helper loaded: date_helper
INFO - 2016-08-09 09:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:36:46 --> Final output sent to browser
DEBUG - 2016-08-09 09:36:46 --> Total execution time: 0.4113
INFO - 2016-08-09 09:37:11 --> Config Class Initialized
INFO - 2016-08-09 09:37:11 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:37:11 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:37:11 --> Utf8 Class Initialized
INFO - 2016-08-09 09:37:11 --> URI Class Initialized
INFO - 2016-08-09 09:37:11 --> Router Class Initialized
INFO - 2016-08-09 09:37:11 --> Output Class Initialized
INFO - 2016-08-09 09:37:11 --> Security Class Initialized
DEBUG - 2016-08-09 09:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:37:11 --> Input Class Initialized
INFO - 2016-08-09 09:37:11 --> Language Class Initialized
INFO - 2016-08-09 09:37:11 --> Loader Class Initialized
INFO - 2016-08-09 09:37:11 --> Helper loaded: url_helper
INFO - 2016-08-09 09:37:11 --> Database Driver Class Initialized
INFO - 2016-08-09 09:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:37:11 --> Email Class Initialized
INFO - 2016-08-09 09:37:11 --> Model Class Initialized
INFO - 2016-08-09 09:37:11 --> Controller Class Initialized
DEBUG - 2016-08-09 09:37:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:37:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:37:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:37:11 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:37:11 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:37:11 --> Model Class Initialized
INFO - 2016-08-09 09:37:11 --> Helper loaded: date_helper
INFO - 2016-08-09 09:37:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:37:12 --> Final output sent to browser
DEBUG - 2016-08-09 09:37:12 --> Total execution time: 0.4745
INFO - 2016-08-09 09:37:40 --> Config Class Initialized
INFO - 2016-08-09 09:37:40 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:37:40 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:37:40 --> Utf8 Class Initialized
INFO - 2016-08-09 09:37:40 --> URI Class Initialized
INFO - 2016-08-09 09:37:40 --> Router Class Initialized
INFO - 2016-08-09 09:37:40 --> Output Class Initialized
INFO - 2016-08-09 09:37:40 --> Security Class Initialized
DEBUG - 2016-08-09 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:37:40 --> Input Class Initialized
INFO - 2016-08-09 09:37:40 --> Language Class Initialized
INFO - 2016-08-09 09:37:40 --> Loader Class Initialized
INFO - 2016-08-09 09:37:40 --> Helper loaded: url_helper
INFO - 2016-08-09 09:37:40 --> Database Driver Class Initialized
INFO - 2016-08-09 09:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:37:40 --> Email Class Initialized
INFO - 2016-08-09 09:37:40 --> Model Class Initialized
INFO - 2016-08-09 09:37:40 --> Controller Class Initialized
DEBUG - 2016-08-09 09:37:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:37:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:37:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:37:40 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:37:40 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:37:40 --> Model Class Initialized
INFO - 2016-08-09 09:37:40 --> Helper loaded: date_helper
INFO - 2016-08-09 09:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:37:40 --> Final output sent to browser
DEBUG - 2016-08-09 09:37:40 --> Total execution time: 0.5837
INFO - 2016-08-09 09:38:32 --> Config Class Initialized
INFO - 2016-08-09 09:38:32 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:38:32 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:38:32 --> Utf8 Class Initialized
INFO - 2016-08-09 09:38:32 --> URI Class Initialized
INFO - 2016-08-09 09:38:32 --> Router Class Initialized
INFO - 2016-08-09 09:38:32 --> Output Class Initialized
INFO - 2016-08-09 09:38:32 --> Security Class Initialized
DEBUG - 2016-08-09 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:38:32 --> Input Class Initialized
INFO - 2016-08-09 09:38:32 --> Language Class Initialized
INFO - 2016-08-09 09:38:32 --> Loader Class Initialized
INFO - 2016-08-09 09:38:32 --> Helper loaded: url_helper
INFO - 2016-08-09 09:38:32 --> Database Driver Class Initialized
INFO - 2016-08-09 09:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:38:32 --> Email Class Initialized
INFO - 2016-08-09 09:38:32 --> Model Class Initialized
INFO - 2016-08-09 09:38:32 --> Controller Class Initialized
DEBUG - 2016-08-09 09:38:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:38:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:38:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:38:32 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:38:32 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:38:32 --> Model Class Initialized
INFO - 2016-08-09 09:38:32 --> Helper loaded: date_helper
INFO - 2016-08-09 09:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:38:32 --> Final output sent to browser
DEBUG - 2016-08-09 09:38:32 --> Total execution time: 0.4844
INFO - 2016-08-09 09:39:04 --> Config Class Initialized
INFO - 2016-08-09 09:39:04 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:39:04 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:39:04 --> Utf8 Class Initialized
INFO - 2016-08-09 09:39:04 --> URI Class Initialized
INFO - 2016-08-09 09:39:04 --> Router Class Initialized
INFO - 2016-08-09 09:39:04 --> Output Class Initialized
INFO - 2016-08-09 09:39:04 --> Security Class Initialized
DEBUG - 2016-08-09 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:39:04 --> Input Class Initialized
INFO - 2016-08-09 09:39:04 --> Language Class Initialized
INFO - 2016-08-09 09:39:04 --> Loader Class Initialized
INFO - 2016-08-09 09:39:04 --> Helper loaded: url_helper
INFO - 2016-08-09 09:39:04 --> Database Driver Class Initialized
INFO - 2016-08-09 09:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:39:04 --> Email Class Initialized
INFO - 2016-08-09 09:39:04 --> Model Class Initialized
INFO - 2016-08-09 09:39:04 --> Controller Class Initialized
DEBUG - 2016-08-09 09:39:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:39:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:39:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:39:04 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:39:04 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:39:04 --> Model Class Initialized
INFO - 2016-08-09 09:39:04 --> Helper loaded: date_helper
INFO - 2016-08-09 09:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:39:04 --> Final output sent to browser
DEBUG - 2016-08-09 09:39:05 --> Total execution time: 0.4200
INFO - 2016-08-09 09:40:57 --> Config Class Initialized
INFO - 2016-08-09 09:40:57 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:40:57 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:40:57 --> Utf8 Class Initialized
INFO - 2016-08-09 09:40:57 --> URI Class Initialized
INFO - 2016-08-09 09:40:57 --> Router Class Initialized
INFO - 2016-08-09 09:40:57 --> Output Class Initialized
INFO - 2016-08-09 09:40:57 --> Security Class Initialized
DEBUG - 2016-08-09 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:40:57 --> Input Class Initialized
INFO - 2016-08-09 09:40:57 --> Language Class Initialized
INFO - 2016-08-09 09:40:57 --> Loader Class Initialized
INFO - 2016-08-09 09:40:57 --> Helper loaded: url_helper
INFO - 2016-08-09 09:40:57 --> Database Driver Class Initialized
INFO - 2016-08-09 09:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:40:57 --> Email Class Initialized
INFO - 2016-08-09 09:40:57 --> Model Class Initialized
INFO - 2016-08-09 09:40:57 --> Controller Class Initialized
DEBUG - 2016-08-09 09:40:57 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:40:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:40:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:40:57 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:40:57 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:40:57 --> Model Class Initialized
INFO - 2016-08-09 09:40:57 --> Helper loaded: date_helper
INFO - 2016-08-09 09:40:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:40:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:40:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:40:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:40:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:40:57 --> Final output sent to browser
DEBUG - 2016-08-09 09:40:57 --> Total execution time: 0.4173
INFO - 2016-08-09 09:42:29 --> Config Class Initialized
INFO - 2016-08-09 09:42:29 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:42:29 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:42:29 --> Utf8 Class Initialized
INFO - 2016-08-09 09:42:29 --> URI Class Initialized
INFO - 2016-08-09 09:42:29 --> Router Class Initialized
INFO - 2016-08-09 09:42:29 --> Output Class Initialized
INFO - 2016-08-09 09:42:29 --> Security Class Initialized
DEBUG - 2016-08-09 09:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:42:29 --> Input Class Initialized
INFO - 2016-08-09 09:42:29 --> Language Class Initialized
INFO - 2016-08-09 09:42:29 --> Loader Class Initialized
INFO - 2016-08-09 09:42:29 --> Helper loaded: url_helper
INFO - 2016-08-09 09:42:29 --> Database Driver Class Initialized
INFO - 2016-08-09 09:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:42:29 --> Email Class Initialized
INFO - 2016-08-09 09:42:29 --> Model Class Initialized
INFO - 2016-08-09 09:42:29 --> Controller Class Initialized
DEBUG - 2016-08-09 09:42:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:42:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:42:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:42:29 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:42:29 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:42:29 --> Model Class Initialized
INFO - 2016-08-09 09:42:29 --> Helper loaded: date_helper
INFO - 2016-08-09 09:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:42:29 --> Final output sent to browser
DEBUG - 2016-08-09 09:42:29 --> Total execution time: 0.4192
INFO - 2016-08-09 09:42:54 --> Config Class Initialized
INFO - 2016-08-09 09:42:54 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:42:54 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:42:54 --> Utf8 Class Initialized
INFO - 2016-08-09 09:42:54 --> URI Class Initialized
INFO - 2016-08-09 09:42:54 --> Router Class Initialized
INFO - 2016-08-09 09:42:54 --> Output Class Initialized
INFO - 2016-08-09 09:42:54 --> Security Class Initialized
DEBUG - 2016-08-09 09:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:42:54 --> Input Class Initialized
INFO - 2016-08-09 09:42:54 --> Language Class Initialized
INFO - 2016-08-09 09:42:54 --> Loader Class Initialized
INFO - 2016-08-09 09:42:54 --> Helper loaded: url_helper
INFO - 2016-08-09 09:42:54 --> Database Driver Class Initialized
INFO - 2016-08-09 09:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:42:54 --> Email Class Initialized
INFO - 2016-08-09 09:42:54 --> Model Class Initialized
INFO - 2016-08-09 09:42:54 --> Controller Class Initialized
DEBUG - 2016-08-09 09:42:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:42:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:42:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:42:54 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:42:54 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:42:54 --> Model Class Initialized
INFO - 2016-08-09 09:42:54 --> Helper loaded: date_helper
INFO - 2016-08-09 09:42:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:42:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:42:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:42:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:42:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:42:54 --> Final output sent to browser
DEBUG - 2016-08-09 09:42:55 --> Total execution time: 0.4436
INFO - 2016-08-09 09:43:12 --> Config Class Initialized
INFO - 2016-08-09 09:43:12 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:43:12 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:43:12 --> Utf8 Class Initialized
INFO - 2016-08-09 09:43:12 --> URI Class Initialized
INFO - 2016-08-09 09:43:12 --> Router Class Initialized
INFO - 2016-08-09 09:43:12 --> Output Class Initialized
INFO - 2016-08-09 09:43:12 --> Security Class Initialized
DEBUG - 2016-08-09 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:43:12 --> Input Class Initialized
INFO - 2016-08-09 09:43:12 --> Language Class Initialized
INFO - 2016-08-09 09:43:12 --> Loader Class Initialized
INFO - 2016-08-09 09:43:12 --> Helper loaded: url_helper
INFO - 2016-08-09 09:43:13 --> Database Driver Class Initialized
INFO - 2016-08-09 09:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:43:13 --> Email Class Initialized
INFO - 2016-08-09 09:43:13 --> Model Class Initialized
INFO - 2016-08-09 09:43:13 --> Controller Class Initialized
DEBUG - 2016-08-09 09:43:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:43:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:43:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:43:13 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:43:13 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:43:13 --> Model Class Initialized
INFO - 2016-08-09 09:43:13 --> Helper loaded: date_helper
INFO - 2016-08-09 09:43:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:43:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:43:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:43:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:43:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:43:13 --> Final output sent to browser
DEBUG - 2016-08-09 09:43:13 --> Total execution time: 0.6220
INFO - 2016-08-09 09:44:01 --> Config Class Initialized
INFO - 2016-08-09 09:44:01 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:44:01 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:44:01 --> Utf8 Class Initialized
INFO - 2016-08-09 09:44:01 --> URI Class Initialized
INFO - 2016-08-09 09:44:01 --> Router Class Initialized
INFO - 2016-08-09 09:44:01 --> Output Class Initialized
INFO - 2016-08-09 09:44:01 --> Security Class Initialized
DEBUG - 2016-08-09 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:44:01 --> Input Class Initialized
INFO - 2016-08-09 09:44:01 --> Language Class Initialized
INFO - 2016-08-09 09:44:01 --> Loader Class Initialized
INFO - 2016-08-09 09:44:01 --> Helper loaded: url_helper
INFO - 2016-08-09 09:44:01 --> Database Driver Class Initialized
INFO - 2016-08-09 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:44:01 --> Email Class Initialized
INFO - 2016-08-09 09:44:01 --> Model Class Initialized
INFO - 2016-08-09 09:44:01 --> Controller Class Initialized
DEBUG - 2016-08-09 09:44:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:44:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:44:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:44:01 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:44:01 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:44:01 --> Model Class Initialized
INFO - 2016-08-09 09:44:01 --> Helper loaded: date_helper
INFO - 2016-08-09 09:44:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:44:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:44:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:44:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:44:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:44:01 --> Final output sent to browser
DEBUG - 2016-08-09 09:44:01 --> Total execution time: 0.4262
INFO - 2016-08-09 09:46:00 --> Config Class Initialized
INFO - 2016-08-09 09:46:00 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:46:00 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:46:00 --> Utf8 Class Initialized
INFO - 2016-08-09 09:46:00 --> URI Class Initialized
INFO - 2016-08-09 09:46:00 --> Router Class Initialized
INFO - 2016-08-09 09:46:00 --> Output Class Initialized
INFO - 2016-08-09 09:46:00 --> Security Class Initialized
DEBUG - 2016-08-09 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:46:00 --> Input Class Initialized
INFO - 2016-08-09 09:46:00 --> Language Class Initialized
INFO - 2016-08-09 09:46:00 --> Loader Class Initialized
INFO - 2016-08-09 09:46:00 --> Helper loaded: url_helper
INFO - 2016-08-09 09:46:00 --> Database Driver Class Initialized
INFO - 2016-08-09 09:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:46:00 --> Email Class Initialized
INFO - 2016-08-09 09:46:00 --> Model Class Initialized
INFO - 2016-08-09 09:46:00 --> Controller Class Initialized
DEBUG - 2016-08-09 09:46:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:46:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:46:00 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:46:00 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:00 --> Model Class Initialized
INFO - 2016-08-09 09:46:00 --> Helper loaded: date_helper
INFO - 2016-08-09 09:46:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:46:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:46:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:46:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:46:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:46:01 --> Final output sent to browser
DEBUG - 2016-08-09 09:46:01 --> Total execution time: 0.5008
INFO - 2016-08-09 09:46:10 --> Config Class Initialized
INFO - 2016-08-09 09:46:10 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:46:10 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:46:10 --> Utf8 Class Initialized
INFO - 2016-08-09 09:46:10 --> URI Class Initialized
INFO - 2016-08-09 09:46:10 --> Router Class Initialized
INFO - 2016-08-09 09:46:10 --> Output Class Initialized
INFO - 2016-08-09 09:46:10 --> Security Class Initialized
DEBUG - 2016-08-09 09:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:46:10 --> Input Class Initialized
INFO - 2016-08-09 09:46:10 --> Language Class Initialized
INFO - 2016-08-09 09:46:10 --> Loader Class Initialized
INFO - 2016-08-09 09:46:10 --> Helper loaded: url_helper
INFO - 2016-08-09 09:46:10 --> Database Driver Class Initialized
INFO - 2016-08-09 09:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:46:10 --> Email Class Initialized
INFO - 2016-08-09 09:46:10 --> Model Class Initialized
INFO - 2016-08-09 09:46:10 --> Controller Class Initialized
DEBUG - 2016-08-09 09:46:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:46:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:46:10 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:46:10 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:10 --> Model Class Initialized
INFO - 2016-08-09 09:46:10 --> Helper loaded: date_helper
INFO - 2016-08-09 09:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:46:10 --> Final output sent to browser
DEBUG - 2016-08-09 09:46:10 --> Total execution time: 0.4271
INFO - 2016-08-09 09:46:25 --> Config Class Initialized
INFO - 2016-08-09 09:46:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:46:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:46:25 --> Utf8 Class Initialized
INFO - 2016-08-09 09:46:25 --> URI Class Initialized
INFO - 2016-08-09 09:46:25 --> Router Class Initialized
INFO - 2016-08-09 09:46:25 --> Output Class Initialized
INFO - 2016-08-09 09:46:25 --> Security Class Initialized
DEBUG - 2016-08-09 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:46:25 --> Input Class Initialized
INFO - 2016-08-09 09:46:25 --> Language Class Initialized
INFO - 2016-08-09 09:46:25 --> Loader Class Initialized
INFO - 2016-08-09 09:46:25 --> Helper loaded: url_helper
INFO - 2016-08-09 09:46:25 --> Database Driver Class Initialized
INFO - 2016-08-09 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:46:25 --> Email Class Initialized
INFO - 2016-08-09 09:46:25 --> Model Class Initialized
INFO - 2016-08-09 09:46:25 --> Controller Class Initialized
DEBUG - 2016-08-09 09:46:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:46:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:46:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:46:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:46:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:25 --> Model Class Initialized
INFO - 2016-08-09 09:46:25 --> Helper loaded: date_helper
INFO - 2016-08-09 09:46:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:46:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:46:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:46:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:46:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:46:25 --> Final output sent to browser
DEBUG - 2016-08-09 09:46:25 --> Total execution time: 0.4433
INFO - 2016-08-09 09:46:50 --> Config Class Initialized
INFO - 2016-08-09 09:46:50 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:46:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:46:50 --> Utf8 Class Initialized
INFO - 2016-08-09 09:46:50 --> URI Class Initialized
DEBUG - 2016-08-09 09:46:50 --> No URI present. Default controller set.
INFO - 2016-08-09 09:46:50 --> Router Class Initialized
INFO - 2016-08-09 09:46:50 --> Output Class Initialized
INFO - 2016-08-09 09:46:50 --> Security Class Initialized
DEBUG - 2016-08-09 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:46:50 --> Input Class Initialized
INFO - 2016-08-09 09:46:50 --> Language Class Initialized
INFO - 2016-08-09 09:46:50 --> Loader Class Initialized
INFO - 2016-08-09 09:46:50 --> Helper loaded: url_helper
INFO - 2016-08-09 09:46:50 --> Database Driver Class Initialized
INFO - 2016-08-09 09:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:46:50 --> Email Class Initialized
INFO - 2016-08-09 09:46:50 --> Model Class Initialized
INFO - 2016-08-09 09:46:50 --> Controller Class Initialized
DEBUG - 2016-08-09 09:46:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:46:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:46:50 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:46:50 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:46:51 --> Model Class Initialized
INFO - 2016-08-09 09:46:51 --> Helper loaded: date_helper
INFO - 2016-08-09 09:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-09 09:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-09 09:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-09 09:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-09 09:46:51 --> Final output sent to browser
DEBUG - 2016-08-09 09:46:51 --> Total execution time: 0.8250
INFO - 2016-08-09 09:52:08 --> Config Class Initialized
INFO - 2016-08-09 09:52:08 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:52:08 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:52:08 --> Utf8 Class Initialized
INFO - 2016-08-09 09:52:08 --> URI Class Initialized
INFO - 2016-08-09 09:52:08 --> Router Class Initialized
INFO - 2016-08-09 09:52:08 --> Output Class Initialized
INFO - 2016-08-09 09:52:08 --> Security Class Initialized
DEBUG - 2016-08-09 09:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:52:08 --> Input Class Initialized
INFO - 2016-08-09 09:52:08 --> Language Class Initialized
INFO - 2016-08-09 09:52:08 --> Loader Class Initialized
INFO - 2016-08-09 09:52:08 --> Helper loaded: url_helper
INFO - 2016-08-09 09:52:08 --> Database Driver Class Initialized
INFO - 2016-08-09 09:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:52:08 --> Email Class Initialized
INFO - 2016-08-09 09:52:08 --> Model Class Initialized
INFO - 2016-08-09 09:52:08 --> Controller Class Initialized
DEBUG - 2016-08-09 09:52:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:52:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:52:08 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:52:08 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:08 --> Model Class Initialized
INFO - 2016-08-09 09:52:08 --> Helper loaded: date_helper
INFO - 2016-08-09 09:52:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:52:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:52:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:52:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:52:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:52:08 --> Final output sent to browser
DEBUG - 2016-08-09 09:52:08 --> Total execution time: 0.5021
INFO - 2016-08-09 09:52:23 --> Config Class Initialized
INFO - 2016-08-09 09:52:23 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:52:23 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:52:23 --> Utf8 Class Initialized
INFO - 2016-08-09 09:52:23 --> URI Class Initialized
INFO - 2016-08-09 09:52:23 --> Router Class Initialized
INFO - 2016-08-09 09:52:23 --> Output Class Initialized
INFO - 2016-08-09 09:52:23 --> Security Class Initialized
DEBUG - 2016-08-09 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:52:23 --> Input Class Initialized
INFO - 2016-08-09 09:52:23 --> Language Class Initialized
INFO - 2016-08-09 09:52:23 --> Loader Class Initialized
INFO - 2016-08-09 09:52:23 --> Helper loaded: url_helper
INFO - 2016-08-09 09:52:23 --> Database Driver Class Initialized
INFO - 2016-08-09 09:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:52:23 --> Email Class Initialized
INFO - 2016-08-09 09:52:23 --> Model Class Initialized
INFO - 2016-08-09 09:52:23 --> Controller Class Initialized
DEBUG - 2016-08-09 09:52:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:52:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:52:23 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:52:23 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:23 --> Model Class Initialized
INFO - 2016-08-09 09:52:23 --> Helper loaded: date_helper
INFO - 2016-08-09 09:52:23 --> Config Class Initialized
INFO - 2016-08-09 09:52:23 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:52:24 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:52:24 --> Utf8 Class Initialized
INFO - 2016-08-09 09:52:24 --> URI Class Initialized
INFO - 2016-08-09 09:52:24 --> Router Class Initialized
INFO - 2016-08-09 09:52:24 --> Output Class Initialized
INFO - 2016-08-09 09:52:24 --> Security Class Initialized
DEBUG - 2016-08-09 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:52:24 --> Input Class Initialized
INFO - 2016-08-09 09:52:24 --> Language Class Initialized
INFO - 2016-08-09 09:52:24 --> Loader Class Initialized
INFO - 2016-08-09 09:52:24 --> Helper loaded: url_helper
INFO - 2016-08-09 09:52:24 --> Database Driver Class Initialized
INFO - 2016-08-09 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:52:24 --> Email Class Initialized
INFO - 2016-08-09 09:52:24 --> Model Class Initialized
INFO - 2016-08-09 09:52:24 --> Controller Class Initialized
DEBUG - 2016-08-09 09:52:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:52:24 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:52:24 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:52:24 --> Model Class Initialized
INFO - 2016-08-09 09:52:24 --> Helper loaded: date_helper
INFO - 2016-08-09 09:52:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:52:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:52:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:52:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:52:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:52:24 --> Final output sent to browser
DEBUG - 2016-08-09 09:52:24 --> Total execution time: 0.8442
INFO - 2016-08-09 09:53:02 --> Config Class Initialized
INFO - 2016-08-09 09:53:02 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:53:02 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:53:02 --> Utf8 Class Initialized
INFO - 2016-08-09 09:53:02 --> URI Class Initialized
INFO - 2016-08-09 09:53:02 --> Router Class Initialized
INFO - 2016-08-09 09:53:02 --> Output Class Initialized
INFO - 2016-08-09 09:53:02 --> Security Class Initialized
DEBUG - 2016-08-09 09:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:53:02 --> Input Class Initialized
INFO - 2016-08-09 09:53:02 --> Language Class Initialized
INFO - 2016-08-09 09:53:02 --> Loader Class Initialized
INFO - 2016-08-09 09:53:02 --> Helper loaded: url_helper
INFO - 2016-08-09 09:53:02 --> Database Driver Class Initialized
INFO - 2016-08-09 09:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:53:02 --> Email Class Initialized
INFO - 2016-08-09 09:53:02 --> Model Class Initialized
INFO - 2016-08-09 09:53:02 --> Controller Class Initialized
DEBUG - 2016-08-09 09:53:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:53:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:53:02 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:53:02 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:02 --> Model Class Initialized
INFO - 2016-08-09 09:53:02 --> Helper loaded: date_helper
INFO - 2016-08-09 09:53:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:53:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:53:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:53:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:53:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:53:02 --> Final output sent to browser
DEBUG - 2016-08-09 09:53:02 --> Total execution time: 0.4410
INFO - 2016-08-09 09:53:09 --> Config Class Initialized
INFO - 2016-08-09 09:53:09 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:53:09 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:53:09 --> Utf8 Class Initialized
INFO - 2016-08-09 09:53:09 --> URI Class Initialized
INFO - 2016-08-09 09:53:09 --> Router Class Initialized
INFO - 2016-08-09 09:53:09 --> Output Class Initialized
INFO - 2016-08-09 09:53:09 --> Security Class Initialized
DEBUG - 2016-08-09 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:53:09 --> Input Class Initialized
INFO - 2016-08-09 09:53:09 --> Language Class Initialized
INFO - 2016-08-09 09:53:09 --> Loader Class Initialized
INFO - 2016-08-09 09:53:09 --> Helper loaded: url_helper
INFO - 2016-08-09 09:53:09 --> Database Driver Class Initialized
INFO - 2016-08-09 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:53:09 --> Email Class Initialized
INFO - 2016-08-09 09:53:09 --> Model Class Initialized
INFO - 2016-08-09 09:53:09 --> Controller Class Initialized
DEBUG - 2016-08-09 09:53:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:53:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:53:09 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:53:09 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:09 --> Model Class Initialized
INFO - 2016-08-09 09:53:09 --> Helper loaded: date_helper
INFO - 2016-08-09 09:53:09 --> Config Class Initialized
INFO - 2016-08-09 09:53:09 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:53:09 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:53:09 --> Utf8 Class Initialized
INFO - 2016-08-09 09:53:09 --> URI Class Initialized
INFO - 2016-08-09 09:53:09 --> Router Class Initialized
INFO - 2016-08-09 09:53:09 --> Output Class Initialized
INFO - 2016-08-09 09:53:09 --> Security Class Initialized
DEBUG - 2016-08-09 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:53:09 --> Input Class Initialized
INFO - 2016-08-09 09:53:09 --> Language Class Initialized
INFO - 2016-08-09 09:53:09 --> Loader Class Initialized
INFO - 2016-08-09 09:53:09 --> Helper loaded: url_helper
INFO - 2016-08-09 09:53:09 --> Database Driver Class Initialized
INFO - 2016-08-09 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:53:10 --> Email Class Initialized
INFO - 2016-08-09 09:53:10 --> Model Class Initialized
INFO - 2016-08-09 09:53:10 --> Controller Class Initialized
DEBUG - 2016-08-09 09:53:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:53:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:53:10 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:53:10 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:10 --> Model Class Initialized
INFO - 2016-08-09 09:53:10 --> Helper loaded: date_helper
INFO - 2016-08-09 09:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:53:10 --> Final output sent to browser
DEBUG - 2016-08-09 09:53:10 --> Total execution time: 0.7983
INFO - 2016-08-09 09:53:18 --> Config Class Initialized
INFO - 2016-08-09 09:53:18 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:53:18 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:53:18 --> Utf8 Class Initialized
INFO - 2016-08-09 09:53:18 --> URI Class Initialized
INFO - 2016-08-09 09:53:18 --> Router Class Initialized
INFO - 2016-08-09 09:53:18 --> Output Class Initialized
INFO - 2016-08-09 09:53:18 --> Security Class Initialized
DEBUG - 2016-08-09 09:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:53:18 --> Input Class Initialized
INFO - 2016-08-09 09:53:18 --> Language Class Initialized
INFO - 2016-08-09 09:53:18 --> Loader Class Initialized
INFO - 2016-08-09 09:53:18 --> Helper loaded: url_helper
INFO - 2016-08-09 09:53:18 --> Database Driver Class Initialized
INFO - 2016-08-09 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:53:19 --> Email Class Initialized
INFO - 2016-08-09 09:53:19 --> Model Class Initialized
INFO - 2016-08-09 09:53:19 --> Controller Class Initialized
DEBUG - 2016-08-09 09:53:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:53:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:53:19 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:53:19 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:19 --> Model Class Initialized
INFO - 2016-08-09 09:53:19 --> Helper loaded: date_helper
INFO - 2016-08-09 09:53:19 --> Config Class Initialized
INFO - 2016-08-09 09:53:19 --> Hooks Class Initialized
DEBUG - 2016-08-09 09:53:19 --> UTF-8 Support Enabled
INFO - 2016-08-09 09:53:19 --> Utf8 Class Initialized
INFO - 2016-08-09 09:53:19 --> URI Class Initialized
INFO - 2016-08-09 09:53:19 --> Router Class Initialized
INFO - 2016-08-09 09:53:19 --> Output Class Initialized
INFO - 2016-08-09 09:53:19 --> Security Class Initialized
DEBUG - 2016-08-09 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 09:53:19 --> Input Class Initialized
INFO - 2016-08-09 09:53:19 --> Language Class Initialized
INFO - 2016-08-09 09:53:19 --> Loader Class Initialized
INFO - 2016-08-09 09:53:19 --> Helper loaded: url_helper
INFO - 2016-08-09 09:53:19 --> Database Driver Class Initialized
INFO - 2016-08-09 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 09:53:19 --> Email Class Initialized
INFO - 2016-08-09 09:53:19 --> Model Class Initialized
INFO - 2016-08-09 09:53:19 --> Controller Class Initialized
DEBUG - 2016-08-09 09:53:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 09:53:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 09:53:19 --> Helper loaded: cookie_helper
INFO - 2016-08-09 09:53:19 --> Helper loaded: language_helper
DEBUG - 2016-08-09 09:53:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 09:53:20 --> Model Class Initialized
INFO - 2016-08-09 09:53:20 --> Helper loaded: date_helper
INFO - 2016-08-09 09:53:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 09:53:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 09:53:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 09:53:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 09:53:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 09:53:20 --> Final output sent to browser
DEBUG - 2016-08-09 09:53:20 --> Total execution time: 0.8511
INFO - 2016-08-09 11:16:27 --> Config Class Initialized
INFO - 2016-08-09 11:16:27 --> Hooks Class Initialized
DEBUG - 2016-08-09 11:16:27 --> UTF-8 Support Enabled
INFO - 2016-08-09 11:16:27 --> Utf8 Class Initialized
INFO - 2016-08-09 11:16:27 --> URI Class Initialized
INFO - 2016-08-09 11:16:27 --> Router Class Initialized
INFO - 2016-08-09 11:16:27 --> Output Class Initialized
INFO - 2016-08-09 11:16:27 --> Security Class Initialized
DEBUG - 2016-08-09 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 11:16:27 --> Input Class Initialized
INFO - 2016-08-09 11:16:27 --> Language Class Initialized
INFO - 2016-08-09 11:16:27 --> Loader Class Initialized
INFO - 2016-08-09 11:16:27 --> Helper loaded: url_helper
INFO - 2016-08-09 11:16:27 --> Database Driver Class Initialized
INFO - 2016-08-09 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 11:16:27 --> Email Class Initialized
INFO - 2016-08-09 11:16:27 --> Model Class Initialized
INFO - 2016-08-09 11:16:27 --> Controller Class Initialized
DEBUG - 2016-08-09 11:16:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 11:16:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:16:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 11:16:27 --> Helper loaded: cookie_helper
INFO - 2016-08-09 11:16:27 --> Helper loaded: language_helper
DEBUG - 2016-08-09 11:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:16:27 --> Model Class Initialized
INFO - 2016-08-09 11:16:27 --> Helper loaded: date_helper
INFO - 2016-08-09 11:16:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 11:16:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 11:16:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 11:16:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 11:16:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 11:16:27 --> Final output sent to browser
DEBUG - 2016-08-09 11:16:27 --> Total execution time: 0.6140
INFO - 2016-08-09 11:17:19 --> Config Class Initialized
INFO - 2016-08-09 11:17:19 --> Hooks Class Initialized
DEBUG - 2016-08-09 11:17:19 --> UTF-8 Support Enabled
INFO - 2016-08-09 11:17:19 --> Utf8 Class Initialized
INFO - 2016-08-09 11:17:19 --> URI Class Initialized
INFO - 2016-08-09 11:17:19 --> Router Class Initialized
INFO - 2016-08-09 11:17:19 --> Output Class Initialized
INFO - 2016-08-09 11:17:19 --> Security Class Initialized
DEBUG - 2016-08-09 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 11:17:19 --> Input Class Initialized
INFO - 2016-08-09 11:17:19 --> Language Class Initialized
INFO - 2016-08-09 11:17:19 --> Loader Class Initialized
INFO - 2016-08-09 11:17:19 --> Helper loaded: url_helper
INFO - 2016-08-09 11:17:19 --> Database Driver Class Initialized
INFO - 2016-08-09 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 11:17:19 --> Email Class Initialized
INFO - 2016-08-09 11:17:19 --> Model Class Initialized
INFO - 2016-08-09 11:17:19 --> Controller Class Initialized
DEBUG - 2016-08-09 11:17:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 11:17:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 11:17:20 --> Helper loaded: cookie_helper
INFO - 2016-08-09 11:17:20 --> Helper loaded: language_helper
DEBUG - 2016-08-09 11:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:20 --> Model Class Initialized
INFO - 2016-08-09 11:17:20 --> Helper loaded: date_helper
INFO - 2016-08-09 11:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 11:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 11:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 11:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 11:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 11:17:20 --> Final output sent to browser
DEBUG - 2016-08-09 11:17:20 --> Total execution time: 0.5242
INFO - 2016-08-09 11:17:24 --> Config Class Initialized
INFO - 2016-08-09 11:17:24 --> Hooks Class Initialized
DEBUG - 2016-08-09 11:17:24 --> UTF-8 Support Enabled
INFO - 2016-08-09 11:17:24 --> Utf8 Class Initialized
INFO - 2016-08-09 11:17:24 --> URI Class Initialized
INFO - 2016-08-09 11:17:25 --> Router Class Initialized
INFO - 2016-08-09 11:17:25 --> Output Class Initialized
INFO - 2016-08-09 11:17:25 --> Security Class Initialized
DEBUG - 2016-08-09 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 11:17:25 --> Input Class Initialized
INFO - 2016-08-09 11:17:25 --> Language Class Initialized
INFO - 2016-08-09 11:17:25 --> Loader Class Initialized
INFO - 2016-08-09 11:17:25 --> Helper loaded: url_helper
INFO - 2016-08-09 11:17:25 --> Database Driver Class Initialized
INFO - 2016-08-09 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 11:17:25 --> Email Class Initialized
INFO - 2016-08-09 11:17:25 --> Model Class Initialized
INFO - 2016-08-09 11:17:25 --> Controller Class Initialized
DEBUG - 2016-08-09 11:17:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 11:17:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 11:17:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 11:17:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 11:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:25 --> Model Class Initialized
INFO - 2016-08-09 11:17:25 --> Helper loaded: date_helper
INFO - 2016-08-09 11:17:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 11:17:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 11:17:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 11:17:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 11:17:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 11:17:25 --> Final output sent to browser
DEBUG - 2016-08-09 11:17:25 --> Total execution time: 0.4684
INFO - 2016-08-09 11:17:57 --> Config Class Initialized
INFO - 2016-08-09 11:17:57 --> Hooks Class Initialized
DEBUG - 2016-08-09 11:17:57 --> UTF-8 Support Enabled
INFO - 2016-08-09 11:17:57 --> Utf8 Class Initialized
INFO - 2016-08-09 11:17:57 --> URI Class Initialized
INFO - 2016-08-09 11:17:57 --> Router Class Initialized
INFO - 2016-08-09 11:17:57 --> Output Class Initialized
INFO - 2016-08-09 11:17:57 --> Security Class Initialized
DEBUG - 2016-08-09 11:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 11:17:57 --> Input Class Initialized
INFO - 2016-08-09 11:17:57 --> Language Class Initialized
INFO - 2016-08-09 11:17:57 --> Loader Class Initialized
INFO - 2016-08-09 11:17:57 --> Helper loaded: url_helper
INFO - 2016-08-09 11:17:57 --> Database Driver Class Initialized
INFO - 2016-08-09 11:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 11:17:57 --> Email Class Initialized
INFO - 2016-08-09 11:17:57 --> Model Class Initialized
INFO - 2016-08-09 11:17:57 --> Controller Class Initialized
DEBUG - 2016-08-09 11:17:57 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 11:17:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 11:17:57 --> Helper loaded: cookie_helper
INFO - 2016-08-09 11:17:57 --> Helper loaded: language_helper
DEBUG - 2016-08-09 11:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 11:17:57 --> Model Class Initialized
INFO - 2016-08-09 11:17:57 --> Helper loaded: date_helper
INFO - 2016-08-09 11:17:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 11:17:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 11:17:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 11:17:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 11:17:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 11:17:58 --> Final output sent to browser
DEBUG - 2016-08-09 11:17:58 --> Total execution time: 0.4676
INFO - 2016-08-09 13:01:51 --> Config Class Initialized
INFO - 2016-08-09 13:01:51 --> Hooks Class Initialized
DEBUG - 2016-08-09 13:01:51 --> UTF-8 Support Enabled
INFO - 2016-08-09 13:01:51 --> Utf8 Class Initialized
INFO - 2016-08-09 13:01:51 --> URI Class Initialized
INFO - 2016-08-09 13:01:51 --> Router Class Initialized
INFO - 2016-08-09 13:01:51 --> Output Class Initialized
INFO - 2016-08-09 13:01:52 --> Security Class Initialized
DEBUG - 2016-08-09 13:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 13:01:52 --> Input Class Initialized
INFO - 2016-08-09 13:01:52 --> Language Class Initialized
INFO - 2016-08-09 13:01:52 --> Loader Class Initialized
INFO - 2016-08-09 13:01:52 --> Helper loaded: url_helper
INFO - 2016-08-09 13:01:52 --> Database Driver Class Initialized
INFO - 2016-08-09 13:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 13:01:52 --> Email Class Initialized
INFO - 2016-08-09 13:01:52 --> Model Class Initialized
INFO - 2016-08-09 13:01:52 --> Controller Class Initialized
DEBUG - 2016-08-09 13:01:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 13:01:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:01:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 13:01:52 --> Helper loaded: cookie_helper
INFO - 2016-08-09 13:01:52 --> Helper loaded: language_helper
DEBUG - 2016-08-09 13:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:01:52 --> Model Class Initialized
INFO - 2016-08-09 13:01:52 --> Helper loaded: date_helper
INFO - 2016-08-09 13:01:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 13:01:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 13:01:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 13:01:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 13:01:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 13:01:52 --> Final output sent to browser
DEBUG - 2016-08-09 13:01:52 --> Total execution time: 1.0190
INFO - 2016-08-09 13:02:15 --> Config Class Initialized
INFO - 2016-08-09 13:02:15 --> Hooks Class Initialized
DEBUG - 2016-08-09 13:02:15 --> UTF-8 Support Enabled
INFO - 2016-08-09 13:02:15 --> Utf8 Class Initialized
INFO - 2016-08-09 13:02:15 --> URI Class Initialized
INFO - 2016-08-09 13:02:15 --> Router Class Initialized
INFO - 2016-08-09 13:02:15 --> Output Class Initialized
INFO - 2016-08-09 13:02:15 --> Security Class Initialized
DEBUG - 2016-08-09 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 13:02:15 --> Input Class Initialized
INFO - 2016-08-09 13:02:15 --> Language Class Initialized
INFO - 2016-08-09 13:02:15 --> Loader Class Initialized
INFO - 2016-08-09 13:02:15 --> Helper loaded: url_helper
INFO - 2016-08-09 13:02:15 --> Database Driver Class Initialized
INFO - 2016-08-09 13:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 13:02:15 --> Email Class Initialized
INFO - 2016-08-09 13:02:15 --> Model Class Initialized
INFO - 2016-08-09 13:02:15 --> Controller Class Initialized
DEBUG - 2016-08-09 13:02:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 13:02:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:02:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 13:02:15 --> Helper loaded: cookie_helper
INFO - 2016-08-09 13:02:15 --> Helper loaded: language_helper
DEBUG - 2016-08-09 13:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:02:15 --> Model Class Initialized
INFO - 2016-08-09 13:02:15 --> Helper loaded: date_helper
INFO - 2016-08-09 13:02:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 13:02:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 13:02:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 13:02:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 13:02:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 13:02:15 --> Final output sent to browser
DEBUG - 2016-08-09 13:02:15 --> Total execution time: 0.7690
INFO - 2016-08-09 13:04:44 --> Config Class Initialized
INFO - 2016-08-09 13:04:44 --> Hooks Class Initialized
DEBUG - 2016-08-09 13:04:44 --> UTF-8 Support Enabled
INFO - 2016-08-09 13:04:44 --> Utf8 Class Initialized
INFO - 2016-08-09 13:04:44 --> URI Class Initialized
INFO - 2016-08-09 13:04:44 --> Router Class Initialized
INFO - 2016-08-09 13:04:44 --> Output Class Initialized
INFO - 2016-08-09 13:04:44 --> Security Class Initialized
DEBUG - 2016-08-09 13:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 13:04:44 --> Input Class Initialized
INFO - 2016-08-09 13:04:44 --> Language Class Initialized
INFO - 2016-08-09 13:04:44 --> Loader Class Initialized
INFO - 2016-08-09 13:04:44 --> Helper loaded: url_helper
INFO - 2016-08-09 13:04:44 --> Database Driver Class Initialized
INFO - 2016-08-09 13:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 13:04:44 --> Email Class Initialized
INFO - 2016-08-09 13:04:44 --> Model Class Initialized
INFO - 2016-08-09 13:04:44 --> Controller Class Initialized
DEBUG - 2016-08-09 13:04:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 13:04:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:04:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 13:04:44 --> Helper loaded: cookie_helper
INFO - 2016-08-09 13:04:44 --> Helper loaded: language_helper
DEBUG - 2016-08-09 13:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:04:45 --> Model Class Initialized
INFO - 2016-08-09 13:04:45 --> Helper loaded: date_helper
INFO - 2016-08-09 13:04:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 13:04:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 13:04:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 13:04:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 13:04:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 13:04:45 --> Final output sent to browser
DEBUG - 2016-08-09 13:04:45 --> Total execution time: 0.5947
INFO - 2016-08-09 13:04:54 --> Config Class Initialized
INFO - 2016-08-09 13:04:54 --> Hooks Class Initialized
DEBUG - 2016-08-09 13:04:54 --> UTF-8 Support Enabled
INFO - 2016-08-09 13:04:54 --> Utf8 Class Initialized
INFO - 2016-08-09 13:04:54 --> URI Class Initialized
INFO - 2016-08-09 13:04:54 --> Router Class Initialized
INFO - 2016-08-09 13:04:54 --> Output Class Initialized
INFO - 2016-08-09 13:04:54 --> Security Class Initialized
DEBUG - 2016-08-09 13:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 13:04:54 --> Input Class Initialized
INFO - 2016-08-09 13:04:54 --> Language Class Initialized
INFO - 2016-08-09 13:04:54 --> Loader Class Initialized
INFO - 2016-08-09 13:04:54 --> Helper loaded: url_helper
INFO - 2016-08-09 13:04:54 --> Database Driver Class Initialized
INFO - 2016-08-09 13:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 13:04:54 --> Email Class Initialized
INFO - 2016-08-09 13:04:54 --> Model Class Initialized
INFO - 2016-08-09 13:04:54 --> Controller Class Initialized
DEBUG - 2016-08-09 13:04:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 13:04:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:04:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 13:04:54 --> Helper loaded: cookie_helper
INFO - 2016-08-09 13:04:54 --> Helper loaded: language_helper
DEBUG - 2016-08-09 13:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 13:04:54 --> Model Class Initialized
INFO - 2016-08-09 13:04:54 --> Helper loaded: date_helper
INFO - 2016-08-09 13:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 13:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 13:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 13:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 13:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 13:04:54 --> Final output sent to browser
DEBUG - 2016-08-09 13:04:54 --> Total execution time: 0.7309
INFO - 2016-08-09 14:26:28 --> Config Class Initialized
INFO - 2016-08-09 14:26:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:26:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:26:28 --> Utf8 Class Initialized
INFO - 2016-08-09 14:26:28 --> URI Class Initialized
INFO - 2016-08-09 14:26:28 --> Router Class Initialized
INFO - 2016-08-09 14:26:28 --> Output Class Initialized
INFO - 2016-08-09 14:26:28 --> Security Class Initialized
DEBUG - 2016-08-09 14:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:26:28 --> Input Class Initialized
INFO - 2016-08-09 14:26:28 --> Language Class Initialized
INFO - 2016-08-09 14:26:28 --> Loader Class Initialized
INFO - 2016-08-09 14:26:28 --> Helper loaded: url_helper
INFO - 2016-08-09 14:26:28 --> Database Driver Class Initialized
INFO - 2016-08-09 14:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:26:29 --> Email Class Initialized
INFO - 2016-08-09 14:26:29 --> Model Class Initialized
INFO - 2016-08-09 14:26:29 --> Controller Class Initialized
DEBUG - 2016-08-09 14:26:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:26:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:26:29 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:26:29 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:29 --> Model Class Initialized
INFO - 2016-08-09 14:26:29 --> Helper loaded: date_helper
INFO - 2016-08-09 14:26:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 14:26:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 14:26:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 14:26:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-09 14:26:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 14:26:29 --> Final output sent to browser
DEBUG - 2016-08-09 14:26:29 --> Total execution time: 0.4867
INFO - 2016-08-09 14:26:34 --> Config Class Initialized
INFO - 2016-08-09 14:26:34 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:26:34 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:26:34 --> Utf8 Class Initialized
INFO - 2016-08-09 14:26:34 --> URI Class Initialized
INFO - 2016-08-09 14:26:34 --> Router Class Initialized
INFO - 2016-08-09 14:26:34 --> Output Class Initialized
INFO - 2016-08-09 14:26:34 --> Security Class Initialized
DEBUG - 2016-08-09 14:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:26:34 --> Input Class Initialized
INFO - 2016-08-09 14:26:34 --> Language Class Initialized
INFO - 2016-08-09 14:26:34 --> Loader Class Initialized
INFO - 2016-08-09 14:26:34 --> Helper loaded: url_helper
INFO - 2016-08-09 14:26:34 --> Database Driver Class Initialized
INFO - 2016-08-09 14:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:26:34 --> Email Class Initialized
INFO - 2016-08-09 14:26:34 --> Model Class Initialized
INFO - 2016-08-09 14:26:34 --> Controller Class Initialized
DEBUG - 2016-08-09 14:26:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:26:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:26:34 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:26:34 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:26:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:34 --> Model Class Initialized
INFO - 2016-08-09 14:26:34 --> Helper loaded: date_helper
INFO - 2016-08-09 14:26:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 14:26:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 14:26:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 14:26:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-09 14:26:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 14:26:34 --> Final output sent to browser
DEBUG - 2016-08-09 14:26:34 --> Total execution time: 0.6026
INFO - 2016-08-09 14:26:37 --> Config Class Initialized
INFO - 2016-08-09 14:26:37 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:26:37 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:26:37 --> Utf8 Class Initialized
INFO - 2016-08-09 14:26:37 --> URI Class Initialized
INFO - 2016-08-09 14:26:37 --> Router Class Initialized
INFO - 2016-08-09 14:26:37 --> Output Class Initialized
INFO - 2016-08-09 14:26:37 --> Security Class Initialized
DEBUG - 2016-08-09 14:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:26:37 --> Input Class Initialized
INFO - 2016-08-09 14:26:37 --> Language Class Initialized
INFO - 2016-08-09 14:26:37 --> Loader Class Initialized
INFO - 2016-08-09 14:26:37 --> Helper loaded: url_helper
INFO - 2016-08-09 14:26:37 --> Database Driver Class Initialized
INFO - 2016-08-09 14:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:26:38 --> Email Class Initialized
INFO - 2016-08-09 14:26:38 --> Model Class Initialized
INFO - 2016-08-09 14:26:38 --> Controller Class Initialized
DEBUG - 2016-08-09 14:26:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:26:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:26:38 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:26:38 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:26:38 --> Model Class Initialized
INFO - 2016-08-09 14:26:38 --> Helper loaded: date_helper
INFO - 2016-08-09 14:26:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 14:26:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 14:26:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 14:26:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-09 14:26:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 14:26:38 --> Final output sent to browser
DEBUG - 2016-08-09 14:26:38 --> Total execution time: 0.4788
INFO - 2016-08-09 14:27:13 --> Config Class Initialized
INFO - 2016-08-09 14:27:13 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:27:13 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:27:13 --> Utf8 Class Initialized
INFO - 2016-08-09 14:27:13 --> URI Class Initialized
INFO - 2016-08-09 14:27:13 --> Router Class Initialized
INFO - 2016-08-09 14:27:13 --> Output Class Initialized
INFO - 2016-08-09 14:27:13 --> Security Class Initialized
DEBUG - 2016-08-09 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:27:13 --> Input Class Initialized
INFO - 2016-08-09 14:27:13 --> Language Class Initialized
INFO - 2016-08-09 14:27:13 --> Loader Class Initialized
INFO - 2016-08-09 14:27:13 --> Helper loaded: url_helper
INFO - 2016-08-09 14:27:13 --> Database Driver Class Initialized
INFO - 2016-08-09 14:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:27:13 --> Email Class Initialized
INFO - 2016-08-09 14:27:13 --> Model Class Initialized
INFO - 2016-08-09 14:27:14 --> Controller Class Initialized
DEBUG - 2016-08-09 14:27:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:27:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:27:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:27:14 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:27:14 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:27:14 --> Model Class Initialized
INFO - 2016-08-09 14:27:14 --> Helper loaded: date_helper
INFO - 2016-08-09 14:27:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-09 14:27:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-09 14:27:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-09 14:27:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-09 14:27:14 --> Final output sent to browser
DEBUG - 2016-08-09 14:27:14 --> Total execution time: 0.6644
INFO - 2016-08-09 14:27:14 --> Config Class Initialized
INFO - 2016-08-09 14:27:14 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:27:14 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:27:15 --> Utf8 Class Initialized
INFO - 2016-08-09 14:27:15 --> URI Class Initialized
INFO - 2016-08-09 14:27:15 --> Router Class Initialized
INFO - 2016-08-09 14:27:15 --> Output Class Initialized
INFO - 2016-08-09 14:27:15 --> Security Class Initialized
DEBUG - 2016-08-09 14:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:27:15 --> Input Class Initialized
INFO - 2016-08-09 14:27:15 --> Language Class Initialized
ERROR - 2016-08-09 14:27:15 --> 404 Page Not Found: Assets/css
INFO - 2016-08-09 14:28:50 --> Config Class Initialized
INFO - 2016-08-09 14:28:50 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:28:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:28:50 --> Utf8 Class Initialized
INFO - 2016-08-09 14:28:50 --> URI Class Initialized
INFO - 2016-08-09 14:28:50 --> Router Class Initialized
INFO - 2016-08-09 14:28:50 --> Output Class Initialized
INFO - 2016-08-09 14:28:50 --> Security Class Initialized
DEBUG - 2016-08-09 14:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:28:50 --> Input Class Initialized
INFO - 2016-08-09 14:28:50 --> Language Class Initialized
INFO - 2016-08-09 14:28:50 --> Loader Class Initialized
INFO - 2016-08-09 14:28:50 --> Helper loaded: url_helper
INFO - 2016-08-09 14:28:50 --> Database Driver Class Initialized
INFO - 2016-08-09 14:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:28:50 --> Email Class Initialized
INFO - 2016-08-09 14:28:50 --> Model Class Initialized
INFO - 2016-08-09 14:28:50 --> Controller Class Initialized
DEBUG - 2016-08-09 14:28:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:28:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:28:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:28:50 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:28:50 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:28:50 --> Model Class Initialized
INFO - 2016-08-09 14:28:50 --> Helper loaded: date_helper
INFO - 2016-08-09 14:28:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-09 14:28:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-09 14:28:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-09 14:28:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-09 14:28:51 --> Final output sent to browser
DEBUG - 2016-08-09 14:28:51 --> Total execution time: 0.5516
INFO - 2016-08-09 14:50:55 --> Config Class Initialized
INFO - 2016-08-09 14:50:55 --> Hooks Class Initialized
DEBUG - 2016-08-09 14:50:55 --> UTF-8 Support Enabled
INFO - 2016-08-09 14:50:55 --> Utf8 Class Initialized
INFO - 2016-08-09 14:50:55 --> URI Class Initialized
INFO - 2016-08-09 14:50:55 --> Router Class Initialized
INFO - 2016-08-09 14:50:55 --> Output Class Initialized
INFO - 2016-08-09 14:50:55 --> Security Class Initialized
DEBUG - 2016-08-09 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 14:50:55 --> Input Class Initialized
INFO - 2016-08-09 14:50:55 --> Language Class Initialized
INFO - 2016-08-09 14:50:55 --> Loader Class Initialized
INFO - 2016-08-09 14:50:55 --> Helper loaded: url_helper
INFO - 2016-08-09 14:50:55 --> Database Driver Class Initialized
INFO - 2016-08-09 14:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 14:50:55 --> Email Class Initialized
INFO - 2016-08-09 14:50:55 --> Model Class Initialized
INFO - 2016-08-09 14:50:55 --> Controller Class Initialized
DEBUG - 2016-08-09 14:50:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 14:50:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:50:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 14:50:55 --> Helper loaded: cookie_helper
INFO - 2016-08-09 14:50:55 --> Helper loaded: language_helper
DEBUG - 2016-08-09 14:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 14:50:55 --> Model Class Initialized
INFO - 2016-08-09 14:50:55 --> Helper loaded: date_helper
INFO - 2016-08-09 14:50:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 14:50:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 14:50:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 14:50:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 14:50:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 14:50:55 --> Final output sent to browser
DEBUG - 2016-08-09 14:50:55 --> Total execution time: 0.5448
INFO - 2016-08-09 17:19:40 --> Config Class Initialized
INFO - 2016-08-09 17:19:40 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:19:40 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:19:40 --> Utf8 Class Initialized
INFO - 2016-08-09 17:19:40 --> URI Class Initialized
INFO - 2016-08-09 17:19:40 --> Router Class Initialized
INFO - 2016-08-09 17:19:40 --> Output Class Initialized
INFO - 2016-08-09 17:19:40 --> Security Class Initialized
DEBUG - 2016-08-09 17:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:19:40 --> Input Class Initialized
INFO - 2016-08-09 17:19:40 --> Language Class Initialized
INFO - 2016-08-09 17:19:40 --> Loader Class Initialized
INFO - 2016-08-09 17:19:40 --> Helper loaded: url_helper
INFO - 2016-08-09 17:19:40 --> Database Driver Class Initialized
INFO - 2016-08-09 17:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:19:40 --> Email Class Initialized
INFO - 2016-08-09 17:19:40 --> Model Class Initialized
INFO - 2016-08-09 17:19:40 --> Controller Class Initialized
INFO - 2016-08-09 17:19:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:19:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:19:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 17:19:40 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 43
ERROR - 2016-08-09 17:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 43
INFO - 2016-08-09 17:19:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:19:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:19:40 --> Final output sent to browser
DEBUG - 2016-08-09 17:19:40 --> Total execution time: 0.8641
INFO - 2016-08-09 17:25:27 --> Config Class Initialized
INFO - 2016-08-09 17:25:27 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:25:27 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:25:27 --> Utf8 Class Initialized
INFO - 2016-08-09 17:25:27 --> URI Class Initialized
INFO - 2016-08-09 17:25:27 --> Router Class Initialized
INFO - 2016-08-09 17:25:27 --> Output Class Initialized
INFO - 2016-08-09 17:25:27 --> Security Class Initialized
DEBUG - 2016-08-09 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:25:27 --> Input Class Initialized
INFO - 2016-08-09 17:25:27 --> Language Class Initialized
INFO - 2016-08-09 17:25:27 --> Loader Class Initialized
INFO - 2016-08-09 17:25:27 --> Helper loaded: url_helper
INFO - 2016-08-09 17:25:27 --> Database Driver Class Initialized
INFO - 2016-08-09 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:25:27 --> Email Class Initialized
INFO - 2016-08-09 17:25:27 --> Model Class Initialized
INFO - 2016-08-09 17:25:27 --> Controller Class Initialized
INFO - 2016-08-09 17:25:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:25:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:25:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 17:25:27 --> Severity: Notice --> Undefined property: stdClass::$judul D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 46
ERROR - 2016-08-09 17:25:27 --> Severity: Notice --> Undefined property: stdClass::$slug D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 47
ERROR - 2016-08-09 17:25:27 --> Severity: Notice --> Undefined property: stdClass::$gambar D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 48
ERROR - 2016-08-09 17:25:27 --> Severity: Notice --> Undefined property: stdClass::$konten D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 49
INFO - 2016-08-09 17:25:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:25:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:25:27 --> Final output sent to browser
DEBUG - 2016-08-09 17:25:27 --> Total execution time: 0.4450
INFO - 2016-08-09 17:26:19 --> Config Class Initialized
INFO - 2016-08-09 17:26:19 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:26:19 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:26:19 --> Utf8 Class Initialized
INFO - 2016-08-09 17:26:19 --> URI Class Initialized
INFO - 2016-08-09 17:26:19 --> Router Class Initialized
INFO - 2016-08-09 17:26:19 --> Output Class Initialized
INFO - 2016-08-09 17:26:19 --> Security Class Initialized
DEBUG - 2016-08-09 17:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:26:19 --> Input Class Initialized
INFO - 2016-08-09 17:26:19 --> Language Class Initialized
INFO - 2016-08-09 17:26:19 --> Loader Class Initialized
INFO - 2016-08-09 17:26:19 --> Helper loaded: url_helper
INFO - 2016-08-09 17:26:19 --> Database Driver Class Initialized
INFO - 2016-08-09 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:26:19 --> Email Class Initialized
INFO - 2016-08-09 17:26:19 --> Model Class Initialized
INFO - 2016-08-09 17:26:19 --> Controller Class Initialized
INFO - 2016-08-09 17:26:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:26:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:26:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:26:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:26:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:26:19 --> Final output sent to browser
DEBUG - 2016-08-09 17:26:19 --> Total execution time: 0.3816
INFO - 2016-08-09 17:26:45 --> Config Class Initialized
INFO - 2016-08-09 17:26:45 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:26:45 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:26:45 --> Utf8 Class Initialized
INFO - 2016-08-09 17:26:45 --> URI Class Initialized
INFO - 2016-08-09 17:26:45 --> Router Class Initialized
INFO - 2016-08-09 17:26:45 --> Output Class Initialized
INFO - 2016-08-09 17:26:45 --> Security Class Initialized
DEBUG - 2016-08-09 17:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:26:45 --> Input Class Initialized
INFO - 2016-08-09 17:26:45 --> Language Class Initialized
INFO - 2016-08-09 17:26:45 --> Loader Class Initialized
INFO - 2016-08-09 17:26:46 --> Helper loaded: url_helper
INFO - 2016-08-09 17:26:46 --> Database Driver Class Initialized
INFO - 2016-08-09 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:26:46 --> Email Class Initialized
INFO - 2016-08-09 17:26:46 --> Model Class Initialized
INFO - 2016-08-09 17:26:46 --> Controller Class Initialized
INFO - 2016-08-09 17:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:26:46 --> Final output sent to browser
DEBUG - 2016-08-09 17:26:46 --> Total execution time: 0.4114
INFO - 2016-08-09 17:28:18 --> Config Class Initialized
INFO - 2016-08-09 17:28:18 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:18 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:18 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:18 --> URI Class Initialized
INFO - 2016-08-09 17:28:18 --> Router Class Initialized
INFO - 2016-08-09 17:28:18 --> Output Class Initialized
INFO - 2016-08-09 17:28:18 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:18 --> Input Class Initialized
INFO - 2016-08-09 17:28:18 --> Language Class Initialized
INFO - 2016-08-09 17:28:18 --> Loader Class Initialized
INFO - 2016-08-09 17:28:18 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:18 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:18 --> Email Class Initialized
INFO - 2016-08-09 17:28:18 --> Model Class Initialized
INFO - 2016-08-09 17:28:18 --> Controller Class Initialized
INFO - 2016-08-09 17:28:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:28:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:28:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:28:18 --> Final output sent to browser
DEBUG - 2016-08-09 17:28:18 --> Total execution time: 0.3835
INFO - 2016-08-09 17:28:20 --> Config Class Initialized
INFO - 2016-08-09 17:28:20 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:20 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:20 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:20 --> URI Class Initialized
INFO - 2016-08-09 17:28:20 --> Router Class Initialized
INFO - 2016-08-09 17:28:20 --> Output Class Initialized
INFO - 2016-08-09 17:28:20 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:20 --> Input Class Initialized
INFO - 2016-08-09 17:28:20 --> Language Class Initialized
INFO - 2016-08-09 17:28:20 --> Loader Class Initialized
INFO - 2016-08-09 17:28:20 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:20 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:20 --> Email Class Initialized
INFO - 2016-08-09 17:28:20 --> Model Class Initialized
INFO - 2016-08-09 17:28:20 --> Controller Class Initialized
INFO - 2016-08-09 17:28:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:28:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:28:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:28:20 --> Final output sent to browser
DEBUG - 2016-08-09 17:28:20 --> Total execution time: 0.4623
INFO - 2016-08-09 17:28:23 --> Config Class Initialized
INFO - 2016-08-09 17:28:23 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:23 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:23 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:23 --> URI Class Initialized
INFO - 2016-08-09 17:28:23 --> Router Class Initialized
INFO - 2016-08-09 17:28:23 --> Output Class Initialized
INFO - 2016-08-09 17:28:23 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:23 --> Input Class Initialized
INFO - 2016-08-09 17:28:23 --> Language Class Initialized
INFO - 2016-08-09 17:28:24 --> Loader Class Initialized
INFO - 2016-08-09 17:28:24 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:24 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:24 --> Email Class Initialized
INFO - 2016-08-09 17:28:24 --> Model Class Initialized
INFO - 2016-08-09 17:28:24 --> Controller Class Initialized
INFO - 2016-08-09 17:28:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:28:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:28:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:28:24 --> Final output sent to browser
DEBUG - 2016-08-09 17:28:24 --> Total execution time: 0.3731
INFO - 2016-08-09 17:28:47 --> Config Class Initialized
INFO - 2016-08-09 17:28:47 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:47 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:47 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:47 --> URI Class Initialized
INFO - 2016-08-09 17:28:47 --> Router Class Initialized
INFO - 2016-08-09 17:28:47 --> Output Class Initialized
INFO - 2016-08-09 17:28:47 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:47 --> Input Class Initialized
INFO - 2016-08-09 17:28:47 --> Language Class Initialized
INFO - 2016-08-09 17:28:47 --> Loader Class Initialized
INFO - 2016-08-09 17:28:47 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:47 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:47 --> Email Class Initialized
INFO - 2016-08-09 17:28:47 --> Model Class Initialized
INFO - 2016-08-09 17:28:47 --> Controller Class Initialized
INFO - 2016-08-09 17:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:28:47 --> Final output sent to browser
DEBUG - 2016-08-09 17:28:47 --> Total execution time: 0.3804
INFO - 2016-08-09 17:28:49 --> Config Class Initialized
INFO - 2016-08-09 17:28:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:49 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:49 --> URI Class Initialized
INFO - 2016-08-09 17:28:49 --> Router Class Initialized
INFO - 2016-08-09 17:28:49 --> Output Class Initialized
INFO - 2016-08-09 17:28:49 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:49 --> Input Class Initialized
INFO - 2016-08-09 17:28:49 --> Language Class Initialized
INFO - 2016-08-09 17:28:49 --> Loader Class Initialized
INFO - 2016-08-09 17:28:49 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:49 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:49 --> Email Class Initialized
INFO - 2016-08-09 17:28:49 --> Model Class Initialized
INFO - 2016-08-09 17:28:49 --> Controller Class Initialized
INFO - 2016-08-09 17:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 17:28:49 --> Severity: Notice --> Undefined variable: groups D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\tambah_page.php 61
ERROR - 2016-08-09 17:28:49 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\tambah_page.php 61
INFO - 2016-08-09 17:28:52 --> Config Class Initialized
INFO - 2016-08-09 17:28:52 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:28:52 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:28:52 --> Utf8 Class Initialized
INFO - 2016-08-09 17:28:52 --> URI Class Initialized
INFO - 2016-08-09 17:28:52 --> Router Class Initialized
INFO - 2016-08-09 17:28:52 --> Output Class Initialized
INFO - 2016-08-09 17:28:52 --> Security Class Initialized
DEBUG - 2016-08-09 17:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:28:52 --> Input Class Initialized
INFO - 2016-08-09 17:28:52 --> Language Class Initialized
INFO - 2016-08-09 17:28:52 --> Loader Class Initialized
INFO - 2016-08-09 17:28:52 --> Helper loaded: url_helper
INFO - 2016-08-09 17:28:52 --> Database Driver Class Initialized
INFO - 2016-08-09 17:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:28:52 --> Email Class Initialized
INFO - 2016-08-09 17:28:52 --> Model Class Initialized
INFO - 2016-08-09 17:28:52 --> Controller Class Initialized
INFO - 2016-08-09 17:28:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:28:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:28:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:28:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:28:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:28:52 --> Final output sent to browser
DEBUG - 2016-08-09 17:28:52 --> Total execution time: 0.4387
INFO - 2016-08-09 17:29:06 --> Config Class Initialized
INFO - 2016-08-09 17:29:06 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:29:06 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:29:06 --> Utf8 Class Initialized
INFO - 2016-08-09 17:29:06 --> URI Class Initialized
INFO - 2016-08-09 17:29:06 --> Router Class Initialized
INFO - 2016-08-09 17:29:06 --> Output Class Initialized
INFO - 2016-08-09 17:29:06 --> Security Class Initialized
DEBUG - 2016-08-09 17:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:29:06 --> Input Class Initialized
INFO - 2016-08-09 17:29:06 --> Language Class Initialized
INFO - 2016-08-09 17:29:06 --> Loader Class Initialized
INFO - 2016-08-09 17:29:06 --> Helper loaded: url_helper
INFO - 2016-08-09 17:29:06 --> Database Driver Class Initialized
INFO - 2016-08-09 17:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:29:06 --> Email Class Initialized
INFO - 2016-08-09 17:29:06 --> Model Class Initialized
INFO - 2016-08-09 17:29:06 --> Controller Class Initialized
INFO - 2016-08-09 17:29:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:29:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:29:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:29:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 17:29:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:29:06 --> Final output sent to browser
DEBUG - 2016-08-09 17:29:06 --> Total execution time: 0.4428
INFO - 2016-08-09 17:29:09 --> Config Class Initialized
INFO - 2016-08-09 17:29:09 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:29:09 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:29:09 --> Utf8 Class Initialized
INFO - 2016-08-09 17:29:09 --> URI Class Initialized
INFO - 2016-08-09 17:29:09 --> Router Class Initialized
INFO - 2016-08-09 17:29:09 --> Output Class Initialized
INFO - 2016-08-09 17:29:09 --> Security Class Initialized
DEBUG - 2016-08-09 17:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:29:09 --> Input Class Initialized
INFO - 2016-08-09 17:29:09 --> Language Class Initialized
INFO - 2016-08-09 17:29:09 --> Loader Class Initialized
INFO - 2016-08-09 17:29:09 --> Helper loaded: url_helper
INFO - 2016-08-09 17:29:09 --> Database Driver Class Initialized
INFO - 2016-08-09 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:29:09 --> Email Class Initialized
INFO - 2016-08-09 17:29:09 --> Model Class Initialized
INFO - 2016-08-09 17:29:09 --> Controller Class Initialized
INFO - 2016-08-09 17:29:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:29:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:29:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:29:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:29:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:29:09 --> Final output sent to browser
DEBUG - 2016-08-09 17:29:09 --> Total execution time: 0.4453
INFO - 2016-08-09 17:29:51 --> Config Class Initialized
INFO - 2016-08-09 17:29:51 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:29:51 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:29:51 --> Utf8 Class Initialized
INFO - 2016-08-09 17:29:51 --> URI Class Initialized
INFO - 2016-08-09 17:29:51 --> Router Class Initialized
INFO - 2016-08-09 17:29:51 --> Output Class Initialized
INFO - 2016-08-09 17:29:51 --> Security Class Initialized
DEBUG - 2016-08-09 17:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:29:51 --> Input Class Initialized
INFO - 2016-08-09 17:29:51 --> Language Class Initialized
INFO - 2016-08-09 17:29:51 --> Loader Class Initialized
INFO - 2016-08-09 17:29:51 --> Helper loaded: url_helper
INFO - 2016-08-09 17:29:51 --> Database Driver Class Initialized
INFO - 2016-08-09 17:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:29:52 --> Email Class Initialized
INFO - 2016-08-09 17:29:52 --> Model Class Initialized
INFO - 2016-08-09 17:29:52 --> Controller Class Initialized
INFO - 2016-08-09 17:29:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:29:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:29:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:29:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:29:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:29:52 --> Final output sent to browser
DEBUG - 2016-08-09 17:29:52 --> Total execution time: 0.3965
INFO - 2016-08-09 17:31:31 --> Config Class Initialized
INFO - 2016-08-09 17:31:31 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:31:31 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:31:31 --> Utf8 Class Initialized
INFO - 2016-08-09 17:31:31 --> URI Class Initialized
INFO - 2016-08-09 17:31:31 --> Router Class Initialized
INFO - 2016-08-09 17:31:31 --> Output Class Initialized
INFO - 2016-08-09 17:31:31 --> Security Class Initialized
DEBUG - 2016-08-09 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:31:31 --> Input Class Initialized
INFO - 2016-08-09 17:31:31 --> Language Class Initialized
INFO - 2016-08-09 17:31:31 --> Loader Class Initialized
INFO - 2016-08-09 17:31:31 --> Helper loaded: url_helper
INFO - 2016-08-09 17:31:31 --> Database Driver Class Initialized
INFO - 2016-08-09 17:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:31:31 --> Email Class Initialized
INFO - 2016-08-09 17:31:31 --> Model Class Initialized
INFO - 2016-08-09 17:31:31 --> Controller Class Initialized
INFO - 2016-08-09 17:31:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:31:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:31:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:31:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:31:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:31:31 --> Final output sent to browser
DEBUG - 2016-08-09 17:31:31 --> Total execution time: 0.3912
INFO - 2016-08-09 17:31:49 --> Config Class Initialized
INFO - 2016-08-09 17:31:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:31:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:31:50 --> Utf8 Class Initialized
INFO - 2016-08-09 17:31:50 --> URI Class Initialized
INFO - 2016-08-09 17:31:50 --> Router Class Initialized
INFO - 2016-08-09 17:31:50 --> Output Class Initialized
INFO - 2016-08-09 17:31:50 --> Security Class Initialized
DEBUG - 2016-08-09 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:31:50 --> Input Class Initialized
INFO - 2016-08-09 17:31:50 --> Language Class Initialized
INFO - 2016-08-09 17:31:50 --> Loader Class Initialized
INFO - 2016-08-09 17:31:50 --> Helper loaded: url_helper
INFO - 2016-08-09 17:31:50 --> Database Driver Class Initialized
INFO - 2016-08-09 17:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:31:50 --> Email Class Initialized
INFO - 2016-08-09 17:31:50 --> Model Class Initialized
INFO - 2016-08-09 17:31:50 --> Controller Class Initialized
INFO - 2016-08-09 17:31:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:31:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:31:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:31:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:31:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:31:50 --> Final output sent to browser
DEBUG - 2016-08-09 17:31:50 --> Total execution time: 0.4311
INFO - 2016-08-09 17:32:14 --> Config Class Initialized
INFO - 2016-08-09 17:32:14 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:32:14 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:32:14 --> Utf8 Class Initialized
INFO - 2016-08-09 17:32:14 --> URI Class Initialized
INFO - 2016-08-09 17:32:14 --> Router Class Initialized
INFO - 2016-08-09 17:32:14 --> Output Class Initialized
INFO - 2016-08-09 17:32:14 --> Security Class Initialized
DEBUG - 2016-08-09 17:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:32:14 --> Input Class Initialized
INFO - 2016-08-09 17:32:14 --> Language Class Initialized
INFO - 2016-08-09 17:32:14 --> Loader Class Initialized
INFO - 2016-08-09 17:32:14 --> Helper loaded: url_helper
INFO - 2016-08-09 17:32:14 --> Database Driver Class Initialized
INFO - 2016-08-09 17:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:32:15 --> Email Class Initialized
INFO - 2016-08-09 17:32:15 --> Model Class Initialized
INFO - 2016-08-09 17:32:15 --> Controller Class Initialized
INFO - 2016-08-09 17:32:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:32:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:32:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:32:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:32:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:32:15 --> Final output sent to browser
DEBUG - 2016-08-09 17:32:15 --> Total execution time: 0.4456
INFO - 2016-08-09 17:32:41 --> Config Class Initialized
INFO - 2016-08-09 17:32:41 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:32:41 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:32:41 --> Utf8 Class Initialized
INFO - 2016-08-09 17:32:41 --> URI Class Initialized
INFO - 2016-08-09 17:32:41 --> Router Class Initialized
INFO - 2016-08-09 17:32:41 --> Output Class Initialized
INFO - 2016-08-09 17:32:41 --> Security Class Initialized
DEBUG - 2016-08-09 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:32:41 --> Input Class Initialized
INFO - 2016-08-09 17:32:41 --> Language Class Initialized
INFO - 2016-08-09 17:32:41 --> Loader Class Initialized
INFO - 2016-08-09 17:32:41 --> Helper loaded: url_helper
INFO - 2016-08-09 17:32:41 --> Database Driver Class Initialized
INFO - 2016-08-09 17:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:32:41 --> Email Class Initialized
INFO - 2016-08-09 17:32:41 --> Model Class Initialized
INFO - 2016-08-09 17:32:41 --> Controller Class Initialized
INFO - 2016-08-09 17:32:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:32:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:32:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:32:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:32:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:32:41 --> Final output sent to browser
DEBUG - 2016-08-09 17:32:41 --> Total execution time: 0.4167
INFO - 2016-08-09 17:34:12 --> Config Class Initialized
INFO - 2016-08-09 17:34:12 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:34:12 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:34:12 --> Utf8 Class Initialized
INFO - 2016-08-09 17:34:12 --> URI Class Initialized
INFO - 2016-08-09 17:34:12 --> Router Class Initialized
INFO - 2016-08-09 17:34:12 --> Output Class Initialized
INFO - 2016-08-09 17:34:12 --> Security Class Initialized
DEBUG - 2016-08-09 17:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:34:12 --> Input Class Initialized
INFO - 2016-08-09 17:34:12 --> Language Class Initialized
INFO - 2016-08-09 17:34:12 --> Loader Class Initialized
INFO - 2016-08-09 17:34:12 --> Helper loaded: url_helper
INFO - 2016-08-09 17:34:12 --> Database Driver Class Initialized
INFO - 2016-08-09 17:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:34:12 --> Email Class Initialized
INFO - 2016-08-09 17:34:12 --> Model Class Initialized
INFO - 2016-08-09 17:34:12 --> Controller Class Initialized
INFO - 2016-08-09 17:34:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:34:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:34:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:34:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:34:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:34:12 --> Final output sent to browser
DEBUG - 2016-08-09 17:34:12 --> Total execution time: 0.3933
INFO - 2016-08-09 17:34:58 --> Config Class Initialized
INFO - 2016-08-09 17:34:58 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:34:58 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:34:58 --> Utf8 Class Initialized
INFO - 2016-08-09 17:34:58 --> URI Class Initialized
INFO - 2016-08-09 17:34:58 --> Router Class Initialized
INFO - 2016-08-09 17:34:58 --> Output Class Initialized
INFO - 2016-08-09 17:34:58 --> Security Class Initialized
DEBUG - 2016-08-09 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:34:58 --> Input Class Initialized
INFO - 2016-08-09 17:34:58 --> Language Class Initialized
INFO - 2016-08-09 17:34:58 --> Loader Class Initialized
INFO - 2016-08-09 17:34:58 --> Helper loaded: url_helper
INFO - 2016-08-09 17:34:58 --> Database Driver Class Initialized
INFO - 2016-08-09 17:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:34:58 --> Email Class Initialized
INFO - 2016-08-09 17:34:58 --> Model Class Initialized
INFO - 2016-08-09 17:34:58 --> Controller Class Initialized
INFO - 2016-08-09 17:34:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:34:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:34:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:34:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:34:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:34:58 --> Final output sent to browser
DEBUG - 2016-08-09 17:34:58 --> Total execution time: 0.3926
INFO - 2016-08-09 17:35:10 --> Config Class Initialized
INFO - 2016-08-09 17:35:10 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:35:10 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:35:10 --> Utf8 Class Initialized
INFO - 2016-08-09 17:35:10 --> URI Class Initialized
INFO - 2016-08-09 17:35:10 --> Router Class Initialized
INFO - 2016-08-09 17:35:10 --> Output Class Initialized
INFO - 2016-08-09 17:35:10 --> Security Class Initialized
DEBUG - 2016-08-09 17:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:35:10 --> Input Class Initialized
INFO - 2016-08-09 17:35:10 --> Language Class Initialized
INFO - 2016-08-09 17:35:10 --> Loader Class Initialized
INFO - 2016-08-09 17:35:10 --> Helper loaded: url_helper
INFO - 2016-08-09 17:35:10 --> Database Driver Class Initialized
INFO - 2016-08-09 17:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:35:10 --> Email Class Initialized
INFO - 2016-08-09 17:35:10 --> Model Class Initialized
INFO - 2016-08-09 17:35:10 --> Controller Class Initialized
INFO - 2016-08-09 17:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:35:10 --> Final output sent to browser
DEBUG - 2016-08-09 17:35:10 --> Total execution time: 0.3831
INFO - 2016-08-09 17:35:24 --> Config Class Initialized
INFO - 2016-08-09 17:35:24 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:35:24 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:35:24 --> Utf8 Class Initialized
INFO - 2016-08-09 17:35:24 --> URI Class Initialized
INFO - 2016-08-09 17:35:24 --> Router Class Initialized
INFO - 2016-08-09 17:35:24 --> Output Class Initialized
INFO - 2016-08-09 17:35:24 --> Security Class Initialized
DEBUG - 2016-08-09 17:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:35:24 --> Input Class Initialized
INFO - 2016-08-09 17:35:24 --> Language Class Initialized
INFO - 2016-08-09 17:35:24 --> Loader Class Initialized
INFO - 2016-08-09 17:35:24 --> Helper loaded: url_helper
INFO - 2016-08-09 17:35:24 --> Database Driver Class Initialized
INFO - 2016-08-09 17:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:35:24 --> Email Class Initialized
INFO - 2016-08-09 17:35:24 --> Model Class Initialized
INFO - 2016-08-09 17:35:24 --> Controller Class Initialized
INFO - 2016-08-09 17:35:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:35:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:35:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:35:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:35:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:35:25 --> Final output sent to browser
DEBUG - 2016-08-09 17:35:25 --> Total execution time: 0.3910
INFO - 2016-08-09 17:36:15 --> Config Class Initialized
INFO - 2016-08-09 17:36:15 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:36:15 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:36:15 --> Utf8 Class Initialized
INFO - 2016-08-09 17:36:15 --> URI Class Initialized
INFO - 2016-08-09 17:36:15 --> Router Class Initialized
INFO - 2016-08-09 17:36:15 --> Output Class Initialized
INFO - 2016-08-09 17:36:15 --> Security Class Initialized
DEBUG - 2016-08-09 17:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:36:15 --> Input Class Initialized
INFO - 2016-08-09 17:36:15 --> Language Class Initialized
INFO - 2016-08-09 17:36:15 --> Loader Class Initialized
INFO - 2016-08-09 17:36:15 --> Helper loaded: url_helper
INFO - 2016-08-09 17:36:16 --> Database Driver Class Initialized
INFO - 2016-08-09 17:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:36:16 --> Email Class Initialized
INFO - 2016-08-09 17:36:16 --> Model Class Initialized
INFO - 2016-08-09 17:36:16 --> Controller Class Initialized
INFO - 2016-08-09 17:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:36:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:36:16 --> Final output sent to browser
DEBUG - 2016-08-09 17:36:16 --> Total execution time: 0.4507
INFO - 2016-08-09 17:36:55 --> Config Class Initialized
INFO - 2016-08-09 17:36:55 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:36:55 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:36:55 --> Utf8 Class Initialized
INFO - 2016-08-09 17:36:55 --> URI Class Initialized
INFO - 2016-08-09 17:36:55 --> Router Class Initialized
INFO - 2016-08-09 17:36:55 --> Output Class Initialized
INFO - 2016-08-09 17:36:55 --> Security Class Initialized
DEBUG - 2016-08-09 17:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:36:56 --> Input Class Initialized
INFO - 2016-08-09 17:36:56 --> Language Class Initialized
INFO - 2016-08-09 17:36:56 --> Loader Class Initialized
INFO - 2016-08-09 17:36:56 --> Helper loaded: url_helper
INFO - 2016-08-09 17:36:56 --> Database Driver Class Initialized
INFO - 2016-08-09 17:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:36:56 --> Email Class Initialized
INFO - 2016-08-09 17:36:56 --> Model Class Initialized
INFO - 2016-08-09 17:36:56 --> Controller Class Initialized
INFO - 2016-08-09 17:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:36:56 --> Final output sent to browser
DEBUG - 2016-08-09 17:36:56 --> Total execution time: 0.4190
INFO - 2016-08-09 17:37:12 --> Config Class Initialized
INFO - 2016-08-09 17:37:12 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:37:12 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:37:12 --> Utf8 Class Initialized
INFO - 2016-08-09 17:37:12 --> URI Class Initialized
INFO - 2016-08-09 17:37:12 --> Router Class Initialized
INFO - 2016-08-09 17:37:12 --> Output Class Initialized
INFO - 2016-08-09 17:37:12 --> Security Class Initialized
DEBUG - 2016-08-09 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:37:12 --> Input Class Initialized
INFO - 2016-08-09 17:37:12 --> Language Class Initialized
INFO - 2016-08-09 17:37:12 --> Loader Class Initialized
INFO - 2016-08-09 17:37:12 --> Helper loaded: url_helper
INFO - 2016-08-09 17:37:13 --> Database Driver Class Initialized
INFO - 2016-08-09 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:37:13 --> Email Class Initialized
INFO - 2016-08-09 17:37:13 --> Model Class Initialized
INFO - 2016-08-09 17:37:13 --> Controller Class Initialized
INFO - 2016-08-09 17:37:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:37:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:37:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:37:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:37:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:37:13 --> Final output sent to browser
DEBUG - 2016-08-09 17:37:13 --> Total execution time: 0.3880
INFO - 2016-08-09 17:37:34 --> Config Class Initialized
INFO - 2016-08-09 17:37:34 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:37:34 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:37:34 --> Utf8 Class Initialized
INFO - 2016-08-09 17:37:34 --> URI Class Initialized
INFO - 2016-08-09 17:37:34 --> Router Class Initialized
INFO - 2016-08-09 17:37:34 --> Output Class Initialized
INFO - 2016-08-09 17:37:34 --> Security Class Initialized
DEBUG - 2016-08-09 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:37:34 --> Input Class Initialized
INFO - 2016-08-09 17:37:34 --> Language Class Initialized
INFO - 2016-08-09 17:37:34 --> Loader Class Initialized
INFO - 2016-08-09 17:37:34 --> Helper loaded: url_helper
INFO - 2016-08-09 17:37:34 --> Database Driver Class Initialized
INFO - 2016-08-09 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:37:34 --> Email Class Initialized
INFO - 2016-08-09 17:37:34 --> Model Class Initialized
INFO - 2016-08-09 17:37:34 --> Controller Class Initialized
INFO - 2016-08-09 17:37:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:37:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:37:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:37:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:37:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:37:34 --> Final output sent to browser
DEBUG - 2016-08-09 17:37:34 --> Total execution time: 0.3891
INFO - 2016-08-09 17:37:47 --> Config Class Initialized
INFO - 2016-08-09 17:37:47 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:37:47 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:37:48 --> Utf8 Class Initialized
INFO - 2016-08-09 17:37:48 --> URI Class Initialized
INFO - 2016-08-09 17:37:48 --> Router Class Initialized
INFO - 2016-08-09 17:37:48 --> Output Class Initialized
INFO - 2016-08-09 17:37:48 --> Security Class Initialized
DEBUG - 2016-08-09 17:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:37:48 --> Input Class Initialized
INFO - 2016-08-09 17:37:48 --> Language Class Initialized
INFO - 2016-08-09 17:37:48 --> Loader Class Initialized
INFO - 2016-08-09 17:37:48 --> Helper loaded: url_helper
INFO - 2016-08-09 17:37:48 --> Database Driver Class Initialized
INFO - 2016-08-09 17:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:37:48 --> Email Class Initialized
INFO - 2016-08-09 17:37:48 --> Model Class Initialized
INFO - 2016-08-09 17:37:48 --> Controller Class Initialized
INFO - 2016-08-09 17:37:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:37:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:37:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:37:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:37:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:37:48 --> Final output sent to browser
DEBUG - 2016-08-09 17:37:48 --> Total execution time: 0.3940
INFO - 2016-08-09 17:38:07 --> Config Class Initialized
INFO - 2016-08-09 17:38:07 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:38:07 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:38:07 --> Utf8 Class Initialized
INFO - 2016-08-09 17:38:07 --> URI Class Initialized
INFO - 2016-08-09 17:38:07 --> Router Class Initialized
INFO - 2016-08-09 17:38:07 --> Output Class Initialized
INFO - 2016-08-09 17:38:07 --> Security Class Initialized
DEBUG - 2016-08-09 17:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:38:07 --> Input Class Initialized
INFO - 2016-08-09 17:38:07 --> Language Class Initialized
INFO - 2016-08-09 17:38:07 --> Loader Class Initialized
INFO - 2016-08-09 17:38:07 --> Helper loaded: url_helper
INFO - 2016-08-09 17:38:07 --> Database Driver Class Initialized
INFO - 2016-08-09 17:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:38:07 --> Email Class Initialized
INFO - 2016-08-09 17:38:07 --> Model Class Initialized
INFO - 2016-08-09 17:38:07 --> Controller Class Initialized
INFO - 2016-08-09 17:38:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:38:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:38:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:38:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:38:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:38:07 --> Final output sent to browser
DEBUG - 2016-08-09 17:38:07 --> Total execution time: 0.3891
INFO - 2016-08-09 17:38:50 --> Config Class Initialized
INFO - 2016-08-09 17:38:50 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:38:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:38:50 --> Utf8 Class Initialized
INFO - 2016-08-09 17:38:50 --> URI Class Initialized
INFO - 2016-08-09 17:38:50 --> Router Class Initialized
INFO - 2016-08-09 17:38:50 --> Output Class Initialized
INFO - 2016-08-09 17:38:50 --> Security Class Initialized
DEBUG - 2016-08-09 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:38:50 --> Input Class Initialized
INFO - 2016-08-09 17:38:50 --> Language Class Initialized
INFO - 2016-08-09 17:38:50 --> Loader Class Initialized
INFO - 2016-08-09 17:38:50 --> Helper loaded: url_helper
INFO - 2016-08-09 17:38:50 --> Database Driver Class Initialized
INFO - 2016-08-09 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:38:50 --> Email Class Initialized
INFO - 2016-08-09 17:38:50 --> Model Class Initialized
INFO - 2016-08-09 17:38:50 --> Controller Class Initialized
INFO - 2016-08-09 17:38:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:38:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:38:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:38:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:38:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:38:51 --> Final output sent to browser
DEBUG - 2016-08-09 17:38:51 --> Total execution time: 0.4013
INFO - 2016-08-09 17:39:27 --> Config Class Initialized
INFO - 2016-08-09 17:39:27 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:39:27 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:39:27 --> Utf8 Class Initialized
INFO - 2016-08-09 17:39:27 --> URI Class Initialized
INFO - 2016-08-09 17:39:27 --> Router Class Initialized
INFO - 2016-08-09 17:39:27 --> Output Class Initialized
INFO - 2016-08-09 17:39:27 --> Security Class Initialized
DEBUG - 2016-08-09 17:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:39:27 --> Input Class Initialized
INFO - 2016-08-09 17:39:27 --> Language Class Initialized
INFO - 2016-08-09 17:39:27 --> Loader Class Initialized
INFO - 2016-08-09 17:39:27 --> Helper loaded: url_helper
INFO - 2016-08-09 17:39:27 --> Database Driver Class Initialized
INFO - 2016-08-09 17:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:39:27 --> Email Class Initialized
INFO - 2016-08-09 17:39:27 --> Model Class Initialized
INFO - 2016-08-09 17:39:27 --> Controller Class Initialized
INFO - 2016-08-09 17:39:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:39:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:39:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:39:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:39:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:39:27 --> Final output sent to browser
DEBUG - 2016-08-09 17:39:27 --> Total execution time: 0.4522
INFO - 2016-08-09 17:45:50 --> Config Class Initialized
INFO - 2016-08-09 17:45:50 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:45:50 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:45:50 --> Utf8 Class Initialized
INFO - 2016-08-09 17:45:50 --> URI Class Initialized
INFO - 2016-08-09 17:45:50 --> Router Class Initialized
INFO - 2016-08-09 17:45:50 --> Output Class Initialized
INFO - 2016-08-09 17:45:50 --> Security Class Initialized
DEBUG - 2016-08-09 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:45:50 --> Input Class Initialized
INFO - 2016-08-09 17:45:50 --> Language Class Initialized
INFO - 2016-08-09 17:45:50 --> Loader Class Initialized
INFO - 2016-08-09 17:45:50 --> Helper loaded: url_helper
INFO - 2016-08-09 17:45:50 --> Database Driver Class Initialized
INFO - 2016-08-09 17:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:45:50 --> Email Class Initialized
INFO - 2016-08-09 17:45:50 --> Model Class Initialized
INFO - 2016-08-09 17:45:50 --> Controller Class Initialized
INFO - 2016-08-09 17:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:45:50 --> Final output sent to browser
DEBUG - 2016-08-09 17:45:50 --> Total execution time: 0.3972
INFO - 2016-08-09 17:46:02 --> Config Class Initialized
INFO - 2016-08-09 17:46:02 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:46:02 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:46:02 --> Utf8 Class Initialized
INFO - 2016-08-09 17:46:02 --> URI Class Initialized
INFO - 2016-08-09 17:46:02 --> Router Class Initialized
INFO - 2016-08-09 17:46:02 --> Output Class Initialized
INFO - 2016-08-09 17:46:02 --> Security Class Initialized
DEBUG - 2016-08-09 17:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:46:02 --> Input Class Initialized
INFO - 2016-08-09 17:46:02 --> Language Class Initialized
INFO - 2016-08-09 17:46:02 --> Loader Class Initialized
INFO - 2016-08-09 17:46:02 --> Helper loaded: url_helper
INFO - 2016-08-09 17:46:02 --> Database Driver Class Initialized
INFO - 2016-08-09 17:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:46:02 --> Email Class Initialized
INFO - 2016-08-09 17:46:02 --> Model Class Initialized
INFO - 2016-08-09 17:46:02 --> Controller Class Initialized
INFO - 2016-08-09 17:46:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:46:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:46:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:46:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:46:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:46:02 --> Final output sent to browser
DEBUG - 2016-08-09 17:46:03 --> Total execution time: 0.4033
INFO - 2016-08-09 17:46:20 --> Config Class Initialized
INFO - 2016-08-09 17:46:20 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:46:20 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:46:20 --> Utf8 Class Initialized
INFO - 2016-08-09 17:46:20 --> URI Class Initialized
INFO - 2016-08-09 17:46:21 --> Router Class Initialized
INFO - 2016-08-09 17:46:21 --> Output Class Initialized
INFO - 2016-08-09 17:46:21 --> Security Class Initialized
DEBUG - 2016-08-09 17:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:46:21 --> Input Class Initialized
INFO - 2016-08-09 17:46:21 --> Language Class Initialized
INFO - 2016-08-09 17:46:21 --> Loader Class Initialized
INFO - 2016-08-09 17:46:21 --> Helper loaded: url_helper
INFO - 2016-08-09 17:46:21 --> Database Driver Class Initialized
INFO - 2016-08-09 17:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:46:21 --> Email Class Initialized
INFO - 2016-08-09 17:46:21 --> Model Class Initialized
INFO - 2016-08-09 17:46:21 --> Controller Class Initialized
INFO - 2016-08-09 17:46:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:46:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:46:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:46:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:46:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:46:21 --> Final output sent to browser
DEBUG - 2016-08-09 17:46:21 --> Total execution time: 0.3990
INFO - 2016-08-09 17:46:42 --> Config Class Initialized
INFO - 2016-08-09 17:46:42 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:46:42 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:46:42 --> Utf8 Class Initialized
INFO - 2016-08-09 17:46:42 --> URI Class Initialized
INFO - 2016-08-09 17:46:42 --> Router Class Initialized
INFO - 2016-08-09 17:46:42 --> Output Class Initialized
INFO - 2016-08-09 17:46:42 --> Security Class Initialized
DEBUG - 2016-08-09 17:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:46:42 --> Input Class Initialized
INFO - 2016-08-09 17:46:42 --> Language Class Initialized
INFO - 2016-08-09 17:46:42 --> Loader Class Initialized
INFO - 2016-08-09 17:46:43 --> Helper loaded: url_helper
INFO - 2016-08-09 17:46:43 --> Database Driver Class Initialized
INFO - 2016-08-09 17:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:46:43 --> Email Class Initialized
INFO - 2016-08-09 17:46:43 --> Model Class Initialized
INFO - 2016-08-09 17:46:43 --> Controller Class Initialized
INFO - 2016-08-09 17:46:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:46:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:46:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:46:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:46:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:46:43 --> Final output sent to browser
DEBUG - 2016-08-09 17:46:43 --> Total execution time: 0.3933
INFO - 2016-08-09 17:46:54 --> Config Class Initialized
INFO - 2016-08-09 17:46:54 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:46:54 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:46:54 --> Utf8 Class Initialized
INFO - 2016-08-09 17:46:54 --> URI Class Initialized
INFO - 2016-08-09 17:46:54 --> Router Class Initialized
INFO - 2016-08-09 17:46:54 --> Output Class Initialized
INFO - 2016-08-09 17:46:54 --> Security Class Initialized
DEBUG - 2016-08-09 17:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:46:54 --> Input Class Initialized
INFO - 2016-08-09 17:46:54 --> Language Class Initialized
INFO - 2016-08-09 17:46:54 --> Loader Class Initialized
INFO - 2016-08-09 17:46:54 --> Helper loaded: url_helper
INFO - 2016-08-09 17:46:54 --> Database Driver Class Initialized
INFO - 2016-08-09 17:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:46:55 --> Email Class Initialized
INFO - 2016-08-09 17:46:55 --> Model Class Initialized
INFO - 2016-08-09 17:46:55 --> Controller Class Initialized
INFO - 2016-08-09 17:46:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:46:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:46:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:46:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:46:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:46:55 --> Final output sent to browser
DEBUG - 2016-08-09 17:46:55 --> Total execution time: 0.4173
INFO - 2016-08-09 17:48:17 --> Config Class Initialized
INFO - 2016-08-09 17:48:17 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:48:17 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:48:17 --> Utf8 Class Initialized
INFO - 2016-08-09 17:48:17 --> URI Class Initialized
INFO - 2016-08-09 17:48:17 --> Router Class Initialized
INFO - 2016-08-09 17:48:17 --> Output Class Initialized
INFO - 2016-08-09 17:48:17 --> Security Class Initialized
DEBUG - 2016-08-09 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:48:17 --> Input Class Initialized
INFO - 2016-08-09 17:48:17 --> Language Class Initialized
INFO - 2016-08-09 17:48:17 --> Loader Class Initialized
INFO - 2016-08-09 17:48:17 --> Helper loaded: url_helper
INFO - 2016-08-09 17:48:17 --> Database Driver Class Initialized
INFO - 2016-08-09 17:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:48:18 --> Email Class Initialized
INFO - 2016-08-09 17:48:18 --> Model Class Initialized
INFO - 2016-08-09 17:48:18 --> Controller Class Initialized
INFO - 2016-08-09 17:48:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:48:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:48:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:48:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:48:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:48:18 --> Final output sent to browser
DEBUG - 2016-08-09 17:48:18 --> Total execution time: 0.3980
INFO - 2016-08-09 17:49:26 --> Config Class Initialized
INFO - 2016-08-09 17:49:26 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:49:26 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:49:26 --> Utf8 Class Initialized
INFO - 2016-08-09 17:49:26 --> URI Class Initialized
INFO - 2016-08-09 17:49:26 --> Router Class Initialized
INFO - 2016-08-09 17:49:27 --> Output Class Initialized
INFO - 2016-08-09 17:49:27 --> Security Class Initialized
DEBUG - 2016-08-09 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:49:27 --> Input Class Initialized
INFO - 2016-08-09 17:49:27 --> Language Class Initialized
INFO - 2016-08-09 17:49:27 --> Loader Class Initialized
INFO - 2016-08-09 17:49:27 --> Helper loaded: url_helper
INFO - 2016-08-09 17:49:27 --> Database Driver Class Initialized
INFO - 2016-08-09 17:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:49:27 --> Email Class Initialized
INFO - 2016-08-09 17:49:27 --> Model Class Initialized
INFO - 2016-08-09 17:49:27 --> Controller Class Initialized
INFO - 2016-08-09 17:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:49:27 --> Final output sent to browser
DEBUG - 2016-08-09 17:49:27 --> Total execution time: 0.4023
INFO - 2016-08-09 17:49:35 --> Config Class Initialized
INFO - 2016-08-09 17:49:35 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:49:35 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:49:35 --> Utf8 Class Initialized
INFO - 2016-08-09 17:49:35 --> URI Class Initialized
INFO - 2016-08-09 17:49:35 --> Router Class Initialized
INFO - 2016-08-09 17:49:35 --> Output Class Initialized
INFO - 2016-08-09 17:49:35 --> Security Class Initialized
DEBUG - 2016-08-09 17:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:49:35 --> Input Class Initialized
INFO - 2016-08-09 17:49:36 --> Language Class Initialized
ERROR - 2016-08-09 17:49:36 --> 404 Page Not Found: Content/create_page
INFO - 2016-08-09 17:49:37 --> Config Class Initialized
INFO - 2016-08-09 17:49:37 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:49:37 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:49:37 --> Utf8 Class Initialized
INFO - 2016-08-09 17:49:37 --> URI Class Initialized
INFO - 2016-08-09 17:49:38 --> Router Class Initialized
INFO - 2016-08-09 17:49:38 --> Output Class Initialized
INFO - 2016-08-09 17:49:38 --> Security Class Initialized
DEBUG - 2016-08-09 17:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:49:38 --> Input Class Initialized
INFO - 2016-08-09 17:49:38 --> Language Class Initialized
INFO - 2016-08-09 17:49:38 --> Loader Class Initialized
INFO - 2016-08-09 17:49:38 --> Helper loaded: url_helper
INFO - 2016-08-09 17:49:38 --> Database Driver Class Initialized
INFO - 2016-08-09 17:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:49:38 --> Email Class Initialized
INFO - 2016-08-09 17:49:38 --> Model Class Initialized
INFO - 2016-08-09 17:49:38 --> Controller Class Initialized
INFO - 2016-08-09 17:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:49:38 --> Final output sent to browser
DEBUG - 2016-08-09 17:49:38 --> Total execution time: 0.4121
INFO - 2016-08-09 17:51:23 --> Config Class Initialized
INFO - 2016-08-09 17:51:23 --> Hooks Class Initialized
DEBUG - 2016-08-09 17:51:23 --> UTF-8 Support Enabled
INFO - 2016-08-09 17:51:23 --> Utf8 Class Initialized
INFO - 2016-08-09 17:51:23 --> URI Class Initialized
INFO - 2016-08-09 17:51:23 --> Router Class Initialized
INFO - 2016-08-09 17:51:23 --> Output Class Initialized
INFO - 2016-08-09 17:51:23 --> Security Class Initialized
DEBUG - 2016-08-09 17:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 17:51:23 --> Input Class Initialized
INFO - 2016-08-09 17:51:23 --> Language Class Initialized
INFO - 2016-08-09 17:51:23 --> Loader Class Initialized
INFO - 2016-08-09 17:51:23 --> Helper loaded: url_helper
INFO - 2016-08-09 17:51:23 --> Database Driver Class Initialized
INFO - 2016-08-09 17:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 17:51:23 --> Email Class Initialized
INFO - 2016-08-09 17:51:23 --> Model Class Initialized
INFO - 2016-08-09 17:51:23 --> Controller Class Initialized
INFO - 2016-08-09 17:51:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 17:51:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 17:51:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 17:51:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 17:51:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 17:51:24 --> Final output sent to browser
DEBUG - 2016-08-09 17:51:24 --> Total execution time: 0.4302
INFO - 2016-08-09 18:03:33 --> Config Class Initialized
INFO - 2016-08-09 18:03:33 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:03:33 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:03:33 --> Utf8 Class Initialized
INFO - 2016-08-09 18:03:33 --> URI Class Initialized
INFO - 2016-08-09 18:03:33 --> Router Class Initialized
INFO - 2016-08-09 18:03:33 --> Output Class Initialized
INFO - 2016-08-09 18:03:33 --> Security Class Initialized
DEBUG - 2016-08-09 18:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:03:33 --> Input Class Initialized
INFO - 2016-08-09 18:03:33 --> Language Class Initialized
INFO - 2016-08-09 18:03:33 --> Loader Class Initialized
INFO - 2016-08-09 18:03:33 --> Helper loaded: url_helper
INFO - 2016-08-09 18:03:33 --> Database Driver Class Initialized
INFO - 2016-08-09 18:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:03:33 --> Email Class Initialized
INFO - 2016-08-09 18:03:33 --> Model Class Initialized
INFO - 2016-08-09 18:03:33 --> Controller Class Initialized
INFO - 2016-08-09 18:03:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:03:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:03:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:03:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:03:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:03:33 --> Final output sent to browser
DEBUG - 2016-08-09 18:03:33 --> Total execution time: 0.4078
INFO - 2016-08-09 18:03:49 --> Config Class Initialized
INFO - 2016-08-09 18:03:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:03:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:03:49 --> Utf8 Class Initialized
INFO - 2016-08-09 18:03:49 --> URI Class Initialized
INFO - 2016-08-09 18:03:49 --> Router Class Initialized
INFO - 2016-08-09 18:03:49 --> Output Class Initialized
INFO - 2016-08-09 18:03:49 --> Security Class Initialized
DEBUG - 2016-08-09 18:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:03:49 --> Input Class Initialized
INFO - 2016-08-09 18:03:49 --> Language Class Initialized
INFO - 2016-08-09 18:03:49 --> Loader Class Initialized
INFO - 2016-08-09 18:03:49 --> Helper loaded: url_helper
INFO - 2016-08-09 18:03:49 --> Database Driver Class Initialized
INFO - 2016-08-09 18:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:03:49 --> Email Class Initialized
INFO - 2016-08-09 18:03:49 --> Model Class Initialized
INFO - 2016-08-09 18:03:49 --> Controller Class Initialized
INFO - 2016-08-09 18:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:03:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:03:49 --> Final output sent to browser
DEBUG - 2016-08-09 18:03:49 --> Total execution time: 0.4721
INFO - 2016-08-09 18:04:05 --> Config Class Initialized
INFO - 2016-08-09 18:04:05 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:04:05 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:04:05 --> Utf8 Class Initialized
INFO - 2016-08-09 18:04:05 --> URI Class Initialized
INFO - 2016-08-09 18:04:05 --> Router Class Initialized
INFO - 2016-08-09 18:04:05 --> Output Class Initialized
INFO - 2016-08-09 18:04:05 --> Security Class Initialized
DEBUG - 2016-08-09 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:04:05 --> Input Class Initialized
INFO - 2016-08-09 18:04:05 --> Language Class Initialized
INFO - 2016-08-09 18:04:05 --> Loader Class Initialized
INFO - 2016-08-09 18:04:05 --> Helper loaded: url_helper
INFO - 2016-08-09 18:04:05 --> Database Driver Class Initialized
INFO - 2016-08-09 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:04:05 --> Email Class Initialized
INFO - 2016-08-09 18:04:05 --> Model Class Initialized
INFO - 2016-08-09 18:04:05 --> Controller Class Initialized
INFO - 2016-08-09 18:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:04:05 --> Final output sent to browser
DEBUG - 2016-08-09 18:04:05 --> Total execution time: 0.4410
INFO - 2016-08-09 18:05:39 --> Config Class Initialized
INFO - 2016-08-09 18:05:39 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:05:39 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:05:39 --> Utf8 Class Initialized
INFO - 2016-08-09 18:05:39 --> URI Class Initialized
INFO - 2016-08-09 18:05:39 --> Router Class Initialized
INFO - 2016-08-09 18:05:39 --> Output Class Initialized
INFO - 2016-08-09 18:05:39 --> Security Class Initialized
DEBUG - 2016-08-09 18:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:05:39 --> Input Class Initialized
INFO - 2016-08-09 18:05:39 --> Language Class Initialized
INFO - 2016-08-09 18:05:39 --> Loader Class Initialized
INFO - 2016-08-09 18:05:39 --> Helper loaded: url_helper
INFO - 2016-08-09 18:05:39 --> Database Driver Class Initialized
INFO - 2016-08-09 18:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:05:39 --> Email Class Initialized
INFO - 2016-08-09 18:05:39 --> Model Class Initialized
INFO - 2016-08-09 18:05:39 --> Controller Class Initialized
INFO - 2016-08-09 18:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:05:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:05:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:05:40 --> Final output sent to browser
DEBUG - 2016-08-09 18:05:40 --> Total execution time: 0.5875
INFO - 2016-08-09 18:10:05 --> Config Class Initialized
INFO - 2016-08-09 18:10:05 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:10:05 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:10:05 --> Utf8 Class Initialized
INFO - 2016-08-09 18:10:05 --> URI Class Initialized
INFO - 2016-08-09 18:10:05 --> Router Class Initialized
INFO - 2016-08-09 18:10:05 --> Output Class Initialized
INFO - 2016-08-09 18:10:05 --> Security Class Initialized
DEBUG - 2016-08-09 18:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:10:05 --> Input Class Initialized
INFO - 2016-08-09 18:10:05 --> Language Class Initialized
INFO - 2016-08-09 18:10:05 --> Loader Class Initialized
INFO - 2016-08-09 18:10:05 --> Helper loaded: url_helper
INFO - 2016-08-09 18:10:05 --> Database Driver Class Initialized
INFO - 2016-08-09 18:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:10:05 --> Email Class Initialized
INFO - 2016-08-09 18:10:05 --> Model Class Initialized
INFO - 2016-08-09 18:10:05 --> Controller Class Initialized
INFO - 2016-08-09 18:10:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:10:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:10:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 18:10:06 --> Severity: Error --> Call to undefined function unix_to_human() D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\tambah_page.php 3
INFO - 2016-08-09 18:10:56 --> Config Class Initialized
INFO - 2016-08-09 18:10:56 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:10:56 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:10:56 --> Utf8 Class Initialized
INFO - 2016-08-09 18:10:56 --> URI Class Initialized
INFO - 2016-08-09 18:10:56 --> Router Class Initialized
INFO - 2016-08-09 18:10:56 --> Output Class Initialized
INFO - 2016-08-09 18:10:56 --> Security Class Initialized
DEBUG - 2016-08-09 18:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:10:56 --> Input Class Initialized
INFO - 2016-08-09 18:10:56 --> Language Class Initialized
INFO - 2016-08-09 18:10:56 --> Loader Class Initialized
INFO - 2016-08-09 18:10:56 --> Helper loaded: url_helper
INFO - 2016-08-09 18:10:56 --> Database Driver Class Initialized
INFO - 2016-08-09 18:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:10:56 --> Email Class Initialized
INFO - 2016-08-09 18:10:56 --> Model Class Initialized
INFO - 2016-08-09 18:10:56 --> Controller Class Initialized
INFO - 2016-08-09 18:10:56 --> Helper loaded: date_helper
INFO - 2016-08-09 18:10:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:10:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:10:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:10:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:10:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:10:56 --> Final output sent to browser
DEBUG - 2016-08-09 18:10:56 --> Total execution time: 0.5160
INFO - 2016-08-09 18:11:30 --> Config Class Initialized
INFO - 2016-08-09 18:11:30 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:11:30 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:11:30 --> Utf8 Class Initialized
INFO - 2016-08-09 18:11:30 --> URI Class Initialized
INFO - 2016-08-09 18:11:31 --> Router Class Initialized
INFO - 2016-08-09 18:11:31 --> Output Class Initialized
INFO - 2016-08-09 18:11:31 --> Security Class Initialized
DEBUG - 2016-08-09 18:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:11:31 --> Input Class Initialized
INFO - 2016-08-09 18:11:31 --> Language Class Initialized
INFO - 2016-08-09 18:11:31 --> Loader Class Initialized
INFO - 2016-08-09 18:11:31 --> Helper loaded: url_helper
INFO - 2016-08-09 18:11:31 --> Database Driver Class Initialized
INFO - 2016-08-09 18:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:11:31 --> Email Class Initialized
INFO - 2016-08-09 18:11:31 --> Model Class Initialized
INFO - 2016-08-09 18:11:31 --> Controller Class Initialized
INFO - 2016-08-09 18:11:31 --> Helper loaded: date_helper
INFO - 2016-08-09 18:11:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:11:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:11:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:11:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:11:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:11:31 --> Final output sent to browser
DEBUG - 2016-08-09 18:11:31 --> Total execution time: 0.4353
INFO - 2016-08-09 18:11:59 --> Config Class Initialized
INFO - 2016-08-09 18:11:59 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:11:59 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:11:59 --> Utf8 Class Initialized
INFO - 2016-08-09 18:11:59 --> URI Class Initialized
INFO - 2016-08-09 18:11:59 --> Router Class Initialized
INFO - 2016-08-09 18:11:59 --> Output Class Initialized
INFO - 2016-08-09 18:12:00 --> Security Class Initialized
DEBUG - 2016-08-09 18:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:12:00 --> Input Class Initialized
INFO - 2016-08-09 18:12:00 --> Language Class Initialized
INFO - 2016-08-09 18:12:00 --> Loader Class Initialized
INFO - 2016-08-09 18:12:00 --> Helper loaded: url_helper
INFO - 2016-08-09 18:12:00 --> Database Driver Class Initialized
INFO - 2016-08-09 18:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:12:00 --> Email Class Initialized
INFO - 2016-08-09 18:12:00 --> Model Class Initialized
INFO - 2016-08-09 18:12:00 --> Controller Class Initialized
INFO - 2016-08-09 18:12:00 --> Helper loaded: date_helper
INFO - 2016-08-09 18:12:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:12:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:12:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:12:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:12:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:12:00 --> Final output sent to browser
DEBUG - 2016-08-09 18:12:00 --> Total execution time: 0.4366
INFO - 2016-08-09 18:12:52 --> Config Class Initialized
INFO - 2016-08-09 18:12:52 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:12:52 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:12:52 --> Utf8 Class Initialized
INFO - 2016-08-09 18:12:52 --> URI Class Initialized
INFO - 2016-08-09 18:12:52 --> Router Class Initialized
INFO - 2016-08-09 18:12:52 --> Output Class Initialized
INFO - 2016-08-09 18:12:52 --> Security Class Initialized
DEBUG - 2016-08-09 18:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:12:52 --> Input Class Initialized
INFO - 2016-08-09 18:12:52 --> Language Class Initialized
INFO - 2016-08-09 18:12:52 --> Loader Class Initialized
INFO - 2016-08-09 18:12:52 --> Helper loaded: url_helper
INFO - 2016-08-09 18:12:52 --> Helper loaded: date_helper
INFO - 2016-08-09 18:12:52 --> Database Driver Class Initialized
INFO - 2016-08-09 18:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:12:52 --> Email Class Initialized
INFO - 2016-08-09 18:12:52 --> Model Class Initialized
INFO - 2016-08-09 18:12:52 --> Controller Class Initialized
INFO - 2016-08-09 18:12:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:12:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:12:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:12:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:12:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:12:52 --> Final output sent to browser
DEBUG - 2016-08-09 18:12:52 --> Total execution time: 0.4590
INFO - 2016-08-09 18:14:35 --> Config Class Initialized
INFO - 2016-08-09 18:14:35 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:14:35 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:14:35 --> Utf8 Class Initialized
INFO - 2016-08-09 18:14:35 --> URI Class Initialized
INFO - 2016-08-09 18:14:35 --> Router Class Initialized
INFO - 2016-08-09 18:14:36 --> Output Class Initialized
INFO - 2016-08-09 18:14:36 --> Security Class Initialized
DEBUG - 2016-08-09 18:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:14:36 --> Input Class Initialized
INFO - 2016-08-09 18:14:36 --> Language Class Initialized
INFO - 2016-08-09 18:14:36 --> Loader Class Initialized
INFO - 2016-08-09 18:14:36 --> Helper loaded: url_helper
INFO - 2016-08-09 18:14:36 --> Helper loaded: date_helper
INFO - 2016-08-09 18:14:36 --> Database Driver Class Initialized
INFO - 2016-08-09 18:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:14:36 --> Email Class Initialized
INFO - 2016-08-09 18:14:36 --> Model Class Initialized
INFO - 2016-08-09 18:14:36 --> Controller Class Initialized
INFO - 2016-08-09 18:14:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:14:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:14:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 18:14:36 --> Severity: Notice --> Undefined variable: human D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\tambah_page.php 36
INFO - 2016-08-09 18:14:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:14:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:14:36 --> Final output sent to browser
DEBUG - 2016-08-09 18:14:36 --> Total execution time: 0.4545
INFO - 2016-08-09 18:14:49 --> Config Class Initialized
INFO - 2016-08-09 18:14:49 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:14:49 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:14:49 --> Utf8 Class Initialized
INFO - 2016-08-09 18:14:49 --> URI Class Initialized
INFO - 2016-08-09 18:14:49 --> Router Class Initialized
INFO - 2016-08-09 18:14:49 --> Output Class Initialized
INFO - 2016-08-09 18:14:49 --> Security Class Initialized
DEBUG - 2016-08-09 18:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:14:49 --> Input Class Initialized
INFO - 2016-08-09 18:14:49 --> Language Class Initialized
INFO - 2016-08-09 18:14:49 --> Loader Class Initialized
INFO - 2016-08-09 18:14:49 --> Helper loaded: url_helper
INFO - 2016-08-09 18:14:49 --> Helper loaded: date_helper
INFO - 2016-08-09 18:14:49 --> Database Driver Class Initialized
INFO - 2016-08-09 18:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:14:49 --> Email Class Initialized
INFO - 2016-08-09 18:14:49 --> Model Class Initialized
INFO - 2016-08-09 18:14:49 --> Controller Class Initialized
INFO - 2016-08-09 18:14:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:14:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:14:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:14:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:14:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:14:49 --> Final output sent to browser
DEBUG - 2016-08-09 18:14:49 --> Total execution time: 0.4333
INFO - 2016-08-09 18:15:20 --> Config Class Initialized
INFO - 2016-08-09 18:15:20 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:15:20 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:15:20 --> Utf8 Class Initialized
INFO - 2016-08-09 18:15:20 --> URI Class Initialized
INFO - 2016-08-09 18:15:20 --> Router Class Initialized
INFO - 2016-08-09 18:15:20 --> Output Class Initialized
INFO - 2016-08-09 18:15:20 --> Security Class Initialized
DEBUG - 2016-08-09 18:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:15:20 --> Input Class Initialized
INFO - 2016-08-09 18:15:20 --> Language Class Initialized
INFO - 2016-08-09 18:15:20 --> Loader Class Initialized
INFO - 2016-08-09 18:15:20 --> Helper loaded: url_helper
INFO - 2016-08-09 18:15:20 --> Helper loaded: date_helper
INFO - 2016-08-09 18:15:20 --> Database Driver Class Initialized
INFO - 2016-08-09 18:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:15:20 --> Email Class Initialized
INFO - 2016-08-09 18:15:20 --> Model Class Initialized
INFO - 2016-08-09 18:15:20 --> Controller Class Initialized
INFO - 2016-08-09 18:15:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:15:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:15:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:15:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:15:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:15:20 --> Final output sent to browser
DEBUG - 2016-08-09 18:15:20 --> Total execution time: 0.4681
INFO - 2016-08-09 18:17:18 --> Config Class Initialized
INFO - 2016-08-09 18:17:18 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:17:18 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:17:18 --> Utf8 Class Initialized
INFO - 2016-08-09 18:17:18 --> URI Class Initialized
INFO - 2016-08-09 18:17:18 --> Router Class Initialized
INFO - 2016-08-09 18:17:18 --> Output Class Initialized
INFO - 2016-08-09 18:17:18 --> Security Class Initialized
DEBUG - 2016-08-09 18:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:17:18 --> Input Class Initialized
INFO - 2016-08-09 18:17:18 --> Language Class Initialized
INFO - 2016-08-09 18:17:18 --> Loader Class Initialized
INFO - 2016-08-09 18:17:18 --> Helper loaded: url_helper
INFO - 2016-08-09 18:17:18 --> Helper loaded: date_helper
INFO - 2016-08-09 18:17:18 --> Database Driver Class Initialized
INFO - 2016-08-09 18:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:17:18 --> Email Class Initialized
INFO - 2016-08-09 18:17:18 --> Model Class Initialized
INFO - 2016-08-09 18:17:18 --> Controller Class Initialized
INFO - 2016-08-09 18:17:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:17:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:17:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:17:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:17:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:17:18 --> Final output sent to browser
DEBUG - 2016-08-09 18:17:18 --> Total execution time: 0.4391
INFO - 2016-08-09 18:17:41 --> Config Class Initialized
INFO - 2016-08-09 18:17:41 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:17:41 --> UTF-8 Support Enabled
INFO - 2016-08-09 18:17:41 --> Utf8 Class Initialized
INFO - 2016-08-09 18:17:41 --> URI Class Initialized
INFO - 2016-08-09 18:17:41 --> Router Class Initialized
INFO - 2016-08-09 18:17:41 --> Output Class Initialized
INFO - 2016-08-09 18:17:41 --> Security Class Initialized
DEBUG - 2016-08-09 18:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 18:17:41 --> Input Class Initialized
INFO - 2016-08-09 18:17:41 --> Language Class Initialized
INFO - 2016-08-09 18:17:41 --> Loader Class Initialized
INFO - 2016-08-09 18:17:41 --> Helper loaded: url_helper
INFO - 2016-08-09 18:17:41 --> Helper loaded: date_helper
INFO - 2016-08-09 18:17:41 --> Database Driver Class Initialized
INFO - 2016-08-09 18:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 18:17:41 --> Email Class Initialized
INFO - 2016-08-09 18:17:41 --> Model Class Initialized
INFO - 2016-08-09 18:17:41 --> Controller Class Initialized
INFO - 2016-08-09 18:17:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 18:17:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 18:17:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 18:17:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 18:17:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 18:17:42 --> Final output sent to browser
DEBUG - 2016-08-09 18:17:42 --> Total execution time: 0.4372
INFO - 2016-08-09 23:19:08 --> Config Class Initialized
INFO - 2016-08-09 23:19:08 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:19:08 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:19:08 --> Utf8 Class Initialized
INFO - 2016-08-09 23:19:08 --> URI Class Initialized
INFO - 2016-08-09 23:19:08 --> Router Class Initialized
INFO - 2016-08-09 23:19:08 --> Output Class Initialized
INFO - 2016-08-09 23:19:08 --> Security Class Initialized
DEBUG - 2016-08-09 23:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:19:08 --> Input Class Initialized
INFO - 2016-08-09 23:19:08 --> Language Class Initialized
INFO - 2016-08-09 23:19:08 --> Loader Class Initialized
INFO - 2016-08-09 23:19:08 --> Helper loaded: url_helper
INFO - 2016-08-09 23:19:08 --> Helper loaded: date_helper
INFO - 2016-08-09 23:19:08 --> Database Driver Class Initialized
INFO - 2016-08-09 23:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:19:08 --> Email Class Initialized
INFO - 2016-08-09 23:19:08 --> Model Class Initialized
INFO - 2016-08-09 23:19:08 --> Controller Class Initialized
INFO - 2016-08-09 23:19:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:19:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:19:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:19:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:19:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:19:08 --> Final output sent to browser
DEBUG - 2016-08-09 23:19:08 --> Total execution time: 0.4533
INFO - 2016-08-09 23:27:35 --> Config Class Initialized
INFO - 2016-08-09 23:27:35 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:27:35 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:27:35 --> Utf8 Class Initialized
INFO - 2016-08-09 23:27:35 --> URI Class Initialized
INFO - 2016-08-09 23:27:35 --> Router Class Initialized
INFO - 2016-08-09 23:27:35 --> Output Class Initialized
INFO - 2016-08-09 23:27:35 --> Security Class Initialized
DEBUG - 2016-08-09 23:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:27:35 --> Input Class Initialized
INFO - 2016-08-09 23:27:35 --> Language Class Initialized
INFO - 2016-08-09 23:27:35 --> Loader Class Initialized
INFO - 2016-08-09 23:27:35 --> Helper loaded: url_helper
INFO - 2016-08-09 23:27:35 --> Helper loaded: date_helper
INFO - 2016-08-09 23:27:35 --> Database Driver Class Initialized
INFO - 2016-08-09 23:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:27:35 --> Email Class Initialized
INFO - 2016-08-09 23:27:35 --> Model Class Initialized
INFO - 2016-08-09 23:27:35 --> Controller Class Initialized
INFO - 2016-08-09 23:27:57 --> Config Class Initialized
INFO - 2016-08-09 23:27:57 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:27:57 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:27:57 --> Utf8 Class Initialized
INFO - 2016-08-09 23:27:57 --> URI Class Initialized
INFO - 2016-08-09 23:27:57 --> Router Class Initialized
INFO - 2016-08-09 23:27:57 --> Output Class Initialized
INFO - 2016-08-09 23:27:57 --> Security Class Initialized
DEBUG - 2016-08-09 23:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:27:57 --> Input Class Initialized
INFO - 2016-08-09 23:27:57 --> Language Class Initialized
INFO - 2016-08-09 23:27:57 --> Loader Class Initialized
INFO - 2016-08-09 23:27:57 --> Helper loaded: url_helper
INFO - 2016-08-09 23:27:57 --> Helper loaded: date_helper
INFO - 2016-08-09 23:27:57 --> Database Driver Class Initialized
INFO - 2016-08-09 23:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:27:58 --> Email Class Initialized
INFO - 2016-08-09 23:27:58 --> Model Class Initialized
INFO - 2016-08-09 23:27:58 --> Controller Class Initialized
INFO - 2016-08-09 23:28:32 --> Config Class Initialized
INFO - 2016-08-09 23:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:28:32 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:28:32 --> Utf8 Class Initialized
INFO - 2016-08-09 23:28:32 --> URI Class Initialized
INFO - 2016-08-09 23:28:32 --> Router Class Initialized
INFO - 2016-08-09 23:28:32 --> Output Class Initialized
INFO - 2016-08-09 23:28:32 --> Security Class Initialized
DEBUG - 2016-08-09 23:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:28:32 --> Input Class Initialized
INFO - 2016-08-09 23:28:32 --> Language Class Initialized
INFO - 2016-08-09 23:28:32 --> Loader Class Initialized
INFO - 2016-08-09 23:28:32 --> Helper loaded: url_helper
INFO - 2016-08-09 23:28:32 --> Helper loaded: date_helper
INFO - 2016-08-09 23:28:32 --> Database Driver Class Initialized
INFO - 2016-08-09 23:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:28:32 --> Email Class Initialized
INFO - 2016-08-09 23:28:32 --> Model Class Initialized
INFO - 2016-08-09 23:28:32 --> Controller Class Initialized
INFO - 2016-08-09 23:28:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:28:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:28:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:28:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:28:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:28:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:28:32 --> Final output sent to browser
DEBUG - 2016-08-09 23:28:32 --> Total execution time: 0.4691
INFO - 2016-08-09 23:30:33 --> Config Class Initialized
INFO - 2016-08-09 23:30:33 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:30:33 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:30:33 --> Utf8 Class Initialized
INFO - 2016-08-09 23:30:33 --> URI Class Initialized
INFO - 2016-08-09 23:30:33 --> Router Class Initialized
INFO - 2016-08-09 23:30:33 --> Output Class Initialized
INFO - 2016-08-09 23:30:33 --> Security Class Initialized
DEBUG - 2016-08-09 23:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:30:33 --> Input Class Initialized
INFO - 2016-08-09 23:30:33 --> Language Class Initialized
INFO - 2016-08-09 23:30:33 --> Loader Class Initialized
INFO - 2016-08-09 23:30:33 --> Helper loaded: url_helper
INFO - 2016-08-09 23:30:33 --> Helper loaded: date_helper
INFO - 2016-08-09 23:30:33 --> Database Driver Class Initialized
INFO - 2016-08-09 23:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:30:33 --> Email Class Initialized
INFO - 2016-08-09 23:30:33 --> Model Class Initialized
INFO - 2016-08-09 23:30:33 --> Controller Class Initialized
INFO - 2016-08-09 23:30:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:30:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:30:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:30:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-09 23:30:33 --> Severity: Notice --> A non well formed numeric value encountered D:\xampp\htdocs\aqiqahsehati\application\helpers\Tanggal_indonesia_helper.php 72
INFO - 2016-08-09 23:30:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:30:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:30:33 --> Final output sent to browser
DEBUG - 2016-08-09 23:30:33 --> Total execution time: 0.4955
INFO - 2016-08-09 23:31:25 --> Config Class Initialized
INFO - 2016-08-09 23:31:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:31:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:31:25 --> Utf8 Class Initialized
INFO - 2016-08-09 23:31:25 --> URI Class Initialized
INFO - 2016-08-09 23:31:25 --> Router Class Initialized
INFO - 2016-08-09 23:31:25 --> Output Class Initialized
INFO - 2016-08-09 23:31:25 --> Security Class Initialized
DEBUG - 2016-08-09 23:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:31:25 --> Input Class Initialized
INFO - 2016-08-09 23:31:25 --> Language Class Initialized
INFO - 2016-08-09 23:31:25 --> Loader Class Initialized
INFO - 2016-08-09 23:31:25 --> Helper loaded: url_helper
INFO - 2016-08-09 23:31:25 --> Helper loaded: date_helper
INFO - 2016-08-09 23:31:25 --> Database Driver Class Initialized
INFO - 2016-08-09 23:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:31:26 --> Email Class Initialized
INFO - 2016-08-09 23:31:26 --> Model Class Initialized
INFO - 2016-08-09 23:31:26 --> Controller Class Initialized
INFO - 2016-08-09 23:31:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:31:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:31:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:31:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:31:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:31:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:31:26 --> Final output sent to browser
DEBUG - 2016-08-09 23:31:26 --> Total execution time: 0.4550
INFO - 2016-08-09 23:31:52 --> Config Class Initialized
INFO - 2016-08-09 23:31:52 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:31:52 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:31:52 --> Utf8 Class Initialized
INFO - 2016-08-09 23:31:52 --> URI Class Initialized
INFO - 2016-08-09 23:31:52 --> Router Class Initialized
INFO - 2016-08-09 23:31:52 --> Output Class Initialized
INFO - 2016-08-09 23:31:52 --> Security Class Initialized
DEBUG - 2016-08-09 23:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:31:52 --> Input Class Initialized
INFO - 2016-08-09 23:31:52 --> Language Class Initialized
INFO - 2016-08-09 23:31:52 --> Loader Class Initialized
INFO - 2016-08-09 23:31:52 --> Helper loaded: url_helper
INFO - 2016-08-09 23:31:52 --> Helper loaded: date_helper
INFO - 2016-08-09 23:31:52 --> Database Driver Class Initialized
INFO - 2016-08-09 23:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:31:52 --> Email Class Initialized
INFO - 2016-08-09 23:31:52 --> Model Class Initialized
INFO - 2016-08-09 23:31:52 --> Controller Class Initialized
INFO - 2016-08-09 23:31:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:31:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:31:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:31:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:31:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:31:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:31:52 --> Final output sent to browser
DEBUG - 2016-08-09 23:31:52 --> Total execution time: 0.4658
INFO - 2016-08-09 23:32:07 --> Config Class Initialized
INFO - 2016-08-09 23:32:07 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:32:07 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:32:07 --> Utf8 Class Initialized
INFO - 2016-08-09 23:32:07 --> URI Class Initialized
INFO - 2016-08-09 23:32:07 --> Router Class Initialized
INFO - 2016-08-09 23:32:07 --> Output Class Initialized
INFO - 2016-08-09 23:32:07 --> Security Class Initialized
DEBUG - 2016-08-09 23:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:32:07 --> Input Class Initialized
INFO - 2016-08-09 23:32:07 --> Language Class Initialized
INFO - 2016-08-09 23:32:07 --> Loader Class Initialized
INFO - 2016-08-09 23:32:07 --> Helper loaded: url_helper
INFO - 2016-08-09 23:32:07 --> Helper loaded: date_helper
INFO - 2016-08-09 23:32:07 --> Database Driver Class Initialized
INFO - 2016-08-09 23:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:32:07 --> Email Class Initialized
INFO - 2016-08-09 23:32:07 --> Model Class Initialized
INFO - 2016-08-09 23:32:07 --> Controller Class Initialized
INFO - 2016-08-09 23:32:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:32:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:32:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:32:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:32:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:32:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:32:07 --> Final output sent to browser
DEBUG - 2016-08-09 23:32:07 --> Total execution time: 0.4660
INFO - 2016-08-09 23:32:17 --> Config Class Initialized
INFO - 2016-08-09 23:32:17 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:32:17 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:32:17 --> Utf8 Class Initialized
INFO - 2016-08-09 23:32:17 --> URI Class Initialized
INFO - 2016-08-09 23:32:17 --> Router Class Initialized
INFO - 2016-08-09 23:32:17 --> Output Class Initialized
INFO - 2016-08-09 23:32:17 --> Security Class Initialized
DEBUG - 2016-08-09 23:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:32:17 --> Input Class Initialized
INFO - 2016-08-09 23:32:17 --> Language Class Initialized
INFO - 2016-08-09 23:32:17 --> Loader Class Initialized
INFO - 2016-08-09 23:32:17 --> Helper loaded: url_helper
INFO - 2016-08-09 23:32:17 --> Helper loaded: date_helper
INFO - 2016-08-09 23:32:17 --> Database Driver Class Initialized
INFO - 2016-08-09 23:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:32:17 --> Email Class Initialized
INFO - 2016-08-09 23:32:17 --> Model Class Initialized
INFO - 2016-08-09 23:32:17 --> Controller Class Initialized
INFO - 2016-08-09 23:32:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:32:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:32:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:32:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:32:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:32:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:32:18 --> Final output sent to browser
DEBUG - 2016-08-09 23:32:18 --> Total execution time: 0.4624
INFO - 2016-08-09 23:32:44 --> Config Class Initialized
INFO - 2016-08-09 23:32:44 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:32:44 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:32:44 --> Utf8 Class Initialized
INFO - 2016-08-09 23:32:44 --> URI Class Initialized
INFO - 2016-08-09 23:32:44 --> Router Class Initialized
INFO - 2016-08-09 23:32:44 --> Output Class Initialized
INFO - 2016-08-09 23:32:44 --> Security Class Initialized
DEBUG - 2016-08-09 23:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:32:44 --> Input Class Initialized
INFO - 2016-08-09 23:32:44 --> Language Class Initialized
INFO - 2016-08-09 23:32:44 --> Loader Class Initialized
INFO - 2016-08-09 23:32:44 --> Helper loaded: url_helper
INFO - 2016-08-09 23:32:44 --> Helper loaded: date_helper
INFO - 2016-08-09 23:32:44 --> Database Driver Class Initialized
INFO - 2016-08-09 23:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:32:44 --> Email Class Initialized
INFO - 2016-08-09 23:32:44 --> Model Class Initialized
INFO - 2016-08-09 23:32:44 --> Controller Class Initialized
INFO - 2016-08-09 23:32:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:32:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:32:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:32:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:32:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:32:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:32:44 --> Final output sent to browser
DEBUG - 2016-08-09 23:32:44 --> Total execution time: 0.4687
INFO - 2016-08-09 23:33:03 --> Config Class Initialized
INFO - 2016-08-09 23:33:03 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:33:03 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:33:03 --> Utf8 Class Initialized
INFO - 2016-08-09 23:33:03 --> URI Class Initialized
INFO - 2016-08-09 23:33:03 --> Router Class Initialized
INFO - 2016-08-09 23:33:03 --> Output Class Initialized
INFO - 2016-08-09 23:33:03 --> Security Class Initialized
DEBUG - 2016-08-09 23:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:33:03 --> Input Class Initialized
INFO - 2016-08-09 23:33:03 --> Language Class Initialized
INFO - 2016-08-09 23:33:03 --> Loader Class Initialized
INFO - 2016-08-09 23:33:03 --> Helper loaded: url_helper
INFO - 2016-08-09 23:33:03 --> Helper loaded: date_helper
INFO - 2016-08-09 23:33:03 --> Database Driver Class Initialized
INFO - 2016-08-09 23:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:33:03 --> Email Class Initialized
INFO - 2016-08-09 23:33:03 --> Model Class Initialized
INFO - 2016-08-09 23:33:03 --> Controller Class Initialized
INFO - 2016-08-09 23:33:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:33:04 --> Final output sent to browser
DEBUG - 2016-08-09 23:33:04 --> Total execution time: 0.4614
INFO - 2016-08-09 23:34:43 --> Config Class Initialized
INFO - 2016-08-09 23:34:43 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:34:43 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:34:43 --> Utf8 Class Initialized
INFO - 2016-08-09 23:34:43 --> URI Class Initialized
INFO - 2016-08-09 23:34:43 --> Router Class Initialized
INFO - 2016-08-09 23:34:43 --> Output Class Initialized
INFO - 2016-08-09 23:34:43 --> Security Class Initialized
DEBUG - 2016-08-09 23:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:34:44 --> Input Class Initialized
INFO - 2016-08-09 23:34:44 --> Language Class Initialized
INFO - 2016-08-09 23:34:44 --> Loader Class Initialized
INFO - 2016-08-09 23:34:44 --> Helper loaded: url_helper
INFO - 2016-08-09 23:34:44 --> Helper loaded: date_helper
INFO - 2016-08-09 23:34:44 --> Database Driver Class Initialized
INFO - 2016-08-09 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:34:44 --> Email Class Initialized
INFO - 2016-08-09 23:34:44 --> Model Class Initialized
INFO - 2016-08-09 23:34:44 --> Controller Class Initialized
INFO - 2016-08-09 23:34:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:34:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:34:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:34:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:34:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:34:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:34:44 --> Final output sent to browser
DEBUG - 2016-08-09 23:34:44 --> Total execution time: 0.4776
INFO - 2016-08-09 23:35:11 --> Config Class Initialized
INFO - 2016-08-09 23:35:11 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:35:11 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:35:12 --> Utf8 Class Initialized
INFO - 2016-08-09 23:35:12 --> URI Class Initialized
INFO - 2016-08-09 23:35:12 --> Router Class Initialized
INFO - 2016-08-09 23:35:12 --> Output Class Initialized
INFO - 2016-08-09 23:35:12 --> Security Class Initialized
DEBUG - 2016-08-09 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:35:12 --> Input Class Initialized
INFO - 2016-08-09 23:35:12 --> Language Class Initialized
INFO - 2016-08-09 23:35:12 --> Loader Class Initialized
INFO - 2016-08-09 23:35:12 --> Helper loaded: url_helper
INFO - 2016-08-09 23:35:12 --> Helper loaded: date_helper
INFO - 2016-08-09 23:35:12 --> Database Driver Class Initialized
INFO - 2016-08-09 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:35:12 --> Email Class Initialized
INFO - 2016-08-09 23:35:12 --> Model Class Initialized
INFO - 2016-08-09 23:35:12 --> Controller Class Initialized
INFO - 2016-08-09 23:35:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:35:12 --> Final output sent to browser
DEBUG - 2016-08-09 23:35:12 --> Total execution time: 0.4703
INFO - 2016-08-09 23:35:31 --> Config Class Initialized
INFO - 2016-08-09 23:35:31 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:35:31 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:35:31 --> Utf8 Class Initialized
INFO - 2016-08-09 23:35:31 --> URI Class Initialized
INFO - 2016-08-09 23:35:31 --> Router Class Initialized
INFO - 2016-08-09 23:35:31 --> Output Class Initialized
INFO - 2016-08-09 23:35:31 --> Security Class Initialized
DEBUG - 2016-08-09 23:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:35:31 --> Input Class Initialized
INFO - 2016-08-09 23:35:31 --> Language Class Initialized
INFO - 2016-08-09 23:35:31 --> Loader Class Initialized
INFO - 2016-08-09 23:35:31 --> Helper loaded: url_helper
INFO - 2016-08-09 23:35:31 --> Helper loaded: date_helper
INFO - 2016-08-09 23:35:31 --> Database Driver Class Initialized
INFO - 2016-08-09 23:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:35:31 --> Email Class Initialized
INFO - 2016-08-09 23:35:31 --> Model Class Initialized
INFO - 2016-08-09 23:35:31 --> Controller Class Initialized
INFO - 2016-08-09 23:35:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:35:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:35:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:35:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:35:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:35:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:35:31 --> Final output sent to browser
DEBUG - 2016-08-09 23:35:31 --> Total execution time: 0.4673
INFO - 2016-08-09 23:47:54 --> Config Class Initialized
INFO - 2016-08-09 23:47:54 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:47:54 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:47:54 --> Utf8 Class Initialized
INFO - 2016-08-09 23:47:54 --> URI Class Initialized
INFO - 2016-08-09 23:47:54 --> Router Class Initialized
INFO - 2016-08-09 23:47:54 --> Output Class Initialized
INFO - 2016-08-09 23:47:54 --> Security Class Initialized
DEBUG - 2016-08-09 23:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:47:54 --> Input Class Initialized
INFO - 2016-08-09 23:47:54 --> Language Class Initialized
INFO - 2016-08-09 23:47:54 --> Loader Class Initialized
INFO - 2016-08-09 23:47:54 --> Helper loaded: url_helper
INFO - 2016-08-09 23:47:54 --> Helper loaded: date_helper
INFO - 2016-08-09 23:47:54 --> Database Driver Class Initialized
INFO - 2016-08-09 23:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:47:54 --> Email Class Initialized
INFO - 2016-08-09 23:47:54 --> Model Class Initialized
INFO - 2016-08-09 23:47:54 --> Controller Class Initialized
INFO - 2016-08-09 23:47:54 --> Helper loaded: tanggal_indonesia_helper
ERROR - 2016-08-09 23:47:54 --> Severity: Notice --> Undefined property: Content::$ion_auth D:\xampp\htdocs\aqiqahsehati\application\controllers\Content.php 43
ERROR - 2016-08-09 23:47:54 --> Severity: Error --> Call to a member function user() on a non-object D:\xampp\htdocs\aqiqahsehati\application\controllers\Content.php 43
INFO - 2016-08-09 23:48:25 --> Config Class Initialized
INFO - 2016-08-09 23:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:48:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:48:25 --> Utf8 Class Initialized
INFO - 2016-08-09 23:48:25 --> URI Class Initialized
INFO - 2016-08-09 23:48:25 --> Router Class Initialized
INFO - 2016-08-09 23:48:25 --> Output Class Initialized
INFO - 2016-08-09 23:48:25 --> Security Class Initialized
DEBUG - 2016-08-09 23:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:48:25 --> Input Class Initialized
INFO - 2016-08-09 23:48:25 --> Language Class Initialized
INFO - 2016-08-09 23:48:25 --> Loader Class Initialized
INFO - 2016-08-09 23:48:25 --> Helper loaded: url_helper
INFO - 2016-08-09 23:48:25 --> Helper loaded: date_helper
INFO - 2016-08-09 23:48:25 --> Database Driver Class Initialized
INFO - 2016-08-09 23:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:48:25 --> Email Class Initialized
INFO - 2016-08-09 23:48:25 --> Model Class Initialized
INFO - 2016-08-09 23:48:25 --> Controller Class Initialized
INFO - 2016-08-09 23:48:25 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-09 23:48:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:48:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:48:25 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:48:25 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:25 --> Model Class Initialized
INFO - 2016-08-09 23:48:25 --> Config Class Initialized
INFO - 2016-08-09 23:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:48:25 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:48:26 --> Utf8 Class Initialized
INFO - 2016-08-09 23:48:26 --> URI Class Initialized
INFO - 2016-08-09 23:48:26 --> Router Class Initialized
INFO - 2016-08-09 23:48:26 --> Output Class Initialized
INFO - 2016-08-09 23:48:26 --> Security Class Initialized
DEBUG - 2016-08-09 23:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:48:26 --> Input Class Initialized
INFO - 2016-08-09 23:48:26 --> Language Class Initialized
INFO - 2016-08-09 23:48:26 --> Loader Class Initialized
INFO - 2016-08-09 23:48:26 --> Helper loaded: url_helper
INFO - 2016-08-09 23:48:26 --> Helper loaded: date_helper
INFO - 2016-08-09 23:48:26 --> Database Driver Class Initialized
INFO - 2016-08-09 23:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:48:26 --> Email Class Initialized
INFO - 2016-08-09 23:48:26 --> Model Class Initialized
INFO - 2016-08-09 23:48:26 --> Controller Class Initialized
DEBUG - 2016-08-09 23:48:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:48:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:48:26 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:48:26 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:26 --> Model Class Initialized
INFO - 2016-08-09 23:48:26 --> Helper loaded: form_helper
INFO - 2016-08-09 23:48:26 --> Form Validation Class Initialized
INFO - 2016-08-09 23:48:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 23:48:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-09 23:48:26 --> Final output sent to browser
DEBUG - 2016-08-09 23:48:26 --> Total execution time: 0.8676
INFO - 2016-08-09 23:48:37 --> Config Class Initialized
INFO - 2016-08-09 23:48:37 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:48:37 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:48:37 --> Utf8 Class Initialized
INFO - 2016-08-09 23:48:37 --> URI Class Initialized
INFO - 2016-08-09 23:48:37 --> Router Class Initialized
INFO - 2016-08-09 23:48:37 --> Output Class Initialized
INFO - 2016-08-09 23:48:37 --> Security Class Initialized
DEBUG - 2016-08-09 23:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:48:37 --> Input Class Initialized
INFO - 2016-08-09 23:48:37 --> Language Class Initialized
INFO - 2016-08-09 23:48:37 --> Loader Class Initialized
INFO - 2016-08-09 23:48:37 --> Helper loaded: url_helper
INFO - 2016-08-09 23:48:37 --> Helper loaded: date_helper
INFO - 2016-08-09 23:48:37 --> Database Driver Class Initialized
INFO - 2016-08-09 23:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:48:37 --> Email Class Initialized
INFO - 2016-08-09 23:48:37 --> Model Class Initialized
INFO - 2016-08-09 23:48:37 --> Controller Class Initialized
DEBUG - 2016-08-09 23:48:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:48:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:48:37 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:48:37 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:37 --> Model Class Initialized
INFO - 2016-08-09 23:48:37 --> Helper loaded: form_helper
INFO - 2016-08-09 23:48:37 --> Form Validation Class Initialized
INFO - 2016-08-09 23:48:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-09 23:48:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-09 23:48:38 --> Config Class Initialized
INFO - 2016-08-09 23:48:38 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:48:38 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:48:38 --> Utf8 Class Initialized
INFO - 2016-08-09 23:48:38 --> URI Class Initialized
INFO - 2016-08-09 23:48:38 --> Router Class Initialized
INFO - 2016-08-09 23:48:38 --> Output Class Initialized
INFO - 2016-08-09 23:48:38 --> Security Class Initialized
DEBUG - 2016-08-09 23:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:48:38 --> Input Class Initialized
INFO - 2016-08-09 23:48:38 --> Language Class Initialized
INFO - 2016-08-09 23:48:38 --> Loader Class Initialized
INFO - 2016-08-09 23:48:38 --> Helper loaded: url_helper
INFO - 2016-08-09 23:48:38 --> Helper loaded: date_helper
INFO - 2016-08-09 23:48:38 --> Database Driver Class Initialized
INFO - 2016-08-09 23:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:48:38 --> Email Class Initialized
INFO - 2016-08-09 23:48:38 --> Model Class Initialized
INFO - 2016-08-09 23:48:38 --> Controller Class Initialized
DEBUG - 2016-08-09 23:48:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:48:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:48:38 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:48:38 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:48:38 --> Model Class Initialized
INFO - 2016-08-09 23:48:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:48:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:48:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:48:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 23:48:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:48:38 --> Final output sent to browser
DEBUG - 2016-08-09 23:48:38 --> Total execution time: 0.6511
INFO - 2016-08-09 23:49:32 --> Config Class Initialized
INFO - 2016-08-09 23:49:32 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:49:32 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:49:32 --> Utf8 Class Initialized
INFO - 2016-08-09 23:49:32 --> URI Class Initialized
INFO - 2016-08-09 23:49:32 --> Router Class Initialized
INFO - 2016-08-09 23:49:32 --> Output Class Initialized
INFO - 2016-08-09 23:49:32 --> Security Class Initialized
DEBUG - 2016-08-09 23:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:49:32 --> Input Class Initialized
INFO - 2016-08-09 23:49:32 --> Language Class Initialized
INFO - 2016-08-09 23:49:32 --> Loader Class Initialized
INFO - 2016-08-09 23:49:32 --> Helper loaded: url_helper
INFO - 2016-08-09 23:49:32 --> Helper loaded: date_helper
INFO - 2016-08-09 23:49:32 --> Database Driver Class Initialized
INFO - 2016-08-09 23:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:49:32 --> Email Class Initialized
INFO - 2016-08-09 23:49:32 --> Model Class Initialized
INFO - 2016-08-09 23:49:32 --> Controller Class Initialized
DEBUG - 2016-08-09 23:49:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:49:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:49:32 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:49:32 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:32 --> Model Class Initialized
INFO - 2016-08-09 23:49:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:49:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:49:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:49:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-09 23:49:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:49:32 --> Final output sent to browser
DEBUG - 2016-08-09 23:49:32 --> Total execution time: 0.5884
INFO - 2016-08-09 23:49:36 --> Config Class Initialized
INFO - 2016-08-09 23:49:36 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:49:36 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:49:36 --> Utf8 Class Initialized
INFO - 2016-08-09 23:49:36 --> URI Class Initialized
INFO - 2016-08-09 23:49:36 --> Router Class Initialized
INFO - 2016-08-09 23:49:36 --> Output Class Initialized
INFO - 2016-08-09 23:49:36 --> Security Class Initialized
DEBUG - 2016-08-09 23:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:49:36 --> Input Class Initialized
INFO - 2016-08-09 23:49:37 --> Language Class Initialized
INFO - 2016-08-09 23:49:37 --> Loader Class Initialized
INFO - 2016-08-09 23:49:37 --> Helper loaded: url_helper
INFO - 2016-08-09 23:49:37 --> Helper loaded: date_helper
INFO - 2016-08-09 23:49:37 --> Database Driver Class Initialized
INFO - 2016-08-09 23:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:49:37 --> Email Class Initialized
INFO - 2016-08-09 23:49:37 --> Model Class Initialized
INFO - 2016-08-09 23:49:37 --> Controller Class Initialized
INFO - 2016-08-09 23:49:37 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-09 23:49:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:49:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:49:37 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:49:37 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:37 --> Model Class Initialized
INFO - 2016-08-09 23:49:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:49:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:49:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:49:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-09 23:49:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:49:37 --> Final output sent to browser
DEBUG - 2016-08-09 23:49:37 --> Total execution time: 0.6241
INFO - 2016-08-09 23:49:39 --> Config Class Initialized
INFO - 2016-08-09 23:49:39 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:49:39 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:49:39 --> Utf8 Class Initialized
INFO - 2016-08-09 23:49:39 --> URI Class Initialized
INFO - 2016-08-09 23:49:39 --> Router Class Initialized
INFO - 2016-08-09 23:49:39 --> Output Class Initialized
INFO - 2016-08-09 23:49:39 --> Security Class Initialized
DEBUG - 2016-08-09 23:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:49:39 --> Input Class Initialized
INFO - 2016-08-09 23:49:40 --> Language Class Initialized
INFO - 2016-08-09 23:49:40 --> Loader Class Initialized
INFO - 2016-08-09 23:49:40 --> Helper loaded: url_helper
INFO - 2016-08-09 23:49:40 --> Helper loaded: date_helper
INFO - 2016-08-09 23:49:40 --> Database Driver Class Initialized
INFO - 2016-08-09 23:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:49:40 --> Email Class Initialized
INFO - 2016-08-09 23:49:40 --> Model Class Initialized
INFO - 2016-08-09 23:49:40 --> Controller Class Initialized
INFO - 2016-08-09 23:49:40 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-09 23:49:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:49:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:49:40 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:49:40 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:40 --> Model Class Initialized
INFO - 2016-08-09 23:49:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:49:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:49:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:49:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:49:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:49:40 --> Final output sent to browser
DEBUG - 2016-08-09 23:49:40 --> Total execution time: 0.6143
INFO - 2016-08-09 23:49:42 --> Config Class Initialized
INFO - 2016-08-09 23:49:42 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:49:42 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:49:42 --> Utf8 Class Initialized
INFO - 2016-08-09 23:49:42 --> URI Class Initialized
INFO - 2016-08-09 23:49:42 --> Router Class Initialized
INFO - 2016-08-09 23:49:42 --> Output Class Initialized
INFO - 2016-08-09 23:49:42 --> Security Class Initialized
DEBUG - 2016-08-09 23:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:49:42 --> Input Class Initialized
INFO - 2016-08-09 23:49:42 --> Language Class Initialized
INFO - 2016-08-09 23:49:42 --> Loader Class Initialized
INFO - 2016-08-09 23:49:42 --> Helper loaded: url_helper
INFO - 2016-08-09 23:49:42 --> Helper loaded: date_helper
INFO - 2016-08-09 23:49:42 --> Database Driver Class Initialized
INFO - 2016-08-09 23:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:49:43 --> Email Class Initialized
INFO - 2016-08-09 23:49:43 --> Model Class Initialized
INFO - 2016-08-09 23:49:43 --> Controller Class Initialized
INFO - 2016-08-09 23:49:43 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-09 23:49:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:49:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:49:43 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:49:43 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:49:43 --> Model Class Initialized
ERROR - 2016-08-09 23:49:43 --> Severity: Notice --> Undefined property: Content::$id D:\xampp\htdocs\aqiqahsehati\system\core\Model.php 77
INFO - 2016-08-09 23:49:43 --> Final output sent to browser
DEBUG - 2016-08-09 23:49:43 --> Total execution time: 0.5717
INFO - 2016-08-09 23:50:31 --> Config Class Initialized
INFO - 2016-08-09 23:50:31 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:50:31 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:50:31 --> Utf8 Class Initialized
INFO - 2016-08-09 23:50:31 --> URI Class Initialized
INFO - 2016-08-09 23:50:31 --> Router Class Initialized
INFO - 2016-08-09 23:50:31 --> Output Class Initialized
INFO - 2016-08-09 23:50:31 --> Security Class Initialized
DEBUG - 2016-08-09 23:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:50:31 --> Input Class Initialized
INFO - 2016-08-09 23:50:31 --> Language Class Initialized
INFO - 2016-08-09 23:50:31 --> Loader Class Initialized
INFO - 2016-08-09 23:50:31 --> Helper loaded: url_helper
INFO - 2016-08-09 23:50:31 --> Helper loaded: date_helper
INFO - 2016-08-09 23:50:31 --> Database Driver Class Initialized
INFO - 2016-08-09 23:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:50:31 --> Email Class Initialized
INFO - 2016-08-09 23:50:31 --> Model Class Initialized
INFO - 2016-08-09 23:50:31 --> Controller Class Initialized
INFO - 2016-08-09 23:50:31 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-09 23:50:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:50:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:50:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:50:32 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:50:32 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:50:32 --> Model Class Initialized
INFO - 2016-08-09 23:50:32 --> Final output sent to browser
DEBUG - 2016-08-09 23:50:32 --> Total execution time: 0.5319
INFO - 2016-08-09 23:53:26 --> Config Class Initialized
INFO - 2016-08-09 23:53:26 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:53:26 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:53:26 --> Utf8 Class Initialized
INFO - 2016-08-09 23:53:26 --> URI Class Initialized
INFO - 2016-08-09 23:53:26 --> Router Class Initialized
INFO - 2016-08-09 23:53:26 --> Output Class Initialized
INFO - 2016-08-09 23:53:26 --> Security Class Initialized
DEBUG - 2016-08-09 23:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:53:26 --> Input Class Initialized
INFO - 2016-08-09 23:53:26 --> Language Class Initialized
INFO - 2016-08-09 23:53:26 --> Loader Class Initialized
INFO - 2016-08-09 23:53:26 --> Helper loaded: url_helper
INFO - 2016-08-09 23:53:26 --> Helper loaded: date_helper
INFO - 2016-08-09 23:53:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:53:26 --> Database Driver Class Initialized
INFO - 2016-08-09 23:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:53:26 --> Email Class Initialized
INFO - 2016-08-09 23:53:26 --> Model Class Initialized
INFO - 2016-08-09 23:53:26 --> Controller Class Initialized
DEBUG - 2016-08-09 23:53:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:53:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:53:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:53:26 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:53:26 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:53:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:53:26 --> Model Class Initialized
INFO - 2016-08-09 23:53:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:53:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:53:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:53:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:53:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:53:26 --> Final output sent to browser
DEBUG - 2016-08-09 23:53:26 --> Total execution time: 0.8434
INFO - 2016-08-09 23:53:27 --> Config Class Initialized
INFO - 2016-08-09 23:53:28 --> Hooks Class Initialized
DEBUG - 2016-08-09 23:53:28 --> UTF-8 Support Enabled
INFO - 2016-08-09 23:53:28 --> Utf8 Class Initialized
INFO - 2016-08-09 23:53:28 --> URI Class Initialized
INFO - 2016-08-09 23:53:28 --> Router Class Initialized
INFO - 2016-08-09 23:53:28 --> Output Class Initialized
INFO - 2016-08-09 23:53:28 --> Security Class Initialized
DEBUG - 2016-08-09 23:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-09 23:53:28 --> Input Class Initialized
INFO - 2016-08-09 23:53:28 --> Language Class Initialized
INFO - 2016-08-09 23:53:28 --> Loader Class Initialized
INFO - 2016-08-09 23:53:28 --> Helper loaded: url_helper
INFO - 2016-08-09 23:53:28 --> Helper loaded: date_helper
INFO - 2016-08-09 23:53:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-09 23:53:28 --> Database Driver Class Initialized
INFO - 2016-08-09 23:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-09 23:53:28 --> Email Class Initialized
INFO - 2016-08-09 23:53:28 --> Model Class Initialized
INFO - 2016-08-09 23:53:28 --> Controller Class Initialized
DEBUG - 2016-08-09 23:53:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-09 23:53:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:53:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-09 23:53:28 --> Helper loaded: cookie_helper
INFO - 2016-08-09 23:53:28 --> Helper loaded: language_helper
DEBUG - 2016-08-09 23:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-09 23:53:28 --> Model Class Initialized
INFO - 2016-08-09 23:53:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-09 23:53:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-09 23:53:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-09 23:53:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-09 23:53:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-09 23:53:28 --> Final output sent to browser
DEBUG - 2016-08-09 23:53:28 --> Total execution time: 0.6777
