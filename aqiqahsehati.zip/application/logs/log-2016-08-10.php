<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-10 00:22:37 --> Config Class Initialized
INFO - 2016-08-10 00:22:37 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:22:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:22:37 --> Utf8 Class Initialized
INFO - 2016-08-10 00:22:37 --> URI Class Initialized
INFO - 2016-08-10 00:22:38 --> Router Class Initialized
INFO - 2016-08-10 00:22:38 --> Output Class Initialized
INFO - 2016-08-10 00:22:38 --> Security Class Initialized
DEBUG - 2016-08-10 00:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:22:38 --> Input Class Initialized
INFO - 2016-08-10 00:22:38 --> Language Class Initialized
INFO - 2016-08-10 00:22:38 --> Loader Class Initialized
INFO - 2016-08-10 00:22:38 --> Helper loaded: url_helper
INFO - 2016-08-10 00:22:38 --> Helper loaded: date_helper
INFO - 2016-08-10 00:22:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:22:38 --> Database Driver Class Initialized
INFO - 2016-08-10 00:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:22:38 --> Email Class Initialized
INFO - 2016-08-10 00:22:38 --> Model Class Initialized
INFO - 2016-08-10 00:22:38 --> Controller Class Initialized
DEBUG - 2016-08-10 00:22:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:22:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:22:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:22:38 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:22:38 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:22:38 --> Model Class Initialized
INFO - 2016-08-10 00:22:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:22:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:22:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:22:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 00:22:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:22:38 --> Final output sent to browser
DEBUG - 2016-08-10 00:22:38 --> Total execution time: 0.3255
INFO - 2016-08-10 00:23:07 --> Config Class Initialized
INFO - 2016-08-10 00:23:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:23:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:23:07 --> Utf8 Class Initialized
INFO - 2016-08-10 00:23:07 --> URI Class Initialized
INFO - 2016-08-10 00:23:07 --> Router Class Initialized
INFO - 2016-08-10 00:23:07 --> Output Class Initialized
INFO - 2016-08-10 00:23:07 --> Security Class Initialized
DEBUG - 2016-08-10 00:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:23:07 --> Input Class Initialized
INFO - 2016-08-10 00:23:07 --> Language Class Initialized
INFO - 2016-08-10 00:23:07 --> Loader Class Initialized
INFO - 2016-08-10 00:23:07 --> Helper loaded: url_helper
INFO - 2016-08-10 00:23:07 --> Helper loaded: date_helper
INFO - 2016-08-10 00:23:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:23:07 --> Database Driver Class Initialized
INFO - 2016-08-10 00:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:23:07 --> Email Class Initialized
INFO - 2016-08-10 00:23:07 --> Model Class Initialized
INFO - 2016-08-10 00:23:07 --> Controller Class Initialized
DEBUG - 2016-08-10 00:23:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:23:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:23:07 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:23:07 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:07 --> Model Class Initialized
INFO - 2016-08-10 00:23:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:23:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:23:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:23:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 00:23:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:23:07 --> Final output sent to browser
DEBUG - 2016-08-10 00:23:07 --> Total execution time: 0.3205
INFO - 2016-08-10 00:23:27 --> Config Class Initialized
INFO - 2016-08-10 00:23:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:23:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:23:27 --> Utf8 Class Initialized
INFO - 2016-08-10 00:23:27 --> URI Class Initialized
DEBUG - 2016-08-10 00:23:27 --> No URI present. Default controller set.
INFO - 2016-08-10 00:23:27 --> Router Class Initialized
INFO - 2016-08-10 00:23:27 --> Output Class Initialized
INFO - 2016-08-10 00:23:27 --> Security Class Initialized
DEBUG - 2016-08-10 00:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:23:27 --> Input Class Initialized
INFO - 2016-08-10 00:23:27 --> Language Class Initialized
INFO - 2016-08-10 00:23:27 --> Loader Class Initialized
INFO - 2016-08-10 00:23:27 --> Helper loaded: url_helper
INFO - 2016-08-10 00:23:27 --> Helper loaded: date_helper
INFO - 2016-08-10 00:23:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:23:27 --> Database Driver Class Initialized
INFO - 2016-08-10 00:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:23:27 --> Email Class Initialized
INFO - 2016-08-10 00:23:27 --> Model Class Initialized
INFO - 2016-08-10 00:23:27 --> Controller Class Initialized
DEBUG - 2016-08-10 00:23:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:23:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:23:27 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:23:27 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:27 --> Model Class Initialized
INFO - 2016-08-10 00:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 00:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 00:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-10 00:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 00:23:27 --> Final output sent to browser
DEBUG - 2016-08-10 00:23:27 --> Total execution time: 0.4170
INFO - 2016-08-10 00:23:31 --> Config Class Initialized
INFO - 2016-08-10 00:23:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:23:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:23:31 --> Utf8 Class Initialized
INFO - 2016-08-10 00:23:31 --> URI Class Initialized
INFO - 2016-08-10 00:23:31 --> Router Class Initialized
INFO - 2016-08-10 00:23:31 --> Output Class Initialized
INFO - 2016-08-10 00:23:31 --> Security Class Initialized
DEBUG - 2016-08-10 00:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:23:31 --> Input Class Initialized
INFO - 2016-08-10 00:23:31 --> Language Class Initialized
INFO - 2016-08-10 00:23:31 --> Loader Class Initialized
INFO - 2016-08-10 00:23:31 --> Helper loaded: url_helper
INFO - 2016-08-10 00:23:31 --> Helper loaded: date_helper
INFO - 2016-08-10 00:23:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:23:31 --> Database Driver Class Initialized
INFO - 2016-08-10 00:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:23:31 --> Email Class Initialized
INFO - 2016-08-10 00:23:31 --> Model Class Initialized
INFO - 2016-08-10 00:23:31 --> Controller Class Initialized
DEBUG - 2016-08-10 00:23:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:23:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:23:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:23:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:23:31 --> Model Class Initialized
INFO - 2016-08-10 00:23:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 00:23:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 00:23:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-10 00:23:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 00:23:31 --> Final output sent to browser
DEBUG - 2016-08-10 00:23:31 --> Total execution time: 0.4191
INFO - 2016-08-10 00:23:32 --> Config Class Initialized
INFO - 2016-08-10 00:23:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:23:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:23:32 --> Utf8 Class Initialized
INFO - 2016-08-10 00:23:32 --> URI Class Initialized
INFO - 2016-08-10 00:23:32 --> Router Class Initialized
INFO - 2016-08-10 00:23:32 --> Output Class Initialized
INFO - 2016-08-10 00:23:32 --> Security Class Initialized
DEBUG - 2016-08-10 00:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:23:32 --> Input Class Initialized
INFO - 2016-08-10 00:23:32 --> Language Class Initialized
ERROR - 2016-08-10 00:23:32 --> 404 Page Not Found: Assets/css
INFO - 2016-08-10 00:24:33 --> Config Class Initialized
INFO - 2016-08-10 00:24:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:24:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:24:33 --> Utf8 Class Initialized
INFO - 2016-08-10 00:24:33 --> URI Class Initialized
INFO - 2016-08-10 00:24:33 --> Router Class Initialized
INFO - 2016-08-10 00:24:33 --> Output Class Initialized
INFO - 2016-08-10 00:24:33 --> Security Class Initialized
DEBUG - 2016-08-10 00:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:24:33 --> Input Class Initialized
INFO - 2016-08-10 00:24:33 --> Language Class Initialized
INFO - 2016-08-10 00:24:33 --> Loader Class Initialized
INFO - 2016-08-10 00:24:33 --> Helper loaded: url_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: date_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:24:33 --> Database Driver Class Initialized
INFO - 2016-08-10 00:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:24:33 --> Email Class Initialized
INFO - 2016-08-10 00:24:33 --> Model Class Initialized
INFO - 2016-08-10 00:24:33 --> Controller Class Initialized
DEBUG - 2016-08-10 00:24:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:24:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:24:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:24:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:24:33 --> Model Class Initialized
INFO - 2016-08-10 00:24:33 --> Upload Class Initialized
INFO - 2016-08-10 00:24:33 --> Config Class Initialized
INFO - 2016-08-10 00:24:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:24:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:24:33 --> Utf8 Class Initialized
INFO - 2016-08-10 00:24:33 --> URI Class Initialized
INFO - 2016-08-10 00:24:33 --> Router Class Initialized
INFO - 2016-08-10 00:24:33 --> Output Class Initialized
INFO - 2016-08-10 00:24:33 --> Security Class Initialized
DEBUG - 2016-08-10 00:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:24:33 --> Input Class Initialized
INFO - 2016-08-10 00:24:33 --> Language Class Initialized
INFO - 2016-08-10 00:24:33 --> Loader Class Initialized
INFO - 2016-08-10 00:24:33 --> Helper loaded: url_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: date_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:24:33 --> Database Driver Class Initialized
INFO - 2016-08-10 00:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:24:33 --> Email Class Initialized
INFO - 2016-08-10 00:24:33 --> Model Class Initialized
INFO - 2016-08-10 00:24:33 --> Controller Class Initialized
DEBUG - 2016-08-10 00:24:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:24:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:24:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:24:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:24:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:24:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:24:33 --> Model Class Initialized
INFO - 2016-08-10 00:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:24:33 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 51
ERROR - 2016-08-10 00:24:33 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 52
INFO - 2016-08-10 00:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:24:33 --> Final output sent to browser
DEBUG - 2016-08-10 00:24:33 --> Total execution time: 0.3556
INFO - 2016-08-10 00:27:44 --> Config Class Initialized
INFO - 2016-08-10 00:27:44 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:27:44 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:27:44 --> Utf8 Class Initialized
INFO - 2016-08-10 00:27:44 --> URI Class Initialized
INFO - 2016-08-10 00:27:44 --> Router Class Initialized
INFO - 2016-08-10 00:27:44 --> Output Class Initialized
INFO - 2016-08-10 00:27:44 --> Security Class Initialized
DEBUG - 2016-08-10 00:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:27:44 --> Input Class Initialized
INFO - 2016-08-10 00:27:44 --> Language Class Initialized
INFO - 2016-08-10 00:27:44 --> Loader Class Initialized
INFO - 2016-08-10 00:27:44 --> Helper loaded: url_helper
INFO - 2016-08-10 00:27:44 --> Helper loaded: date_helper
INFO - 2016-08-10 00:27:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:27:44 --> Database Driver Class Initialized
INFO - 2016-08-10 00:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:27:44 --> Email Class Initialized
INFO - 2016-08-10 00:27:44 --> Model Class Initialized
INFO - 2016-08-10 00:27:44 --> Controller Class Initialized
DEBUG - 2016-08-10 00:27:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:27:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:27:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:27:44 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:27:44 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:27:44 --> Model Class Initialized
INFO - 2016-08-10 00:27:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:27:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:27:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:27:45 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 51
ERROR - 2016-08-10 00:27:45 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 52
INFO - 2016-08-10 00:27:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:27:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:27:45 --> Final output sent to browser
DEBUG - 2016-08-10 00:27:45 --> Total execution time: 0.8925
INFO - 2016-08-10 00:27:49 --> Config Class Initialized
INFO - 2016-08-10 00:27:49 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:27:49 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:27:49 --> Utf8 Class Initialized
INFO - 2016-08-10 00:27:49 --> URI Class Initialized
INFO - 2016-08-10 00:27:49 --> Router Class Initialized
INFO - 2016-08-10 00:27:49 --> Output Class Initialized
INFO - 2016-08-10 00:27:49 --> Security Class Initialized
DEBUG - 2016-08-10 00:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:27:49 --> Input Class Initialized
INFO - 2016-08-10 00:27:49 --> Language Class Initialized
INFO - 2016-08-10 00:27:49 --> Loader Class Initialized
INFO - 2016-08-10 00:27:49 --> Helper loaded: url_helper
INFO - 2016-08-10 00:27:50 --> Helper loaded: date_helper
INFO - 2016-08-10 00:27:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:27:50 --> Database Driver Class Initialized
INFO - 2016-08-10 00:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:27:50 --> Email Class Initialized
INFO - 2016-08-10 00:27:50 --> Model Class Initialized
INFO - 2016-08-10 00:27:50 --> Controller Class Initialized
DEBUG - 2016-08-10 00:27:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:27:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:27:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:27:51 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:27:51 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:27:51 --> Model Class Initialized
INFO - 2016-08-10 00:27:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 00:27:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 00:27:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-10 00:27:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 00:27:52 --> Final output sent to browser
DEBUG - 2016-08-10 00:27:52 --> Total execution time: 3.0618
INFO - 2016-08-10 00:28:49 --> Config Class Initialized
INFO - 2016-08-10 00:28:49 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:28:49 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:28:49 --> Utf8 Class Initialized
INFO - 2016-08-10 00:28:49 --> URI Class Initialized
INFO - 2016-08-10 00:28:49 --> Router Class Initialized
INFO - 2016-08-10 00:28:49 --> Output Class Initialized
INFO - 2016-08-10 00:28:49 --> Security Class Initialized
DEBUG - 2016-08-10 00:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:28:49 --> Input Class Initialized
INFO - 2016-08-10 00:28:49 --> Language Class Initialized
INFO - 2016-08-10 00:28:49 --> Loader Class Initialized
INFO - 2016-08-10 00:28:49 --> Helper loaded: url_helper
INFO - 2016-08-10 00:28:49 --> Helper loaded: date_helper
INFO - 2016-08-10 00:28:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:28:49 --> Database Driver Class Initialized
INFO - 2016-08-10 00:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:28:49 --> Email Class Initialized
INFO - 2016-08-10 00:28:49 --> Model Class Initialized
INFO - 2016-08-10 00:28:49 --> Controller Class Initialized
DEBUG - 2016-08-10 00:28:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:28:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:28:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:28:49 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:28:49 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:28:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:28:49 --> Model Class Initialized
INFO - 2016-08-10 00:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:28:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 51
ERROR - 2016-08-10 00:28:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 52
INFO - 2016-08-10 00:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:28:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:28:49 --> Final output sent to browser
DEBUG - 2016-08-10 00:28:49 --> Total execution time: 0.3537
INFO - 2016-08-10 00:29:36 --> Config Class Initialized
INFO - 2016-08-10 00:29:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:29:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:29:37 --> Utf8 Class Initialized
INFO - 2016-08-10 00:29:37 --> URI Class Initialized
INFO - 2016-08-10 00:29:37 --> Router Class Initialized
INFO - 2016-08-10 00:29:37 --> Output Class Initialized
INFO - 2016-08-10 00:29:37 --> Security Class Initialized
DEBUG - 2016-08-10 00:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:29:37 --> Input Class Initialized
INFO - 2016-08-10 00:29:37 --> Language Class Initialized
INFO - 2016-08-10 00:29:37 --> Loader Class Initialized
INFO - 2016-08-10 00:29:37 --> Helper loaded: url_helper
INFO - 2016-08-10 00:29:37 --> Helper loaded: date_helper
INFO - 2016-08-10 00:29:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:29:37 --> Database Driver Class Initialized
INFO - 2016-08-10 00:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:29:37 --> Email Class Initialized
INFO - 2016-08-10 00:29:37 --> Model Class Initialized
INFO - 2016-08-10 00:29:37 --> Controller Class Initialized
DEBUG - 2016-08-10 00:29:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:29:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:29:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:29:37 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:29:37 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:29:37 --> Model Class Initialized
INFO - 2016-08-10 00:29:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:29:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:29:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:29:37 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 48
ERROR - 2016-08-10 00:29:37 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 49
INFO - 2016-08-10 00:29:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:29:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:29:37 --> Final output sent to browser
DEBUG - 2016-08-10 00:29:37 --> Total execution time: 0.4614
INFO - 2016-08-10 00:31:25 --> Config Class Initialized
INFO - 2016-08-10 00:31:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:31:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:31:25 --> Utf8 Class Initialized
INFO - 2016-08-10 00:31:25 --> URI Class Initialized
INFO - 2016-08-10 00:31:25 --> Router Class Initialized
INFO - 2016-08-10 00:31:25 --> Output Class Initialized
INFO - 2016-08-10 00:31:25 --> Security Class Initialized
DEBUG - 2016-08-10 00:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:31:25 --> Input Class Initialized
INFO - 2016-08-10 00:31:25 --> Language Class Initialized
INFO - 2016-08-10 00:31:25 --> Loader Class Initialized
INFO - 2016-08-10 00:31:25 --> Helper loaded: url_helper
INFO - 2016-08-10 00:31:25 --> Helper loaded: date_helper
INFO - 2016-08-10 00:31:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:31:25 --> Database Driver Class Initialized
INFO - 2016-08-10 00:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:31:25 --> Email Class Initialized
INFO - 2016-08-10 00:31:25 --> Model Class Initialized
INFO - 2016-08-10 00:31:25 --> Controller Class Initialized
DEBUG - 2016-08-10 00:31:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:31:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:31:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:31:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:31:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:31:25 --> Model Class Initialized
INFO - 2016-08-10 00:31:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:31:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:31:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:31:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:31:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:31:25 --> Final output sent to browser
DEBUG - 2016-08-10 00:31:25 --> Total execution time: 0.3394
INFO - 2016-08-10 00:31:59 --> Config Class Initialized
INFO - 2016-08-10 00:31:59 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:31:59 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:31:59 --> Utf8 Class Initialized
INFO - 2016-08-10 00:31:59 --> URI Class Initialized
INFO - 2016-08-10 00:31:59 --> Router Class Initialized
INFO - 2016-08-10 00:31:59 --> Output Class Initialized
INFO - 2016-08-10 00:31:59 --> Security Class Initialized
DEBUG - 2016-08-10 00:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:31:59 --> Input Class Initialized
INFO - 2016-08-10 00:31:59 --> Language Class Initialized
INFO - 2016-08-10 00:31:59 --> Loader Class Initialized
INFO - 2016-08-10 00:31:59 --> Helper loaded: url_helper
INFO - 2016-08-10 00:31:59 --> Helper loaded: date_helper
INFO - 2016-08-10 00:31:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:31:59 --> Database Driver Class Initialized
INFO - 2016-08-10 00:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:31:59 --> Email Class Initialized
INFO - 2016-08-10 00:31:59 --> Model Class Initialized
INFO - 2016-08-10 00:31:59 --> Controller Class Initialized
DEBUG - 2016-08-10 00:31:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:31:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:31:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:31:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:31:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:31:59 --> Model Class Initialized
INFO - 2016-08-10 00:31:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:31:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:31:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:31:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:31:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:31:59 --> Final output sent to browser
DEBUG - 2016-08-10 00:31:59 --> Total execution time: 0.3618
INFO - 2016-08-10 00:38:32 --> Config Class Initialized
INFO - 2016-08-10 00:38:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:38:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:38:32 --> Utf8 Class Initialized
INFO - 2016-08-10 00:38:32 --> URI Class Initialized
INFO - 2016-08-10 00:38:32 --> Router Class Initialized
INFO - 2016-08-10 00:38:32 --> Output Class Initialized
INFO - 2016-08-10 00:38:32 --> Security Class Initialized
DEBUG - 2016-08-10 00:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:38:32 --> Input Class Initialized
INFO - 2016-08-10 00:38:32 --> Language Class Initialized
INFO - 2016-08-10 00:38:32 --> Loader Class Initialized
INFO - 2016-08-10 00:38:32 --> Helper loaded: url_helper
INFO - 2016-08-10 00:38:32 --> Helper loaded: date_helper
INFO - 2016-08-10 00:38:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:38:33 --> Database Driver Class Initialized
INFO - 2016-08-10 00:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:38:33 --> Email Class Initialized
INFO - 2016-08-10 00:38:33 --> Model Class Initialized
INFO - 2016-08-10 00:38:33 --> Controller Class Initialized
DEBUG - 2016-08-10 00:38:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:38:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:38:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:38:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:38:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:38:33 --> Model Class Initialized
INFO - 2016-08-10 00:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:38:33 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$first_name D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:38:33 --> Final output sent to browser
DEBUG - 2016-08-10 00:38:33 --> Total execution time: 0.3611
INFO - 2016-08-10 00:38:45 --> Config Class Initialized
INFO - 2016-08-10 00:38:45 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:38:45 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:38:45 --> Utf8 Class Initialized
INFO - 2016-08-10 00:38:45 --> URI Class Initialized
INFO - 2016-08-10 00:38:45 --> Router Class Initialized
INFO - 2016-08-10 00:38:45 --> Output Class Initialized
INFO - 2016-08-10 00:38:45 --> Security Class Initialized
DEBUG - 2016-08-10 00:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:38:45 --> Input Class Initialized
INFO - 2016-08-10 00:38:45 --> Language Class Initialized
INFO - 2016-08-10 00:38:45 --> Loader Class Initialized
INFO - 2016-08-10 00:38:45 --> Helper loaded: url_helper
INFO - 2016-08-10 00:38:45 --> Helper loaded: date_helper
INFO - 2016-08-10 00:38:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:38:45 --> Database Driver Class Initialized
INFO - 2016-08-10 00:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:38:45 --> Email Class Initialized
INFO - 2016-08-10 00:38:45 --> Model Class Initialized
INFO - 2016-08-10 00:38:45 --> Controller Class Initialized
DEBUG - 2016-08-10 00:38:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:38:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:38:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:38:45 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:38:45 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:38:45 --> Model Class Initialized
INFO - 2016-08-10 00:38:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:38:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:38:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:38:45 --> Severity: Error --> Cannot use object of type CI_DB_mysqli_result as array D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:39:53 --> Config Class Initialized
INFO - 2016-08-10 00:39:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:39:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:39:53 --> Utf8 Class Initialized
INFO - 2016-08-10 00:39:53 --> URI Class Initialized
INFO - 2016-08-10 00:39:53 --> Router Class Initialized
INFO - 2016-08-10 00:39:53 --> Output Class Initialized
INFO - 2016-08-10 00:39:53 --> Security Class Initialized
DEBUG - 2016-08-10 00:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:39:53 --> Input Class Initialized
INFO - 2016-08-10 00:39:53 --> Language Class Initialized
INFO - 2016-08-10 00:39:53 --> Loader Class Initialized
INFO - 2016-08-10 00:39:53 --> Helper loaded: url_helper
INFO - 2016-08-10 00:39:53 --> Helper loaded: date_helper
INFO - 2016-08-10 00:39:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:39:53 --> Database Driver Class Initialized
INFO - 2016-08-10 00:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:39:53 --> Email Class Initialized
INFO - 2016-08-10 00:39:53 --> Model Class Initialized
INFO - 2016-08-10 00:39:53 --> Controller Class Initialized
DEBUG - 2016-08-10 00:39:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:39:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:39:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:39:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:39:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:39:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:39:53 --> Model Class Initialized
INFO - 2016-08-10 00:39:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:39:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:39:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:39:53 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:40:32 --> Config Class Initialized
INFO - 2016-08-10 00:40:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:40:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:40:32 --> Utf8 Class Initialized
INFO - 2016-08-10 00:40:32 --> URI Class Initialized
INFO - 2016-08-10 00:40:32 --> Router Class Initialized
INFO - 2016-08-10 00:40:32 --> Output Class Initialized
INFO - 2016-08-10 00:40:32 --> Security Class Initialized
DEBUG - 2016-08-10 00:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:40:32 --> Input Class Initialized
INFO - 2016-08-10 00:40:32 --> Language Class Initialized
INFO - 2016-08-10 00:40:32 --> Loader Class Initialized
INFO - 2016-08-10 00:40:32 --> Helper loaded: url_helper
INFO - 2016-08-10 00:40:32 --> Helper loaded: date_helper
INFO - 2016-08-10 00:40:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:40:32 --> Database Driver Class Initialized
INFO - 2016-08-10 00:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:40:32 --> Email Class Initialized
INFO - 2016-08-10 00:40:32 --> Model Class Initialized
INFO - 2016-08-10 00:40:32 --> Controller Class Initialized
DEBUG - 2016-08-10 00:40:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:40:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:40:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:40:32 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:40:32 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:40:32 --> Model Class Initialized
INFO - 2016-08-10 00:40:32 --> Final output sent to browser
DEBUG - 2016-08-10 00:40:32 --> Total execution time: 0.4788
INFO - 2016-08-10 00:41:01 --> Config Class Initialized
INFO - 2016-08-10 00:41:01 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:41:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:41:01 --> Utf8 Class Initialized
INFO - 2016-08-10 00:41:01 --> URI Class Initialized
INFO - 2016-08-10 00:41:01 --> Router Class Initialized
INFO - 2016-08-10 00:41:01 --> Output Class Initialized
INFO - 2016-08-10 00:41:01 --> Security Class Initialized
DEBUG - 2016-08-10 00:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:41:01 --> Input Class Initialized
INFO - 2016-08-10 00:41:01 --> Language Class Initialized
INFO - 2016-08-10 00:41:01 --> Loader Class Initialized
INFO - 2016-08-10 00:41:01 --> Helper loaded: url_helper
INFO - 2016-08-10 00:41:01 --> Helper loaded: date_helper
INFO - 2016-08-10 00:41:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:41:01 --> Database Driver Class Initialized
INFO - 2016-08-10 00:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:41:01 --> Email Class Initialized
INFO - 2016-08-10 00:41:01 --> Model Class Initialized
INFO - 2016-08-10 00:41:01 --> Controller Class Initialized
DEBUG - 2016-08-10 00:41:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:41:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:41:01 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:41:01 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:01 --> Model Class Initialized
INFO - 2016-08-10 00:41:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:41:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:41:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:41:01 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:41:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:41:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:41:02 --> Final output sent to browser
DEBUG - 2016-08-10 00:41:02 --> Total execution time: 0.5618
INFO - 2016-08-10 00:41:23 --> Config Class Initialized
INFO - 2016-08-10 00:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:41:23 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:41:23 --> Utf8 Class Initialized
INFO - 2016-08-10 00:41:23 --> URI Class Initialized
INFO - 2016-08-10 00:41:23 --> Router Class Initialized
INFO - 2016-08-10 00:41:23 --> Output Class Initialized
INFO - 2016-08-10 00:41:23 --> Security Class Initialized
DEBUG - 2016-08-10 00:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:41:23 --> Input Class Initialized
INFO - 2016-08-10 00:41:23 --> Language Class Initialized
INFO - 2016-08-10 00:41:23 --> Loader Class Initialized
INFO - 2016-08-10 00:41:23 --> Helper loaded: url_helper
INFO - 2016-08-10 00:41:23 --> Helper loaded: date_helper
INFO - 2016-08-10 00:41:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:41:23 --> Database Driver Class Initialized
INFO - 2016-08-10 00:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:41:23 --> Email Class Initialized
INFO - 2016-08-10 00:41:23 --> Model Class Initialized
INFO - 2016-08-10 00:41:23 --> Controller Class Initialized
DEBUG - 2016-08-10 00:41:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:41:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:41:23 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:41:23 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:23 --> Model Class Initialized
INFO - 2016-08-10 00:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:41:23 --> Severity: Notice --> Undefined index: first_name D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:41:23 --> Final output sent to browser
DEBUG - 2016-08-10 00:41:23 --> Total execution time: 0.6318
INFO - 2016-08-10 00:41:47 --> Config Class Initialized
INFO - 2016-08-10 00:41:47 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:41:47 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:41:47 --> Utf8 Class Initialized
INFO - 2016-08-10 00:41:47 --> URI Class Initialized
INFO - 2016-08-10 00:41:47 --> Router Class Initialized
INFO - 2016-08-10 00:41:47 --> Output Class Initialized
INFO - 2016-08-10 00:41:47 --> Security Class Initialized
DEBUG - 2016-08-10 00:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:41:47 --> Input Class Initialized
INFO - 2016-08-10 00:41:47 --> Language Class Initialized
INFO - 2016-08-10 00:41:47 --> Loader Class Initialized
INFO - 2016-08-10 00:41:47 --> Helper loaded: url_helper
INFO - 2016-08-10 00:41:47 --> Helper loaded: date_helper
INFO - 2016-08-10 00:41:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:41:47 --> Database Driver Class Initialized
INFO - 2016-08-10 00:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:41:47 --> Email Class Initialized
INFO - 2016-08-10 00:41:47 --> Model Class Initialized
INFO - 2016-08-10 00:41:47 --> Controller Class Initialized
DEBUG - 2016-08-10 00:41:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:41:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:41:47 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:41:47 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:41:47 --> Model Class Initialized
INFO - 2016-08-10 00:41:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:41:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:41:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:41:47 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:42:02 --> Config Class Initialized
INFO - 2016-08-10 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:42:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:42:02 --> Utf8 Class Initialized
INFO - 2016-08-10 00:42:02 --> URI Class Initialized
INFO - 2016-08-10 00:42:02 --> Router Class Initialized
INFO - 2016-08-10 00:42:02 --> Output Class Initialized
INFO - 2016-08-10 00:42:02 --> Security Class Initialized
DEBUG - 2016-08-10 00:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:42:02 --> Input Class Initialized
INFO - 2016-08-10 00:42:02 --> Language Class Initialized
INFO - 2016-08-10 00:42:02 --> Loader Class Initialized
INFO - 2016-08-10 00:42:02 --> Helper loaded: url_helper
INFO - 2016-08-10 00:42:02 --> Helper loaded: date_helper
INFO - 2016-08-10 00:42:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:42:02 --> Database Driver Class Initialized
INFO - 2016-08-10 00:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:42:02 --> Email Class Initialized
INFO - 2016-08-10 00:42:02 --> Model Class Initialized
INFO - 2016-08-10 00:42:02 --> Controller Class Initialized
DEBUG - 2016-08-10 00:42:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:42:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:42:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:42:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:42:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:42:02 --> Model Class Initialized
INFO - 2016-08-10 00:42:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:42:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:42:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 00:42:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\aqiqahsehati\application\views\admin\page\view_page.php 45
INFO - 2016-08-10 00:42:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:42:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:42:02 --> Final output sent to browser
DEBUG - 2016-08-10 00:42:02 --> Total execution time: 0.5745
INFO - 2016-08-10 00:43:12 --> Config Class Initialized
INFO - 2016-08-10 00:43:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:43:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:43:12 --> Utf8 Class Initialized
INFO - 2016-08-10 00:43:12 --> URI Class Initialized
INFO - 2016-08-10 00:43:12 --> Router Class Initialized
INFO - 2016-08-10 00:43:12 --> Output Class Initialized
INFO - 2016-08-10 00:43:12 --> Security Class Initialized
DEBUG - 2016-08-10 00:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:43:12 --> Input Class Initialized
INFO - 2016-08-10 00:43:12 --> Language Class Initialized
INFO - 2016-08-10 00:43:12 --> Loader Class Initialized
INFO - 2016-08-10 00:43:12 --> Helper loaded: url_helper
INFO - 2016-08-10 00:43:12 --> Helper loaded: date_helper
INFO - 2016-08-10 00:43:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:43:12 --> Database Driver Class Initialized
INFO - 2016-08-10 00:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:43:12 --> Email Class Initialized
INFO - 2016-08-10 00:43:12 --> Model Class Initialized
INFO - 2016-08-10 00:43:12 --> Controller Class Initialized
DEBUG - 2016-08-10 00:43:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:43:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:43:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:43:12 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:43:12 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:43:12 --> Model Class Initialized
INFO - 2016-08-10 00:43:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:43:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:43:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:43:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:43:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:43:12 --> Final output sent to browser
DEBUG - 2016-08-10 00:43:12 --> Total execution time: 0.4260
INFO - 2016-08-10 00:43:54 --> Config Class Initialized
INFO - 2016-08-10 00:43:54 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:43:54 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:43:54 --> Utf8 Class Initialized
INFO - 2016-08-10 00:43:54 --> URI Class Initialized
INFO - 2016-08-10 00:43:54 --> Router Class Initialized
INFO - 2016-08-10 00:43:54 --> Output Class Initialized
INFO - 2016-08-10 00:43:54 --> Security Class Initialized
DEBUG - 2016-08-10 00:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:43:54 --> Input Class Initialized
INFO - 2016-08-10 00:43:54 --> Language Class Initialized
INFO - 2016-08-10 00:43:54 --> Loader Class Initialized
INFO - 2016-08-10 00:43:54 --> Helper loaded: url_helper
INFO - 2016-08-10 00:43:54 --> Helper loaded: date_helper
INFO - 2016-08-10 00:43:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:43:54 --> Database Driver Class Initialized
INFO - 2016-08-10 00:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:43:54 --> Email Class Initialized
INFO - 2016-08-10 00:43:54 --> Model Class Initialized
INFO - 2016-08-10 00:43:54 --> Controller Class Initialized
DEBUG - 2016-08-10 00:43:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:43:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:43:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:43:54 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:43:54 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:43:54 --> Model Class Initialized
INFO - 2016-08-10 00:43:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:43:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:43:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:43:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:43:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:43:54 --> Final output sent to browser
DEBUG - 2016-08-10 00:43:55 --> Total execution time: 0.3998
INFO - 2016-08-10 00:44:31 --> Config Class Initialized
INFO - 2016-08-10 00:44:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:44:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:44:31 --> Utf8 Class Initialized
INFO - 2016-08-10 00:44:31 --> URI Class Initialized
INFO - 2016-08-10 00:44:31 --> Router Class Initialized
INFO - 2016-08-10 00:44:31 --> Output Class Initialized
INFO - 2016-08-10 00:44:31 --> Security Class Initialized
DEBUG - 2016-08-10 00:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:44:31 --> Input Class Initialized
INFO - 2016-08-10 00:44:31 --> Language Class Initialized
INFO - 2016-08-10 00:44:31 --> Loader Class Initialized
INFO - 2016-08-10 00:44:31 --> Helper loaded: url_helper
INFO - 2016-08-10 00:44:31 --> Helper loaded: date_helper
INFO - 2016-08-10 00:44:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:44:31 --> Database Driver Class Initialized
INFO - 2016-08-10 00:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:44:31 --> Email Class Initialized
INFO - 2016-08-10 00:44:31 --> Model Class Initialized
INFO - 2016-08-10 00:44:31 --> Controller Class Initialized
DEBUG - 2016-08-10 00:44:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:44:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:44:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:44:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:44:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:44:31 --> Model Class Initialized
INFO - 2016-08-10 00:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 00:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:44:31 --> Final output sent to browser
DEBUG - 2016-08-10 00:44:31 --> Total execution time: 0.3751
INFO - 2016-08-10 00:45:19 --> Config Class Initialized
INFO - 2016-08-10 00:45:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:45:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:45:19 --> Utf8 Class Initialized
INFO - 2016-08-10 00:45:19 --> URI Class Initialized
INFO - 2016-08-10 00:45:19 --> Router Class Initialized
INFO - 2016-08-10 00:45:19 --> Output Class Initialized
INFO - 2016-08-10 00:45:19 --> Security Class Initialized
DEBUG - 2016-08-10 00:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:45:19 --> Input Class Initialized
INFO - 2016-08-10 00:45:19 --> Language Class Initialized
INFO - 2016-08-10 00:45:19 --> Loader Class Initialized
INFO - 2016-08-10 00:45:19 --> Helper loaded: url_helper
INFO - 2016-08-10 00:45:19 --> Helper loaded: date_helper
INFO - 2016-08-10 00:45:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:45:19 --> Database Driver Class Initialized
INFO - 2016-08-10 00:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:45:19 --> Email Class Initialized
INFO - 2016-08-10 00:45:19 --> Model Class Initialized
INFO - 2016-08-10 00:45:19 --> Controller Class Initialized
DEBUG - 2016-08-10 00:45:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:45:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:45:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:45:19 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:45:19 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:45:19 --> Model Class Initialized
INFO - 2016-08-10 00:45:19 --> Upload Class Initialized
INFO - 2016-08-10 00:45:19 --> Config Class Initialized
INFO - 2016-08-10 00:45:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:45:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:45:19 --> Utf8 Class Initialized
INFO - 2016-08-10 00:45:19 --> URI Class Initialized
INFO - 2016-08-10 00:45:19 --> Router Class Initialized
INFO - 2016-08-10 00:45:19 --> Output Class Initialized
INFO - 2016-08-10 00:45:19 --> Security Class Initialized
DEBUG - 2016-08-10 00:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:45:19 --> Input Class Initialized
INFO - 2016-08-10 00:45:19 --> Language Class Initialized
INFO - 2016-08-10 00:45:19 --> Loader Class Initialized
INFO - 2016-08-10 00:45:19 --> Helper loaded: url_helper
INFO - 2016-08-10 00:45:19 --> Helper loaded: date_helper
INFO - 2016-08-10 00:45:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:45:19 --> Database Driver Class Initialized
INFO - 2016-08-10 00:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:45:20 --> Email Class Initialized
INFO - 2016-08-10 00:45:20 --> Model Class Initialized
INFO - 2016-08-10 00:45:20 --> Controller Class Initialized
DEBUG - 2016-08-10 00:45:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:45:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:45:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:45:20 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:45:20 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:45:20 --> Model Class Initialized
INFO - 2016-08-10 00:45:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:45:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:45:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:45:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:45:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:45:20 --> Final output sent to browser
DEBUG - 2016-08-10 00:45:20 --> Total execution time: 0.6508
INFO - 2016-08-10 00:48:07 --> Config Class Initialized
INFO - 2016-08-10 00:48:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:48:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:48:07 --> Utf8 Class Initialized
INFO - 2016-08-10 00:48:07 --> URI Class Initialized
INFO - 2016-08-10 00:48:07 --> Router Class Initialized
INFO - 2016-08-10 00:48:07 --> Output Class Initialized
INFO - 2016-08-10 00:48:07 --> Security Class Initialized
DEBUG - 2016-08-10 00:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:48:07 --> Input Class Initialized
INFO - 2016-08-10 00:48:07 --> Language Class Initialized
INFO - 2016-08-10 00:48:07 --> Loader Class Initialized
INFO - 2016-08-10 00:48:07 --> Helper loaded: url_helper
INFO - 2016-08-10 00:48:07 --> Helper loaded: date_helper
INFO - 2016-08-10 00:48:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:48:07 --> Database Driver Class Initialized
INFO - 2016-08-10 00:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:48:07 --> Email Class Initialized
INFO - 2016-08-10 00:48:07 --> Model Class Initialized
INFO - 2016-08-10 00:48:07 --> Controller Class Initialized
DEBUG - 2016-08-10 00:48:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:48:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:48:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:48:07 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:48:07 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:48:07 --> Model Class Initialized
INFO - 2016-08-10 00:48:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:48:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:48:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:48:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 00:48:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:48:07 --> Final output sent to browser
DEBUG - 2016-08-10 00:48:07 --> Total execution time: 0.4069
INFO - 2016-08-10 00:55:01 --> Config Class Initialized
INFO - 2016-08-10 00:55:01 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:55:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:55:01 --> Utf8 Class Initialized
INFO - 2016-08-10 00:55:01 --> URI Class Initialized
INFO - 2016-08-10 00:55:01 --> Router Class Initialized
INFO - 2016-08-10 00:55:01 --> Output Class Initialized
INFO - 2016-08-10 00:55:01 --> Security Class Initialized
DEBUG - 2016-08-10 00:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:55:01 --> Input Class Initialized
INFO - 2016-08-10 00:55:01 --> Language Class Initialized
INFO - 2016-08-10 00:55:02 --> Loader Class Initialized
INFO - 2016-08-10 00:55:02 --> Helper loaded: url_helper
INFO - 2016-08-10 00:55:02 --> Helper loaded: date_helper
INFO - 2016-08-10 00:55:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:55:02 --> Database Driver Class Initialized
INFO - 2016-08-10 00:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:55:02 --> Email Class Initialized
INFO - 2016-08-10 00:55:02 --> Model Class Initialized
INFO - 2016-08-10 00:55:02 --> Controller Class Initialized
DEBUG - 2016-08-10 00:55:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:55:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:55:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:55:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:02 --> Model Class Initialized
INFO - 2016-08-10 00:55:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:55:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:55:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:55:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:55:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:55:02 --> Final output sent to browser
DEBUG - 2016-08-10 00:55:02 --> Total execution time: 0.3656
INFO - 2016-08-10 00:55:12 --> Config Class Initialized
INFO - 2016-08-10 00:55:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:55:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:55:12 --> Utf8 Class Initialized
INFO - 2016-08-10 00:55:12 --> URI Class Initialized
INFO - 2016-08-10 00:55:12 --> Router Class Initialized
INFO - 2016-08-10 00:55:12 --> Output Class Initialized
INFO - 2016-08-10 00:55:12 --> Security Class Initialized
DEBUG - 2016-08-10 00:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:55:12 --> Input Class Initialized
INFO - 2016-08-10 00:55:12 --> Language Class Initialized
INFO - 2016-08-10 00:55:12 --> Loader Class Initialized
INFO - 2016-08-10 00:55:12 --> Helper loaded: url_helper
INFO - 2016-08-10 00:55:12 --> Helper loaded: date_helper
INFO - 2016-08-10 00:55:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:55:12 --> Database Driver Class Initialized
INFO - 2016-08-10 00:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:55:12 --> Email Class Initialized
INFO - 2016-08-10 00:55:12 --> Model Class Initialized
INFO - 2016-08-10 00:55:12 --> Controller Class Initialized
DEBUG - 2016-08-10 00:55:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:55:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:55:12 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:55:12 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:12 --> Model Class Initialized
INFO - 2016-08-10 00:55:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:55:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:55:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:55:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:55:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:55:13 --> Final output sent to browser
DEBUG - 2016-08-10 00:55:13 --> Total execution time: 0.3663
INFO - 2016-08-10 00:55:17 --> Config Class Initialized
INFO - 2016-08-10 00:55:17 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:55:17 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:55:17 --> Utf8 Class Initialized
INFO - 2016-08-10 00:55:17 --> URI Class Initialized
INFO - 2016-08-10 00:55:17 --> Router Class Initialized
INFO - 2016-08-10 00:55:17 --> Output Class Initialized
INFO - 2016-08-10 00:55:17 --> Security Class Initialized
DEBUG - 2016-08-10 00:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:55:17 --> Input Class Initialized
INFO - 2016-08-10 00:55:17 --> Language Class Initialized
INFO - 2016-08-10 00:55:17 --> Loader Class Initialized
INFO - 2016-08-10 00:55:17 --> Helper loaded: url_helper
INFO - 2016-08-10 00:55:17 --> Helper loaded: date_helper
INFO - 2016-08-10 00:55:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:55:17 --> Database Driver Class Initialized
INFO - 2016-08-10 00:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:55:17 --> Email Class Initialized
INFO - 2016-08-10 00:55:17 --> Model Class Initialized
INFO - 2016-08-10 00:55:17 --> Controller Class Initialized
DEBUG - 2016-08-10 00:55:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:55:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:55:17 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:55:17 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:17 --> Model Class Initialized
INFO - 2016-08-10 00:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:55:17 --> Final output sent to browser
DEBUG - 2016-08-10 00:55:17 --> Total execution time: 0.3895
INFO - 2016-08-10 00:55:51 --> Config Class Initialized
INFO - 2016-08-10 00:55:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:55:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:55:51 --> Utf8 Class Initialized
INFO - 2016-08-10 00:55:51 --> URI Class Initialized
INFO - 2016-08-10 00:55:51 --> Router Class Initialized
INFO - 2016-08-10 00:55:51 --> Output Class Initialized
INFO - 2016-08-10 00:55:51 --> Security Class Initialized
DEBUG - 2016-08-10 00:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:55:51 --> Input Class Initialized
INFO - 2016-08-10 00:55:51 --> Language Class Initialized
INFO - 2016-08-10 00:55:51 --> Loader Class Initialized
INFO - 2016-08-10 00:55:51 --> Helper loaded: url_helper
INFO - 2016-08-10 00:55:51 --> Helper loaded: date_helper
INFO - 2016-08-10 00:55:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:55:51 --> Database Driver Class Initialized
INFO - 2016-08-10 00:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:55:51 --> Email Class Initialized
INFO - 2016-08-10 00:55:51 --> Model Class Initialized
INFO - 2016-08-10 00:55:51 --> Controller Class Initialized
DEBUG - 2016-08-10 00:55:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:55:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:55:51 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:55:51 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:51 --> Model Class Initialized
INFO - 2016-08-10 00:55:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:55:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:55:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:55:52 --> Final output sent to browser
DEBUG - 2016-08-10 00:55:52 --> Total execution time: 0.3736
INFO - 2016-08-10 00:55:54 --> Config Class Initialized
INFO - 2016-08-10 00:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:55:54 --> Utf8 Class Initialized
INFO - 2016-08-10 00:55:54 --> URI Class Initialized
INFO - 2016-08-10 00:55:54 --> Router Class Initialized
INFO - 2016-08-10 00:55:54 --> Output Class Initialized
INFO - 2016-08-10 00:55:54 --> Security Class Initialized
DEBUG - 2016-08-10 00:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:55:54 --> Input Class Initialized
INFO - 2016-08-10 00:55:54 --> Language Class Initialized
INFO - 2016-08-10 00:55:54 --> Loader Class Initialized
INFO - 2016-08-10 00:55:54 --> Helper loaded: url_helper
INFO - 2016-08-10 00:55:54 --> Helper loaded: date_helper
INFO - 2016-08-10 00:55:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:55:54 --> Database Driver Class Initialized
INFO - 2016-08-10 00:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:55:54 --> Email Class Initialized
INFO - 2016-08-10 00:55:54 --> Model Class Initialized
INFO - 2016-08-10 00:55:54 --> Controller Class Initialized
DEBUG - 2016-08-10 00:55:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:55:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:55:54 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:55:54 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:55:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:55:54 --> Model Class Initialized
INFO - 2016-08-10 00:55:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:55:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:55:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:55:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 00:55:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:55:54 --> Final output sent to browser
DEBUG - 2016-08-10 00:55:54 --> Total execution time: 0.3955
INFO - 2016-08-10 00:56:30 --> Config Class Initialized
INFO - 2016-08-10 00:56:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:56:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:56:30 --> Utf8 Class Initialized
INFO - 2016-08-10 00:56:30 --> URI Class Initialized
INFO - 2016-08-10 00:56:30 --> Router Class Initialized
INFO - 2016-08-10 00:56:30 --> Output Class Initialized
INFO - 2016-08-10 00:56:30 --> Security Class Initialized
DEBUG - 2016-08-10 00:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:56:30 --> Input Class Initialized
INFO - 2016-08-10 00:56:30 --> Language Class Initialized
INFO - 2016-08-10 00:56:30 --> Loader Class Initialized
INFO - 2016-08-10 00:56:30 --> Helper loaded: url_helper
INFO - 2016-08-10 00:56:30 --> Helper loaded: date_helper
INFO - 2016-08-10 00:56:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:56:31 --> Database Driver Class Initialized
INFO - 2016-08-10 00:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:56:31 --> Email Class Initialized
INFO - 2016-08-10 00:56:31 --> Model Class Initialized
INFO - 2016-08-10 00:56:31 --> Controller Class Initialized
DEBUG - 2016-08-10 00:56:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:56:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:56:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:56:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:56:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:56:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:56:31 --> Model Class Initialized
INFO - 2016-08-10 00:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:56:31 --> Final output sent to browser
DEBUG - 2016-08-10 00:56:31 --> Total execution time: 0.4461
INFO - 2016-08-10 00:58:15 --> Config Class Initialized
INFO - 2016-08-10 00:58:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:58:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:58:15 --> Utf8 Class Initialized
INFO - 2016-08-10 00:58:15 --> URI Class Initialized
INFO - 2016-08-10 00:58:15 --> Router Class Initialized
INFO - 2016-08-10 00:58:15 --> Output Class Initialized
INFO - 2016-08-10 00:58:15 --> Security Class Initialized
DEBUG - 2016-08-10 00:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:58:15 --> Input Class Initialized
INFO - 2016-08-10 00:58:15 --> Language Class Initialized
INFO - 2016-08-10 00:58:16 --> Loader Class Initialized
INFO - 2016-08-10 00:58:16 --> Helper loaded: url_helper
INFO - 2016-08-10 00:58:16 --> Helper loaded: date_helper
INFO - 2016-08-10 00:58:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:58:16 --> Database Driver Class Initialized
INFO - 2016-08-10 00:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:58:16 --> Email Class Initialized
INFO - 2016-08-10 00:58:16 --> Model Class Initialized
INFO - 2016-08-10 00:58:16 --> Controller Class Initialized
DEBUG - 2016-08-10 00:58:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:58:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:58:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:58:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:58:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:58:16 --> Model Class Initialized
INFO - 2016-08-10 00:58:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:58:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:58:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:58:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:58:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:58:16 --> Final output sent to browser
DEBUG - 2016-08-10 00:58:16 --> Total execution time: 0.4560
INFO - 2016-08-10 00:58:34 --> Config Class Initialized
INFO - 2016-08-10 00:58:34 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:58:35 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:58:35 --> Utf8 Class Initialized
INFO - 2016-08-10 00:58:35 --> URI Class Initialized
INFO - 2016-08-10 00:58:35 --> Router Class Initialized
INFO - 2016-08-10 00:58:35 --> Output Class Initialized
INFO - 2016-08-10 00:58:35 --> Security Class Initialized
DEBUG - 2016-08-10 00:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:58:35 --> Input Class Initialized
INFO - 2016-08-10 00:58:35 --> Language Class Initialized
INFO - 2016-08-10 00:58:35 --> Loader Class Initialized
INFO - 2016-08-10 00:58:35 --> Helper loaded: url_helper
INFO - 2016-08-10 00:58:35 --> Helper loaded: date_helper
INFO - 2016-08-10 00:58:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:58:35 --> Database Driver Class Initialized
INFO - 2016-08-10 00:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:58:35 --> Email Class Initialized
INFO - 2016-08-10 00:58:35 --> Model Class Initialized
INFO - 2016-08-10 00:58:35 --> Controller Class Initialized
DEBUG - 2016-08-10 00:58:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:58:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:58:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:58:35 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:58:35 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:58:35 --> Model Class Initialized
INFO - 2016-08-10 00:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:58:35 --> Final output sent to browser
DEBUG - 2016-08-10 00:58:35 --> Total execution time: 0.8226
INFO - 2016-08-10 00:59:51 --> Config Class Initialized
INFO - 2016-08-10 00:59:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 00:59:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 00:59:51 --> Utf8 Class Initialized
INFO - 2016-08-10 00:59:51 --> URI Class Initialized
INFO - 2016-08-10 00:59:51 --> Router Class Initialized
INFO - 2016-08-10 00:59:51 --> Output Class Initialized
INFO - 2016-08-10 00:59:51 --> Security Class Initialized
DEBUG - 2016-08-10 00:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 00:59:51 --> Input Class Initialized
INFO - 2016-08-10 00:59:51 --> Language Class Initialized
INFO - 2016-08-10 00:59:51 --> Loader Class Initialized
INFO - 2016-08-10 00:59:52 --> Helper loaded: url_helper
INFO - 2016-08-10 00:59:52 --> Helper loaded: date_helper
INFO - 2016-08-10 00:59:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 00:59:52 --> Database Driver Class Initialized
INFO - 2016-08-10 00:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 00:59:52 --> Email Class Initialized
INFO - 2016-08-10 00:59:52 --> Model Class Initialized
INFO - 2016-08-10 00:59:52 --> Controller Class Initialized
DEBUG - 2016-08-10 00:59:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 00:59:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:59:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 00:59:52 --> Helper loaded: cookie_helper
INFO - 2016-08-10 00:59:52 --> Helper loaded: language_helper
DEBUG - 2016-08-10 00:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 00:59:52 --> Model Class Initialized
INFO - 2016-08-10 00:59:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 00:59:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 00:59:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 00:59:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 00:59:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 00:59:52 --> Final output sent to browser
DEBUG - 2016-08-10 00:59:52 --> Total execution time: 0.4229
INFO - 2016-08-10 01:00:33 --> Config Class Initialized
INFO - 2016-08-10 01:00:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:00:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:00:33 --> Utf8 Class Initialized
INFO - 2016-08-10 01:00:33 --> URI Class Initialized
INFO - 2016-08-10 01:00:33 --> Router Class Initialized
INFO - 2016-08-10 01:00:33 --> Output Class Initialized
INFO - 2016-08-10 01:00:33 --> Security Class Initialized
DEBUG - 2016-08-10 01:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:00:33 --> Input Class Initialized
INFO - 2016-08-10 01:00:33 --> Language Class Initialized
INFO - 2016-08-10 01:00:33 --> Loader Class Initialized
INFO - 2016-08-10 01:00:33 --> Helper loaded: url_helper
INFO - 2016-08-10 01:00:33 --> Helper loaded: date_helper
INFO - 2016-08-10 01:00:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:00:33 --> Database Driver Class Initialized
INFO - 2016-08-10 01:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:00:33 --> Email Class Initialized
INFO - 2016-08-10 01:00:33 --> Model Class Initialized
INFO - 2016-08-10 01:00:33 --> Controller Class Initialized
DEBUG - 2016-08-10 01:00:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:00:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:00:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:00:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:33 --> Model Class Initialized
INFO - 2016-08-10 01:00:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:00:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:00:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:00:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:00:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:00:34 --> Final output sent to browser
DEBUG - 2016-08-10 01:00:34 --> Total execution time: 0.4214
INFO - 2016-08-10 01:00:36 --> Config Class Initialized
INFO - 2016-08-10 01:00:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:00:36 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:00:36 --> Utf8 Class Initialized
INFO - 2016-08-10 01:00:36 --> URI Class Initialized
INFO - 2016-08-10 01:00:36 --> Router Class Initialized
INFO - 2016-08-10 01:00:36 --> Output Class Initialized
INFO - 2016-08-10 01:00:36 --> Security Class Initialized
DEBUG - 2016-08-10 01:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:00:36 --> Input Class Initialized
INFO - 2016-08-10 01:00:36 --> Language Class Initialized
INFO - 2016-08-10 01:00:36 --> Loader Class Initialized
INFO - 2016-08-10 01:00:36 --> Helper loaded: url_helper
INFO - 2016-08-10 01:00:36 --> Helper loaded: date_helper
INFO - 2016-08-10 01:00:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:00:36 --> Database Driver Class Initialized
INFO - 2016-08-10 01:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:00:36 --> Email Class Initialized
INFO - 2016-08-10 01:00:36 --> Model Class Initialized
INFO - 2016-08-10 01:00:36 --> Controller Class Initialized
DEBUG - 2016-08-10 01:00:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:00:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:00:36 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:00:36 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:36 --> Model Class Initialized
INFO - 2016-08-10 01:00:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:00:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:00:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:00:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:00:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:00:36 --> Final output sent to browser
DEBUG - 2016-08-10 01:00:36 --> Total execution time: 0.4471
INFO - 2016-08-10 01:00:40 --> Config Class Initialized
INFO - 2016-08-10 01:00:40 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:00:40 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:00:40 --> Utf8 Class Initialized
INFO - 2016-08-10 01:00:40 --> URI Class Initialized
INFO - 2016-08-10 01:00:40 --> Router Class Initialized
INFO - 2016-08-10 01:00:40 --> Output Class Initialized
INFO - 2016-08-10 01:00:40 --> Security Class Initialized
DEBUG - 2016-08-10 01:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:00:40 --> Input Class Initialized
INFO - 2016-08-10 01:00:40 --> Language Class Initialized
INFO - 2016-08-10 01:00:40 --> Loader Class Initialized
INFO - 2016-08-10 01:00:40 --> Helper loaded: url_helper
INFO - 2016-08-10 01:00:40 --> Helper loaded: date_helper
INFO - 2016-08-10 01:00:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:00:40 --> Database Driver Class Initialized
INFO - 2016-08-10 01:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:00:40 --> Email Class Initialized
INFO - 2016-08-10 01:00:40 --> Model Class Initialized
INFO - 2016-08-10 01:00:40 --> Controller Class Initialized
DEBUG - 2016-08-10 01:00:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:00:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:00:40 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:00:40 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:00:40 --> Model Class Initialized
INFO - 2016-08-10 01:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:00:40 --> Final output sent to browser
DEBUG - 2016-08-10 01:00:40 --> Total execution time: 0.4150
INFO - 2016-08-10 01:01:01 --> Config Class Initialized
INFO - 2016-08-10 01:01:01 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:01 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:01 --> URI Class Initialized
INFO - 2016-08-10 01:01:01 --> Router Class Initialized
INFO - 2016-08-10 01:01:01 --> Output Class Initialized
INFO - 2016-08-10 01:01:01 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:01 --> Input Class Initialized
INFO - 2016-08-10 01:01:01 --> Language Class Initialized
INFO - 2016-08-10 01:01:01 --> Loader Class Initialized
INFO - 2016-08-10 01:01:01 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:01 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:01 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:01 --> Email Class Initialized
INFO - 2016-08-10 01:01:01 --> Model Class Initialized
INFO - 2016-08-10 01:01:01 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:01 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:01 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:01 --> Model Class Initialized
INFO - 2016-08-10 01:01:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:01 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:01 --> Total execution time: 0.3971
INFO - 2016-08-10 01:01:04 --> Config Class Initialized
INFO - 2016-08-10 01:01:04 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:04 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:04 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:04 --> URI Class Initialized
INFO - 2016-08-10 01:01:04 --> Router Class Initialized
INFO - 2016-08-10 01:01:04 --> Output Class Initialized
INFO - 2016-08-10 01:01:04 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:04 --> Input Class Initialized
INFO - 2016-08-10 01:01:04 --> Language Class Initialized
INFO - 2016-08-10 01:01:04 --> Loader Class Initialized
INFO - 2016-08-10 01:01:04 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:04 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:04 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:04 --> Email Class Initialized
INFO - 2016-08-10 01:01:04 --> Model Class Initialized
INFO - 2016-08-10 01:01:04 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:04 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:04 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:04 --> Model Class Initialized
INFO - 2016-08-10 01:01:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:01:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:04 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:04 --> Total execution time: 0.4579
INFO - 2016-08-10 01:01:09 --> Config Class Initialized
INFO - 2016-08-10 01:01:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:09 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:09 --> URI Class Initialized
INFO - 2016-08-10 01:01:09 --> Router Class Initialized
INFO - 2016-08-10 01:01:09 --> Output Class Initialized
INFO - 2016-08-10 01:01:09 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:09 --> Input Class Initialized
INFO - 2016-08-10 01:01:09 --> Language Class Initialized
INFO - 2016-08-10 01:01:09 --> Loader Class Initialized
INFO - 2016-08-10 01:01:09 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:09 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:09 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:09 --> Email Class Initialized
INFO - 2016-08-10 01:01:09 --> Model Class Initialized
INFO - 2016-08-10 01:01:09 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:09 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:09 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:09 --> Model Class Initialized
INFO - 2016-08-10 01:01:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:09 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:09 --> Total execution time: 0.5007
INFO - 2016-08-10 01:01:11 --> Config Class Initialized
INFO - 2016-08-10 01:01:11 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:11 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:11 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:11 --> URI Class Initialized
INFO - 2016-08-10 01:01:11 --> Router Class Initialized
INFO - 2016-08-10 01:01:11 --> Output Class Initialized
INFO - 2016-08-10 01:01:11 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:11 --> Input Class Initialized
INFO - 2016-08-10 01:01:11 --> Language Class Initialized
INFO - 2016-08-10 01:01:11 --> Loader Class Initialized
INFO - 2016-08-10 01:01:11 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:11 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:11 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:11 --> Email Class Initialized
INFO - 2016-08-10 01:01:11 --> Model Class Initialized
INFO - 2016-08-10 01:01:11 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:11 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:11 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:11 --> Model Class Initialized
INFO - 2016-08-10 01:01:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:01:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:11 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:11 --> Total execution time: 0.3899
INFO - 2016-08-10 01:01:14 --> Config Class Initialized
INFO - 2016-08-10 01:01:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:15 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:15 --> URI Class Initialized
INFO - 2016-08-10 01:01:15 --> Router Class Initialized
INFO - 2016-08-10 01:01:15 --> Output Class Initialized
INFO - 2016-08-10 01:01:15 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:15 --> Input Class Initialized
INFO - 2016-08-10 01:01:15 --> Language Class Initialized
INFO - 2016-08-10 01:01:15 --> Loader Class Initialized
INFO - 2016-08-10 01:01:15 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:15 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:15 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:15 --> Email Class Initialized
INFO - 2016-08-10 01:01:15 --> Model Class Initialized
INFO - 2016-08-10 01:01:15 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:15 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:15 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:15 --> Model Class Initialized
INFO - 2016-08-10 01:01:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:15 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:15 --> Total execution time: 0.4303
INFO - 2016-08-10 01:01:30 --> Config Class Initialized
INFO - 2016-08-10 01:01:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:30 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:30 --> URI Class Initialized
INFO - 2016-08-10 01:01:30 --> Router Class Initialized
INFO - 2016-08-10 01:01:30 --> Output Class Initialized
INFO - 2016-08-10 01:01:30 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:31 --> Input Class Initialized
INFO - 2016-08-10 01:01:31 --> Language Class Initialized
INFO - 2016-08-10 01:01:31 --> Loader Class Initialized
INFO - 2016-08-10 01:01:31 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:31 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:31 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:31 --> Email Class Initialized
INFO - 2016-08-10 01:01:31 --> Model Class Initialized
INFO - 2016-08-10 01:01:31 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:31 --> Model Class Initialized
INFO - 2016-08-10 01:01:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:31 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:31 --> Total execution time: 0.8920
INFO - 2016-08-10 01:01:34 --> Config Class Initialized
INFO - 2016-08-10 01:01:34 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:34 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:34 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:34 --> URI Class Initialized
INFO - 2016-08-10 01:01:34 --> Router Class Initialized
INFO - 2016-08-10 01:01:34 --> Output Class Initialized
INFO - 2016-08-10 01:01:34 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:34 --> Input Class Initialized
INFO - 2016-08-10 01:01:34 --> Language Class Initialized
INFO - 2016-08-10 01:01:34 --> Loader Class Initialized
INFO - 2016-08-10 01:01:34 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:34 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:34 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:34 --> Email Class Initialized
INFO - 2016-08-10 01:01:34 --> Model Class Initialized
INFO - 2016-08-10 01:01:34 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:34 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:34 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:34 --> Model Class Initialized
INFO - 2016-08-10 01:01:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:01:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:34 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:34 --> Total execution time: 0.4615
INFO - 2016-08-10 01:01:39 --> Config Class Initialized
INFO - 2016-08-10 01:01:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:39 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:39 --> URI Class Initialized
INFO - 2016-08-10 01:01:39 --> Router Class Initialized
INFO - 2016-08-10 01:01:39 --> Output Class Initialized
INFO - 2016-08-10 01:01:39 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:39 --> Input Class Initialized
INFO - 2016-08-10 01:01:39 --> Language Class Initialized
INFO - 2016-08-10 01:01:39 --> Loader Class Initialized
INFO - 2016-08-10 01:01:39 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:39 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:39 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:39 --> Email Class Initialized
INFO - 2016-08-10 01:01:39 --> Model Class Initialized
INFO - 2016-08-10 01:01:39 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:39 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:39 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:39 --> Model Class Initialized
INFO - 2016-08-10 01:01:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:39 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:39 --> Total execution time: 0.4296
INFO - 2016-08-10 01:01:41 --> Config Class Initialized
INFO - 2016-08-10 01:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:41 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:41 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:41 --> URI Class Initialized
INFO - 2016-08-10 01:01:41 --> Router Class Initialized
INFO - 2016-08-10 01:01:41 --> Output Class Initialized
INFO - 2016-08-10 01:01:41 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:41 --> Input Class Initialized
INFO - 2016-08-10 01:01:41 --> Language Class Initialized
INFO - 2016-08-10 01:01:41 --> Loader Class Initialized
INFO - 2016-08-10 01:01:41 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:41 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:41 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:41 --> Email Class Initialized
INFO - 2016-08-10 01:01:41 --> Model Class Initialized
INFO - 2016-08-10 01:01:41 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:41 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:41 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:41 --> Model Class Initialized
INFO - 2016-08-10 01:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:01:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:42 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:42 --> Total execution time: 0.4054
INFO - 2016-08-10 01:01:44 --> Config Class Initialized
INFO - 2016-08-10 01:01:44 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:01:44 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:01:44 --> Utf8 Class Initialized
INFO - 2016-08-10 01:01:44 --> URI Class Initialized
INFO - 2016-08-10 01:01:44 --> Router Class Initialized
INFO - 2016-08-10 01:01:44 --> Output Class Initialized
INFO - 2016-08-10 01:01:44 --> Security Class Initialized
DEBUG - 2016-08-10 01:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:01:44 --> Input Class Initialized
INFO - 2016-08-10 01:01:44 --> Language Class Initialized
INFO - 2016-08-10 01:01:44 --> Loader Class Initialized
INFO - 2016-08-10 01:01:44 --> Helper loaded: url_helper
INFO - 2016-08-10 01:01:44 --> Helper loaded: date_helper
INFO - 2016-08-10 01:01:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:01:44 --> Database Driver Class Initialized
INFO - 2016-08-10 01:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:01:44 --> Email Class Initialized
INFO - 2016-08-10 01:01:44 --> Model Class Initialized
INFO - 2016-08-10 01:01:44 --> Controller Class Initialized
DEBUG - 2016-08-10 01:01:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:01:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:01:44 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:01:44 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:01:44 --> Model Class Initialized
INFO - 2016-08-10 01:01:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:01:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:01:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:01:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:01:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:01:44 --> Final output sent to browser
DEBUG - 2016-08-10 01:01:44 --> Total execution time: 0.4412
INFO - 2016-08-10 01:06:59 --> Config Class Initialized
INFO - 2016-08-10 01:06:59 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:06:59 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:06:59 --> Utf8 Class Initialized
INFO - 2016-08-10 01:06:59 --> URI Class Initialized
INFO - 2016-08-10 01:06:59 --> Router Class Initialized
INFO - 2016-08-10 01:06:59 --> Output Class Initialized
INFO - 2016-08-10 01:06:59 --> Security Class Initialized
DEBUG - 2016-08-10 01:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:06:59 --> Input Class Initialized
INFO - 2016-08-10 01:06:59 --> Language Class Initialized
INFO - 2016-08-10 01:06:59 --> Loader Class Initialized
INFO - 2016-08-10 01:06:59 --> Helper loaded: url_helper
INFO - 2016-08-10 01:06:59 --> Helper loaded: date_helper
INFO - 2016-08-10 01:06:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:06:59 --> Database Driver Class Initialized
INFO - 2016-08-10 01:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:06:59 --> Email Class Initialized
INFO - 2016-08-10 01:06:59 --> Model Class Initialized
INFO - 2016-08-10 01:06:59 --> Controller Class Initialized
DEBUG - 2016-08-10 01:06:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:06:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:06:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:06:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:06:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:06:59 --> Model Class Initialized
INFO - 2016-08-10 01:06:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:06:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:06:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:06:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:06:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:06:59 --> Final output sent to browser
DEBUG - 2016-08-10 01:06:59 --> Total execution time: 0.4395
INFO - 2016-08-10 01:07:22 --> Config Class Initialized
INFO - 2016-08-10 01:07:22 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:07:22 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:07:22 --> Utf8 Class Initialized
INFO - 2016-08-10 01:07:22 --> URI Class Initialized
INFO - 2016-08-10 01:07:22 --> Router Class Initialized
INFO - 2016-08-10 01:07:22 --> Output Class Initialized
INFO - 2016-08-10 01:07:22 --> Security Class Initialized
DEBUG - 2016-08-10 01:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:07:22 --> Input Class Initialized
INFO - 2016-08-10 01:07:22 --> Language Class Initialized
INFO - 2016-08-10 01:07:22 --> Loader Class Initialized
INFO - 2016-08-10 01:07:22 --> Helper loaded: url_helper
INFO - 2016-08-10 01:07:22 --> Helper loaded: date_helper
INFO - 2016-08-10 01:07:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:07:23 --> Database Driver Class Initialized
INFO - 2016-08-10 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:07:23 --> Email Class Initialized
INFO - 2016-08-10 01:07:23 --> Model Class Initialized
INFO - 2016-08-10 01:07:23 --> Controller Class Initialized
DEBUG - 2016-08-10 01:07:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:07:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:07:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:07:23 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:07:23 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:07:23 --> Model Class Initialized
INFO - 2016-08-10 01:07:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:07:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:07:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:07:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:07:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:07:23 --> Final output sent to browser
DEBUG - 2016-08-10 01:07:23 --> Total execution time: 0.4132
INFO - 2016-08-10 01:18:02 --> Config Class Initialized
INFO - 2016-08-10 01:18:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:18:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:18:02 --> Utf8 Class Initialized
INFO - 2016-08-10 01:18:02 --> URI Class Initialized
INFO - 2016-08-10 01:18:02 --> Router Class Initialized
INFO - 2016-08-10 01:18:02 --> Output Class Initialized
INFO - 2016-08-10 01:18:02 --> Security Class Initialized
DEBUG - 2016-08-10 01:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:18:02 --> Input Class Initialized
INFO - 2016-08-10 01:18:02 --> Language Class Initialized
INFO - 2016-08-10 01:18:02 --> Loader Class Initialized
INFO - 2016-08-10 01:18:02 --> Helper loaded: url_helper
INFO - 2016-08-10 01:18:02 --> Helper loaded: date_helper
INFO - 2016-08-10 01:18:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:18:02 --> Database Driver Class Initialized
INFO - 2016-08-10 01:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:18:02 --> Email Class Initialized
INFO - 2016-08-10 01:18:02 --> Model Class Initialized
INFO - 2016-08-10 01:18:02 --> Controller Class Initialized
DEBUG - 2016-08-10 01:18:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:18:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:18:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:18:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:03 --> Model Class Initialized
INFO - 2016-08-10 01:18:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:18:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:18:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:18:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:18:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:18:03 --> Final output sent to browser
DEBUG - 2016-08-10 01:18:03 --> Total execution time: 0.4653
INFO - 2016-08-10 01:18:15 --> Config Class Initialized
INFO - 2016-08-10 01:18:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:18:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:18:15 --> Utf8 Class Initialized
INFO - 2016-08-10 01:18:15 --> URI Class Initialized
INFO - 2016-08-10 01:18:15 --> Router Class Initialized
INFO - 2016-08-10 01:18:15 --> Output Class Initialized
INFO - 2016-08-10 01:18:15 --> Security Class Initialized
DEBUG - 2016-08-10 01:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:18:15 --> Input Class Initialized
INFO - 2016-08-10 01:18:15 --> Language Class Initialized
INFO - 2016-08-10 01:18:15 --> Loader Class Initialized
INFO - 2016-08-10 01:18:15 --> Helper loaded: url_helper
INFO - 2016-08-10 01:18:15 --> Helper loaded: date_helper
INFO - 2016-08-10 01:18:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:18:15 --> Database Driver Class Initialized
INFO - 2016-08-10 01:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:18:15 --> Email Class Initialized
INFO - 2016-08-10 01:18:15 --> Model Class Initialized
INFO - 2016-08-10 01:18:15 --> Controller Class Initialized
DEBUG - 2016-08-10 01:18:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:18:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:18:15 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:18:15 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:18:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:15 --> Model Class Initialized
INFO - 2016-08-10 01:18:15 --> Upload Class Initialized
INFO - 2016-08-10 01:18:16 --> Config Class Initialized
INFO - 2016-08-10 01:18:16 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:18:16 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:18:16 --> Utf8 Class Initialized
INFO - 2016-08-10 01:18:16 --> URI Class Initialized
INFO - 2016-08-10 01:18:16 --> Router Class Initialized
INFO - 2016-08-10 01:18:16 --> Output Class Initialized
INFO - 2016-08-10 01:18:16 --> Security Class Initialized
DEBUG - 2016-08-10 01:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:18:16 --> Input Class Initialized
INFO - 2016-08-10 01:18:16 --> Language Class Initialized
INFO - 2016-08-10 01:18:16 --> Loader Class Initialized
INFO - 2016-08-10 01:18:16 --> Helper loaded: url_helper
INFO - 2016-08-10 01:18:16 --> Helper loaded: date_helper
INFO - 2016-08-10 01:18:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:18:16 --> Database Driver Class Initialized
INFO - 2016-08-10 01:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:18:16 --> Email Class Initialized
INFO - 2016-08-10 01:18:16 --> Model Class Initialized
INFO - 2016-08-10 01:18:16 --> Controller Class Initialized
DEBUG - 2016-08-10 01:18:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:18:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:18:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:18:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:16 --> Model Class Initialized
INFO - 2016-08-10 01:18:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:18:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:18:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:18:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:18:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:18:16 --> Final output sent to browser
DEBUG - 2016-08-10 01:18:16 --> Total execution time: 0.4171
INFO - 2016-08-10 01:18:19 --> Config Class Initialized
INFO - 2016-08-10 01:18:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:18:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:18:19 --> Utf8 Class Initialized
INFO - 2016-08-10 01:18:19 --> URI Class Initialized
INFO - 2016-08-10 01:18:19 --> Router Class Initialized
INFO - 2016-08-10 01:18:19 --> Output Class Initialized
INFO - 2016-08-10 01:18:19 --> Security Class Initialized
DEBUG - 2016-08-10 01:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:18:19 --> Input Class Initialized
INFO - 2016-08-10 01:18:20 --> Language Class Initialized
INFO - 2016-08-10 01:18:20 --> Loader Class Initialized
INFO - 2016-08-10 01:18:20 --> Helper loaded: url_helper
INFO - 2016-08-10 01:18:20 --> Helper loaded: date_helper
INFO - 2016-08-10 01:18:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:18:20 --> Database Driver Class Initialized
INFO - 2016-08-10 01:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:18:20 --> Email Class Initialized
INFO - 2016-08-10 01:18:20 --> Model Class Initialized
INFO - 2016-08-10 01:18:20 --> Controller Class Initialized
DEBUG - 2016-08-10 01:18:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:18:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:18:20 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:18:20 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:20 --> Model Class Initialized
INFO - 2016-08-10 01:18:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:18:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:18:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:18:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:18:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:18:20 --> Final output sent to browser
DEBUG - 2016-08-10 01:18:20 --> Total execution time: 0.4162
INFO - 2016-08-10 01:18:30 --> Config Class Initialized
INFO - 2016-08-10 01:18:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:18:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:18:30 --> Utf8 Class Initialized
INFO - 2016-08-10 01:18:30 --> URI Class Initialized
INFO - 2016-08-10 01:18:30 --> Router Class Initialized
INFO - 2016-08-10 01:18:30 --> Output Class Initialized
INFO - 2016-08-10 01:18:30 --> Security Class Initialized
DEBUG - 2016-08-10 01:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:18:30 --> Input Class Initialized
INFO - 2016-08-10 01:18:30 --> Language Class Initialized
INFO - 2016-08-10 01:18:30 --> Loader Class Initialized
INFO - 2016-08-10 01:18:30 --> Helper loaded: url_helper
INFO - 2016-08-10 01:18:30 --> Helper loaded: date_helper
INFO - 2016-08-10 01:18:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:18:30 --> Database Driver Class Initialized
INFO - 2016-08-10 01:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:18:31 --> Email Class Initialized
INFO - 2016-08-10 01:18:31 --> Model Class Initialized
INFO - 2016-08-10 01:18:31 --> Controller Class Initialized
DEBUG - 2016-08-10 01:18:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:18:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:18:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:18:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:18:31 --> Model Class Initialized
INFO - 2016-08-10 01:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:18:31 --> Final output sent to browser
DEBUG - 2016-08-10 01:18:31 --> Total execution time: 0.4189
INFO - 2016-08-10 01:23:12 --> Config Class Initialized
INFO - 2016-08-10 01:23:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:12 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:12 --> URI Class Initialized
INFO - 2016-08-10 01:23:12 --> Router Class Initialized
INFO - 2016-08-10 01:23:12 --> Output Class Initialized
INFO - 2016-08-10 01:23:12 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:12 --> Input Class Initialized
INFO - 2016-08-10 01:23:12 --> Language Class Initialized
INFO - 2016-08-10 01:23:12 --> Loader Class Initialized
INFO - 2016-08-10 01:23:12 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:12 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:12 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:12 --> Email Class Initialized
INFO - 2016-08-10 01:23:12 --> Model Class Initialized
INFO - 2016-08-10 01:23:12 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:12 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:12 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:12 --> Model Class Initialized
INFO - 2016-08-10 01:23:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:23:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:23:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:23:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:23:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:23:13 --> Final output sent to browser
DEBUG - 2016-08-10 01:23:13 --> Total execution time: 0.7709
INFO - 2016-08-10 01:23:16 --> Config Class Initialized
INFO - 2016-08-10 01:23:16 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:16 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:16 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:16 --> URI Class Initialized
INFO - 2016-08-10 01:23:16 --> Router Class Initialized
INFO - 2016-08-10 01:23:16 --> Output Class Initialized
INFO - 2016-08-10 01:23:16 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:16 --> Input Class Initialized
INFO - 2016-08-10 01:23:16 --> Language Class Initialized
INFO - 2016-08-10 01:23:16 --> Loader Class Initialized
INFO - 2016-08-10 01:23:16 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:16 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:16 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:16 --> Email Class Initialized
INFO - 2016-08-10 01:23:16 --> Model Class Initialized
INFO - 2016-08-10 01:23:16 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:16 --> Model Class Initialized
INFO - 2016-08-10 01:23:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:23:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:23:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:23:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:23:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:23:16 --> Final output sent to browser
DEBUG - 2016-08-10 01:23:16 --> Total execution time: 0.4779
INFO - 2016-08-10 01:23:24 --> Config Class Initialized
INFO - 2016-08-10 01:23:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:24 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:24 --> URI Class Initialized
INFO - 2016-08-10 01:23:24 --> Router Class Initialized
INFO - 2016-08-10 01:23:24 --> Output Class Initialized
INFO - 2016-08-10 01:23:24 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:24 --> Input Class Initialized
INFO - 2016-08-10 01:23:24 --> Language Class Initialized
INFO - 2016-08-10 01:23:24 --> Loader Class Initialized
INFO - 2016-08-10 01:23:24 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:24 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:24 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:24 --> Email Class Initialized
INFO - 2016-08-10 01:23:24 --> Model Class Initialized
INFO - 2016-08-10 01:23:24 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:24 --> Model Class Initialized
INFO - 2016-08-10 01:23:24 --> Upload Class Initialized
INFO - 2016-08-10 01:23:24 --> Config Class Initialized
INFO - 2016-08-10 01:23:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:24 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:24 --> URI Class Initialized
INFO - 2016-08-10 01:23:24 --> Router Class Initialized
INFO - 2016-08-10 01:23:24 --> Output Class Initialized
INFO - 2016-08-10 01:23:24 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:24 --> Input Class Initialized
INFO - 2016-08-10 01:23:24 --> Language Class Initialized
INFO - 2016-08-10 01:23:25 --> Loader Class Initialized
INFO - 2016-08-10 01:23:25 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:25 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:25 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:25 --> Email Class Initialized
INFO - 2016-08-10 01:23:25 --> Model Class Initialized
INFO - 2016-08-10 01:23:25 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:25 --> Model Class Initialized
INFO - 2016-08-10 01:23:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:23:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:23:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:23:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:23:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:23:25 --> Final output sent to browser
DEBUG - 2016-08-10 01:23:25 --> Total execution time: 0.7382
INFO - 2016-08-10 01:23:27 --> Config Class Initialized
INFO - 2016-08-10 01:23:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:27 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:27 --> URI Class Initialized
INFO - 2016-08-10 01:23:27 --> Router Class Initialized
INFO - 2016-08-10 01:23:27 --> Output Class Initialized
INFO - 2016-08-10 01:23:27 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:27 --> Input Class Initialized
INFO - 2016-08-10 01:23:27 --> Language Class Initialized
INFO - 2016-08-10 01:23:27 --> Loader Class Initialized
INFO - 2016-08-10 01:23:27 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:27 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:27 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:27 --> Email Class Initialized
INFO - 2016-08-10 01:23:27 --> Model Class Initialized
INFO - 2016-08-10 01:23:27 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:27 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:27 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:27 --> Model Class Initialized
INFO - 2016-08-10 01:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:23:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:23:27 --> Final output sent to browser
DEBUG - 2016-08-10 01:23:27 --> Total execution time: 0.4311
INFO - 2016-08-10 01:23:31 --> Config Class Initialized
INFO - 2016-08-10 01:23:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:23:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:23:31 --> Utf8 Class Initialized
INFO - 2016-08-10 01:23:31 --> URI Class Initialized
INFO - 2016-08-10 01:23:31 --> Router Class Initialized
INFO - 2016-08-10 01:23:31 --> Output Class Initialized
INFO - 2016-08-10 01:23:31 --> Security Class Initialized
DEBUG - 2016-08-10 01:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:23:31 --> Input Class Initialized
INFO - 2016-08-10 01:23:31 --> Language Class Initialized
INFO - 2016-08-10 01:23:31 --> Loader Class Initialized
INFO - 2016-08-10 01:23:31 --> Helper loaded: url_helper
INFO - 2016-08-10 01:23:31 --> Helper loaded: date_helper
INFO - 2016-08-10 01:23:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:23:31 --> Database Driver Class Initialized
INFO - 2016-08-10 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:23:31 --> Email Class Initialized
INFO - 2016-08-10 01:23:31 --> Model Class Initialized
INFO - 2016-08-10 01:23:31 --> Controller Class Initialized
DEBUG - 2016-08-10 01:23:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:23:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:23:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:23:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:23:32 --> Model Class Initialized
INFO - 2016-08-10 01:23:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:23:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:23:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:23:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:23:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:23:32 --> Final output sent to browser
DEBUG - 2016-08-10 01:23:32 --> Total execution time: 0.4524
INFO - 2016-08-10 01:25:12 --> Config Class Initialized
INFO - 2016-08-10 01:25:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:25:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:25:12 --> Utf8 Class Initialized
INFO - 2016-08-10 01:25:12 --> URI Class Initialized
INFO - 2016-08-10 01:25:12 --> Router Class Initialized
INFO - 2016-08-10 01:25:12 --> Output Class Initialized
INFO - 2016-08-10 01:25:12 --> Security Class Initialized
DEBUG - 2016-08-10 01:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:25:13 --> Input Class Initialized
INFO - 2016-08-10 01:25:13 --> Language Class Initialized
INFO - 2016-08-10 01:25:13 --> Loader Class Initialized
INFO - 2016-08-10 01:25:13 --> Helper loaded: url_helper
INFO - 2016-08-10 01:25:13 --> Helper loaded: date_helper
INFO - 2016-08-10 01:25:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:25:13 --> Database Driver Class Initialized
INFO - 2016-08-10 01:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:25:13 --> Email Class Initialized
INFO - 2016-08-10 01:25:13 --> Model Class Initialized
INFO - 2016-08-10 01:25:13 --> Controller Class Initialized
DEBUG - 2016-08-10 01:25:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:25:13 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:25:13 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:13 --> Model Class Initialized
INFO - 2016-08-10 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:25:13 --> Final output sent to browser
DEBUG - 2016-08-10 01:25:13 --> Total execution time: 0.7335
INFO - 2016-08-10 01:25:20 --> Config Class Initialized
INFO - 2016-08-10 01:25:20 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:25:20 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:25:20 --> Utf8 Class Initialized
INFO - 2016-08-10 01:25:20 --> URI Class Initialized
INFO - 2016-08-10 01:25:20 --> Router Class Initialized
INFO - 2016-08-10 01:25:20 --> Output Class Initialized
INFO - 2016-08-10 01:25:20 --> Security Class Initialized
DEBUG - 2016-08-10 01:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:25:20 --> Input Class Initialized
INFO - 2016-08-10 01:25:20 --> Language Class Initialized
INFO - 2016-08-10 01:25:20 --> Loader Class Initialized
INFO - 2016-08-10 01:25:20 --> Helper loaded: url_helper
INFO - 2016-08-10 01:25:20 --> Helper loaded: date_helper
INFO - 2016-08-10 01:25:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:25:20 --> Database Driver Class Initialized
INFO - 2016-08-10 01:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:25:20 --> Email Class Initialized
INFO - 2016-08-10 01:25:20 --> Model Class Initialized
INFO - 2016-08-10 01:25:20 --> Controller Class Initialized
DEBUG - 2016-08-10 01:25:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:25:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:25:20 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:25:20 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:20 --> Model Class Initialized
INFO - 2016-08-10 01:25:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 01:25:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 01:25:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-10 01:25:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 01:25:20 --> Final output sent to browser
DEBUG - 2016-08-10 01:25:20 --> Total execution time: 0.4588
INFO - 2016-08-10 01:25:21 --> Config Class Initialized
INFO - 2016-08-10 01:25:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:25:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:25:21 --> Utf8 Class Initialized
INFO - 2016-08-10 01:25:21 --> URI Class Initialized
INFO - 2016-08-10 01:25:21 --> Router Class Initialized
INFO - 2016-08-10 01:25:21 --> Output Class Initialized
INFO - 2016-08-10 01:25:21 --> Security Class Initialized
DEBUG - 2016-08-10 01:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:25:21 --> Input Class Initialized
INFO - 2016-08-10 01:25:21 --> Language Class Initialized
ERROR - 2016-08-10 01:25:21 --> 404 Page Not Found: Assets/css
INFO - 2016-08-10 01:25:43 --> Config Class Initialized
INFO - 2016-08-10 01:25:43 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:25:43 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:25:43 --> Utf8 Class Initialized
INFO - 2016-08-10 01:25:43 --> URI Class Initialized
INFO - 2016-08-10 01:25:43 --> Router Class Initialized
INFO - 2016-08-10 01:25:43 --> Output Class Initialized
INFO - 2016-08-10 01:25:43 --> Security Class Initialized
DEBUG - 2016-08-10 01:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:25:43 --> Input Class Initialized
INFO - 2016-08-10 01:25:43 --> Language Class Initialized
INFO - 2016-08-10 01:25:43 --> Loader Class Initialized
INFO - 2016-08-10 01:25:43 --> Helper loaded: url_helper
INFO - 2016-08-10 01:25:43 --> Helper loaded: date_helper
INFO - 2016-08-10 01:25:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:25:43 --> Database Driver Class Initialized
INFO - 2016-08-10 01:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:25:43 --> Email Class Initialized
INFO - 2016-08-10 01:25:43 --> Model Class Initialized
INFO - 2016-08-10 01:25:43 --> Controller Class Initialized
DEBUG - 2016-08-10 01:25:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:25:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:25:43 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:25:43 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:43 --> Model Class Initialized
INFO - 2016-08-10 01:25:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 01:25:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 01:25:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-10 01:25:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 01:25:43 --> Final output sent to browser
DEBUG - 2016-08-10 01:25:43 --> Total execution time: 0.4699
INFO - 2016-08-10 01:25:58 --> Config Class Initialized
INFO - 2016-08-10 01:25:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:25:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:25:58 --> Utf8 Class Initialized
INFO - 2016-08-10 01:25:58 --> URI Class Initialized
INFO - 2016-08-10 01:25:58 --> Router Class Initialized
INFO - 2016-08-10 01:25:58 --> Output Class Initialized
INFO - 2016-08-10 01:25:58 --> Security Class Initialized
DEBUG - 2016-08-10 01:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:25:58 --> Input Class Initialized
INFO - 2016-08-10 01:25:58 --> Language Class Initialized
INFO - 2016-08-10 01:25:58 --> Loader Class Initialized
INFO - 2016-08-10 01:25:58 --> Helper loaded: url_helper
INFO - 2016-08-10 01:25:58 --> Helper loaded: date_helper
INFO - 2016-08-10 01:25:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:25:58 --> Database Driver Class Initialized
INFO - 2016-08-10 01:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:25:58 --> Email Class Initialized
INFO - 2016-08-10 01:25:58 --> Model Class Initialized
INFO - 2016-08-10 01:25:58 --> Controller Class Initialized
DEBUG - 2016-08-10 01:25:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:25:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:25:58 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:25:58 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:25:58 --> Model Class Initialized
INFO - 2016-08-10 01:25:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:25:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:25:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:25:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:25:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:25:58 --> Final output sent to browser
DEBUG - 2016-08-10 01:25:58 --> Total execution time: 0.4765
INFO - 2016-08-10 01:27:33 --> Config Class Initialized
INFO - 2016-08-10 01:27:34 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:27:34 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:27:34 --> Utf8 Class Initialized
INFO - 2016-08-10 01:27:34 --> URI Class Initialized
INFO - 2016-08-10 01:27:34 --> Router Class Initialized
INFO - 2016-08-10 01:27:34 --> Output Class Initialized
INFO - 2016-08-10 01:27:34 --> Security Class Initialized
DEBUG - 2016-08-10 01:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:27:34 --> Input Class Initialized
INFO - 2016-08-10 01:27:34 --> Language Class Initialized
INFO - 2016-08-10 01:27:34 --> Loader Class Initialized
INFO - 2016-08-10 01:27:34 --> Helper loaded: url_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: date_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:27:34 --> Database Driver Class Initialized
INFO - 2016-08-10 01:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:27:34 --> Email Class Initialized
INFO - 2016-08-10 01:27:34 --> Model Class Initialized
INFO - 2016-08-10 01:27:34 --> Controller Class Initialized
DEBUG - 2016-08-10 01:27:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:27:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:27:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:27:34 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:27:34 --> Model Class Initialized
INFO - 2016-08-10 01:27:34 --> Upload Class Initialized
INFO - 2016-08-10 01:27:34 --> Config Class Initialized
INFO - 2016-08-10 01:27:34 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:27:34 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:27:34 --> Utf8 Class Initialized
INFO - 2016-08-10 01:27:34 --> URI Class Initialized
INFO - 2016-08-10 01:27:34 --> Router Class Initialized
INFO - 2016-08-10 01:27:34 --> Output Class Initialized
INFO - 2016-08-10 01:27:34 --> Security Class Initialized
DEBUG - 2016-08-10 01:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:27:34 --> Input Class Initialized
INFO - 2016-08-10 01:27:34 --> Language Class Initialized
INFO - 2016-08-10 01:27:34 --> Loader Class Initialized
INFO - 2016-08-10 01:27:34 --> Helper loaded: url_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: date_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:27:34 --> Database Driver Class Initialized
INFO - 2016-08-10 01:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:27:34 --> Email Class Initialized
INFO - 2016-08-10 01:27:34 --> Model Class Initialized
INFO - 2016-08-10 01:27:34 --> Controller Class Initialized
DEBUG - 2016-08-10 01:27:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:27:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:27:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:27:34 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:27:34 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:27:34 --> Model Class Initialized
INFO - 2016-08-10 01:27:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:27:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:27:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:27:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:27:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:27:34 --> Final output sent to browser
DEBUG - 2016-08-10 01:27:34 --> Total execution time: 0.4402
INFO - 2016-08-10 01:28:12 --> Config Class Initialized
INFO - 2016-08-10 01:28:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:28:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:28:12 --> Utf8 Class Initialized
INFO - 2016-08-10 01:28:12 --> URI Class Initialized
INFO - 2016-08-10 01:28:12 --> Router Class Initialized
INFO - 2016-08-10 01:28:12 --> Output Class Initialized
INFO - 2016-08-10 01:28:12 --> Security Class Initialized
DEBUG - 2016-08-10 01:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:28:12 --> Input Class Initialized
INFO - 2016-08-10 01:28:12 --> Language Class Initialized
INFO - 2016-08-10 01:28:12 --> Loader Class Initialized
INFO - 2016-08-10 01:28:12 --> Helper loaded: url_helper
INFO - 2016-08-10 01:28:12 --> Helper loaded: date_helper
INFO - 2016-08-10 01:28:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:28:12 --> Database Driver Class Initialized
INFO - 2016-08-10 01:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:28:12 --> Email Class Initialized
INFO - 2016-08-10 01:28:12 --> Model Class Initialized
INFO - 2016-08-10 01:28:12 --> Controller Class Initialized
DEBUG - 2016-08-10 01:28:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:28:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:28:12 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:28:12 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:12 --> Model Class Initialized
INFO - 2016-08-10 01:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:28:12 --> Final output sent to browser
DEBUG - 2016-08-10 01:28:12 --> Total execution time: 0.4567
INFO - 2016-08-10 01:28:55 --> Config Class Initialized
INFO - 2016-08-10 01:28:55 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:28:55 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:28:55 --> Utf8 Class Initialized
INFO - 2016-08-10 01:28:55 --> URI Class Initialized
INFO - 2016-08-10 01:28:55 --> Router Class Initialized
INFO - 2016-08-10 01:28:55 --> Output Class Initialized
INFO - 2016-08-10 01:28:55 --> Security Class Initialized
DEBUG - 2016-08-10 01:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:28:55 --> Input Class Initialized
INFO - 2016-08-10 01:28:55 --> Language Class Initialized
INFO - 2016-08-10 01:28:55 --> Loader Class Initialized
INFO - 2016-08-10 01:28:55 --> Helper loaded: url_helper
INFO - 2016-08-10 01:28:55 --> Helper loaded: date_helper
INFO - 2016-08-10 01:28:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:28:55 --> Database Driver Class Initialized
INFO - 2016-08-10 01:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:28:55 --> Email Class Initialized
INFO - 2016-08-10 01:28:55 --> Model Class Initialized
INFO - 2016-08-10 01:28:55 --> Controller Class Initialized
DEBUG - 2016-08-10 01:28:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:28:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:28:55 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:28:55 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:55 --> Model Class Initialized
INFO - 2016-08-10 01:28:55 --> Upload Class Initialized
INFO - 2016-08-10 01:28:55 --> Config Class Initialized
INFO - 2016-08-10 01:28:55 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:28:55 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:28:55 --> Utf8 Class Initialized
INFO - 2016-08-10 01:28:55 --> URI Class Initialized
INFO - 2016-08-10 01:28:55 --> Router Class Initialized
INFO - 2016-08-10 01:28:55 --> Output Class Initialized
INFO - 2016-08-10 01:28:55 --> Security Class Initialized
DEBUG - 2016-08-10 01:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:28:55 --> Input Class Initialized
INFO - 2016-08-10 01:28:55 --> Language Class Initialized
INFO - 2016-08-10 01:28:56 --> Loader Class Initialized
INFO - 2016-08-10 01:28:56 --> Helper loaded: url_helper
INFO - 2016-08-10 01:28:56 --> Helper loaded: date_helper
INFO - 2016-08-10 01:28:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:28:56 --> Database Driver Class Initialized
INFO - 2016-08-10 01:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:28:56 --> Email Class Initialized
INFO - 2016-08-10 01:28:56 --> Model Class Initialized
INFO - 2016-08-10 01:28:56 --> Controller Class Initialized
DEBUG - 2016-08-10 01:28:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:28:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:28:56 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:28:56 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:28:56 --> Model Class Initialized
INFO - 2016-08-10 01:28:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:28:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:28:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:28:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:28:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:28:56 --> Final output sent to browser
DEBUG - 2016-08-10 01:28:56 --> Total execution time: 0.8885
INFO - 2016-08-10 01:29:02 --> Config Class Initialized
INFO - 2016-08-10 01:29:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:29:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:29:02 --> Utf8 Class Initialized
INFO - 2016-08-10 01:29:02 --> URI Class Initialized
INFO - 2016-08-10 01:29:02 --> Router Class Initialized
INFO - 2016-08-10 01:29:02 --> Output Class Initialized
INFO - 2016-08-10 01:29:02 --> Security Class Initialized
DEBUG - 2016-08-10 01:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:29:02 --> Input Class Initialized
INFO - 2016-08-10 01:29:02 --> Language Class Initialized
INFO - 2016-08-10 01:29:02 --> Loader Class Initialized
INFO - 2016-08-10 01:29:02 --> Helper loaded: url_helper
INFO - 2016-08-10 01:29:03 --> Helper loaded: date_helper
INFO - 2016-08-10 01:29:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:29:03 --> Database Driver Class Initialized
INFO - 2016-08-10 01:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:29:03 --> Email Class Initialized
INFO - 2016-08-10 01:29:03 --> Model Class Initialized
INFO - 2016-08-10 01:29:03 --> Controller Class Initialized
DEBUG - 2016-08-10 01:29:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:29:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:29:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:29:03 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:29:03 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:29:03 --> Model Class Initialized
INFO - 2016-08-10 01:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:29:03 --> Final output sent to browser
DEBUG - 2016-08-10 01:29:03 --> Total execution time: 0.4403
INFO - 2016-08-10 01:30:20 --> Config Class Initialized
INFO - 2016-08-10 01:30:20 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:30:20 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:30:20 --> Utf8 Class Initialized
INFO - 2016-08-10 01:30:20 --> URI Class Initialized
INFO - 2016-08-10 01:30:20 --> Router Class Initialized
INFO - 2016-08-10 01:30:20 --> Output Class Initialized
INFO - 2016-08-10 01:30:20 --> Security Class Initialized
DEBUG - 2016-08-10 01:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:30:20 --> Input Class Initialized
INFO - 2016-08-10 01:30:20 --> Language Class Initialized
INFO - 2016-08-10 01:30:20 --> Loader Class Initialized
INFO - 2016-08-10 01:30:20 --> Helper loaded: url_helper
INFO - 2016-08-10 01:30:20 --> Helper loaded: date_helper
INFO - 2016-08-10 01:30:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:30:20 --> Database Driver Class Initialized
INFO - 2016-08-10 01:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:30:20 --> Email Class Initialized
INFO - 2016-08-10 01:30:20 --> Model Class Initialized
INFO - 2016-08-10 01:30:20 --> Controller Class Initialized
DEBUG - 2016-08-10 01:30:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:30:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:30:21 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:30:21 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:21 --> Model Class Initialized
INFO - 2016-08-10 01:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:30:21 --> Final output sent to browser
DEBUG - 2016-08-10 01:30:21 --> Total execution time: 0.7487
INFO - 2016-08-10 01:30:24 --> Config Class Initialized
INFO - 2016-08-10 01:30:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:30:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:30:24 --> Utf8 Class Initialized
INFO - 2016-08-10 01:30:24 --> URI Class Initialized
INFO - 2016-08-10 01:30:24 --> Router Class Initialized
INFO - 2016-08-10 01:30:24 --> Output Class Initialized
INFO - 2016-08-10 01:30:24 --> Security Class Initialized
DEBUG - 2016-08-10 01:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:30:24 --> Input Class Initialized
INFO - 2016-08-10 01:30:24 --> Language Class Initialized
INFO - 2016-08-10 01:30:24 --> Loader Class Initialized
INFO - 2016-08-10 01:30:24 --> Helper loaded: url_helper
INFO - 2016-08-10 01:30:24 --> Helper loaded: date_helper
INFO - 2016-08-10 01:30:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:30:24 --> Database Driver Class Initialized
INFO - 2016-08-10 01:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:30:24 --> Email Class Initialized
INFO - 2016-08-10 01:30:24 --> Model Class Initialized
INFO - 2016-08-10 01:30:24 --> Controller Class Initialized
DEBUG - 2016-08-10 01:30:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:30:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:30:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:30:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:24 --> Model Class Initialized
INFO - 2016-08-10 01:30:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:30:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:30:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:30:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:30:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:30:24 --> Final output sent to browser
DEBUG - 2016-08-10 01:30:24 --> Total execution time: 0.5335
INFO - 2016-08-10 01:30:30 --> Config Class Initialized
INFO - 2016-08-10 01:30:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:30:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:30:30 --> Utf8 Class Initialized
INFO - 2016-08-10 01:30:30 --> URI Class Initialized
INFO - 2016-08-10 01:30:30 --> Router Class Initialized
INFO - 2016-08-10 01:30:30 --> Output Class Initialized
INFO - 2016-08-10 01:30:30 --> Security Class Initialized
DEBUG - 2016-08-10 01:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:30:30 --> Input Class Initialized
INFO - 2016-08-10 01:30:30 --> Language Class Initialized
INFO - 2016-08-10 01:30:30 --> Loader Class Initialized
INFO - 2016-08-10 01:30:30 --> Helper loaded: url_helper
INFO - 2016-08-10 01:30:30 --> Helper loaded: date_helper
INFO - 2016-08-10 01:30:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:30:30 --> Database Driver Class Initialized
INFO - 2016-08-10 01:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:30:30 --> Email Class Initialized
INFO - 2016-08-10 01:30:30 --> Model Class Initialized
INFO - 2016-08-10 01:30:30 --> Controller Class Initialized
DEBUG - 2016-08-10 01:30:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:30:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:30:30 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:30:30 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:30 --> Model Class Initialized
INFO - 2016-08-10 01:30:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:30:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:30:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:30:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:30:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:30:30 --> Final output sent to browser
DEBUG - 2016-08-10 01:30:30 --> Total execution time: 0.4647
INFO - 2016-08-10 01:30:50 --> Config Class Initialized
INFO - 2016-08-10 01:30:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:30:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:30:50 --> Utf8 Class Initialized
INFO - 2016-08-10 01:30:50 --> URI Class Initialized
INFO - 2016-08-10 01:30:50 --> Router Class Initialized
INFO - 2016-08-10 01:30:50 --> Output Class Initialized
INFO - 2016-08-10 01:30:50 --> Security Class Initialized
DEBUG - 2016-08-10 01:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:30:50 --> Input Class Initialized
INFO - 2016-08-10 01:30:50 --> Language Class Initialized
INFO - 2016-08-10 01:30:50 --> Loader Class Initialized
INFO - 2016-08-10 01:30:51 --> Helper loaded: url_helper
INFO - 2016-08-10 01:30:51 --> Helper loaded: date_helper
INFO - 2016-08-10 01:30:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:30:51 --> Database Driver Class Initialized
INFO - 2016-08-10 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:30:51 --> Email Class Initialized
INFO - 2016-08-10 01:30:51 --> Model Class Initialized
INFO - 2016-08-10 01:30:51 --> Controller Class Initialized
DEBUG - 2016-08-10 01:30:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:30:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:30:51 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:30:51 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:30:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:30:51 --> Model Class Initialized
INFO - 2016-08-10 01:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:30:51 --> Final output sent to browser
DEBUG - 2016-08-10 01:30:51 --> Total execution time: 0.5903
INFO - 2016-08-10 01:31:17 --> Config Class Initialized
INFO - 2016-08-10 01:31:17 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:18 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:18 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:18 --> URI Class Initialized
INFO - 2016-08-10 01:31:18 --> Router Class Initialized
INFO - 2016-08-10 01:31:18 --> Output Class Initialized
INFO - 2016-08-10 01:31:18 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:18 --> Input Class Initialized
INFO - 2016-08-10 01:31:18 --> Language Class Initialized
INFO - 2016-08-10 01:31:18 --> Loader Class Initialized
INFO - 2016-08-10 01:31:18 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:18 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:18 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:18 --> Email Class Initialized
INFO - 2016-08-10 01:31:18 --> Model Class Initialized
INFO - 2016-08-10 01:31:18 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:18 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:18 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:18 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:18 --> Model Class Initialized
INFO - 2016-08-10 01:31:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:31:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:18 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:18 --> Total execution time: 0.7524
INFO - 2016-08-10 01:31:21 --> Config Class Initialized
INFO - 2016-08-10 01:31:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:21 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:21 --> URI Class Initialized
INFO - 2016-08-10 01:31:21 --> Router Class Initialized
INFO - 2016-08-10 01:31:21 --> Output Class Initialized
INFO - 2016-08-10 01:31:21 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:21 --> Input Class Initialized
INFO - 2016-08-10 01:31:21 --> Language Class Initialized
INFO - 2016-08-10 01:31:21 --> Loader Class Initialized
INFO - 2016-08-10 01:31:21 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:21 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:21 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:21 --> Email Class Initialized
INFO - 2016-08-10 01:31:21 --> Model Class Initialized
INFO - 2016-08-10 01:31:21 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:21 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:21 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:21 --> Model Class Initialized
INFO - 2016-08-10 01:31:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:31:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:21 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:21 --> Total execution time: 0.4673
INFO - 2016-08-10 01:31:23 --> Config Class Initialized
INFO - 2016-08-10 01:31:23 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:23 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:23 --> URI Class Initialized
INFO - 2016-08-10 01:31:23 --> Router Class Initialized
INFO - 2016-08-10 01:31:23 --> Output Class Initialized
INFO - 2016-08-10 01:31:23 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:23 --> Input Class Initialized
INFO - 2016-08-10 01:31:23 --> Language Class Initialized
INFO - 2016-08-10 01:31:23 --> Loader Class Initialized
INFO - 2016-08-10 01:31:23 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:23 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:23 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:23 --> Email Class Initialized
INFO - 2016-08-10 01:31:23 --> Model Class Initialized
INFO - 2016-08-10 01:31:23 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:24 --> Model Class Initialized
INFO - 2016-08-10 01:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:24 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:24 --> Total execution time: 0.5270
INFO - 2016-08-10 01:31:28 --> Config Class Initialized
INFO - 2016-08-10 01:31:28 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:28 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:28 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:28 --> URI Class Initialized
INFO - 2016-08-10 01:31:28 --> Router Class Initialized
INFO - 2016-08-10 01:31:28 --> Output Class Initialized
INFO - 2016-08-10 01:31:28 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:28 --> Input Class Initialized
INFO - 2016-08-10 01:31:28 --> Language Class Initialized
INFO - 2016-08-10 01:31:28 --> Loader Class Initialized
INFO - 2016-08-10 01:31:28 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:28 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:28 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:28 --> Email Class Initialized
INFO - 2016-08-10 01:31:28 --> Model Class Initialized
INFO - 2016-08-10 01:31:28 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:28 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:28 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:28 --> Model Class Initialized
INFO - 2016-08-10 01:31:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:31:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:28 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:28 --> Total execution time: 0.4781
INFO - 2016-08-10 01:31:45 --> Config Class Initialized
INFO - 2016-08-10 01:31:45 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:45 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:45 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:45 --> URI Class Initialized
INFO - 2016-08-10 01:31:45 --> Router Class Initialized
INFO - 2016-08-10 01:31:45 --> Output Class Initialized
INFO - 2016-08-10 01:31:45 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:45 --> Input Class Initialized
INFO - 2016-08-10 01:31:45 --> Language Class Initialized
INFO - 2016-08-10 01:31:45 --> Loader Class Initialized
INFO - 2016-08-10 01:31:45 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:45 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:45 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:45 --> Email Class Initialized
INFO - 2016-08-10 01:31:45 --> Model Class Initialized
INFO - 2016-08-10 01:31:45 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:45 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:45 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:45 --> Model Class Initialized
INFO - 2016-08-10 01:31:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:31:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:45 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:45 --> Total execution time: 0.7614
INFO - 2016-08-10 01:31:48 --> Config Class Initialized
INFO - 2016-08-10 01:31:48 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:48 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:48 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:48 --> URI Class Initialized
INFO - 2016-08-10 01:31:48 --> Router Class Initialized
INFO - 2016-08-10 01:31:48 --> Output Class Initialized
INFO - 2016-08-10 01:31:48 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:48 --> Input Class Initialized
INFO - 2016-08-10 01:31:48 --> Language Class Initialized
INFO - 2016-08-10 01:31:48 --> Loader Class Initialized
INFO - 2016-08-10 01:31:48 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:48 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:48 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:48 --> Email Class Initialized
INFO - 2016-08-10 01:31:48 --> Model Class Initialized
INFO - 2016-08-10 01:31:48 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:48 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:48 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:48 --> Model Class Initialized
INFO - 2016-08-10 01:31:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 01:31:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:48 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:48 --> Total execution time: 0.4775
INFO - 2016-08-10 01:31:51 --> Config Class Initialized
INFO - 2016-08-10 01:31:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:51 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:51 --> URI Class Initialized
INFO - 2016-08-10 01:31:51 --> Router Class Initialized
INFO - 2016-08-10 01:31:51 --> Output Class Initialized
INFO - 2016-08-10 01:31:51 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:51 --> Input Class Initialized
INFO - 2016-08-10 01:31:51 --> Language Class Initialized
INFO - 2016-08-10 01:31:51 --> Loader Class Initialized
INFO - 2016-08-10 01:31:51 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:51 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:51 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:51 --> Email Class Initialized
INFO - 2016-08-10 01:31:51 --> Model Class Initialized
INFO - 2016-08-10 01:31:51 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:51 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:51 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:51 --> Model Class Initialized
INFO - 2016-08-10 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:51 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:51 --> Total execution time: 0.4660
INFO - 2016-08-10 01:31:53 --> Config Class Initialized
INFO - 2016-08-10 01:31:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:53 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:53 --> URI Class Initialized
INFO - 2016-08-10 01:31:53 --> Router Class Initialized
INFO - 2016-08-10 01:31:53 --> Output Class Initialized
INFO - 2016-08-10 01:31:53 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:53 --> Input Class Initialized
INFO - 2016-08-10 01:31:53 --> Language Class Initialized
INFO - 2016-08-10 01:31:53 --> Loader Class Initialized
INFO - 2016-08-10 01:31:53 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:53 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:53 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:53 --> Email Class Initialized
INFO - 2016-08-10 01:31:53 --> Model Class Initialized
INFO - 2016-08-10 01:31:53 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:54 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:54 --> Model Class Initialized
INFO - 2016-08-10 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:54 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:54 --> Total execution time: 0.4793
INFO - 2016-08-10 01:31:55 --> Config Class Initialized
INFO - 2016-08-10 01:31:55 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:31:55 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:31:55 --> Utf8 Class Initialized
INFO - 2016-08-10 01:31:55 --> URI Class Initialized
INFO - 2016-08-10 01:31:55 --> Router Class Initialized
INFO - 2016-08-10 01:31:55 --> Output Class Initialized
INFO - 2016-08-10 01:31:55 --> Security Class Initialized
DEBUG - 2016-08-10 01:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:31:55 --> Input Class Initialized
INFO - 2016-08-10 01:31:55 --> Language Class Initialized
INFO - 2016-08-10 01:31:55 --> Loader Class Initialized
INFO - 2016-08-10 01:31:55 --> Helper loaded: url_helper
INFO - 2016-08-10 01:31:55 --> Helper loaded: date_helper
INFO - 2016-08-10 01:31:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:31:55 --> Database Driver Class Initialized
INFO - 2016-08-10 01:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:31:56 --> Email Class Initialized
INFO - 2016-08-10 01:31:56 --> Model Class Initialized
INFO - 2016-08-10 01:31:56 --> Controller Class Initialized
DEBUG - 2016-08-10 01:31:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:31:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:31:56 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:31:56 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:31:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:31:56 --> Model Class Initialized
INFO - 2016-08-10 01:31:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:31:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:31:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:31:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 01:31:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:31:56 --> Final output sent to browser
DEBUG - 2016-08-10 01:31:56 --> Total execution time: 0.5066
INFO - 2016-08-10 01:51:27 --> Config Class Initialized
INFO - 2016-08-10 01:51:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:51:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:51:27 --> Utf8 Class Initialized
INFO - 2016-08-10 01:51:27 --> URI Class Initialized
INFO - 2016-08-10 01:51:27 --> Router Class Initialized
INFO - 2016-08-10 01:51:27 --> Output Class Initialized
INFO - 2016-08-10 01:51:27 --> Security Class Initialized
DEBUG - 2016-08-10 01:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:51:27 --> Input Class Initialized
INFO - 2016-08-10 01:51:27 --> Language Class Initialized
INFO - 2016-08-10 01:51:27 --> Loader Class Initialized
INFO - 2016-08-10 01:51:27 --> Helper loaded: url_helper
INFO - 2016-08-10 01:51:27 --> Helper loaded: date_helper
INFO - 2016-08-10 01:51:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:51:27 --> Database Driver Class Initialized
INFO - 2016-08-10 01:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:51:27 --> Email Class Initialized
INFO - 2016-08-10 01:51:27 --> Model Class Initialized
INFO - 2016-08-10 01:51:27 --> Controller Class Initialized
DEBUG - 2016-08-10 01:51:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:51:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:51:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:51:27 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:51:27 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:51:27 --> Model Class Initialized
INFO - 2016-08-10 01:51:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 01:51:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 01:51:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 01:51:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 01:51:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 01:51:27 --> Final output sent to browser
DEBUG - 2016-08-10 01:51:27 --> Total execution time: 0.4921
INFO - 2016-08-10 01:51:37 --> Config Class Initialized
INFO - 2016-08-10 01:51:37 --> Hooks Class Initialized
DEBUG - 2016-08-10 01:51:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 01:51:37 --> Utf8 Class Initialized
INFO - 2016-08-10 01:51:37 --> URI Class Initialized
INFO - 2016-08-10 01:51:37 --> Router Class Initialized
INFO - 2016-08-10 01:51:37 --> Output Class Initialized
INFO - 2016-08-10 01:51:37 --> Security Class Initialized
DEBUG - 2016-08-10 01:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 01:51:37 --> Input Class Initialized
INFO - 2016-08-10 01:51:37 --> Language Class Initialized
INFO - 2016-08-10 01:51:37 --> Loader Class Initialized
INFO - 2016-08-10 01:51:37 --> Helper loaded: url_helper
INFO - 2016-08-10 01:51:37 --> Helper loaded: date_helper
INFO - 2016-08-10 01:51:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 01:51:37 --> Database Driver Class Initialized
INFO - 2016-08-10 01:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 01:51:37 --> Email Class Initialized
INFO - 2016-08-10 01:51:37 --> Model Class Initialized
INFO - 2016-08-10 01:51:37 --> Controller Class Initialized
DEBUG - 2016-08-10 01:51:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 01:51:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:51:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 01:51:37 --> Helper loaded: cookie_helper
INFO - 2016-08-10 01:51:37 --> Helper loaded: language_helper
DEBUG - 2016-08-10 01:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 01:51:37 --> Model Class Initialized
INFO - 2016-08-10 01:51:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 01:51:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 01:51:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-10 01:51:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 01:51:38 --> Final output sent to browser
DEBUG - 2016-08-10 01:51:38 --> Total execution time: 0.7121
INFO - 2016-08-10 02:01:29 --> Config Class Initialized
INFO - 2016-08-10 02:01:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:01:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:01:29 --> Utf8 Class Initialized
INFO - 2016-08-10 02:01:29 --> URI Class Initialized
INFO - 2016-08-10 02:01:29 --> Router Class Initialized
INFO - 2016-08-10 02:01:29 --> Output Class Initialized
INFO - 2016-08-10 02:01:29 --> Security Class Initialized
DEBUG - 2016-08-10 02:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:01:29 --> Input Class Initialized
INFO - 2016-08-10 02:01:29 --> Language Class Initialized
INFO - 2016-08-10 02:01:29 --> Loader Class Initialized
INFO - 2016-08-10 02:01:29 --> Helper loaded: url_helper
INFO - 2016-08-10 02:01:29 --> Helper loaded: date_helper
INFO - 2016-08-10 02:01:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:01:29 --> Database Driver Class Initialized
INFO - 2016-08-10 02:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:01:29 --> Email Class Initialized
INFO - 2016-08-10 02:01:29 --> Model Class Initialized
INFO - 2016-08-10 02:01:29 --> Controller Class Initialized
DEBUG - 2016-08-10 02:01:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:01:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:01:29 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:01:29 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:29 --> Model Class Initialized
INFO - 2016-08-10 02:01:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:01:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:01:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:01:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:01:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:01:30 --> Final output sent to browser
DEBUG - 2016-08-10 02:01:30 --> Total execution time: 0.9990
INFO - 2016-08-10 02:01:39 --> Config Class Initialized
INFO - 2016-08-10 02:01:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:01:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:01:39 --> Utf8 Class Initialized
INFO - 2016-08-10 02:01:39 --> URI Class Initialized
INFO - 2016-08-10 02:01:39 --> Router Class Initialized
INFO - 2016-08-10 02:01:40 --> Output Class Initialized
INFO - 2016-08-10 02:01:40 --> Security Class Initialized
DEBUG - 2016-08-10 02:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:01:40 --> Input Class Initialized
INFO - 2016-08-10 02:01:40 --> Language Class Initialized
INFO - 2016-08-10 02:01:40 --> Loader Class Initialized
INFO - 2016-08-10 02:01:40 --> Helper loaded: url_helper
INFO - 2016-08-10 02:01:40 --> Helper loaded: date_helper
INFO - 2016-08-10 02:01:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:01:40 --> Database Driver Class Initialized
INFO - 2016-08-10 02:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:01:40 --> Email Class Initialized
INFO - 2016-08-10 02:01:40 --> Model Class Initialized
INFO - 2016-08-10 02:01:40 --> Controller Class Initialized
DEBUG - 2016-08-10 02:01:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:01:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:01:40 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:01:40 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:40 --> Model Class Initialized
INFO - 2016-08-10 02:01:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:01:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:01:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:01:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:01:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:01:40 --> Final output sent to browser
DEBUG - 2016-08-10 02:01:40 --> Total execution time: 0.6655
INFO - 2016-08-10 02:01:53 --> Config Class Initialized
INFO - 2016-08-10 02:01:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:01:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:01:53 --> Utf8 Class Initialized
INFO - 2016-08-10 02:01:53 --> URI Class Initialized
INFO - 2016-08-10 02:01:53 --> Router Class Initialized
INFO - 2016-08-10 02:01:53 --> Output Class Initialized
INFO - 2016-08-10 02:01:53 --> Security Class Initialized
DEBUG - 2016-08-10 02:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:01:53 --> Input Class Initialized
INFO - 2016-08-10 02:01:53 --> Language Class Initialized
INFO - 2016-08-10 02:01:53 --> Loader Class Initialized
INFO - 2016-08-10 02:01:53 --> Helper loaded: url_helper
INFO - 2016-08-10 02:01:53 --> Helper loaded: date_helper
INFO - 2016-08-10 02:01:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:01:53 --> Database Driver Class Initialized
INFO - 2016-08-10 02:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:01:53 --> Email Class Initialized
INFO - 2016-08-10 02:01:53 --> Model Class Initialized
INFO - 2016-08-10 02:01:53 --> Controller Class Initialized
DEBUG - 2016-08-10 02:01:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:01:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:01:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:01:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:01:53 --> Model Class Initialized
INFO - 2016-08-10 02:01:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:01:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:01:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:01:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:01:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:01:53 --> Final output sent to browser
DEBUG - 2016-08-10 02:01:53 --> Total execution time: 0.4832
INFO - 2016-08-10 02:02:42 --> Config Class Initialized
INFO - 2016-08-10 02:02:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:02:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:02:42 --> Utf8 Class Initialized
INFO - 2016-08-10 02:02:42 --> URI Class Initialized
INFO - 2016-08-10 02:02:42 --> Router Class Initialized
INFO - 2016-08-10 02:02:42 --> Output Class Initialized
INFO - 2016-08-10 02:02:42 --> Security Class Initialized
DEBUG - 2016-08-10 02:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:02:42 --> Input Class Initialized
INFO - 2016-08-10 02:02:42 --> Language Class Initialized
INFO - 2016-08-10 02:02:42 --> Loader Class Initialized
INFO - 2016-08-10 02:02:42 --> Helper loaded: url_helper
INFO - 2016-08-10 02:02:42 --> Helper loaded: date_helper
INFO - 2016-08-10 02:02:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:02:42 --> Database Driver Class Initialized
INFO - 2016-08-10 02:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:02:42 --> Email Class Initialized
INFO - 2016-08-10 02:02:42 --> Model Class Initialized
INFO - 2016-08-10 02:02:42 --> Controller Class Initialized
DEBUG - 2016-08-10 02:02:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:02:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:02:42 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:02:42 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:02:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:42 --> Model Class Initialized
INFO - 2016-08-10 02:02:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:02:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:02:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:02:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:02:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:02:42 --> Final output sent to browser
DEBUG - 2016-08-10 02:02:42 --> Total execution time: 0.5044
INFO - 2016-08-10 02:02:44 --> Config Class Initialized
INFO - 2016-08-10 02:02:44 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:02:44 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:02:44 --> Utf8 Class Initialized
INFO - 2016-08-10 02:02:44 --> URI Class Initialized
INFO - 2016-08-10 02:02:44 --> Router Class Initialized
INFO - 2016-08-10 02:02:44 --> Output Class Initialized
INFO - 2016-08-10 02:02:44 --> Security Class Initialized
DEBUG - 2016-08-10 02:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:02:44 --> Input Class Initialized
INFO - 2016-08-10 02:02:44 --> Language Class Initialized
INFO - 2016-08-10 02:02:44 --> Loader Class Initialized
INFO - 2016-08-10 02:02:44 --> Helper loaded: url_helper
INFO - 2016-08-10 02:02:44 --> Helper loaded: date_helper
INFO - 2016-08-10 02:02:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:02:44 --> Database Driver Class Initialized
INFO - 2016-08-10 02:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:02:44 --> Email Class Initialized
INFO - 2016-08-10 02:02:44 --> Model Class Initialized
INFO - 2016-08-10 02:02:44 --> Controller Class Initialized
DEBUG - 2016-08-10 02:02:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:02:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:02:45 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:02:45 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:45 --> Model Class Initialized
INFO - 2016-08-10 02:02:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:02:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:02:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:02:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:02:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:02:45 --> Final output sent to browser
DEBUG - 2016-08-10 02:02:45 --> Total execution time: 0.5008
INFO - 2016-08-10 02:02:56 --> Config Class Initialized
INFO - 2016-08-10 02:02:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:02:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:02:56 --> Utf8 Class Initialized
INFO - 2016-08-10 02:02:56 --> URI Class Initialized
INFO - 2016-08-10 02:02:56 --> Router Class Initialized
INFO - 2016-08-10 02:02:56 --> Output Class Initialized
INFO - 2016-08-10 02:02:56 --> Security Class Initialized
DEBUG - 2016-08-10 02:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:02:56 --> Input Class Initialized
INFO - 2016-08-10 02:02:56 --> Language Class Initialized
INFO - 2016-08-10 02:02:56 --> Loader Class Initialized
INFO - 2016-08-10 02:02:56 --> Helper loaded: url_helper
INFO - 2016-08-10 02:02:56 --> Helper loaded: date_helper
INFO - 2016-08-10 02:02:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:02:56 --> Database Driver Class Initialized
INFO - 2016-08-10 02:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:02:56 --> Email Class Initialized
INFO - 2016-08-10 02:02:56 --> Model Class Initialized
INFO - 2016-08-10 02:02:56 --> Controller Class Initialized
DEBUG - 2016-08-10 02:02:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:02:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:02:56 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:02:56 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:02:57 --> Model Class Initialized
INFO - 2016-08-10 02:02:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:02:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:02:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:02:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:02:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:02:57 --> Final output sent to browser
DEBUG - 2016-08-10 02:02:57 --> Total execution time: 0.5013
INFO - 2016-08-10 02:03:58 --> Config Class Initialized
INFO - 2016-08-10 02:03:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:03:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:03:58 --> Utf8 Class Initialized
INFO - 2016-08-10 02:03:58 --> URI Class Initialized
INFO - 2016-08-10 02:03:58 --> Router Class Initialized
INFO - 2016-08-10 02:03:58 --> Output Class Initialized
INFO - 2016-08-10 02:03:58 --> Security Class Initialized
DEBUG - 2016-08-10 02:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:03:58 --> Input Class Initialized
INFO - 2016-08-10 02:03:58 --> Language Class Initialized
INFO - 2016-08-10 02:03:58 --> Loader Class Initialized
INFO - 2016-08-10 02:03:58 --> Helper loaded: url_helper
INFO - 2016-08-10 02:03:58 --> Helper loaded: date_helper
INFO - 2016-08-10 02:03:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:03:58 --> Database Driver Class Initialized
INFO - 2016-08-10 02:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:03:58 --> Email Class Initialized
INFO - 2016-08-10 02:03:58 --> Model Class Initialized
INFO - 2016-08-10 02:03:58 --> Controller Class Initialized
DEBUG - 2016-08-10 02:03:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:03:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:03:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:03:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:03:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:03:59 --> Model Class Initialized
INFO - 2016-08-10 02:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:03:59 --> Final output sent to browser
DEBUG - 2016-08-10 02:03:59 --> Total execution time: 0.5136
INFO - 2016-08-10 02:16:12 --> Config Class Initialized
INFO - 2016-08-10 02:16:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:16:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:16:12 --> Utf8 Class Initialized
INFO - 2016-08-10 02:16:12 --> URI Class Initialized
INFO - 2016-08-10 02:16:12 --> Router Class Initialized
INFO - 2016-08-10 02:16:12 --> Output Class Initialized
INFO - 2016-08-10 02:16:12 --> Security Class Initialized
DEBUG - 2016-08-10 02:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:16:12 --> Input Class Initialized
INFO - 2016-08-10 02:16:12 --> Language Class Initialized
INFO - 2016-08-10 02:16:13 --> Loader Class Initialized
INFO - 2016-08-10 02:16:13 --> Helper loaded: url_helper
INFO - 2016-08-10 02:16:13 --> Helper loaded: date_helper
INFO - 2016-08-10 02:16:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:16:13 --> Database Driver Class Initialized
INFO - 2016-08-10 02:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:16:13 --> Email Class Initialized
INFO - 2016-08-10 02:16:13 --> Model Class Initialized
INFO - 2016-08-10 02:16:13 --> Controller Class Initialized
DEBUG - 2016-08-10 02:16:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:16:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:16:13 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:16:13 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:13 --> Model Class Initialized
INFO - 2016-08-10 02:16:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:16:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:16:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:16:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:16:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:16:13 --> Final output sent to browser
DEBUG - 2016-08-10 02:16:13 --> Total execution time: 0.4892
INFO - 2016-08-10 02:16:29 --> Config Class Initialized
INFO - 2016-08-10 02:16:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:16:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:16:29 --> Utf8 Class Initialized
INFO - 2016-08-10 02:16:29 --> URI Class Initialized
INFO - 2016-08-10 02:16:29 --> Router Class Initialized
INFO - 2016-08-10 02:16:29 --> Output Class Initialized
INFO - 2016-08-10 02:16:29 --> Security Class Initialized
DEBUG - 2016-08-10 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:16:30 --> Input Class Initialized
INFO - 2016-08-10 02:16:30 --> Language Class Initialized
INFO - 2016-08-10 02:16:30 --> Loader Class Initialized
INFO - 2016-08-10 02:16:30 --> Helper loaded: url_helper
INFO - 2016-08-10 02:16:30 --> Helper loaded: date_helper
INFO - 2016-08-10 02:16:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:16:30 --> Database Driver Class Initialized
INFO - 2016-08-10 02:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:16:30 --> Email Class Initialized
INFO - 2016-08-10 02:16:30 --> Model Class Initialized
INFO - 2016-08-10 02:16:30 --> Controller Class Initialized
DEBUG - 2016-08-10 02:16:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:16:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:16:30 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:16:30 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:30 --> Model Class Initialized
INFO - 2016-08-10 02:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:16:30 --> Final output sent to browser
DEBUG - 2016-08-10 02:16:30 --> Total execution time: 0.8527
INFO - 2016-08-10 02:16:34 --> Config Class Initialized
INFO - 2016-08-10 02:16:34 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:16:34 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:16:34 --> Utf8 Class Initialized
INFO - 2016-08-10 02:16:34 --> URI Class Initialized
INFO - 2016-08-10 02:16:34 --> Router Class Initialized
INFO - 2016-08-10 02:16:34 --> Output Class Initialized
INFO - 2016-08-10 02:16:34 --> Security Class Initialized
DEBUG - 2016-08-10 02:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:16:34 --> Input Class Initialized
INFO - 2016-08-10 02:16:34 --> Language Class Initialized
INFO - 2016-08-10 02:16:34 --> Loader Class Initialized
INFO - 2016-08-10 02:16:34 --> Helper loaded: url_helper
INFO - 2016-08-10 02:16:34 --> Helper loaded: date_helper
INFO - 2016-08-10 02:16:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:16:34 --> Database Driver Class Initialized
INFO - 2016-08-10 02:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:16:34 --> Email Class Initialized
INFO - 2016-08-10 02:16:34 --> Model Class Initialized
INFO - 2016-08-10 02:16:34 --> Controller Class Initialized
DEBUG - 2016-08-10 02:16:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:16:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:16:34 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:16:34 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:16:34 --> Model Class Initialized
INFO - 2016-08-10 02:16:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:16:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:16:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:16:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:16:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:16:34 --> Final output sent to browser
DEBUG - 2016-08-10 02:16:34 --> Total execution time: 0.6012
INFO - 2016-08-10 02:17:53 --> Config Class Initialized
INFO - 2016-08-10 02:17:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:17:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:17:53 --> Utf8 Class Initialized
INFO - 2016-08-10 02:17:53 --> URI Class Initialized
INFO - 2016-08-10 02:17:53 --> Router Class Initialized
INFO - 2016-08-10 02:17:53 --> Output Class Initialized
INFO - 2016-08-10 02:17:53 --> Security Class Initialized
DEBUG - 2016-08-10 02:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:17:53 --> Input Class Initialized
INFO - 2016-08-10 02:17:54 --> Language Class Initialized
INFO - 2016-08-10 02:17:54 --> Loader Class Initialized
INFO - 2016-08-10 02:17:54 --> Helper loaded: url_helper
INFO - 2016-08-10 02:17:54 --> Helper loaded: date_helper
INFO - 2016-08-10 02:17:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:17:54 --> Database Driver Class Initialized
INFO - 2016-08-10 02:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:17:54 --> Email Class Initialized
INFO - 2016-08-10 02:17:54 --> Model Class Initialized
INFO - 2016-08-10 02:17:54 --> Controller Class Initialized
DEBUG - 2016-08-10 02:17:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:17:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:17:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:17:54 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:17:54 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:17:54 --> Model Class Initialized
INFO - 2016-08-10 02:17:54 --> Upload Class Initialized
INFO - 2016-08-10 02:17:54 --> Config Class Initialized
INFO - 2016-08-10 02:17:54 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:17:54 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:17:54 --> Utf8 Class Initialized
INFO - 2016-08-10 02:17:54 --> URI Class Initialized
INFO - 2016-08-10 02:17:54 --> Router Class Initialized
INFO - 2016-08-10 02:17:54 --> Output Class Initialized
INFO - 2016-08-10 02:17:54 --> Security Class Initialized
DEBUG - 2016-08-10 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:17:54 --> Input Class Initialized
INFO - 2016-08-10 02:17:54 --> Language Class Initialized
INFO - 2016-08-10 02:17:54 --> Loader Class Initialized
INFO - 2016-08-10 02:17:54 --> Helper loaded: url_helper
INFO - 2016-08-10 02:17:54 --> Helper loaded: date_helper
INFO - 2016-08-10 02:17:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:17:54 --> Database Driver Class Initialized
INFO - 2016-08-10 02:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:17:55 --> Email Class Initialized
INFO - 2016-08-10 02:17:55 --> Model Class Initialized
INFO - 2016-08-10 02:17:55 --> Controller Class Initialized
DEBUG - 2016-08-10 02:17:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:17:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:17:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:17:55 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:17:55 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:17:55 --> Model Class Initialized
INFO - 2016-08-10 02:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:17:55 --> Final output sent to browser
DEBUG - 2016-08-10 02:17:55 --> Total execution time: 0.9064
INFO - 2016-08-10 02:18:00 --> Config Class Initialized
INFO - 2016-08-10 02:18:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:18:00 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:18:00 --> Utf8 Class Initialized
INFO - 2016-08-10 02:18:00 --> URI Class Initialized
INFO - 2016-08-10 02:18:00 --> Router Class Initialized
INFO - 2016-08-10 02:18:00 --> Output Class Initialized
INFO - 2016-08-10 02:18:00 --> Security Class Initialized
DEBUG - 2016-08-10 02:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:18:00 --> Input Class Initialized
INFO - 2016-08-10 02:18:00 --> Language Class Initialized
INFO - 2016-08-10 02:18:00 --> Loader Class Initialized
INFO - 2016-08-10 02:18:00 --> Helper loaded: url_helper
INFO - 2016-08-10 02:18:00 --> Helper loaded: date_helper
INFO - 2016-08-10 02:18:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:18:00 --> Database Driver Class Initialized
INFO - 2016-08-10 02:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:18:00 --> Email Class Initialized
INFO - 2016-08-10 02:18:00 --> Model Class Initialized
INFO - 2016-08-10 02:18:00 --> Controller Class Initialized
DEBUG - 2016-08-10 02:18:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:18:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:18:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:18:00 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:18:00 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:18:00 --> Model Class Initialized
INFO - 2016-08-10 02:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:18:00 --> Final output sent to browser
DEBUG - 2016-08-10 02:18:00 --> Total execution time: 0.5001
INFO - 2016-08-10 02:18:24 --> Config Class Initialized
INFO - 2016-08-10 02:18:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:18:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:18:24 --> Utf8 Class Initialized
INFO - 2016-08-10 02:18:24 --> URI Class Initialized
INFO - 2016-08-10 02:18:24 --> Router Class Initialized
INFO - 2016-08-10 02:18:25 --> Output Class Initialized
INFO - 2016-08-10 02:18:25 --> Security Class Initialized
DEBUG - 2016-08-10 02:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:18:25 --> Input Class Initialized
INFO - 2016-08-10 02:18:25 --> Language Class Initialized
INFO - 2016-08-10 02:18:25 --> Loader Class Initialized
INFO - 2016-08-10 02:18:25 --> Helper loaded: url_helper
INFO - 2016-08-10 02:18:25 --> Helper loaded: date_helper
INFO - 2016-08-10 02:18:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:18:25 --> Database Driver Class Initialized
INFO - 2016-08-10 02:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:18:25 --> Email Class Initialized
INFO - 2016-08-10 02:18:25 --> Model Class Initialized
INFO - 2016-08-10 02:18:25 --> Controller Class Initialized
DEBUG - 2016-08-10 02:18:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:18:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:18:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:18:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:18:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:18:25 --> Model Class Initialized
INFO - 2016-08-10 02:18:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:18:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:18:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:18:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:18:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:18:25 --> Final output sent to browser
DEBUG - 2016-08-10 02:18:25 --> Total execution time: 0.5915
INFO - 2016-08-10 02:19:25 --> Config Class Initialized
INFO - 2016-08-10 02:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:19:25 --> Utf8 Class Initialized
INFO - 2016-08-10 02:19:25 --> URI Class Initialized
INFO - 2016-08-10 02:19:25 --> Router Class Initialized
INFO - 2016-08-10 02:19:25 --> Output Class Initialized
INFO - 2016-08-10 02:19:25 --> Security Class Initialized
DEBUG - 2016-08-10 02:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:19:25 --> Input Class Initialized
INFO - 2016-08-10 02:19:25 --> Language Class Initialized
INFO - 2016-08-10 02:19:25 --> Loader Class Initialized
INFO - 2016-08-10 02:19:25 --> Helper loaded: url_helper
INFO - 2016-08-10 02:19:25 --> Helper loaded: date_helper
INFO - 2016-08-10 02:19:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:19:25 --> Database Driver Class Initialized
INFO - 2016-08-10 02:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:19:25 --> Email Class Initialized
INFO - 2016-08-10 02:19:25 --> Model Class Initialized
INFO - 2016-08-10 02:19:25 --> Controller Class Initialized
DEBUG - 2016-08-10 02:19:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:19:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:19:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:19:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:19:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:19:25 --> Model Class Initialized
INFO - 2016-08-10 02:19:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:19:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:19:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:19:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:19:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:19:25 --> Final output sent to browser
DEBUG - 2016-08-10 02:19:26 --> Total execution time: 0.5252
INFO - 2016-08-10 02:19:36 --> Config Class Initialized
INFO - 2016-08-10 02:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:19:36 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:19:36 --> Utf8 Class Initialized
INFO - 2016-08-10 02:19:36 --> URI Class Initialized
INFO - 2016-08-10 02:19:36 --> Router Class Initialized
INFO - 2016-08-10 02:19:36 --> Output Class Initialized
INFO - 2016-08-10 02:19:36 --> Security Class Initialized
DEBUG - 2016-08-10 02:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:19:36 --> Input Class Initialized
INFO - 2016-08-10 02:19:36 --> Language Class Initialized
INFO - 2016-08-10 02:19:36 --> Loader Class Initialized
INFO - 2016-08-10 02:19:36 --> Helper loaded: url_helper
INFO - 2016-08-10 02:19:36 --> Helper loaded: date_helper
INFO - 2016-08-10 02:19:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:19:36 --> Database Driver Class Initialized
INFO - 2016-08-10 02:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:19:36 --> Email Class Initialized
INFO - 2016-08-10 02:19:36 --> Model Class Initialized
INFO - 2016-08-10 02:19:36 --> Controller Class Initialized
DEBUG - 2016-08-10 02:19:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:19:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:19:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:19:36 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:19:36 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:19:36 --> Model Class Initialized
INFO - 2016-08-10 02:19:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:19:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:19:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:19:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:19:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:19:36 --> Final output sent to browser
DEBUG - 2016-08-10 02:19:36 --> Total execution time: 0.5194
INFO - 2016-08-10 02:20:10 --> Config Class Initialized
INFO - 2016-08-10 02:20:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:20:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:20:10 --> Utf8 Class Initialized
INFO - 2016-08-10 02:20:10 --> URI Class Initialized
INFO - 2016-08-10 02:20:10 --> Router Class Initialized
INFO - 2016-08-10 02:20:10 --> Output Class Initialized
INFO - 2016-08-10 02:20:10 --> Security Class Initialized
DEBUG - 2016-08-10 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:20:10 --> Input Class Initialized
INFO - 2016-08-10 02:20:10 --> Language Class Initialized
INFO - 2016-08-10 02:20:10 --> Loader Class Initialized
INFO - 2016-08-10 02:20:10 --> Helper loaded: url_helper
INFO - 2016-08-10 02:20:10 --> Helper loaded: date_helper
INFO - 2016-08-10 02:20:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:20:10 --> Database Driver Class Initialized
INFO - 2016-08-10 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:20:10 --> Email Class Initialized
INFO - 2016-08-10 02:20:10 --> Model Class Initialized
INFO - 2016-08-10 02:20:10 --> Controller Class Initialized
DEBUG - 2016-08-10 02:20:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:20:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:20:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:20:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:20:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:20:10 --> Model Class Initialized
INFO - 2016-08-10 02:20:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:20:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:20:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:20:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:20:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:20:10 --> Final output sent to browser
DEBUG - 2016-08-10 02:20:10 --> Total execution time: 0.5228
INFO - 2016-08-10 02:21:15 --> Config Class Initialized
INFO - 2016-08-10 02:21:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:21:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:21:15 --> Utf8 Class Initialized
INFO - 2016-08-10 02:21:15 --> URI Class Initialized
INFO - 2016-08-10 02:21:15 --> Router Class Initialized
INFO - 2016-08-10 02:21:15 --> Output Class Initialized
INFO - 2016-08-10 02:21:15 --> Security Class Initialized
DEBUG - 2016-08-10 02:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:21:15 --> Input Class Initialized
INFO - 2016-08-10 02:21:15 --> Language Class Initialized
INFO - 2016-08-10 02:21:15 --> Loader Class Initialized
INFO - 2016-08-10 02:21:15 --> Helper loaded: url_helper
INFO - 2016-08-10 02:21:15 --> Helper loaded: date_helper
INFO - 2016-08-10 02:21:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:21:15 --> Database Driver Class Initialized
INFO - 2016-08-10 02:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:21:15 --> Email Class Initialized
INFO - 2016-08-10 02:21:15 --> Model Class Initialized
INFO - 2016-08-10 02:21:15 --> Controller Class Initialized
DEBUG - 2016-08-10 02:21:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:21:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:21:15 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:21:15 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:15 --> Model Class Initialized
INFO - 2016-08-10 02:21:15 --> Config Class Initialized
INFO - 2016-08-10 02:21:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:21:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:21:15 --> Utf8 Class Initialized
INFO - 2016-08-10 02:21:15 --> URI Class Initialized
INFO - 2016-08-10 02:21:15 --> Router Class Initialized
INFO - 2016-08-10 02:21:15 --> Output Class Initialized
INFO - 2016-08-10 02:21:15 --> Security Class Initialized
DEBUG - 2016-08-10 02:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:21:15 --> Input Class Initialized
INFO - 2016-08-10 02:21:15 --> Language Class Initialized
INFO - 2016-08-10 02:21:15 --> Loader Class Initialized
INFO - 2016-08-10 02:21:15 --> Helper loaded: url_helper
INFO - 2016-08-10 02:21:15 --> Helper loaded: date_helper
INFO - 2016-08-10 02:21:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:21:15 --> Database Driver Class Initialized
INFO - 2016-08-10 02:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:21:15 --> Email Class Initialized
INFO - 2016-08-10 02:21:15 --> Model Class Initialized
INFO - 2016-08-10 02:21:16 --> Controller Class Initialized
DEBUG - 2016-08-10 02:21:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:21:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:21:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:21:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:16 --> Model Class Initialized
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:21:16 --> Final output sent to browser
DEBUG - 2016-08-10 02:21:16 --> Total execution time: 0.7224
INFO - 2016-08-10 02:21:16 --> Config Class Initialized
INFO - 2016-08-10 02:21:16 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:21:16 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:21:16 --> Utf8 Class Initialized
INFO - 2016-08-10 02:21:16 --> URI Class Initialized
INFO - 2016-08-10 02:21:16 --> Router Class Initialized
INFO - 2016-08-10 02:21:16 --> Output Class Initialized
INFO - 2016-08-10 02:21:16 --> Security Class Initialized
DEBUG - 2016-08-10 02:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:21:16 --> Input Class Initialized
INFO - 2016-08-10 02:21:16 --> Language Class Initialized
INFO - 2016-08-10 02:21:16 --> Loader Class Initialized
INFO - 2016-08-10 02:21:16 --> Helper loaded: url_helper
INFO - 2016-08-10 02:21:16 --> Helper loaded: date_helper
INFO - 2016-08-10 02:21:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:21:16 --> Database Driver Class Initialized
INFO - 2016-08-10 02:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:21:16 --> Email Class Initialized
INFO - 2016-08-10 02:21:16 --> Model Class Initialized
INFO - 2016-08-10 02:21:16 --> Controller Class Initialized
DEBUG - 2016-08-10 02:21:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:21:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:21:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:21:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:16 --> Model Class Initialized
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:21:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:21:16 --> Final output sent to browser
DEBUG - 2016-08-10 02:21:16 --> Total execution time: 0.5689
INFO - 2016-08-10 02:21:29 --> Config Class Initialized
INFO - 2016-08-10 02:21:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:21:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:21:29 --> Utf8 Class Initialized
INFO - 2016-08-10 02:21:29 --> URI Class Initialized
INFO - 2016-08-10 02:21:29 --> Router Class Initialized
INFO - 2016-08-10 02:21:29 --> Output Class Initialized
INFO - 2016-08-10 02:21:29 --> Security Class Initialized
DEBUG - 2016-08-10 02:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:21:29 --> Input Class Initialized
INFO - 2016-08-10 02:21:29 --> Language Class Initialized
INFO - 2016-08-10 02:21:29 --> Loader Class Initialized
INFO - 2016-08-10 02:21:29 --> Helper loaded: url_helper
INFO - 2016-08-10 02:21:29 --> Helper loaded: date_helper
INFO - 2016-08-10 02:21:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:21:29 --> Database Driver Class Initialized
INFO - 2016-08-10 02:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:21:29 --> Email Class Initialized
INFO - 2016-08-10 02:21:29 --> Model Class Initialized
INFO - 2016-08-10 02:21:29 --> Controller Class Initialized
DEBUG - 2016-08-10 02:21:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:21:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:21:29 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:21:29 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:29 --> Model Class Initialized
INFO - 2016-08-10 02:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:21:29 --> Final output sent to browser
DEBUG - 2016-08-10 02:21:29 --> Total execution time: 0.5185
INFO - 2016-08-10 02:21:57 --> Config Class Initialized
INFO - 2016-08-10 02:21:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:21:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:21:57 --> Utf8 Class Initialized
INFO - 2016-08-10 02:21:57 --> URI Class Initialized
INFO - 2016-08-10 02:21:57 --> Router Class Initialized
INFO - 2016-08-10 02:21:57 --> Output Class Initialized
INFO - 2016-08-10 02:21:57 --> Security Class Initialized
DEBUG - 2016-08-10 02:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:21:57 --> Input Class Initialized
INFO - 2016-08-10 02:21:57 --> Language Class Initialized
INFO - 2016-08-10 02:21:57 --> Loader Class Initialized
INFO - 2016-08-10 02:21:57 --> Helper loaded: url_helper
INFO - 2016-08-10 02:21:57 --> Helper loaded: date_helper
INFO - 2016-08-10 02:21:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:21:57 --> Database Driver Class Initialized
INFO - 2016-08-10 02:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:21:57 --> Email Class Initialized
INFO - 2016-08-10 02:21:57 --> Model Class Initialized
INFO - 2016-08-10 02:21:57 --> Controller Class Initialized
DEBUG - 2016-08-10 02:21:57 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:21:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:21:57 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:21:57 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:21:58 --> Model Class Initialized
INFO - 2016-08-10 02:21:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:21:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:21:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:21:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:21:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:21:58 --> Final output sent to browser
DEBUG - 2016-08-10 02:21:58 --> Total execution time: 0.5180
INFO - 2016-08-10 02:31:22 --> Config Class Initialized
INFO - 2016-08-10 02:31:22 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:31:22 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:31:22 --> Utf8 Class Initialized
INFO - 2016-08-10 02:31:22 --> URI Class Initialized
INFO - 2016-08-10 02:31:22 --> Router Class Initialized
INFO - 2016-08-10 02:31:22 --> Output Class Initialized
INFO - 2016-08-10 02:31:22 --> Security Class Initialized
DEBUG - 2016-08-10 02:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:31:22 --> Input Class Initialized
INFO - 2016-08-10 02:31:22 --> Language Class Initialized
INFO - 2016-08-10 02:31:22 --> Loader Class Initialized
INFO - 2016-08-10 02:31:22 --> Helper loaded: url_helper
INFO - 2016-08-10 02:31:22 --> Helper loaded: date_helper
INFO - 2016-08-10 02:31:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:31:22 --> Database Driver Class Initialized
INFO - 2016-08-10 02:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:31:22 --> Email Class Initialized
INFO - 2016-08-10 02:31:22 --> Model Class Initialized
INFO - 2016-08-10 02:31:22 --> Controller Class Initialized
DEBUG - 2016-08-10 02:31:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:31:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:31:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:31:22 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:31:22 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:31:22 --> Model Class Initialized
INFO - 2016-08-10 02:31:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:31:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:31:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:31:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 02:31:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:31:22 --> Final output sent to browser
DEBUG - 2016-08-10 02:31:22 --> Total execution time: 0.6509
INFO - 2016-08-10 02:35:14 --> Config Class Initialized
INFO - 2016-08-10 02:35:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:35:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:35:14 --> Utf8 Class Initialized
INFO - 2016-08-10 02:35:14 --> URI Class Initialized
INFO - 2016-08-10 02:35:14 --> Router Class Initialized
INFO - 2016-08-10 02:35:14 --> Output Class Initialized
INFO - 2016-08-10 02:35:14 --> Security Class Initialized
DEBUG - 2016-08-10 02:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:35:14 --> Input Class Initialized
INFO - 2016-08-10 02:35:14 --> Language Class Initialized
INFO - 2016-08-10 02:35:14 --> Loader Class Initialized
INFO - 2016-08-10 02:35:14 --> Helper loaded: url_helper
INFO - 2016-08-10 02:35:14 --> Helper loaded: date_helper
INFO - 2016-08-10 02:35:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:35:14 --> Database Driver Class Initialized
INFO - 2016-08-10 02:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:35:14 --> Email Class Initialized
INFO - 2016-08-10 02:35:14 --> Model Class Initialized
INFO - 2016-08-10 02:35:14 --> Controller Class Initialized
DEBUG - 2016-08-10 02:35:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:35:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:35:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:35:14 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:35:14 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:35:14 --> Model Class Initialized
INFO - 2016-08-10 02:35:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:35:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:35:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:35:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:35:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:35:14 --> Final output sent to browser
DEBUG - 2016-08-10 02:35:15 --> Total execution time: 0.5258
INFO - 2016-08-10 02:36:38 --> Config Class Initialized
INFO - 2016-08-10 02:36:38 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:36:38 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:36:39 --> Utf8 Class Initialized
INFO - 2016-08-10 02:36:39 --> URI Class Initialized
INFO - 2016-08-10 02:36:39 --> Router Class Initialized
INFO - 2016-08-10 02:36:39 --> Output Class Initialized
INFO - 2016-08-10 02:36:39 --> Security Class Initialized
DEBUG - 2016-08-10 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:36:39 --> Input Class Initialized
INFO - 2016-08-10 02:36:39 --> Language Class Initialized
INFO - 2016-08-10 02:36:39 --> Loader Class Initialized
INFO - 2016-08-10 02:36:39 --> Helper loaded: url_helper
INFO - 2016-08-10 02:36:39 --> Helper loaded: date_helper
INFO - 2016-08-10 02:36:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:36:39 --> Database Driver Class Initialized
INFO - 2016-08-10 02:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:36:39 --> Email Class Initialized
INFO - 2016-08-10 02:36:39 --> Model Class Initialized
INFO - 2016-08-10 02:36:39 --> Controller Class Initialized
DEBUG - 2016-08-10 02:36:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:36:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:36:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:36:39 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:36:39 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:36:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:36:39 --> Model Class Initialized
INFO - 2016-08-10 02:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-10 02:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:36:39 --> Final output sent to browser
DEBUG - 2016-08-10 02:36:39 --> Total execution time: 0.5149
INFO - 2016-08-10 02:37:06 --> Config Class Initialized
INFO - 2016-08-10 02:37:06 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:37:06 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:37:06 --> Utf8 Class Initialized
INFO - 2016-08-10 02:37:06 --> URI Class Initialized
INFO - 2016-08-10 02:37:06 --> Router Class Initialized
INFO - 2016-08-10 02:37:06 --> Output Class Initialized
INFO - 2016-08-10 02:37:07 --> Security Class Initialized
DEBUG - 2016-08-10 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:37:07 --> Input Class Initialized
INFO - 2016-08-10 02:37:07 --> Language Class Initialized
INFO - 2016-08-10 02:37:07 --> Loader Class Initialized
INFO - 2016-08-10 02:37:07 --> Helper loaded: url_helper
INFO - 2016-08-10 02:37:07 --> Helper loaded: date_helper
INFO - 2016-08-10 02:37:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:37:07 --> Database Driver Class Initialized
INFO - 2016-08-10 02:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:37:07 --> Email Class Initialized
INFO - 2016-08-10 02:37:07 --> Model Class Initialized
INFO - 2016-08-10 02:37:07 --> Controller Class Initialized
DEBUG - 2016-08-10 02:37:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:37:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:37:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:37:07 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:37:07 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:37:07 --> Model Class Initialized
INFO - 2016-08-10 02:37:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:37:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:37:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:37:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:37:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:37:07 --> Final output sent to browser
DEBUG - 2016-08-10 02:37:07 --> Total execution time: 0.5568
INFO - 2016-08-10 02:38:46 --> Config Class Initialized
INFO - 2016-08-10 02:38:46 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:38:46 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:38:46 --> Utf8 Class Initialized
INFO - 2016-08-10 02:38:46 --> URI Class Initialized
INFO - 2016-08-10 02:38:46 --> Router Class Initialized
INFO - 2016-08-10 02:38:46 --> Output Class Initialized
INFO - 2016-08-10 02:38:46 --> Security Class Initialized
DEBUG - 2016-08-10 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:38:46 --> Input Class Initialized
INFO - 2016-08-10 02:38:46 --> Language Class Initialized
INFO - 2016-08-10 02:38:46 --> Loader Class Initialized
INFO - 2016-08-10 02:38:46 --> Helper loaded: url_helper
INFO - 2016-08-10 02:38:46 --> Helper loaded: date_helper
INFO - 2016-08-10 02:38:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:38:46 --> Database Driver Class Initialized
INFO - 2016-08-10 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:38:46 --> Email Class Initialized
INFO - 2016-08-10 02:38:46 --> Model Class Initialized
INFO - 2016-08-10 02:38:47 --> Controller Class Initialized
DEBUG - 2016-08-10 02:38:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:38:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:38:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:38:47 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:38:47 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:38:47 --> Model Class Initialized
INFO - 2016-08-10 02:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:38:47 --> Final output sent to browser
DEBUG - 2016-08-10 02:38:47 --> Total execution time: 0.5259
INFO - 2016-08-10 02:41:54 --> Config Class Initialized
INFO - 2016-08-10 02:41:54 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:41:54 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:41:54 --> Utf8 Class Initialized
INFO - 2016-08-10 02:41:54 --> URI Class Initialized
INFO - 2016-08-10 02:41:54 --> Router Class Initialized
INFO - 2016-08-10 02:41:54 --> Output Class Initialized
INFO - 2016-08-10 02:41:54 --> Security Class Initialized
DEBUG - 2016-08-10 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:41:54 --> Input Class Initialized
INFO - 2016-08-10 02:41:54 --> Language Class Initialized
INFO - 2016-08-10 02:41:54 --> Loader Class Initialized
INFO - 2016-08-10 02:41:54 --> Helper loaded: url_helper
INFO - 2016-08-10 02:41:54 --> Helper loaded: date_helper
INFO - 2016-08-10 02:41:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:41:54 --> Database Driver Class Initialized
INFO - 2016-08-10 02:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:41:54 --> Email Class Initialized
INFO - 2016-08-10 02:41:54 --> Model Class Initialized
INFO - 2016-08-10 02:41:54 --> Controller Class Initialized
DEBUG - 2016-08-10 02:41:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:41:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:41:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:41:54 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:41:54 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:41:54 --> Model Class Initialized
INFO - 2016-08-10 02:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:41:54 --> Final output sent to browser
DEBUG - 2016-08-10 02:41:54 --> Total execution time: 0.6164
INFO - 2016-08-10 02:42:14 --> Config Class Initialized
INFO - 2016-08-10 02:42:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:42:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:42:14 --> Utf8 Class Initialized
INFO - 2016-08-10 02:42:14 --> URI Class Initialized
INFO - 2016-08-10 02:42:14 --> Router Class Initialized
INFO - 2016-08-10 02:42:14 --> Output Class Initialized
INFO - 2016-08-10 02:42:14 --> Security Class Initialized
DEBUG - 2016-08-10 02:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:42:14 --> Input Class Initialized
INFO - 2016-08-10 02:42:14 --> Language Class Initialized
INFO - 2016-08-10 02:42:14 --> Loader Class Initialized
INFO - 2016-08-10 02:42:14 --> Helper loaded: url_helper
INFO - 2016-08-10 02:42:14 --> Helper loaded: date_helper
INFO - 2016-08-10 02:42:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:42:14 --> Database Driver Class Initialized
INFO - 2016-08-10 02:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:42:14 --> Email Class Initialized
INFO - 2016-08-10 02:42:14 --> Model Class Initialized
INFO - 2016-08-10 02:42:14 --> Controller Class Initialized
DEBUG - 2016-08-10 02:42:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:42:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:42:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:42:15 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:42:15 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:42:15 --> Model Class Initialized
INFO - 2016-08-10 02:42:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:42:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:42:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:42:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:42:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:42:15 --> Final output sent to browser
DEBUG - 2016-08-10 02:42:15 --> Total execution time: 0.5462
INFO - 2016-08-10 02:48:25 --> Config Class Initialized
INFO - 2016-08-10 02:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:48:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:48:25 --> Utf8 Class Initialized
INFO - 2016-08-10 02:48:25 --> URI Class Initialized
INFO - 2016-08-10 02:48:25 --> Router Class Initialized
INFO - 2016-08-10 02:48:25 --> Output Class Initialized
INFO - 2016-08-10 02:48:25 --> Security Class Initialized
DEBUG - 2016-08-10 02:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:48:25 --> Input Class Initialized
INFO - 2016-08-10 02:48:25 --> Language Class Initialized
INFO - 2016-08-10 02:48:25 --> Loader Class Initialized
INFO - 2016-08-10 02:48:25 --> Helper loaded: url_helper
INFO - 2016-08-10 02:48:25 --> Helper loaded: date_helper
INFO - 2016-08-10 02:48:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:48:25 --> Database Driver Class Initialized
INFO - 2016-08-10 02:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:48:25 --> Email Class Initialized
INFO - 2016-08-10 02:48:25 --> Model Class Initialized
INFO - 2016-08-10 02:48:25 --> Controller Class Initialized
DEBUG - 2016-08-10 02:48:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:48:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:48:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:48:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:48:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:48:25 --> Model Class Initialized
INFO - 2016-08-10 02:48:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:48:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:48:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:48:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 02:48:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:48:25 --> Final output sent to browser
DEBUG - 2016-08-10 02:48:25 --> Total execution time: 0.5303
INFO - 2016-08-10 02:50:21 --> Config Class Initialized
INFO - 2016-08-10 02:50:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:50:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:50:21 --> Utf8 Class Initialized
INFO - 2016-08-10 02:50:21 --> URI Class Initialized
INFO - 2016-08-10 02:50:21 --> Router Class Initialized
INFO - 2016-08-10 02:50:21 --> Output Class Initialized
INFO - 2016-08-10 02:50:21 --> Security Class Initialized
DEBUG - 2016-08-10 02:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:50:21 --> Input Class Initialized
INFO - 2016-08-10 02:50:21 --> Language Class Initialized
INFO - 2016-08-10 02:50:21 --> Loader Class Initialized
INFO - 2016-08-10 02:50:21 --> Helper loaded: url_helper
INFO - 2016-08-10 02:50:21 --> Helper loaded: date_helper
INFO - 2016-08-10 02:50:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:50:21 --> Database Driver Class Initialized
INFO - 2016-08-10 02:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:50:21 --> Email Class Initialized
INFO - 2016-08-10 02:50:21 --> Model Class Initialized
INFO - 2016-08-10 02:50:21 --> Controller Class Initialized
DEBUG - 2016-08-10 02:50:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:50:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:50:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:50:22 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:50:22 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:50:22 --> Model Class Initialized
INFO - 2016-08-10 02:50:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:50:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:50:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:50:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_page.php
INFO - 2016-08-10 02:50:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:50:22 --> Final output sent to browser
DEBUG - 2016-08-10 02:50:22 --> Total execution time: 0.5401
INFO - 2016-08-10 02:53:46 --> Config Class Initialized
INFO - 2016-08-10 02:53:46 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:53:46 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:53:46 --> Utf8 Class Initialized
INFO - 2016-08-10 02:53:46 --> URI Class Initialized
INFO - 2016-08-10 02:53:46 --> Router Class Initialized
INFO - 2016-08-10 02:53:46 --> Output Class Initialized
INFO - 2016-08-10 02:53:46 --> Security Class Initialized
DEBUG - 2016-08-10 02:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:53:46 --> Input Class Initialized
INFO - 2016-08-10 02:53:46 --> Language Class Initialized
INFO - 2016-08-10 02:53:46 --> Loader Class Initialized
INFO - 2016-08-10 02:53:46 --> Helper loaded: url_helper
INFO - 2016-08-10 02:53:46 --> Helper loaded: date_helper
INFO - 2016-08-10 02:53:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:53:46 --> Database Driver Class Initialized
INFO - 2016-08-10 02:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:53:46 --> Email Class Initialized
INFO - 2016-08-10 02:53:46 --> Model Class Initialized
INFO - 2016-08-10 02:53:46 --> Controller Class Initialized
DEBUG - 2016-08-10 02:53:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:53:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:53:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:53:46 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:53:46 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:53:46 --> Model Class Initialized
INFO - 2016-08-10 02:53:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:53:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:53:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:53:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 02:53:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:53:47 --> Final output sent to browser
DEBUG - 2016-08-10 02:53:47 --> Total execution time: 0.5467
INFO - 2016-08-10 02:53:50 --> Config Class Initialized
INFO - 2016-08-10 02:53:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:53:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:53:50 --> Utf8 Class Initialized
INFO - 2016-08-10 02:53:50 --> URI Class Initialized
INFO - 2016-08-10 02:53:50 --> Router Class Initialized
INFO - 2016-08-10 02:53:50 --> Output Class Initialized
INFO - 2016-08-10 02:53:50 --> Security Class Initialized
DEBUG - 2016-08-10 02:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:53:50 --> Input Class Initialized
INFO - 2016-08-10 02:53:50 --> Language Class Initialized
INFO - 2016-08-10 02:53:50 --> Loader Class Initialized
INFO - 2016-08-10 02:53:50 --> Helper loaded: url_helper
INFO - 2016-08-10 02:53:50 --> Helper loaded: date_helper
INFO - 2016-08-10 02:53:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:53:50 --> Database Driver Class Initialized
INFO - 2016-08-10 02:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:53:50 --> Email Class Initialized
INFO - 2016-08-10 02:53:50 --> Model Class Initialized
INFO - 2016-08-10 02:53:50 --> Controller Class Initialized
DEBUG - 2016-08-10 02:53:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:53:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:53:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:53:50 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:53:50 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:53:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:53:50 --> Model Class Initialized
INFO - 2016-08-10 02:53:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:53:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:53:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:53:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 02:53:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:53:50 --> Final output sent to browser
DEBUG - 2016-08-10 02:53:50 --> Total execution time: 0.5607
INFO - 2016-08-10 02:55:16 --> Config Class Initialized
INFO - 2016-08-10 02:55:16 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:55:16 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:55:16 --> Utf8 Class Initialized
INFO - 2016-08-10 02:55:16 --> URI Class Initialized
INFO - 2016-08-10 02:55:16 --> Router Class Initialized
INFO - 2016-08-10 02:55:16 --> Output Class Initialized
INFO - 2016-08-10 02:55:16 --> Security Class Initialized
DEBUG - 2016-08-10 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:55:16 --> Input Class Initialized
INFO - 2016-08-10 02:55:16 --> Language Class Initialized
INFO - 2016-08-10 02:55:16 --> Loader Class Initialized
INFO - 2016-08-10 02:55:16 --> Helper loaded: url_helper
INFO - 2016-08-10 02:55:16 --> Helper loaded: date_helper
INFO - 2016-08-10 02:55:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:55:16 --> Database Driver Class Initialized
INFO - 2016-08-10 02:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:55:16 --> Email Class Initialized
INFO - 2016-08-10 02:55:16 --> Model Class Initialized
INFO - 2016-08-10 02:55:16 --> Controller Class Initialized
DEBUG - 2016-08-10 02:55:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:55:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:55:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:55:17 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:17 --> Model Class Initialized
INFO - 2016-08-10 02:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 02:55:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:55:17 --> Final output sent to browser
DEBUG - 2016-08-10 02:55:17 --> Total execution time: 0.5431
INFO - 2016-08-10 02:55:30 --> Config Class Initialized
INFO - 2016-08-10 02:55:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:55:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:55:30 --> Utf8 Class Initialized
INFO - 2016-08-10 02:55:30 --> URI Class Initialized
INFO - 2016-08-10 02:55:30 --> Router Class Initialized
INFO - 2016-08-10 02:55:30 --> Output Class Initialized
INFO - 2016-08-10 02:55:30 --> Security Class Initialized
DEBUG - 2016-08-10 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:55:30 --> Input Class Initialized
INFO - 2016-08-10 02:55:30 --> Language Class Initialized
INFO - 2016-08-10 02:55:30 --> Loader Class Initialized
INFO - 2016-08-10 02:55:30 --> Helper loaded: url_helper
INFO - 2016-08-10 02:55:30 --> Helper loaded: date_helper
INFO - 2016-08-10 02:55:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:55:31 --> Database Driver Class Initialized
INFO - 2016-08-10 02:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:55:31 --> Email Class Initialized
INFO - 2016-08-10 02:55:31 --> Model Class Initialized
INFO - 2016-08-10 02:55:31 --> Controller Class Initialized
DEBUG - 2016-08-10 02:55:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:55:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:55:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:55:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:31 --> Model Class Initialized
INFO - 2016-08-10 02:55:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:55:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:55:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:55:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 02:55:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:55:31 --> Final output sent to browser
DEBUG - 2016-08-10 02:55:31 --> Total execution time: 0.5341
INFO - 2016-08-10 02:55:33 --> Config Class Initialized
INFO - 2016-08-10 02:55:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:55:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:55:33 --> Utf8 Class Initialized
INFO - 2016-08-10 02:55:33 --> URI Class Initialized
INFO - 2016-08-10 02:55:33 --> Router Class Initialized
INFO - 2016-08-10 02:55:33 --> Output Class Initialized
INFO - 2016-08-10 02:55:33 --> Security Class Initialized
DEBUG - 2016-08-10 02:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:55:33 --> Input Class Initialized
INFO - 2016-08-10 02:55:33 --> Language Class Initialized
INFO - 2016-08-10 02:55:33 --> Loader Class Initialized
INFO - 2016-08-10 02:55:33 --> Helper loaded: url_helper
INFO - 2016-08-10 02:55:33 --> Helper loaded: date_helper
INFO - 2016-08-10 02:55:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:55:33 --> Database Driver Class Initialized
INFO - 2016-08-10 02:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:55:33 --> Email Class Initialized
INFO - 2016-08-10 02:55:33 --> Model Class Initialized
INFO - 2016-08-10 02:55:33 --> Controller Class Initialized
DEBUG - 2016-08-10 02:55:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:55:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:55:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:55:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:33 --> Model Class Initialized
INFO - 2016-08-10 02:55:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:55:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:55:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:55:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 02:55:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:55:33 --> Final output sent to browser
DEBUG - 2016-08-10 02:55:33 --> Total execution time: 0.6283
INFO - 2016-08-10 02:55:35 --> Config Class Initialized
INFO - 2016-08-10 02:55:35 --> Hooks Class Initialized
DEBUG - 2016-08-10 02:55:35 --> UTF-8 Support Enabled
INFO - 2016-08-10 02:55:35 --> Utf8 Class Initialized
INFO - 2016-08-10 02:55:35 --> URI Class Initialized
INFO - 2016-08-10 02:55:35 --> Router Class Initialized
INFO - 2016-08-10 02:55:35 --> Output Class Initialized
INFO - 2016-08-10 02:55:35 --> Security Class Initialized
DEBUG - 2016-08-10 02:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 02:55:35 --> Input Class Initialized
INFO - 2016-08-10 02:55:35 --> Language Class Initialized
INFO - 2016-08-10 02:55:35 --> Loader Class Initialized
INFO - 2016-08-10 02:55:35 --> Helper loaded: url_helper
INFO - 2016-08-10 02:55:35 --> Helper loaded: date_helper
INFO - 2016-08-10 02:55:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 02:55:35 --> Database Driver Class Initialized
INFO - 2016-08-10 02:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 02:55:35 --> Email Class Initialized
INFO - 2016-08-10 02:55:35 --> Model Class Initialized
INFO - 2016-08-10 02:55:35 --> Controller Class Initialized
DEBUG - 2016-08-10 02:55:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 02:55:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 02:55:36 --> Helper loaded: cookie_helper
INFO - 2016-08-10 02:55:36 --> Helper loaded: language_helper
DEBUG - 2016-08-10 02:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 02:55:36 --> Model Class Initialized
INFO - 2016-08-10 02:55:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 02:55:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 02:55:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 02:55:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 02:55:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 02:55:36 --> Final output sent to browser
DEBUG - 2016-08-10 02:55:36 --> Total execution time: 0.5790
INFO - 2016-08-10 11:27:38 --> Config Class Initialized
INFO - 2016-08-10 11:27:38 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:27:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:27:39 --> Utf8 Class Initialized
INFO - 2016-08-10 11:27:39 --> URI Class Initialized
DEBUG - 2016-08-10 11:27:39 --> No URI present. Default controller set.
INFO - 2016-08-10 11:27:39 --> Router Class Initialized
INFO - 2016-08-10 11:27:39 --> Output Class Initialized
INFO - 2016-08-10 11:27:39 --> Security Class Initialized
DEBUG - 2016-08-10 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:27:39 --> Input Class Initialized
INFO - 2016-08-10 11:27:39 --> Language Class Initialized
INFO - 2016-08-10 11:27:39 --> Loader Class Initialized
INFO - 2016-08-10 11:27:39 --> Helper loaded: url_helper
INFO - 2016-08-10 11:27:39 --> Helper loaded: date_helper
INFO - 2016-08-10 11:27:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:27:39 --> Database Driver Class Initialized
INFO - 2016-08-10 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:27:40 --> Email Class Initialized
INFO - 2016-08-10 11:27:40 --> Model Class Initialized
INFO - 2016-08-10 11:27:40 --> Controller Class Initialized
DEBUG - 2016-08-10 11:27:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:27:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:27:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:27:40 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:27:40 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:27:40 --> Model Class Initialized
INFO - 2016-08-10 11:27:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 11:27:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 11:27:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-10 11:27:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 11:27:40 --> Final output sent to browser
DEBUG - 2016-08-10 11:27:40 --> Total execution time: 2.7083
INFO - 2016-08-10 11:44:57 --> Config Class Initialized
INFO - 2016-08-10 11:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:44:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:44:57 --> Utf8 Class Initialized
INFO - 2016-08-10 11:44:57 --> URI Class Initialized
INFO - 2016-08-10 11:44:57 --> Router Class Initialized
INFO - 2016-08-10 11:44:57 --> Output Class Initialized
INFO - 2016-08-10 11:44:57 --> Security Class Initialized
DEBUG - 2016-08-10 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:44:57 --> Input Class Initialized
INFO - 2016-08-10 11:44:57 --> Language Class Initialized
INFO - 2016-08-10 11:44:58 --> Loader Class Initialized
INFO - 2016-08-10 11:44:58 --> Helper loaded: url_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: date_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:44:58 --> Database Driver Class Initialized
INFO - 2016-08-10 11:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:44:58 --> Email Class Initialized
INFO - 2016-08-10 11:44:58 --> Model Class Initialized
INFO - 2016-08-10 11:44:58 --> Controller Class Initialized
DEBUG - 2016-08-10 11:44:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:44:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:44:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:44:58 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:44:58 --> Model Class Initialized
INFO - 2016-08-10 11:44:58 --> Config Class Initialized
INFO - 2016-08-10 11:44:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:44:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:44:58 --> Utf8 Class Initialized
INFO - 2016-08-10 11:44:58 --> URI Class Initialized
INFO - 2016-08-10 11:44:58 --> Router Class Initialized
INFO - 2016-08-10 11:44:58 --> Output Class Initialized
INFO - 2016-08-10 11:44:58 --> Security Class Initialized
DEBUG - 2016-08-10 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:44:58 --> Input Class Initialized
INFO - 2016-08-10 11:44:58 --> Language Class Initialized
INFO - 2016-08-10 11:44:58 --> Loader Class Initialized
INFO - 2016-08-10 11:44:58 --> Helper loaded: url_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: date_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:44:58 --> Database Driver Class Initialized
INFO - 2016-08-10 11:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:44:58 --> Email Class Initialized
INFO - 2016-08-10 11:44:58 --> Model Class Initialized
INFO - 2016-08-10 11:44:58 --> Controller Class Initialized
DEBUG - 2016-08-10 11:44:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:44:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:44:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:44:58 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:44:58 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:44:59 --> Model Class Initialized
INFO - 2016-08-10 11:44:59 --> Helper loaded: form_helper
INFO - 2016-08-10 11:44:59 --> Form Validation Class Initialized
INFO - 2016-08-10 11:44:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 11:44:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-10 11:44:59 --> Final output sent to browser
DEBUG - 2016-08-10 11:44:59 --> Total execution time: 0.9563
INFO - 2016-08-10 11:45:13 --> Config Class Initialized
INFO - 2016-08-10 11:45:13 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:45:13 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:45:13 --> Utf8 Class Initialized
INFO - 2016-08-10 11:45:13 --> URI Class Initialized
INFO - 2016-08-10 11:45:13 --> Router Class Initialized
INFO - 2016-08-10 11:45:13 --> Output Class Initialized
INFO - 2016-08-10 11:45:13 --> Security Class Initialized
DEBUG - 2016-08-10 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:45:13 --> Input Class Initialized
INFO - 2016-08-10 11:45:13 --> Language Class Initialized
INFO - 2016-08-10 11:45:13 --> Loader Class Initialized
INFO - 2016-08-10 11:45:13 --> Helper loaded: url_helper
INFO - 2016-08-10 11:45:13 --> Helper loaded: date_helper
INFO - 2016-08-10 11:45:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:45:13 --> Database Driver Class Initialized
INFO - 2016-08-10 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:45:13 --> Email Class Initialized
INFO - 2016-08-10 11:45:13 --> Model Class Initialized
INFO - 2016-08-10 11:45:13 --> Controller Class Initialized
DEBUG - 2016-08-10 11:45:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:45:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:45:13 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:45:13 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:13 --> Model Class Initialized
INFO - 2016-08-10 11:45:13 --> Helper loaded: form_helper
INFO - 2016-08-10 11:45:13 --> Form Validation Class Initialized
INFO - 2016-08-10 11:45:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 11:45:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 11:45:14 --> Config Class Initialized
INFO - 2016-08-10 11:45:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:45:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:45:14 --> Utf8 Class Initialized
INFO - 2016-08-10 11:45:14 --> URI Class Initialized
INFO - 2016-08-10 11:45:14 --> Router Class Initialized
INFO - 2016-08-10 11:45:14 --> Output Class Initialized
INFO - 2016-08-10 11:45:14 --> Security Class Initialized
DEBUG - 2016-08-10 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:45:14 --> Input Class Initialized
INFO - 2016-08-10 11:45:14 --> Language Class Initialized
INFO - 2016-08-10 11:45:14 --> Loader Class Initialized
INFO - 2016-08-10 11:45:14 --> Helper loaded: url_helper
INFO - 2016-08-10 11:45:14 --> Helper loaded: date_helper
INFO - 2016-08-10 11:45:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:45:14 --> Database Driver Class Initialized
INFO - 2016-08-10 11:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:45:14 --> Email Class Initialized
INFO - 2016-08-10 11:45:14 --> Model Class Initialized
INFO - 2016-08-10 11:45:14 --> Controller Class Initialized
DEBUG - 2016-08-10 11:45:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:45:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:45:14 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:45:14 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:14 --> Model Class Initialized
INFO - 2016-08-10 11:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:45:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-10 11:45:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:45:15 --> Final output sent to browser
DEBUG - 2016-08-10 11:45:15 --> Total execution time: 1.1848
INFO - 2016-08-10 11:45:23 --> Config Class Initialized
INFO - 2016-08-10 11:45:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:45:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:45:24 --> Utf8 Class Initialized
INFO - 2016-08-10 11:45:24 --> URI Class Initialized
INFO - 2016-08-10 11:45:24 --> Router Class Initialized
INFO - 2016-08-10 11:45:24 --> Output Class Initialized
INFO - 2016-08-10 11:45:24 --> Security Class Initialized
DEBUG - 2016-08-10 11:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:45:24 --> Input Class Initialized
INFO - 2016-08-10 11:45:24 --> Language Class Initialized
INFO - 2016-08-10 11:45:24 --> Loader Class Initialized
INFO - 2016-08-10 11:45:24 --> Helper loaded: url_helper
INFO - 2016-08-10 11:45:24 --> Helper loaded: date_helper
INFO - 2016-08-10 11:45:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:45:24 --> Database Driver Class Initialized
INFO - 2016-08-10 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:45:24 --> Email Class Initialized
INFO - 2016-08-10 11:45:24 --> Model Class Initialized
INFO - 2016-08-10 11:45:24 --> Controller Class Initialized
DEBUG - 2016-08-10 11:45:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:45:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:45:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:45:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:24 --> Model Class Initialized
INFO - 2016-08-10 11:45:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:45:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:45:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:45:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 11:45:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:45:24 --> Final output sent to browser
DEBUG - 2016-08-10 11:45:24 --> Total execution time: 0.5697
INFO - 2016-08-10 11:45:27 --> Config Class Initialized
INFO - 2016-08-10 11:45:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:45:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:45:27 --> Utf8 Class Initialized
INFO - 2016-08-10 11:45:27 --> URI Class Initialized
INFO - 2016-08-10 11:45:27 --> Router Class Initialized
INFO - 2016-08-10 11:45:27 --> Output Class Initialized
INFO - 2016-08-10 11:45:27 --> Security Class Initialized
DEBUG - 2016-08-10 11:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:45:27 --> Input Class Initialized
INFO - 2016-08-10 11:45:27 --> Language Class Initialized
INFO - 2016-08-10 11:45:27 --> Loader Class Initialized
INFO - 2016-08-10 11:45:27 --> Helper loaded: url_helper
INFO - 2016-08-10 11:45:27 --> Helper loaded: date_helper
INFO - 2016-08-10 11:45:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:45:27 --> Database Driver Class Initialized
INFO - 2016-08-10 11:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:45:27 --> Email Class Initialized
INFO - 2016-08-10 11:45:27 --> Model Class Initialized
INFO - 2016-08-10 11:45:27 --> Controller Class Initialized
DEBUG - 2016-08-10 11:45:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:45:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:45:27 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:45:27 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:27 --> Model Class Initialized
ERROR - 2016-08-10 11:45:27 --> Severity: Notice --> Undefined property: Content::$base_modal D:\xampp\htdocs\aqiqahsehati\application\controllers\Content.php 221
ERROR - 2016-08-10 11:45:27 --> Severity: Error --> Call to a member function get() on a non-object D:\xampp\htdocs\aqiqahsehati\application\controllers\Content.php 221
INFO - 2016-08-10 11:45:56 --> Config Class Initialized
INFO - 2016-08-10 11:45:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:45:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:45:56 --> Utf8 Class Initialized
INFO - 2016-08-10 11:45:56 --> URI Class Initialized
INFO - 2016-08-10 11:45:56 --> Router Class Initialized
INFO - 2016-08-10 11:45:56 --> Output Class Initialized
INFO - 2016-08-10 11:45:56 --> Security Class Initialized
DEBUG - 2016-08-10 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:45:56 --> Input Class Initialized
INFO - 2016-08-10 11:45:56 --> Language Class Initialized
INFO - 2016-08-10 11:45:56 --> Loader Class Initialized
INFO - 2016-08-10 11:45:56 --> Helper loaded: url_helper
INFO - 2016-08-10 11:45:56 --> Helper loaded: date_helper
INFO - 2016-08-10 11:45:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:45:56 --> Database Driver Class Initialized
INFO - 2016-08-10 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:45:56 --> Email Class Initialized
INFO - 2016-08-10 11:45:56 --> Model Class Initialized
INFO - 2016-08-10 11:45:56 --> Controller Class Initialized
DEBUG - 2016-08-10 11:45:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:45:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:45:56 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:45:56 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:45:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:45:56 --> Model Class Initialized
INFO - 2016-08-10 11:45:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:45:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:45:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:45:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:45:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:45:56 --> Final output sent to browser
DEBUG - 2016-08-10 11:45:56 --> Total execution time: 0.5828
INFO - 2016-08-10 11:48:11 --> Config Class Initialized
INFO - 2016-08-10 11:48:11 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:48:11 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:48:11 --> Utf8 Class Initialized
INFO - 2016-08-10 11:48:11 --> URI Class Initialized
INFO - 2016-08-10 11:48:11 --> Router Class Initialized
INFO - 2016-08-10 11:48:11 --> Output Class Initialized
INFO - 2016-08-10 11:48:11 --> Security Class Initialized
DEBUG - 2016-08-10 11:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:48:11 --> Input Class Initialized
INFO - 2016-08-10 11:48:11 --> Language Class Initialized
INFO - 2016-08-10 11:48:11 --> Loader Class Initialized
INFO - 2016-08-10 11:48:11 --> Helper loaded: url_helper
INFO - 2016-08-10 11:48:11 --> Helper loaded: date_helper
INFO - 2016-08-10 11:48:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:48:11 --> Database Driver Class Initialized
INFO - 2016-08-10 11:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:48:11 --> Email Class Initialized
INFO - 2016-08-10 11:48:11 --> Model Class Initialized
INFO - 2016-08-10 11:48:11 --> Controller Class Initialized
DEBUG - 2016-08-10 11:48:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:48:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:48:11 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:48:11 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:11 --> Model Class Initialized
INFO - 2016-08-10 11:48:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:48:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:48:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:48:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:48:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:48:11 --> Final output sent to browser
DEBUG - 2016-08-10 11:48:11 --> Total execution time: 0.5674
INFO - 2016-08-10 11:48:24 --> Config Class Initialized
INFO - 2016-08-10 11:48:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:48:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:48:24 --> Utf8 Class Initialized
INFO - 2016-08-10 11:48:24 --> URI Class Initialized
INFO - 2016-08-10 11:48:24 --> Router Class Initialized
INFO - 2016-08-10 11:48:24 --> Output Class Initialized
INFO - 2016-08-10 11:48:24 --> Security Class Initialized
DEBUG - 2016-08-10 11:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:48:24 --> Input Class Initialized
INFO - 2016-08-10 11:48:24 --> Language Class Initialized
INFO - 2016-08-10 11:48:24 --> Loader Class Initialized
INFO - 2016-08-10 11:48:24 --> Helper loaded: url_helper
INFO - 2016-08-10 11:48:24 --> Helper loaded: date_helper
INFO - 2016-08-10 11:48:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:48:24 --> Database Driver Class Initialized
INFO - 2016-08-10 11:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:48:24 --> Email Class Initialized
INFO - 2016-08-10 11:48:24 --> Model Class Initialized
INFO - 2016-08-10 11:48:24 --> Controller Class Initialized
DEBUG - 2016-08-10 11:48:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:48:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:48:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:48:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:24 --> Model Class Initialized
INFO - 2016-08-10 11:48:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:48:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:48:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:48:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 11:48:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:48:24 --> Final output sent to browser
DEBUG - 2016-08-10 11:48:24 --> Total execution time: 0.5569
INFO - 2016-08-10 11:48:41 --> Config Class Initialized
INFO - 2016-08-10 11:48:41 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:48:41 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:48:41 --> Utf8 Class Initialized
INFO - 2016-08-10 11:48:41 --> URI Class Initialized
INFO - 2016-08-10 11:48:41 --> Router Class Initialized
INFO - 2016-08-10 11:48:41 --> Output Class Initialized
INFO - 2016-08-10 11:48:41 --> Security Class Initialized
DEBUG - 2016-08-10 11:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:48:41 --> Input Class Initialized
INFO - 2016-08-10 11:48:41 --> Language Class Initialized
INFO - 2016-08-10 11:48:41 --> Loader Class Initialized
INFO - 2016-08-10 11:48:41 --> Helper loaded: url_helper
INFO - 2016-08-10 11:48:41 --> Helper loaded: date_helper
INFO - 2016-08-10 11:48:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:48:41 --> Database Driver Class Initialized
INFO - 2016-08-10 11:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:48:41 --> Email Class Initialized
INFO - 2016-08-10 11:48:41 --> Model Class Initialized
INFO - 2016-08-10 11:48:41 --> Controller Class Initialized
DEBUG - 2016-08-10 11:48:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:48:41 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:48:41 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:41 --> Model Class Initialized
INFO - 2016-08-10 11:48:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:48:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:48:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:48:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:48:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:48:41 --> Final output sent to browser
DEBUG - 2016-08-10 11:48:41 --> Total execution time: 0.5500
INFO - 2016-08-10 11:48:44 --> Config Class Initialized
INFO - 2016-08-10 11:48:44 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:48:44 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:48:44 --> Utf8 Class Initialized
INFO - 2016-08-10 11:48:44 --> URI Class Initialized
INFO - 2016-08-10 11:48:44 --> Router Class Initialized
INFO - 2016-08-10 11:48:44 --> Output Class Initialized
INFO - 2016-08-10 11:48:44 --> Security Class Initialized
DEBUG - 2016-08-10 11:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:48:44 --> Input Class Initialized
INFO - 2016-08-10 11:48:44 --> Language Class Initialized
INFO - 2016-08-10 11:48:44 --> Loader Class Initialized
INFO - 2016-08-10 11:48:44 --> Helper loaded: url_helper
INFO - 2016-08-10 11:48:44 --> Helper loaded: date_helper
INFO - 2016-08-10 11:48:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:48:44 --> Database Driver Class Initialized
INFO - 2016-08-10 11:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:48:44 --> Email Class Initialized
INFO - 2016-08-10 11:48:44 --> Model Class Initialized
INFO - 2016-08-10 11:48:44 --> Controller Class Initialized
DEBUG - 2016-08-10 11:48:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:48:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:48:44 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:48:44 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:48:44 --> Model Class Initialized
INFO - 2016-08-10 11:48:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:48:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:48:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:48:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 11:48:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:48:44 --> Final output sent to browser
DEBUG - 2016-08-10 11:48:45 --> Total execution time: 0.5704
INFO - 2016-08-10 11:49:03 --> Config Class Initialized
INFO - 2016-08-10 11:49:03 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:49:03 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:49:03 --> Utf8 Class Initialized
INFO - 2016-08-10 11:49:03 --> URI Class Initialized
INFO - 2016-08-10 11:49:03 --> Router Class Initialized
INFO - 2016-08-10 11:49:03 --> Output Class Initialized
INFO - 2016-08-10 11:49:03 --> Security Class Initialized
DEBUG - 2016-08-10 11:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:49:03 --> Input Class Initialized
INFO - 2016-08-10 11:49:03 --> Language Class Initialized
INFO - 2016-08-10 11:49:03 --> Loader Class Initialized
INFO - 2016-08-10 11:49:03 --> Helper loaded: url_helper
INFO - 2016-08-10 11:49:03 --> Helper loaded: date_helper
INFO - 2016-08-10 11:49:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:49:03 --> Database Driver Class Initialized
INFO - 2016-08-10 11:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:49:03 --> Email Class Initialized
INFO - 2016-08-10 11:49:03 --> Model Class Initialized
INFO - 2016-08-10 11:49:03 --> Controller Class Initialized
DEBUG - 2016-08-10 11:49:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:49:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:49:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:49:03 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:49:03 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:49:03 --> Model Class Initialized
INFO - 2016-08-10 11:49:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:49:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:49:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:49:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:49:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:49:03 --> Final output sent to browser
DEBUG - 2016-08-10 11:49:03 --> Total execution time: 0.5511
INFO - 2016-08-10 11:56:53 --> Config Class Initialized
INFO - 2016-08-10 11:56:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:56:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:56:53 --> Utf8 Class Initialized
INFO - 2016-08-10 11:56:53 --> URI Class Initialized
INFO - 2016-08-10 11:56:53 --> Router Class Initialized
INFO - 2016-08-10 11:56:53 --> Output Class Initialized
INFO - 2016-08-10 11:56:53 --> Security Class Initialized
DEBUG - 2016-08-10 11:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:56:53 --> Input Class Initialized
INFO - 2016-08-10 11:56:53 --> Language Class Initialized
INFO - 2016-08-10 11:56:53 --> Loader Class Initialized
INFO - 2016-08-10 11:56:53 --> Helper loaded: url_helper
INFO - 2016-08-10 11:56:53 --> Helper loaded: date_helper
INFO - 2016-08-10 11:56:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:56:53 --> Database Driver Class Initialized
INFO - 2016-08-10 11:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:56:53 --> Email Class Initialized
INFO - 2016-08-10 11:56:53 --> Model Class Initialized
INFO - 2016-08-10 11:56:53 --> Controller Class Initialized
DEBUG - 2016-08-10 11:56:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:56:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:56:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:56:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:56:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:56:53 --> Model Class Initialized
INFO - 2016-08-10 11:56:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:56:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:56:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:56:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:56:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:56:54 --> Final output sent to browser
DEBUG - 2016-08-10 11:56:54 --> Total execution time: 0.5512
INFO - 2016-08-10 11:57:07 --> Config Class Initialized
INFO - 2016-08-10 11:57:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:57:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:57:07 --> Utf8 Class Initialized
INFO - 2016-08-10 11:57:07 --> URI Class Initialized
INFO - 2016-08-10 11:57:07 --> Router Class Initialized
INFO - 2016-08-10 11:57:07 --> Output Class Initialized
INFO - 2016-08-10 11:57:07 --> Security Class Initialized
DEBUG - 2016-08-10 11:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:57:07 --> Input Class Initialized
INFO - 2016-08-10 11:57:07 --> Language Class Initialized
INFO - 2016-08-10 11:57:07 --> Loader Class Initialized
INFO - 2016-08-10 11:57:07 --> Helper loaded: url_helper
INFO - 2016-08-10 11:57:07 --> Helper loaded: date_helper
INFO - 2016-08-10 11:57:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:57:08 --> Database Driver Class Initialized
INFO - 2016-08-10 11:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:57:08 --> Email Class Initialized
INFO - 2016-08-10 11:57:08 --> Model Class Initialized
INFO - 2016-08-10 11:57:08 --> Controller Class Initialized
DEBUG - 2016-08-10 11:57:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:57:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:57:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:57:08 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:57:08 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:57:08 --> Model Class Initialized
INFO - 2016-08-10 11:57:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-10 11:57:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-10 11:57:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-10 11:57:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-10 11:57:08 --> Final output sent to browser
DEBUG - 2016-08-10 11:57:08 --> Total execution time: 0.5772
INFO - 2016-08-10 11:58:48 --> Config Class Initialized
INFO - 2016-08-10 11:58:48 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:58:48 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:58:48 --> Utf8 Class Initialized
INFO - 2016-08-10 11:58:48 --> URI Class Initialized
INFO - 2016-08-10 11:58:48 --> Router Class Initialized
INFO - 2016-08-10 11:58:48 --> Output Class Initialized
INFO - 2016-08-10 11:58:48 --> Security Class Initialized
DEBUG - 2016-08-10 11:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:58:48 --> Input Class Initialized
INFO - 2016-08-10 11:58:48 --> Language Class Initialized
INFO - 2016-08-10 11:58:48 --> Loader Class Initialized
INFO - 2016-08-10 11:58:48 --> Helper loaded: url_helper
INFO - 2016-08-10 11:58:48 --> Helper loaded: date_helper
INFO - 2016-08-10 11:58:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:58:48 --> Database Driver Class Initialized
INFO - 2016-08-10 11:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:58:48 --> Email Class Initialized
INFO - 2016-08-10 11:58:48 --> Model Class Initialized
INFO - 2016-08-10 11:58:49 --> Controller Class Initialized
DEBUG - 2016-08-10 11:58:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:58:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:58:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:58:49 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:58:49 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:58:49 --> Model Class Initialized
INFO - 2016-08-10 11:58:49 --> Upload Class Initialized
ERROR - 2016-08-10 11:58:49 --> Query error: Unknown column 'kategori' in 'field list' - Invalid query: INSERT INTO `m_posting` (`id_pengguna`, `judul`, `slug`, `konten`, `kategori`, `tipe`, `created_at`, `gambar`) VALUES ('3', 'Aqiqah Sehati Paling Berkualitas', 'aqiqah-sehati-paling-berkualitas', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '1', 'post', '2016-08-10', 'aqiqah-sehati-paling-berkualitas-1470805129.jpg')
INFO - 2016-08-10 11:58:49 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-10 11:59:00 --> Config Class Initialized
INFO - 2016-08-10 11:59:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:59:00 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:59:00 --> Utf8 Class Initialized
INFO - 2016-08-10 11:59:00 --> URI Class Initialized
INFO - 2016-08-10 11:59:00 --> Router Class Initialized
INFO - 2016-08-10 11:59:00 --> Output Class Initialized
INFO - 2016-08-10 11:59:00 --> Security Class Initialized
DEBUG - 2016-08-10 11:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:59:00 --> Input Class Initialized
INFO - 2016-08-10 11:59:00 --> Language Class Initialized
INFO - 2016-08-10 11:59:00 --> Loader Class Initialized
INFO - 2016-08-10 11:59:00 --> Helper loaded: url_helper
INFO - 2016-08-10 11:59:00 --> Helper loaded: date_helper
INFO - 2016-08-10 11:59:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:59:00 --> Database Driver Class Initialized
INFO - 2016-08-10 11:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:59:00 --> Email Class Initialized
INFO - 2016-08-10 11:59:00 --> Model Class Initialized
INFO - 2016-08-10 11:59:00 --> Controller Class Initialized
DEBUG - 2016-08-10 11:59:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:59:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:59:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:59:00 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:59:00 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:59:00 --> Model Class Initialized
INFO - 2016-08-10 11:59:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 11:59:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 11:59:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 11:59:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 11:59:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 11:59:00 --> Final output sent to browser
DEBUG - 2016-08-10 11:59:00 --> Total execution time: 0.5593
INFO - 2016-08-10 11:59:43 --> Config Class Initialized
INFO - 2016-08-10 11:59:43 --> Hooks Class Initialized
DEBUG - 2016-08-10 11:59:43 --> UTF-8 Support Enabled
INFO - 2016-08-10 11:59:43 --> Utf8 Class Initialized
INFO - 2016-08-10 11:59:43 --> URI Class Initialized
INFO - 2016-08-10 11:59:43 --> Router Class Initialized
INFO - 2016-08-10 11:59:43 --> Output Class Initialized
INFO - 2016-08-10 11:59:43 --> Security Class Initialized
DEBUG - 2016-08-10 11:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 11:59:43 --> Input Class Initialized
INFO - 2016-08-10 11:59:43 --> Language Class Initialized
INFO - 2016-08-10 11:59:43 --> Loader Class Initialized
INFO - 2016-08-10 11:59:43 --> Helper loaded: url_helper
INFO - 2016-08-10 11:59:43 --> Helper loaded: date_helper
INFO - 2016-08-10 11:59:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 11:59:43 --> Database Driver Class Initialized
INFO - 2016-08-10 11:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 11:59:43 --> Email Class Initialized
INFO - 2016-08-10 11:59:43 --> Model Class Initialized
INFO - 2016-08-10 11:59:43 --> Controller Class Initialized
DEBUG - 2016-08-10 11:59:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 11:59:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:59:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 11:59:43 --> Helper loaded: cookie_helper
INFO - 2016-08-10 11:59:43 --> Helper loaded: language_helper
DEBUG - 2016-08-10 11:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 11:59:43 --> Model Class Initialized
INFO - 2016-08-10 11:59:43 --> Upload Class Initialized
ERROR - 2016-08-10 11:59:43 --> Query error: Unknown column 'kategori' in 'field list' - Invalid query: INSERT INTO `m_posting` (`id_pengguna`, `judul`, `slug`, `konten`, `kategori`, `tipe`, `created_at`, `gambar`) VALUES ('3', 'Aqiqah Sehati Paling Berkualitas', 'aqiqah-sehati-paling-berkualitas', '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '1', 'post', '2016-08-10', 'aqiqah-sehati-paling-berkualitas-1470805183.jpg')
INFO - 2016-08-10 11:59:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-10 12:01:59 --> Config Class Initialized
INFO - 2016-08-10 12:01:59 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:01:59 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:02:00 --> Utf8 Class Initialized
INFO - 2016-08-10 12:02:00 --> URI Class Initialized
INFO - 2016-08-10 12:02:00 --> Router Class Initialized
INFO - 2016-08-10 12:02:00 --> Output Class Initialized
INFO - 2016-08-10 12:02:00 --> Security Class Initialized
DEBUG - 2016-08-10 12:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:02:00 --> Input Class Initialized
INFO - 2016-08-10 12:02:00 --> Language Class Initialized
INFO - 2016-08-10 12:02:00 --> Loader Class Initialized
INFO - 2016-08-10 12:02:00 --> Helper loaded: url_helper
INFO - 2016-08-10 12:02:00 --> Helper loaded: date_helper
INFO - 2016-08-10 12:02:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:02:00 --> Database Driver Class Initialized
INFO - 2016-08-10 12:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:02:00 --> Email Class Initialized
INFO - 2016-08-10 12:02:00 --> Model Class Initialized
INFO - 2016-08-10 12:02:00 --> Controller Class Initialized
DEBUG - 2016-08-10 12:02:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:02:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:02:00 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:02:00 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:00 --> Model Class Initialized
INFO - 2016-08-10 12:02:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:02:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:02:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:02:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 12:02:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:02:00 --> Final output sent to browser
DEBUG - 2016-08-10 12:02:00 --> Total execution time: 0.5810
INFO - 2016-08-10 12:02:03 --> Config Class Initialized
INFO - 2016-08-10 12:02:03 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:02:03 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:02:03 --> Utf8 Class Initialized
INFO - 2016-08-10 12:02:03 --> URI Class Initialized
INFO - 2016-08-10 12:02:03 --> Router Class Initialized
INFO - 2016-08-10 12:02:03 --> Output Class Initialized
INFO - 2016-08-10 12:02:03 --> Security Class Initialized
DEBUG - 2016-08-10 12:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:02:03 --> Input Class Initialized
INFO - 2016-08-10 12:02:03 --> Language Class Initialized
INFO - 2016-08-10 12:02:03 --> Loader Class Initialized
INFO - 2016-08-10 12:02:03 --> Helper loaded: url_helper
INFO - 2016-08-10 12:02:03 --> Helper loaded: date_helper
INFO - 2016-08-10 12:02:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:02:03 --> Database Driver Class Initialized
INFO - 2016-08-10 12:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:02:03 --> Email Class Initialized
INFO - 2016-08-10 12:02:03 --> Model Class Initialized
INFO - 2016-08-10 12:02:03 --> Controller Class Initialized
DEBUG - 2016-08-10 12:02:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:02:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:02:03 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:02:03 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:02:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:04 --> Model Class Initialized
INFO - 2016-08-10 12:02:04 --> Upload Class Initialized
INFO - 2016-08-10 12:02:04 --> Config Class Initialized
INFO - 2016-08-10 12:02:04 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:02:04 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:02:04 --> Utf8 Class Initialized
INFO - 2016-08-10 12:02:04 --> URI Class Initialized
INFO - 2016-08-10 12:02:04 --> Router Class Initialized
INFO - 2016-08-10 12:02:04 --> Output Class Initialized
INFO - 2016-08-10 12:02:04 --> Security Class Initialized
DEBUG - 2016-08-10 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:02:04 --> Input Class Initialized
INFO - 2016-08-10 12:02:04 --> Language Class Initialized
INFO - 2016-08-10 12:02:04 --> Loader Class Initialized
INFO - 2016-08-10 12:02:04 --> Helper loaded: url_helper
INFO - 2016-08-10 12:02:04 --> Helper loaded: date_helper
INFO - 2016-08-10 12:02:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:02:04 --> Database Driver Class Initialized
INFO - 2016-08-10 12:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:02:04 --> Email Class Initialized
INFO - 2016-08-10 12:02:05 --> Model Class Initialized
INFO - 2016-08-10 12:02:05 --> Controller Class Initialized
DEBUG - 2016-08-10 12:02:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:02:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:02:05 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:02:05 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:02:05 --> Model Class Initialized
INFO - 2016-08-10 12:02:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:02:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:02:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:02:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:02:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:02:05 --> Final output sent to browser
DEBUG - 2016-08-10 12:02:05 --> Total execution time: 1.2762
INFO - 2016-08-10 12:11:39 --> Config Class Initialized
INFO - 2016-08-10 12:11:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:11:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:11:39 --> Utf8 Class Initialized
INFO - 2016-08-10 12:11:39 --> URI Class Initialized
INFO - 2016-08-10 12:11:39 --> Router Class Initialized
INFO - 2016-08-10 12:11:39 --> Output Class Initialized
INFO - 2016-08-10 12:11:39 --> Security Class Initialized
DEBUG - 2016-08-10 12:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:11:39 --> Input Class Initialized
INFO - 2016-08-10 12:11:39 --> Language Class Initialized
INFO - 2016-08-10 12:11:39 --> Loader Class Initialized
INFO - 2016-08-10 12:11:39 --> Helper loaded: url_helper
INFO - 2016-08-10 12:11:39 --> Helper loaded: date_helper
INFO - 2016-08-10 12:11:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:11:39 --> Database Driver Class Initialized
INFO - 2016-08-10 12:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:11:39 --> Email Class Initialized
INFO - 2016-08-10 12:11:39 --> Model Class Initialized
INFO - 2016-08-10 12:11:39 --> Controller Class Initialized
DEBUG - 2016-08-10 12:11:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:11:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:11:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:11:39 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:11:39 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:11:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:11:39 --> Model Class Initialized
INFO - 2016-08-10 12:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:11:39 --> Final output sent to browser
DEBUG - 2016-08-10 12:11:39 --> Total execution time: 0.5733
INFO - 2016-08-10 12:12:00 --> Config Class Initialized
INFO - 2016-08-10 12:12:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:12:00 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:12:00 --> Utf8 Class Initialized
INFO - 2016-08-10 12:12:00 --> URI Class Initialized
INFO - 2016-08-10 12:12:00 --> Router Class Initialized
INFO - 2016-08-10 12:12:00 --> Output Class Initialized
INFO - 2016-08-10 12:12:00 --> Security Class Initialized
DEBUG - 2016-08-10 12:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:12:00 --> Input Class Initialized
INFO - 2016-08-10 12:12:00 --> Language Class Initialized
ERROR - 2016-08-10 12:12:00 --> 404 Page Not Found: Content/index2.html
INFO - 2016-08-10 12:12:02 --> Config Class Initialized
INFO - 2016-08-10 12:12:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:12:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:12:02 --> Utf8 Class Initialized
INFO - 2016-08-10 12:12:02 --> URI Class Initialized
INFO - 2016-08-10 12:12:02 --> Router Class Initialized
INFO - 2016-08-10 12:12:02 --> Output Class Initialized
INFO - 2016-08-10 12:12:02 --> Security Class Initialized
DEBUG - 2016-08-10 12:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:12:02 --> Input Class Initialized
INFO - 2016-08-10 12:12:02 --> Language Class Initialized
INFO - 2016-08-10 12:12:02 --> Loader Class Initialized
INFO - 2016-08-10 12:12:02 --> Helper loaded: url_helper
INFO - 2016-08-10 12:12:02 --> Helper loaded: date_helper
INFO - 2016-08-10 12:12:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:12:02 --> Database Driver Class Initialized
INFO - 2016-08-10 12:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:12:02 --> Email Class Initialized
INFO - 2016-08-10 12:12:02 --> Model Class Initialized
INFO - 2016-08-10 12:12:02 --> Controller Class Initialized
DEBUG - 2016-08-10 12:12:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:12:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:12:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:12:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:12:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:12:03 --> Model Class Initialized
INFO - 2016-08-10 12:12:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:12:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:12:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:12:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:12:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:12:03 --> Final output sent to browser
DEBUG - 2016-08-10 12:12:03 --> Total execution time: 0.5763
INFO - 2016-08-10 12:12:10 --> Config Class Initialized
INFO - 2016-08-10 12:12:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:12:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:12:10 --> Utf8 Class Initialized
INFO - 2016-08-10 12:12:10 --> URI Class Initialized
INFO - 2016-08-10 12:12:10 --> Router Class Initialized
INFO - 2016-08-10 12:12:10 --> Output Class Initialized
INFO - 2016-08-10 12:12:10 --> Security Class Initialized
DEBUG - 2016-08-10 12:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:12:10 --> Input Class Initialized
INFO - 2016-08-10 12:12:10 --> Language Class Initialized
INFO - 2016-08-10 12:12:10 --> Loader Class Initialized
INFO - 2016-08-10 12:12:10 --> Helper loaded: url_helper
INFO - 2016-08-10 12:12:10 --> Helper loaded: date_helper
INFO - 2016-08-10 12:12:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:12:10 --> Database Driver Class Initialized
INFO - 2016-08-10 12:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:12:10 --> Email Class Initialized
INFO - 2016-08-10 12:12:10 --> Model Class Initialized
INFO - 2016-08-10 12:12:10 --> Controller Class Initialized
DEBUG - 2016-08-10 12:12:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:12:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:12:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:12:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:12:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:12:10 --> Model Class Initialized
INFO - 2016-08-10 12:12:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:12:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:12:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:12:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:12:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:12:10 --> Final output sent to browser
DEBUG - 2016-08-10 12:12:10 --> Total execution time: 0.5834
INFO - 2016-08-10 12:14:59 --> Config Class Initialized
INFO - 2016-08-10 12:14:59 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:14:59 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:14:59 --> Utf8 Class Initialized
INFO - 2016-08-10 12:14:59 --> URI Class Initialized
INFO - 2016-08-10 12:14:59 --> Router Class Initialized
INFO - 2016-08-10 12:14:59 --> Output Class Initialized
INFO - 2016-08-10 12:14:59 --> Security Class Initialized
DEBUG - 2016-08-10 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:14:59 --> Input Class Initialized
INFO - 2016-08-10 12:14:59 --> Language Class Initialized
INFO - 2016-08-10 12:14:59 --> Loader Class Initialized
INFO - 2016-08-10 12:14:59 --> Helper loaded: url_helper
INFO - 2016-08-10 12:14:59 --> Helper loaded: date_helper
INFO - 2016-08-10 12:14:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:14:59 --> Database Driver Class Initialized
INFO - 2016-08-10 12:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:14:59 --> Email Class Initialized
INFO - 2016-08-10 12:14:59 --> Model Class Initialized
INFO - 2016-08-10 12:14:59 --> Controller Class Initialized
DEBUG - 2016-08-10 12:14:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:14:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:14:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:14:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:14:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:14:59 --> Model Class Initialized
INFO - 2016-08-10 12:14:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:14:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:14:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:14:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:14:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:14:59 --> Final output sent to browser
DEBUG - 2016-08-10 12:14:59 --> Total execution time: 0.8452
INFO - 2016-08-10 12:16:09 --> Config Class Initialized
INFO - 2016-08-10 12:16:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:16:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:16:09 --> Utf8 Class Initialized
INFO - 2016-08-10 12:16:09 --> URI Class Initialized
INFO - 2016-08-10 12:16:09 --> Router Class Initialized
INFO - 2016-08-10 12:16:09 --> Output Class Initialized
INFO - 2016-08-10 12:16:09 --> Security Class Initialized
DEBUG - 2016-08-10 12:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:16:09 --> Input Class Initialized
INFO - 2016-08-10 12:16:09 --> Language Class Initialized
INFO - 2016-08-10 12:16:09 --> Loader Class Initialized
INFO - 2016-08-10 12:16:09 --> Helper loaded: url_helper
INFO - 2016-08-10 12:16:09 --> Helper loaded: date_helper
INFO - 2016-08-10 12:16:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:16:09 --> Database Driver Class Initialized
INFO - 2016-08-10 12:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:16:10 --> Email Class Initialized
INFO - 2016-08-10 12:16:10 --> Model Class Initialized
INFO - 2016-08-10 12:16:10 --> Controller Class Initialized
DEBUG - 2016-08-10 12:16:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:16:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:16:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:16:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:16:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:16:10 --> Model Class Initialized
INFO - 2016-08-10 12:16:10 --> Final output sent to browser
DEBUG - 2016-08-10 12:16:10 --> Total execution time: 0.7225
INFO - 2016-08-10 12:22:00 --> Config Class Initialized
INFO - 2016-08-10 12:22:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:22:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:22:01 --> Utf8 Class Initialized
INFO - 2016-08-10 12:22:01 --> URI Class Initialized
INFO - 2016-08-10 12:22:01 --> Router Class Initialized
INFO - 2016-08-10 12:22:01 --> Output Class Initialized
INFO - 2016-08-10 12:22:01 --> Security Class Initialized
DEBUG - 2016-08-10 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:22:01 --> Input Class Initialized
INFO - 2016-08-10 12:22:01 --> Language Class Initialized
INFO - 2016-08-10 12:22:01 --> Loader Class Initialized
INFO - 2016-08-10 12:22:01 --> Helper loaded: url_helper
INFO - 2016-08-10 12:22:01 --> Helper loaded: date_helper
INFO - 2016-08-10 12:22:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:22:01 --> Database Driver Class Initialized
INFO - 2016-08-10 12:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:22:01 --> Email Class Initialized
INFO - 2016-08-10 12:22:01 --> Model Class Initialized
INFO - 2016-08-10 12:22:01 --> Controller Class Initialized
DEBUG - 2016-08-10 12:22:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:22:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:22:01 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:22:01 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:01 --> Model Class Initialized
INFO - 2016-08-10 12:22:01 --> Final output sent to browser
DEBUG - 2016-08-10 12:22:01 --> Total execution time: 0.7010
INFO - 2016-08-10 12:22:42 --> Config Class Initialized
INFO - 2016-08-10 12:22:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:22:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:22:42 --> Utf8 Class Initialized
INFO - 2016-08-10 12:22:42 --> URI Class Initialized
INFO - 2016-08-10 12:22:42 --> Router Class Initialized
INFO - 2016-08-10 12:22:42 --> Output Class Initialized
INFO - 2016-08-10 12:22:42 --> Security Class Initialized
DEBUG - 2016-08-10 12:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:22:42 --> Input Class Initialized
INFO - 2016-08-10 12:22:42 --> Language Class Initialized
INFO - 2016-08-10 12:22:42 --> Loader Class Initialized
INFO - 2016-08-10 12:22:42 --> Helper loaded: url_helper
INFO - 2016-08-10 12:22:42 --> Helper loaded: date_helper
INFO - 2016-08-10 12:22:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:22:42 --> Database Driver Class Initialized
INFO - 2016-08-10 12:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:22:42 --> Email Class Initialized
INFO - 2016-08-10 12:22:42 --> Model Class Initialized
INFO - 2016-08-10 12:22:42 --> Controller Class Initialized
DEBUG - 2016-08-10 12:22:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:22:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:22:42 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:22:42 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:43 --> Model Class Initialized
INFO - 2016-08-10 12:22:43 --> Final output sent to browser
DEBUG - 2016-08-10 12:22:43 --> Total execution time: 0.5097
INFO - 2016-08-10 12:22:52 --> Config Class Initialized
INFO - 2016-08-10 12:22:52 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:22:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:22:53 --> Utf8 Class Initialized
INFO - 2016-08-10 12:22:53 --> URI Class Initialized
INFO - 2016-08-10 12:22:53 --> Router Class Initialized
INFO - 2016-08-10 12:22:53 --> Output Class Initialized
INFO - 2016-08-10 12:22:53 --> Security Class Initialized
DEBUG - 2016-08-10 12:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:22:53 --> Input Class Initialized
INFO - 2016-08-10 12:22:53 --> Language Class Initialized
INFO - 2016-08-10 12:22:53 --> Loader Class Initialized
INFO - 2016-08-10 12:22:53 --> Helper loaded: url_helper
INFO - 2016-08-10 12:22:53 --> Helper loaded: date_helper
INFO - 2016-08-10 12:22:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:22:53 --> Database Driver Class Initialized
INFO - 2016-08-10 12:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:22:53 --> Email Class Initialized
INFO - 2016-08-10 12:22:53 --> Model Class Initialized
INFO - 2016-08-10 12:22:53 --> Controller Class Initialized
DEBUG - 2016-08-10 12:22:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:22:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:22:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:22:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:22:53 --> Model Class Initialized
INFO - 2016-08-10 12:22:53 --> Final output sent to browser
DEBUG - 2016-08-10 12:22:53 --> Total execution time: 0.9088
INFO - 2016-08-10 12:23:36 --> Config Class Initialized
INFO - 2016-08-10 12:23:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:23:36 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:23:36 --> Utf8 Class Initialized
INFO - 2016-08-10 12:23:36 --> URI Class Initialized
INFO - 2016-08-10 12:23:36 --> Router Class Initialized
INFO - 2016-08-10 12:23:36 --> Output Class Initialized
INFO - 2016-08-10 12:23:36 --> Security Class Initialized
DEBUG - 2016-08-10 12:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:23:36 --> Input Class Initialized
INFO - 2016-08-10 12:23:36 --> Language Class Initialized
INFO - 2016-08-10 12:23:36 --> Loader Class Initialized
INFO - 2016-08-10 12:23:36 --> Helper loaded: url_helper
INFO - 2016-08-10 12:23:36 --> Helper loaded: date_helper
INFO - 2016-08-10 12:23:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:23:36 --> Database Driver Class Initialized
INFO - 2016-08-10 12:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:23:36 --> Email Class Initialized
INFO - 2016-08-10 12:23:36 --> Model Class Initialized
INFO - 2016-08-10 12:23:36 --> Controller Class Initialized
DEBUG - 2016-08-10 12:23:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:23:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:23:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:23:37 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:23:37 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:23:37 --> Model Class Initialized
INFO - 2016-08-10 12:23:37 --> Final output sent to browser
DEBUG - 2016-08-10 12:23:37 --> Total execution time: 0.4985
INFO - 2016-08-10 12:24:10 --> Config Class Initialized
INFO - 2016-08-10 12:24:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:24:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:24:10 --> Utf8 Class Initialized
INFO - 2016-08-10 12:24:10 --> URI Class Initialized
INFO - 2016-08-10 12:24:10 --> Router Class Initialized
INFO - 2016-08-10 12:24:10 --> Output Class Initialized
INFO - 2016-08-10 12:24:10 --> Security Class Initialized
DEBUG - 2016-08-10 12:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:24:10 --> Input Class Initialized
INFO - 2016-08-10 12:24:10 --> Language Class Initialized
INFO - 2016-08-10 12:24:10 --> Loader Class Initialized
INFO - 2016-08-10 12:24:10 --> Helper loaded: url_helper
INFO - 2016-08-10 12:24:10 --> Helper loaded: date_helper
INFO - 2016-08-10 12:24:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:24:10 --> Database Driver Class Initialized
INFO - 2016-08-10 12:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:24:10 --> Email Class Initialized
INFO - 2016-08-10 12:24:10 --> Model Class Initialized
INFO - 2016-08-10 12:24:10 --> Controller Class Initialized
DEBUG - 2016-08-10 12:24:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:24:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:24:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:24:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:24:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:10 --> Model Class Initialized
INFO - 2016-08-10 12:24:10 --> Final output sent to browser
DEBUG - 2016-08-10 12:24:10 --> Total execution time: 0.6569
INFO - 2016-08-10 12:24:12 --> Config Class Initialized
INFO - 2016-08-10 12:24:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:24:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:24:12 --> Utf8 Class Initialized
INFO - 2016-08-10 12:24:12 --> URI Class Initialized
INFO - 2016-08-10 12:24:12 --> Router Class Initialized
INFO - 2016-08-10 12:24:12 --> Output Class Initialized
INFO - 2016-08-10 12:24:12 --> Security Class Initialized
DEBUG - 2016-08-10 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:24:12 --> Input Class Initialized
INFO - 2016-08-10 12:24:12 --> Language Class Initialized
INFO - 2016-08-10 12:24:12 --> Loader Class Initialized
INFO - 2016-08-10 12:24:12 --> Helper loaded: url_helper
INFO - 2016-08-10 12:24:12 --> Helper loaded: date_helper
INFO - 2016-08-10 12:24:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:24:12 --> Database Driver Class Initialized
INFO - 2016-08-10 12:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:24:13 --> Email Class Initialized
INFO - 2016-08-10 12:24:13 --> Model Class Initialized
INFO - 2016-08-10 12:24:13 --> Controller Class Initialized
DEBUG - 2016-08-10 12:24:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:24:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:24:13 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:24:13 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:13 --> Model Class Initialized
INFO - 2016-08-10 12:24:13 --> Final output sent to browser
DEBUG - 2016-08-10 12:24:13 --> Total execution time: 0.6634
INFO - 2016-08-10 12:24:21 --> Config Class Initialized
INFO - 2016-08-10 12:24:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:24:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:24:21 --> Utf8 Class Initialized
INFO - 2016-08-10 12:24:21 --> URI Class Initialized
INFO - 2016-08-10 12:24:21 --> Router Class Initialized
INFO - 2016-08-10 12:24:21 --> Output Class Initialized
INFO - 2016-08-10 12:24:21 --> Security Class Initialized
DEBUG - 2016-08-10 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:24:21 --> Input Class Initialized
INFO - 2016-08-10 12:24:21 --> Language Class Initialized
INFO - 2016-08-10 12:24:21 --> Loader Class Initialized
INFO - 2016-08-10 12:24:21 --> Helper loaded: url_helper
INFO - 2016-08-10 12:24:21 --> Helper loaded: date_helper
INFO - 2016-08-10 12:24:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:24:21 --> Database Driver Class Initialized
INFO - 2016-08-10 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:24:21 --> Email Class Initialized
INFO - 2016-08-10 12:24:22 --> Model Class Initialized
INFO - 2016-08-10 12:24:22 --> Controller Class Initialized
DEBUG - 2016-08-10 12:24:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:24:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:24:22 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:24:22 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:22 --> Model Class Initialized
INFO - 2016-08-10 12:24:22 --> Final output sent to browser
DEBUG - 2016-08-10 12:24:22 --> Total execution time: 0.5187
INFO - 2016-08-10 12:24:52 --> Config Class Initialized
INFO - 2016-08-10 12:24:52 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:24:52 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:24:52 --> Utf8 Class Initialized
INFO - 2016-08-10 12:24:52 --> URI Class Initialized
INFO - 2016-08-10 12:24:52 --> Router Class Initialized
INFO - 2016-08-10 12:24:52 --> Output Class Initialized
INFO - 2016-08-10 12:24:52 --> Security Class Initialized
DEBUG - 2016-08-10 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:24:53 --> Input Class Initialized
INFO - 2016-08-10 12:24:53 --> Language Class Initialized
INFO - 2016-08-10 12:24:53 --> Loader Class Initialized
INFO - 2016-08-10 12:24:53 --> Helper loaded: url_helper
INFO - 2016-08-10 12:24:53 --> Helper loaded: date_helper
INFO - 2016-08-10 12:24:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:24:53 --> Database Driver Class Initialized
INFO - 2016-08-10 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:24:53 --> Email Class Initialized
INFO - 2016-08-10 12:24:53 --> Model Class Initialized
INFO - 2016-08-10 12:24:53 --> Controller Class Initialized
DEBUG - 2016-08-10 12:24:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:24:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:24:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:24:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:24:53 --> Model Class Initialized
INFO - 2016-08-10 12:24:53 --> Final output sent to browser
DEBUG - 2016-08-10 12:24:53 --> Total execution time: 0.8189
INFO - 2016-08-10 12:25:25 --> Config Class Initialized
INFO - 2016-08-10 12:25:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:25:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:25:25 --> Utf8 Class Initialized
INFO - 2016-08-10 12:25:25 --> URI Class Initialized
INFO - 2016-08-10 12:25:25 --> Router Class Initialized
INFO - 2016-08-10 12:25:25 --> Output Class Initialized
INFO - 2016-08-10 12:25:25 --> Security Class Initialized
DEBUG - 2016-08-10 12:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:25:25 --> Input Class Initialized
INFO - 2016-08-10 12:25:25 --> Language Class Initialized
INFO - 2016-08-10 12:25:25 --> Loader Class Initialized
INFO - 2016-08-10 12:25:25 --> Helper loaded: url_helper
INFO - 2016-08-10 12:25:25 --> Helper loaded: date_helper
INFO - 2016-08-10 12:25:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:25:25 --> Database Driver Class Initialized
INFO - 2016-08-10 12:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:25:25 --> Email Class Initialized
INFO - 2016-08-10 12:25:25 --> Model Class Initialized
INFO - 2016-08-10 12:25:25 --> Controller Class Initialized
DEBUG - 2016-08-10 12:25:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:25:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:25:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:25:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:25:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:25:25 --> Model Class Initialized
INFO - 2016-08-10 12:25:25 --> Final output sent to browser
DEBUG - 2016-08-10 12:25:25 --> Total execution time: 0.5109
INFO - 2016-08-10 12:25:33 --> Config Class Initialized
INFO - 2016-08-10 12:25:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:25:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:25:33 --> Utf8 Class Initialized
INFO - 2016-08-10 12:25:33 --> URI Class Initialized
INFO - 2016-08-10 12:25:33 --> Router Class Initialized
INFO - 2016-08-10 12:25:33 --> Output Class Initialized
INFO - 2016-08-10 12:25:33 --> Security Class Initialized
DEBUG - 2016-08-10 12:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:25:33 --> Input Class Initialized
INFO - 2016-08-10 12:25:33 --> Language Class Initialized
INFO - 2016-08-10 12:25:33 --> Loader Class Initialized
INFO - 2016-08-10 12:25:33 --> Helper loaded: url_helper
INFO - 2016-08-10 12:25:33 --> Helper loaded: date_helper
INFO - 2016-08-10 12:25:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:25:33 --> Database Driver Class Initialized
INFO - 2016-08-10 12:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:25:33 --> Email Class Initialized
INFO - 2016-08-10 12:25:33 --> Model Class Initialized
INFO - 2016-08-10 12:25:33 --> Controller Class Initialized
DEBUG - 2016-08-10 12:25:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:25:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:25:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:25:34 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:25:34 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:25:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:25:34 --> Model Class Initialized
INFO - 2016-08-10 12:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:25:34 --> Final output sent to browser
DEBUG - 2016-08-10 12:25:34 --> Total execution time: 0.6984
INFO - 2016-08-10 12:26:01 --> Config Class Initialized
INFO - 2016-08-10 12:26:01 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:26:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:26:01 --> Utf8 Class Initialized
INFO - 2016-08-10 12:26:01 --> URI Class Initialized
INFO - 2016-08-10 12:26:01 --> Router Class Initialized
INFO - 2016-08-10 12:26:01 --> Output Class Initialized
INFO - 2016-08-10 12:26:01 --> Security Class Initialized
DEBUG - 2016-08-10 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:26:01 --> Input Class Initialized
INFO - 2016-08-10 12:26:01 --> Language Class Initialized
INFO - 2016-08-10 12:26:01 --> Loader Class Initialized
INFO - 2016-08-10 12:26:01 --> Helper loaded: url_helper
INFO - 2016-08-10 12:26:01 --> Helper loaded: date_helper
INFO - 2016-08-10 12:26:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:26:01 --> Database Driver Class Initialized
INFO - 2016-08-10 12:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:26:01 --> Email Class Initialized
INFO - 2016-08-10 12:26:01 --> Model Class Initialized
INFO - 2016-08-10 12:26:01 --> Controller Class Initialized
DEBUG - 2016-08-10 12:26:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:26:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:26:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:26:01 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:26:01 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:26:01 --> Model Class Initialized
INFO - 2016-08-10 12:26:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:26:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:26:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:26:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:26:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:26:01 --> Final output sent to browser
DEBUG - 2016-08-10 12:26:01 --> Total execution time: 0.6010
INFO - 2016-08-10 12:28:15 --> Config Class Initialized
INFO - 2016-08-10 12:28:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:28:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:28:15 --> Utf8 Class Initialized
INFO - 2016-08-10 12:28:15 --> URI Class Initialized
INFO - 2016-08-10 12:28:15 --> Router Class Initialized
INFO - 2016-08-10 12:28:15 --> Output Class Initialized
INFO - 2016-08-10 12:28:15 --> Security Class Initialized
DEBUG - 2016-08-10 12:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:28:15 --> Input Class Initialized
INFO - 2016-08-10 12:28:15 --> Language Class Initialized
INFO - 2016-08-10 12:28:15 --> Loader Class Initialized
INFO - 2016-08-10 12:28:15 --> Helper loaded: url_helper
INFO - 2016-08-10 12:28:15 --> Helper loaded: date_helper
INFO - 2016-08-10 12:28:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:28:15 --> Database Driver Class Initialized
INFO - 2016-08-10 12:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:28:15 --> Email Class Initialized
INFO - 2016-08-10 12:28:15 --> Model Class Initialized
INFO - 2016-08-10 12:28:15 --> Controller Class Initialized
DEBUG - 2016-08-10 12:28:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:28:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:28:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:28:15 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:28:15 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:28:15 --> Model Class Initialized
INFO - 2016-08-10 12:28:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:28:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:28:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:28:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-10 12:28:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:28:15 --> Final output sent to browser
DEBUG - 2016-08-10 12:28:15 --> Total execution time: 0.6182
INFO - 2016-08-10 12:28:19 --> Config Class Initialized
INFO - 2016-08-10 12:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:28:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:28:19 --> Utf8 Class Initialized
INFO - 2016-08-10 12:28:19 --> URI Class Initialized
INFO - 2016-08-10 12:28:19 --> Router Class Initialized
INFO - 2016-08-10 12:28:19 --> Output Class Initialized
INFO - 2016-08-10 12:28:19 --> Security Class Initialized
DEBUG - 2016-08-10 12:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:28:19 --> Input Class Initialized
INFO - 2016-08-10 12:28:19 --> Language Class Initialized
INFO - 2016-08-10 12:28:19 --> Loader Class Initialized
INFO - 2016-08-10 12:28:19 --> Helper loaded: url_helper
INFO - 2016-08-10 12:28:19 --> Helper loaded: date_helper
INFO - 2016-08-10 12:28:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:28:19 --> Database Driver Class Initialized
INFO - 2016-08-10 12:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:28:19 --> Email Class Initialized
INFO - 2016-08-10 12:28:19 --> Model Class Initialized
INFO - 2016-08-10 12:28:19 --> Controller Class Initialized
DEBUG - 2016-08-10 12:28:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:28:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:28:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:28:19 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:28:19 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:28:19 --> Model Class Initialized
INFO - 2016-08-10 12:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:28:19 --> Final output sent to browser
DEBUG - 2016-08-10 12:28:19 --> Total execution time: 0.6066
INFO - 2016-08-10 12:29:02 --> Config Class Initialized
INFO - 2016-08-10 12:29:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:29:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:29:02 --> Utf8 Class Initialized
INFO - 2016-08-10 12:29:02 --> URI Class Initialized
INFO - 2016-08-10 12:29:02 --> Router Class Initialized
INFO - 2016-08-10 12:29:02 --> Output Class Initialized
INFO - 2016-08-10 12:29:02 --> Security Class Initialized
DEBUG - 2016-08-10 12:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:29:02 --> Input Class Initialized
INFO - 2016-08-10 12:29:02 --> Language Class Initialized
INFO - 2016-08-10 12:29:02 --> Loader Class Initialized
INFO - 2016-08-10 12:29:02 --> Helper loaded: url_helper
INFO - 2016-08-10 12:29:02 --> Helper loaded: date_helper
INFO - 2016-08-10 12:29:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:29:02 --> Database Driver Class Initialized
INFO - 2016-08-10 12:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:29:03 --> Email Class Initialized
INFO - 2016-08-10 12:29:03 --> Model Class Initialized
INFO - 2016-08-10 12:29:03 --> Controller Class Initialized
DEBUG - 2016-08-10 12:29:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:29:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:29:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:29:03 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:29:03 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:29:03 --> Model Class Initialized
INFO - 2016-08-10 12:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 12:29:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:29:03 --> Final output sent to browser
DEBUG - 2016-08-10 12:29:03 --> Total execution time: 0.6130
INFO - 2016-08-10 12:46:06 --> Config Class Initialized
INFO - 2016-08-10 12:46:06 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:46:06 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:46:06 --> Utf8 Class Initialized
INFO - 2016-08-10 12:46:06 --> URI Class Initialized
INFO - 2016-08-10 12:46:06 --> Router Class Initialized
INFO - 2016-08-10 12:46:06 --> Output Class Initialized
INFO - 2016-08-10 12:46:06 --> Security Class Initialized
DEBUG - 2016-08-10 12:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:46:06 --> Input Class Initialized
INFO - 2016-08-10 12:46:06 --> Language Class Initialized
INFO - 2016-08-10 12:46:06 --> Loader Class Initialized
INFO - 2016-08-10 12:46:06 --> Helper loaded: url_helper
INFO - 2016-08-10 12:46:06 --> Helper loaded: date_helper
INFO - 2016-08-10 12:46:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:46:06 --> Database Driver Class Initialized
INFO - 2016-08-10 12:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:46:06 --> Email Class Initialized
INFO - 2016-08-10 12:46:06 --> Model Class Initialized
INFO - 2016-08-10 12:46:06 --> Controller Class Initialized
DEBUG - 2016-08-10 12:46:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:46:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:46:06 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:46:06 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:06 --> Model Class Initialized
INFO - 2016-08-10 12:46:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:46:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:46:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:46:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:46:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:46:07 --> Final output sent to browser
DEBUG - 2016-08-10 12:46:07 --> Total execution time: 0.6179
INFO - 2016-08-10 12:46:09 --> Config Class Initialized
INFO - 2016-08-10 12:46:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:46:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:46:09 --> Utf8 Class Initialized
INFO - 2016-08-10 12:46:09 --> URI Class Initialized
INFO - 2016-08-10 12:46:09 --> Router Class Initialized
INFO - 2016-08-10 12:46:09 --> Output Class Initialized
INFO - 2016-08-10 12:46:09 --> Security Class Initialized
DEBUG - 2016-08-10 12:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:46:09 --> Input Class Initialized
INFO - 2016-08-10 12:46:09 --> Language Class Initialized
INFO - 2016-08-10 12:46:09 --> Loader Class Initialized
INFO - 2016-08-10 12:46:09 --> Helper loaded: url_helper
INFO - 2016-08-10 12:46:09 --> Helper loaded: date_helper
INFO - 2016-08-10 12:46:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:46:09 --> Database Driver Class Initialized
INFO - 2016-08-10 12:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:46:09 --> Email Class Initialized
INFO - 2016-08-10 12:46:09 --> Model Class Initialized
INFO - 2016-08-10 12:46:09 --> Controller Class Initialized
DEBUG - 2016-08-10 12:46:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:46:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:46:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:46:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:10 --> Model Class Initialized
INFO - 2016-08-10 12:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-10 12:46:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:46:10 --> Final output sent to browser
DEBUG - 2016-08-10 12:46:10 --> Total execution time: 0.6207
INFO - 2016-08-10 12:46:50 --> Config Class Initialized
INFO - 2016-08-10 12:46:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:46:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:46:50 --> Utf8 Class Initialized
INFO - 2016-08-10 12:46:50 --> URI Class Initialized
INFO - 2016-08-10 12:46:51 --> Router Class Initialized
INFO - 2016-08-10 12:46:51 --> Output Class Initialized
INFO - 2016-08-10 12:46:51 --> Security Class Initialized
DEBUG - 2016-08-10 12:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:46:51 --> Input Class Initialized
INFO - 2016-08-10 12:46:51 --> Language Class Initialized
INFO - 2016-08-10 12:46:51 --> Loader Class Initialized
INFO - 2016-08-10 12:46:51 --> Helper loaded: url_helper
INFO - 2016-08-10 12:46:51 --> Helper loaded: date_helper
INFO - 2016-08-10 12:46:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:46:51 --> Database Driver Class Initialized
INFO - 2016-08-10 12:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:46:51 --> Email Class Initialized
INFO - 2016-08-10 12:46:51 --> Model Class Initialized
INFO - 2016-08-10 12:46:51 --> Controller Class Initialized
DEBUG - 2016-08-10 12:46:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:46:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:46:51 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:46:51 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:51 --> Model Class Initialized
INFO - 2016-08-10 12:46:51 --> Upload Class Initialized
INFO - 2016-08-10 12:46:51 --> Config Class Initialized
INFO - 2016-08-10 12:46:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:46:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:46:51 --> Utf8 Class Initialized
INFO - 2016-08-10 12:46:51 --> URI Class Initialized
INFO - 2016-08-10 12:46:51 --> Router Class Initialized
INFO - 2016-08-10 12:46:51 --> Output Class Initialized
INFO - 2016-08-10 12:46:51 --> Security Class Initialized
DEBUG - 2016-08-10 12:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:46:52 --> Input Class Initialized
INFO - 2016-08-10 12:46:52 --> Language Class Initialized
INFO - 2016-08-10 12:46:52 --> Loader Class Initialized
INFO - 2016-08-10 12:46:52 --> Helper loaded: url_helper
INFO - 2016-08-10 12:46:52 --> Helper loaded: date_helper
INFO - 2016-08-10 12:46:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:46:52 --> Database Driver Class Initialized
INFO - 2016-08-10 12:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:46:52 --> Email Class Initialized
INFO - 2016-08-10 12:46:52 --> Model Class Initialized
INFO - 2016-08-10 12:46:52 --> Controller Class Initialized
DEBUG - 2016-08-10 12:46:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:46:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:46:52 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:46:52 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:46:52 --> Model Class Initialized
INFO - 2016-08-10 12:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:46:52 --> Final output sent to browser
DEBUG - 2016-08-10 12:46:52 --> Total execution time: 0.7339
INFO - 2016-08-10 12:46:57 --> Config Class Initialized
INFO - 2016-08-10 12:46:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:46:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:46:57 --> Utf8 Class Initialized
INFO - 2016-08-10 12:46:57 --> URI Class Initialized
INFO - 2016-08-10 12:46:57 --> Router Class Initialized
INFO - 2016-08-10 12:46:57 --> Output Class Initialized
INFO - 2016-08-10 12:46:57 --> Security Class Initialized
DEBUG - 2016-08-10 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:46:57 --> Input Class Initialized
INFO - 2016-08-10 12:46:57 --> Language Class Initialized
ERROR - 2016-08-10 12:46:57 --> 404 Page Not Found: Content/edit_posting
INFO - 2016-08-10 12:47:18 --> Config Class Initialized
INFO - 2016-08-10 12:47:18 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:47:18 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:47:18 --> Utf8 Class Initialized
INFO - 2016-08-10 12:47:18 --> URI Class Initialized
INFO - 2016-08-10 12:47:18 --> Router Class Initialized
INFO - 2016-08-10 12:47:18 --> Output Class Initialized
INFO - 2016-08-10 12:47:18 --> Security Class Initialized
DEBUG - 2016-08-10 12:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:47:18 --> Input Class Initialized
INFO - 2016-08-10 12:47:18 --> Language Class Initialized
INFO - 2016-08-10 12:47:18 --> Loader Class Initialized
INFO - 2016-08-10 12:47:18 --> Helper loaded: url_helper
INFO - 2016-08-10 12:47:18 --> Helper loaded: date_helper
INFO - 2016-08-10 12:47:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:47:18 --> Database Driver Class Initialized
INFO - 2016-08-10 12:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:47:18 --> Email Class Initialized
INFO - 2016-08-10 12:47:18 --> Model Class Initialized
INFO - 2016-08-10 12:47:18 --> Controller Class Initialized
DEBUG - 2016-08-10 12:47:18 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:47:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:47:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:47:18 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:47:19 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:47:19 --> Model Class Initialized
INFO - 2016-08-10 12:47:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:47:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:47:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:47:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-10 12:47:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:47:19 --> Final output sent to browser
DEBUG - 2016-08-10 12:47:19 --> Total execution time: 0.6292
INFO - 2016-08-10 12:47:20 --> Config Class Initialized
INFO - 2016-08-10 12:47:20 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:47:20 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:47:20 --> Utf8 Class Initialized
INFO - 2016-08-10 12:47:20 --> URI Class Initialized
INFO - 2016-08-10 12:47:20 --> Router Class Initialized
INFO - 2016-08-10 12:47:20 --> Output Class Initialized
INFO - 2016-08-10 12:47:20 --> Security Class Initialized
DEBUG - 2016-08-10 12:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:47:20 --> Input Class Initialized
INFO - 2016-08-10 12:47:20 --> Language Class Initialized
ERROR - 2016-08-10 12:47:20 --> 404 Page Not Found: Upload/images
INFO - 2016-08-10 12:47:39 --> Config Class Initialized
INFO - 2016-08-10 12:47:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:47:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:47:39 --> Utf8 Class Initialized
INFO - 2016-08-10 12:47:39 --> URI Class Initialized
INFO - 2016-08-10 12:47:39 --> Router Class Initialized
INFO - 2016-08-10 12:47:39 --> Output Class Initialized
INFO - 2016-08-10 12:47:39 --> Security Class Initialized
DEBUG - 2016-08-10 12:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:47:39 --> Input Class Initialized
INFO - 2016-08-10 12:47:39 --> Language Class Initialized
INFO - 2016-08-10 12:47:39 --> Loader Class Initialized
INFO - 2016-08-10 12:47:39 --> Helper loaded: url_helper
INFO - 2016-08-10 12:47:39 --> Helper loaded: date_helper
INFO - 2016-08-10 12:47:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:47:39 --> Database Driver Class Initialized
INFO - 2016-08-10 12:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:47:39 --> Email Class Initialized
INFO - 2016-08-10 12:47:39 --> Model Class Initialized
INFO - 2016-08-10 12:47:39 --> Controller Class Initialized
DEBUG - 2016-08-10 12:47:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:47:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:47:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:47:39 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:47:39 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:47:39 --> Model Class Initialized
INFO - 2016-08-10 12:47:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:47:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:47:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:47:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:47:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:47:39 --> Final output sent to browser
DEBUG - 2016-08-10 12:47:39 --> Total execution time: 0.6280
INFO - 2016-08-10 12:48:02 --> Config Class Initialized
INFO - 2016-08-10 12:48:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:48:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:48:02 --> Utf8 Class Initialized
INFO - 2016-08-10 12:48:02 --> URI Class Initialized
INFO - 2016-08-10 12:48:02 --> Router Class Initialized
INFO - 2016-08-10 12:48:02 --> Output Class Initialized
INFO - 2016-08-10 12:48:02 --> Security Class Initialized
DEBUG - 2016-08-10 12:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:48:02 --> Input Class Initialized
INFO - 2016-08-10 12:48:02 --> Language Class Initialized
INFO - 2016-08-10 12:48:02 --> Loader Class Initialized
INFO - 2016-08-10 12:48:02 --> Helper loaded: url_helper
INFO - 2016-08-10 12:48:02 --> Helper loaded: date_helper
INFO - 2016-08-10 12:48:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:48:02 --> Database Driver Class Initialized
INFO - 2016-08-10 12:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:48:02 --> Email Class Initialized
INFO - 2016-08-10 12:48:02 --> Model Class Initialized
INFO - 2016-08-10 12:48:02 --> Controller Class Initialized
DEBUG - 2016-08-10 12:48:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:48:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:48:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:48:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:48:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:48:02 --> Model Class Initialized
INFO - 2016-08-10 12:48:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:48:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:48:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:48:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:48:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:48:02 --> Final output sent to browser
DEBUG - 2016-08-10 12:48:02 --> Total execution time: 0.6650
INFO - 2016-08-10 12:49:26 --> Config Class Initialized
INFO - 2016-08-10 12:49:26 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:49:26 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:49:26 --> Utf8 Class Initialized
INFO - 2016-08-10 12:49:26 --> URI Class Initialized
INFO - 2016-08-10 12:49:26 --> Router Class Initialized
INFO - 2016-08-10 12:49:26 --> Output Class Initialized
INFO - 2016-08-10 12:49:26 --> Security Class Initialized
DEBUG - 2016-08-10 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:49:26 --> Input Class Initialized
INFO - 2016-08-10 12:49:26 --> Language Class Initialized
INFO - 2016-08-10 12:49:26 --> Loader Class Initialized
INFO - 2016-08-10 12:49:27 --> Helper loaded: url_helper
INFO - 2016-08-10 12:49:27 --> Helper loaded: date_helper
INFO - 2016-08-10 12:49:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:49:27 --> Database Driver Class Initialized
INFO - 2016-08-10 12:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:49:27 --> Email Class Initialized
INFO - 2016-08-10 12:49:27 --> Model Class Initialized
INFO - 2016-08-10 12:49:27 --> Controller Class Initialized
DEBUG - 2016-08-10 12:49:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:49:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:49:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:49:27 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:49:27 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:49:27 --> Model Class Initialized
INFO - 2016-08-10 12:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:49:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:49:27 --> Final output sent to browser
DEBUG - 2016-08-10 12:49:27 --> Total execution time: 0.6284
INFO - 2016-08-10 12:52:41 --> Config Class Initialized
INFO - 2016-08-10 12:52:41 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:52:41 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:52:41 --> Utf8 Class Initialized
INFO - 2016-08-10 12:52:41 --> URI Class Initialized
INFO - 2016-08-10 12:52:41 --> Router Class Initialized
INFO - 2016-08-10 12:52:41 --> Output Class Initialized
INFO - 2016-08-10 12:52:41 --> Security Class Initialized
DEBUG - 2016-08-10 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:52:41 --> Input Class Initialized
INFO - 2016-08-10 12:52:41 --> Language Class Initialized
INFO - 2016-08-10 12:52:41 --> Loader Class Initialized
INFO - 2016-08-10 12:52:41 --> Helper loaded: url_helper
INFO - 2016-08-10 12:52:41 --> Helper loaded: date_helper
INFO - 2016-08-10 12:52:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:52:42 --> Database Driver Class Initialized
INFO - 2016-08-10 12:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:52:42 --> Email Class Initialized
INFO - 2016-08-10 12:52:42 --> Model Class Initialized
INFO - 2016-08-10 12:52:42 --> Controller Class Initialized
DEBUG - 2016-08-10 12:52:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:52:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:52:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:52:42 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:52:42 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:52:42 --> Model Class Initialized
INFO - 2016-08-10 12:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:52:42 --> Final output sent to browser
DEBUG - 2016-08-10 12:52:42 --> Total execution time: 0.6776
INFO - 2016-08-10 12:53:01 --> Config Class Initialized
INFO - 2016-08-10 12:53:01 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:53:01 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:53:01 --> Utf8 Class Initialized
INFO - 2016-08-10 12:53:01 --> URI Class Initialized
INFO - 2016-08-10 12:53:01 --> Router Class Initialized
INFO - 2016-08-10 12:53:01 --> Output Class Initialized
INFO - 2016-08-10 12:53:01 --> Security Class Initialized
DEBUG - 2016-08-10 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:53:01 --> Input Class Initialized
INFO - 2016-08-10 12:53:01 --> Language Class Initialized
INFO - 2016-08-10 12:53:01 --> Loader Class Initialized
INFO - 2016-08-10 12:53:01 --> Helper loaded: url_helper
INFO - 2016-08-10 12:53:01 --> Helper loaded: date_helper
INFO - 2016-08-10 12:53:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:53:01 --> Database Driver Class Initialized
INFO - 2016-08-10 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:53:01 --> Email Class Initialized
INFO - 2016-08-10 12:53:01 --> Model Class Initialized
INFO - 2016-08-10 12:53:01 --> Controller Class Initialized
DEBUG - 2016-08-10 12:53:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:53:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:53:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:53:01 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:53:01 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:53:01 --> Model Class Initialized
INFO - 2016-08-10 12:53:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:53:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:53:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:53:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:53:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:53:01 --> Final output sent to browser
DEBUG - 2016-08-10 12:53:01 --> Total execution time: 0.6542
INFO - 2016-08-10 12:53:21 --> Config Class Initialized
INFO - 2016-08-10 12:53:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:53:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:53:21 --> Utf8 Class Initialized
INFO - 2016-08-10 12:53:21 --> URI Class Initialized
INFO - 2016-08-10 12:53:22 --> Router Class Initialized
INFO - 2016-08-10 12:53:22 --> Output Class Initialized
INFO - 2016-08-10 12:53:22 --> Security Class Initialized
DEBUG - 2016-08-10 12:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:53:22 --> Input Class Initialized
INFO - 2016-08-10 12:53:22 --> Language Class Initialized
INFO - 2016-08-10 12:53:22 --> Loader Class Initialized
INFO - 2016-08-10 12:53:22 --> Helper loaded: url_helper
INFO - 2016-08-10 12:53:22 --> Helper loaded: date_helper
INFO - 2016-08-10 12:53:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:53:22 --> Database Driver Class Initialized
INFO - 2016-08-10 12:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:53:22 --> Email Class Initialized
INFO - 2016-08-10 12:53:22 --> Model Class Initialized
INFO - 2016-08-10 12:53:22 --> Controller Class Initialized
DEBUG - 2016-08-10 12:53:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:53:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:53:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:53:22 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:53:22 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:53:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:53:22 --> Model Class Initialized
INFO - 2016-08-10 12:53:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:53:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:53:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:53:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:53:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:53:22 --> Final output sent to browser
DEBUG - 2016-08-10 12:53:22 --> Total execution time: 0.6634
INFO - 2016-08-10 12:54:11 --> Config Class Initialized
INFO - 2016-08-10 12:54:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:54:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:54:12 --> Utf8 Class Initialized
INFO - 2016-08-10 12:54:12 --> URI Class Initialized
INFO - 2016-08-10 12:54:12 --> Router Class Initialized
INFO - 2016-08-10 12:54:12 --> Output Class Initialized
INFO - 2016-08-10 12:54:12 --> Security Class Initialized
DEBUG - 2016-08-10 12:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:54:12 --> Input Class Initialized
INFO - 2016-08-10 12:54:12 --> Language Class Initialized
INFO - 2016-08-10 12:54:12 --> Loader Class Initialized
INFO - 2016-08-10 12:54:12 --> Helper loaded: url_helper
INFO - 2016-08-10 12:54:12 --> Helper loaded: date_helper
INFO - 2016-08-10 12:54:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:54:12 --> Database Driver Class Initialized
INFO - 2016-08-10 12:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:54:12 --> Email Class Initialized
INFO - 2016-08-10 12:54:12 --> Model Class Initialized
INFO - 2016-08-10 12:54:12 --> Controller Class Initialized
DEBUG - 2016-08-10 12:54:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:54:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:54:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:54:12 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:54:12 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:54:12 --> Model Class Initialized
INFO - 2016-08-10 12:54:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:54:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:54:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:54:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:54:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:54:12 --> Final output sent to browser
DEBUG - 2016-08-10 12:54:12 --> Total execution time: 0.6896
INFO - 2016-08-10 12:56:21 --> Config Class Initialized
INFO - 2016-08-10 12:56:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:56:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:56:21 --> Utf8 Class Initialized
INFO - 2016-08-10 12:56:21 --> URI Class Initialized
INFO - 2016-08-10 12:56:21 --> Router Class Initialized
INFO - 2016-08-10 12:56:21 --> Output Class Initialized
INFO - 2016-08-10 12:56:21 --> Security Class Initialized
DEBUG - 2016-08-10 12:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:56:21 --> Input Class Initialized
INFO - 2016-08-10 12:56:21 --> Language Class Initialized
INFO - 2016-08-10 12:56:21 --> Loader Class Initialized
INFO - 2016-08-10 12:56:21 --> Helper loaded: url_helper
INFO - 2016-08-10 12:56:21 --> Helper loaded: date_helper
INFO - 2016-08-10 12:56:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:56:21 --> Database Driver Class Initialized
INFO - 2016-08-10 12:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:56:21 --> Email Class Initialized
INFO - 2016-08-10 12:56:21 --> Model Class Initialized
INFO - 2016-08-10 12:56:21 --> Controller Class Initialized
DEBUG - 2016-08-10 12:56:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:56:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:56:22 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:56:22 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:22 --> Model Class Initialized
INFO - 2016-08-10 12:56:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:56:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:56:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:56:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:56:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:56:22 --> Final output sent to browser
DEBUG - 2016-08-10 12:56:22 --> Total execution time: 0.7873
INFO - 2016-08-10 12:56:43 --> Config Class Initialized
INFO - 2016-08-10 12:56:43 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:56:43 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:56:43 --> Utf8 Class Initialized
INFO - 2016-08-10 12:56:43 --> URI Class Initialized
INFO - 2016-08-10 12:56:43 --> Router Class Initialized
INFO - 2016-08-10 12:56:43 --> Output Class Initialized
INFO - 2016-08-10 12:56:43 --> Security Class Initialized
DEBUG - 2016-08-10 12:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:56:43 --> Input Class Initialized
INFO - 2016-08-10 12:56:43 --> Language Class Initialized
INFO - 2016-08-10 12:56:43 --> Loader Class Initialized
INFO - 2016-08-10 12:56:43 --> Helper loaded: url_helper
INFO - 2016-08-10 12:56:43 --> Helper loaded: date_helper
INFO - 2016-08-10 12:56:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:56:43 --> Database Driver Class Initialized
INFO - 2016-08-10 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:56:43 --> Email Class Initialized
INFO - 2016-08-10 12:56:43 --> Model Class Initialized
INFO - 2016-08-10 12:56:43 --> Controller Class Initialized
DEBUG - 2016-08-10 12:56:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:56:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:56:44 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:56:44 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:44 --> Model Class Initialized
INFO - 2016-08-10 12:56:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:56:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:56:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:56:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 12:56:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:56:44 --> Final output sent to browser
DEBUG - 2016-08-10 12:56:44 --> Total execution time: 0.6388
INFO - 2016-08-10 12:56:46 --> Config Class Initialized
INFO - 2016-08-10 12:56:46 --> Hooks Class Initialized
DEBUG - 2016-08-10 12:56:46 --> UTF-8 Support Enabled
INFO - 2016-08-10 12:56:46 --> Utf8 Class Initialized
INFO - 2016-08-10 12:56:46 --> URI Class Initialized
INFO - 2016-08-10 12:56:46 --> Router Class Initialized
INFO - 2016-08-10 12:56:46 --> Output Class Initialized
INFO - 2016-08-10 12:56:46 --> Security Class Initialized
DEBUG - 2016-08-10 12:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 12:56:46 --> Input Class Initialized
INFO - 2016-08-10 12:56:46 --> Language Class Initialized
INFO - 2016-08-10 12:56:46 --> Loader Class Initialized
INFO - 2016-08-10 12:56:46 --> Helper loaded: url_helper
INFO - 2016-08-10 12:56:46 --> Helper loaded: date_helper
INFO - 2016-08-10 12:56:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 12:56:46 --> Database Driver Class Initialized
INFO - 2016-08-10 12:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 12:56:46 --> Email Class Initialized
INFO - 2016-08-10 12:56:46 --> Model Class Initialized
INFO - 2016-08-10 12:56:46 --> Controller Class Initialized
DEBUG - 2016-08-10 12:56:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 12:56:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 12:56:46 --> Helper loaded: cookie_helper
INFO - 2016-08-10 12:56:46 --> Helper loaded: language_helper
DEBUG - 2016-08-10 12:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 12:56:46 --> Model Class Initialized
INFO - 2016-08-10 12:56:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 12:56:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 12:56:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 12:56:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 12:56:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 12:56:47 --> Final output sent to browser
DEBUG - 2016-08-10 12:56:47 --> Total execution time: 0.6452
INFO - 2016-08-10 13:06:50 --> Config Class Initialized
INFO - 2016-08-10 13:06:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:06:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:06:50 --> Utf8 Class Initialized
INFO - 2016-08-10 13:06:50 --> URI Class Initialized
INFO - 2016-08-10 13:06:50 --> Router Class Initialized
INFO - 2016-08-10 13:06:50 --> Output Class Initialized
INFO - 2016-08-10 13:06:50 --> Security Class Initialized
DEBUG - 2016-08-10 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:06:50 --> Input Class Initialized
INFO - 2016-08-10 13:06:50 --> Language Class Initialized
INFO - 2016-08-10 13:06:50 --> Loader Class Initialized
INFO - 2016-08-10 13:06:50 --> Helper loaded: url_helper
INFO - 2016-08-10 13:06:50 --> Helper loaded: date_helper
INFO - 2016-08-10 13:06:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:06:50 --> Database Driver Class Initialized
INFO - 2016-08-10 13:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:06:50 --> Email Class Initialized
INFO - 2016-08-10 13:06:50 --> Model Class Initialized
INFO - 2016-08-10 13:06:50 --> Controller Class Initialized
DEBUG - 2016-08-10 13:06:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:06:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:06:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:06:50 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:06:50 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:06:50 --> Model Class Initialized
INFO - 2016-08-10 13:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 13:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 13:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 13:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 13:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 13:06:50 --> Final output sent to browser
DEBUG - 2016-08-10 13:06:50 --> Total execution time: 0.6809
INFO - 2016-08-10 13:07:02 --> Config Class Initialized
INFO - 2016-08-10 13:07:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:07:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:07:02 --> Utf8 Class Initialized
INFO - 2016-08-10 13:07:02 --> URI Class Initialized
INFO - 2016-08-10 13:07:02 --> Router Class Initialized
INFO - 2016-08-10 13:07:02 --> Output Class Initialized
INFO - 2016-08-10 13:07:02 --> Security Class Initialized
DEBUG - 2016-08-10 13:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:07:02 --> Input Class Initialized
INFO - 2016-08-10 13:07:02 --> Language Class Initialized
INFO - 2016-08-10 13:07:02 --> Loader Class Initialized
INFO - 2016-08-10 13:07:02 --> Helper loaded: url_helper
INFO - 2016-08-10 13:07:02 --> Helper loaded: date_helper
INFO - 2016-08-10 13:07:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:07:02 --> Database Driver Class Initialized
INFO - 2016-08-10 13:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:07:02 --> Email Class Initialized
INFO - 2016-08-10 13:07:02 --> Model Class Initialized
INFO - 2016-08-10 13:07:02 --> Controller Class Initialized
DEBUG - 2016-08-10 13:07:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:07:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:07:02 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:07:02 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:02 --> Model Class Initialized
INFO - 2016-08-10 13:07:02 --> Upload Class Initialized
INFO - 2016-08-10 13:07:02 --> Config Class Initialized
INFO - 2016-08-10 13:07:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:07:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:07:02 --> Utf8 Class Initialized
INFO - 2016-08-10 13:07:02 --> URI Class Initialized
INFO - 2016-08-10 13:07:03 --> Router Class Initialized
INFO - 2016-08-10 13:07:03 --> Output Class Initialized
INFO - 2016-08-10 13:07:03 --> Security Class Initialized
DEBUG - 2016-08-10 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:07:03 --> Input Class Initialized
INFO - 2016-08-10 13:07:03 --> Language Class Initialized
ERROR - 2016-08-10 13:07:03 --> 404 Page Not Found: Content/post
INFO - 2016-08-10 13:07:05 --> Config Class Initialized
INFO - 2016-08-10 13:07:05 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:07:05 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:07:05 --> Utf8 Class Initialized
INFO - 2016-08-10 13:07:05 --> URI Class Initialized
INFO - 2016-08-10 13:07:05 --> Router Class Initialized
INFO - 2016-08-10 13:07:05 --> Output Class Initialized
INFO - 2016-08-10 13:07:05 --> Security Class Initialized
DEBUG - 2016-08-10 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:07:05 --> Input Class Initialized
INFO - 2016-08-10 13:07:05 --> Language Class Initialized
INFO - 2016-08-10 13:07:05 --> Loader Class Initialized
INFO - 2016-08-10 13:07:05 --> Helper loaded: url_helper
INFO - 2016-08-10 13:07:05 --> Helper loaded: date_helper
INFO - 2016-08-10 13:07:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:07:05 --> Database Driver Class Initialized
INFO - 2016-08-10 13:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:07:05 --> Email Class Initialized
INFO - 2016-08-10 13:07:05 --> Model Class Initialized
INFO - 2016-08-10 13:07:05 --> Controller Class Initialized
DEBUG - 2016-08-10 13:07:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:07:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:07:05 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:07:05 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:06 --> Model Class Initialized
INFO - 2016-08-10 13:07:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 13:07:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 13:07:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 13:07:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 13:07:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 13:07:06 --> Final output sent to browser
DEBUG - 2016-08-10 13:07:06 --> Total execution time: 0.6486
INFO - 2016-08-10 13:07:27 --> Config Class Initialized
INFO - 2016-08-10 13:07:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:07:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:07:27 --> Utf8 Class Initialized
INFO - 2016-08-10 13:07:27 --> URI Class Initialized
INFO - 2016-08-10 13:07:27 --> Router Class Initialized
INFO - 2016-08-10 13:07:27 --> Output Class Initialized
INFO - 2016-08-10 13:07:27 --> Security Class Initialized
DEBUG - 2016-08-10 13:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:07:27 --> Input Class Initialized
INFO - 2016-08-10 13:07:27 --> Language Class Initialized
INFO - 2016-08-10 13:07:27 --> Loader Class Initialized
INFO - 2016-08-10 13:07:27 --> Helper loaded: url_helper
INFO - 2016-08-10 13:07:27 --> Helper loaded: date_helper
INFO - 2016-08-10 13:07:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:07:27 --> Database Driver Class Initialized
INFO - 2016-08-10 13:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:07:28 --> Email Class Initialized
INFO - 2016-08-10 13:07:28 --> Model Class Initialized
INFO - 2016-08-10 13:07:28 --> Controller Class Initialized
DEBUG - 2016-08-10 13:07:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:07:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:07:28 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:07:28 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:28 --> Model Class Initialized
INFO - 2016-08-10 13:07:28 --> Upload Class Initialized
INFO - 2016-08-10 13:07:28 --> Config Class Initialized
INFO - 2016-08-10 13:07:28 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:07:28 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:07:28 --> Utf8 Class Initialized
INFO - 2016-08-10 13:07:28 --> URI Class Initialized
INFO - 2016-08-10 13:07:28 --> Router Class Initialized
INFO - 2016-08-10 13:07:28 --> Output Class Initialized
INFO - 2016-08-10 13:07:28 --> Security Class Initialized
DEBUG - 2016-08-10 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:07:28 --> Input Class Initialized
INFO - 2016-08-10 13:07:28 --> Language Class Initialized
INFO - 2016-08-10 13:07:28 --> Loader Class Initialized
INFO - 2016-08-10 13:07:28 --> Helper loaded: url_helper
INFO - 2016-08-10 13:07:28 --> Helper loaded: date_helper
INFO - 2016-08-10 13:07:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:07:28 --> Database Driver Class Initialized
INFO - 2016-08-10 13:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:07:28 --> Email Class Initialized
INFO - 2016-08-10 13:07:28 --> Model Class Initialized
INFO - 2016-08-10 13:07:28 --> Controller Class Initialized
DEBUG - 2016-08-10 13:07:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:07:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:07:29 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:07:29 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:07:29 --> Model Class Initialized
INFO - 2016-08-10 13:07:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 13:07:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 13:07:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 13:07:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 13:07:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 13:07:29 --> Final output sent to browser
DEBUG - 2016-08-10 13:07:29 --> Total execution time: 1.1025
INFO - 2016-08-10 13:08:09 --> Config Class Initialized
INFO - 2016-08-10 13:08:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:08:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:08:09 --> Utf8 Class Initialized
INFO - 2016-08-10 13:08:09 --> URI Class Initialized
INFO - 2016-08-10 13:08:09 --> Router Class Initialized
INFO - 2016-08-10 13:08:09 --> Output Class Initialized
INFO - 2016-08-10 13:08:09 --> Security Class Initialized
DEBUG - 2016-08-10 13:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:08:09 --> Input Class Initialized
INFO - 2016-08-10 13:08:09 --> Language Class Initialized
INFO - 2016-08-10 13:08:09 --> Loader Class Initialized
INFO - 2016-08-10 13:08:09 --> Helper loaded: url_helper
INFO - 2016-08-10 13:08:09 --> Helper loaded: date_helper
INFO - 2016-08-10 13:08:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:08:09 --> Database Driver Class Initialized
INFO - 2016-08-10 13:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:08:09 --> Email Class Initialized
INFO - 2016-08-10 13:08:09 --> Model Class Initialized
INFO - 2016-08-10 13:08:09 --> Controller Class Initialized
DEBUG - 2016-08-10 13:08:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:08:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:08:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:08:09 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:08:09 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:08:09 --> Model Class Initialized
INFO - 2016-08-10 13:08:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 13:08:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 13:08:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 13:08:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 13:08:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 13:08:10 --> Final output sent to browser
DEBUG - 2016-08-10 13:08:10 --> Total execution time: 0.6562
INFO - 2016-08-10 13:08:12 --> Config Class Initialized
INFO - 2016-08-10 13:08:12 --> Hooks Class Initialized
DEBUG - 2016-08-10 13:08:12 --> UTF-8 Support Enabled
INFO - 2016-08-10 13:08:12 --> Utf8 Class Initialized
INFO - 2016-08-10 13:08:12 --> URI Class Initialized
INFO - 2016-08-10 13:08:12 --> Router Class Initialized
INFO - 2016-08-10 13:08:12 --> Output Class Initialized
INFO - 2016-08-10 13:08:12 --> Security Class Initialized
DEBUG - 2016-08-10 13:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 13:08:12 --> Input Class Initialized
INFO - 2016-08-10 13:08:12 --> Language Class Initialized
INFO - 2016-08-10 13:08:12 --> Loader Class Initialized
INFO - 2016-08-10 13:08:12 --> Helper loaded: url_helper
INFO - 2016-08-10 13:08:12 --> Helper loaded: date_helper
INFO - 2016-08-10 13:08:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 13:08:13 --> Database Driver Class Initialized
INFO - 2016-08-10 13:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 13:08:13 --> Email Class Initialized
INFO - 2016-08-10 13:08:13 --> Model Class Initialized
INFO - 2016-08-10 13:08:13 --> Controller Class Initialized
DEBUG - 2016-08-10 13:08:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 13:08:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:08:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 13:08:13 --> Helper loaded: cookie_helper
INFO - 2016-08-10 13:08:13 --> Helper loaded: language_helper
DEBUG - 2016-08-10 13:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 13:08:13 --> Model Class Initialized
INFO - 2016-08-10 13:08:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 13:08:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 13:08:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 13:08:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 13:08:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 13:08:13 --> Final output sent to browser
DEBUG - 2016-08-10 13:08:13 --> Total execution time: 0.6471
INFO - 2016-08-10 15:34:56 --> Config Class Initialized
INFO - 2016-08-10 15:34:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:34:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:34:57 --> Utf8 Class Initialized
INFO - 2016-08-10 15:34:57 --> URI Class Initialized
INFO - 2016-08-10 15:34:57 --> Router Class Initialized
INFO - 2016-08-10 15:34:57 --> Output Class Initialized
INFO - 2016-08-10 15:34:57 --> Security Class Initialized
DEBUG - 2016-08-10 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:34:57 --> Input Class Initialized
INFO - 2016-08-10 15:34:57 --> Language Class Initialized
INFO - 2016-08-10 15:34:57 --> Loader Class Initialized
INFO - 2016-08-10 15:34:57 --> Helper loaded: url_helper
INFO - 2016-08-10 15:34:57 --> Helper loaded: date_helper
INFO - 2016-08-10 15:34:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:34:58 --> Database Driver Class Initialized
INFO - 2016-08-10 15:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:34:58 --> Email Class Initialized
INFO - 2016-08-10 15:34:58 --> Model Class Initialized
INFO - 2016-08-10 15:34:58 --> Controller Class Initialized
DEBUG - 2016-08-10 15:34:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:34:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:34:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:34:58 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:34:58 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:34:58 --> Model Class Initialized
INFO - 2016-08-10 15:34:58 --> Config Class Initialized
INFO - 2016-08-10 15:34:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:34:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:34:58 --> Utf8 Class Initialized
INFO - 2016-08-10 15:34:58 --> URI Class Initialized
INFO - 2016-08-10 15:34:58 --> Router Class Initialized
INFO - 2016-08-10 15:34:58 --> Output Class Initialized
INFO - 2016-08-10 15:34:58 --> Security Class Initialized
DEBUG - 2016-08-10 15:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:34:58 --> Input Class Initialized
INFO - 2016-08-10 15:34:59 --> Language Class Initialized
INFO - 2016-08-10 15:34:59 --> Loader Class Initialized
INFO - 2016-08-10 15:34:59 --> Helper loaded: url_helper
INFO - 2016-08-10 15:34:59 --> Helper loaded: date_helper
INFO - 2016-08-10 15:34:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:34:59 --> Database Driver Class Initialized
INFO - 2016-08-10 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:34:59 --> Email Class Initialized
INFO - 2016-08-10 15:34:59 --> Model Class Initialized
INFO - 2016-08-10 15:34:59 --> Controller Class Initialized
DEBUG - 2016-08-10 15:34:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:34:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:34:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:34:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:34:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:34:59 --> Model Class Initialized
INFO - 2016-08-10 15:34:59 --> Helper loaded: form_helper
INFO - 2016-08-10 15:34:59 --> Form Validation Class Initialized
INFO - 2016-08-10 15:34:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 15:34:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-10 15:34:59 --> Final output sent to browser
DEBUG - 2016-08-10 15:34:59 --> Total execution time: 0.8394
INFO - 2016-08-10 15:35:09 --> Config Class Initialized
INFO - 2016-08-10 15:35:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:35:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:35:09 --> Utf8 Class Initialized
INFO - 2016-08-10 15:35:09 --> URI Class Initialized
INFO - 2016-08-10 15:35:09 --> Router Class Initialized
INFO - 2016-08-10 15:35:09 --> Output Class Initialized
INFO - 2016-08-10 15:35:09 --> Security Class Initialized
DEBUG - 2016-08-10 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:35:09 --> Input Class Initialized
INFO - 2016-08-10 15:35:09 --> Language Class Initialized
INFO - 2016-08-10 15:35:09 --> Loader Class Initialized
INFO - 2016-08-10 15:35:09 --> Helper loaded: url_helper
INFO - 2016-08-10 15:35:09 --> Helper loaded: date_helper
INFO - 2016-08-10 15:35:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:35:09 --> Database Driver Class Initialized
INFO - 2016-08-10 15:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:35:09 --> Email Class Initialized
INFO - 2016-08-10 15:35:09 --> Model Class Initialized
INFO - 2016-08-10 15:35:09 --> Controller Class Initialized
DEBUG - 2016-08-10 15:35:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:35:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:35:09 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:35:09 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:09 --> Model Class Initialized
INFO - 2016-08-10 15:35:10 --> Helper loaded: form_helper
INFO - 2016-08-10 15:35:10 --> Form Validation Class Initialized
INFO - 2016-08-10 15:35:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 15:35:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 15:35:10 --> Config Class Initialized
INFO - 2016-08-10 15:35:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:35:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:35:10 --> Utf8 Class Initialized
INFO - 2016-08-10 15:35:10 --> URI Class Initialized
INFO - 2016-08-10 15:35:10 --> Router Class Initialized
INFO - 2016-08-10 15:35:10 --> Output Class Initialized
INFO - 2016-08-10 15:35:10 --> Security Class Initialized
DEBUG - 2016-08-10 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:35:10 --> Input Class Initialized
INFO - 2016-08-10 15:35:10 --> Language Class Initialized
INFO - 2016-08-10 15:35:10 --> Loader Class Initialized
INFO - 2016-08-10 15:35:10 --> Helper loaded: url_helper
INFO - 2016-08-10 15:35:10 --> Helper loaded: date_helper
INFO - 2016-08-10 15:35:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:35:10 --> Database Driver Class Initialized
INFO - 2016-08-10 15:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:35:10 --> Email Class Initialized
INFO - 2016-08-10 15:35:10 --> Model Class Initialized
INFO - 2016-08-10 15:35:10 --> Controller Class Initialized
DEBUG - 2016-08-10 15:35:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:35:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:35:10 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:35:10 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:10 --> Model Class Initialized
INFO - 2016-08-10 15:35:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-10 15:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:35:11 --> Final output sent to browser
DEBUG - 2016-08-10 15:35:11 --> Total execution time: 0.7290
INFO - 2016-08-10 15:35:17 --> Config Class Initialized
INFO - 2016-08-10 15:35:17 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:35:17 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:35:17 --> Utf8 Class Initialized
INFO - 2016-08-10 15:35:17 --> URI Class Initialized
INFO - 2016-08-10 15:35:17 --> Router Class Initialized
INFO - 2016-08-10 15:35:17 --> Output Class Initialized
INFO - 2016-08-10 15:35:17 --> Security Class Initialized
DEBUG - 2016-08-10 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:35:17 --> Input Class Initialized
INFO - 2016-08-10 15:35:17 --> Language Class Initialized
INFO - 2016-08-10 15:35:17 --> Loader Class Initialized
INFO - 2016-08-10 15:35:17 --> Helper loaded: url_helper
INFO - 2016-08-10 15:35:17 --> Helper loaded: date_helper
INFO - 2016-08-10 15:35:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:35:17 --> Database Driver Class Initialized
INFO - 2016-08-10 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:35:17 --> Email Class Initialized
INFO - 2016-08-10 15:35:17 --> Model Class Initialized
INFO - 2016-08-10 15:35:17 --> Controller Class Initialized
DEBUG - 2016-08-10 15:35:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:35:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:35:17 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:35:17 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:35:17 --> Model Class Initialized
INFO - 2016-08-10 15:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:35:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:35:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:35:18 --> Final output sent to browser
DEBUG - 2016-08-10 15:35:18 --> Total execution time: 0.7166
INFO - 2016-08-10 15:37:30 --> Config Class Initialized
INFO - 2016-08-10 15:37:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:37:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:37:30 --> Utf8 Class Initialized
INFO - 2016-08-10 15:37:30 --> URI Class Initialized
INFO - 2016-08-10 15:37:30 --> Router Class Initialized
INFO - 2016-08-10 15:37:30 --> Output Class Initialized
INFO - 2016-08-10 15:37:30 --> Security Class Initialized
DEBUG - 2016-08-10 15:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:37:30 --> Input Class Initialized
INFO - 2016-08-10 15:37:30 --> Language Class Initialized
INFO - 2016-08-10 15:37:30 --> Loader Class Initialized
INFO - 2016-08-10 15:37:30 --> Helper loaded: url_helper
INFO - 2016-08-10 15:37:30 --> Helper loaded: date_helper
INFO - 2016-08-10 15:37:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:37:30 --> Database Driver Class Initialized
INFO - 2016-08-10 15:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:37:30 --> Email Class Initialized
INFO - 2016-08-10 15:37:30 --> Model Class Initialized
INFO - 2016-08-10 15:37:30 --> Controller Class Initialized
DEBUG - 2016-08-10 15:37:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:37:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:37:31 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:37:31 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:31 --> Model Class Initialized
INFO - 2016-08-10 15:37:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:37:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:37:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:37:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 15:37:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:37:31 --> Final output sent to browser
DEBUG - 2016-08-10 15:37:31 --> Total execution time: 0.6469
INFO - 2016-08-10 15:37:39 --> Config Class Initialized
INFO - 2016-08-10 15:37:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:37:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:37:39 --> Utf8 Class Initialized
INFO - 2016-08-10 15:37:39 --> URI Class Initialized
INFO - 2016-08-10 15:37:39 --> Router Class Initialized
INFO - 2016-08-10 15:37:39 --> Output Class Initialized
INFO - 2016-08-10 15:37:39 --> Security Class Initialized
DEBUG - 2016-08-10 15:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:37:39 --> Input Class Initialized
INFO - 2016-08-10 15:37:39 --> Language Class Initialized
INFO - 2016-08-10 15:37:39 --> Loader Class Initialized
INFO - 2016-08-10 15:37:39 --> Helper loaded: url_helper
INFO - 2016-08-10 15:37:39 --> Helper loaded: date_helper
INFO - 2016-08-10 15:37:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:37:39 --> Database Driver Class Initialized
INFO - 2016-08-10 15:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:37:39 --> Email Class Initialized
INFO - 2016-08-10 15:37:39 --> Model Class Initialized
INFO - 2016-08-10 15:37:39 --> Controller Class Initialized
DEBUG - 2016-08-10 15:37:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:37:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:37:39 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:37:39 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:39 --> Model Class Initialized
INFO - 2016-08-10 15:37:39 --> Upload Class Initialized
INFO - 2016-08-10 15:37:40 --> Helper loaded: file_helper
INFO - 2016-08-10 15:37:40 --> Config Class Initialized
INFO - 2016-08-10 15:37:40 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:37:40 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:37:40 --> Utf8 Class Initialized
INFO - 2016-08-10 15:37:40 --> URI Class Initialized
INFO - 2016-08-10 15:37:40 --> Router Class Initialized
INFO - 2016-08-10 15:37:40 --> Output Class Initialized
INFO - 2016-08-10 15:37:40 --> Security Class Initialized
DEBUG - 2016-08-10 15:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:37:40 --> Input Class Initialized
INFO - 2016-08-10 15:37:40 --> Language Class Initialized
INFO - 2016-08-10 15:37:40 --> Loader Class Initialized
INFO - 2016-08-10 15:37:40 --> Helper loaded: url_helper
INFO - 2016-08-10 15:37:40 --> Helper loaded: date_helper
INFO - 2016-08-10 15:37:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:37:40 --> Database Driver Class Initialized
INFO - 2016-08-10 15:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:37:40 --> Email Class Initialized
INFO - 2016-08-10 15:37:40 --> Model Class Initialized
INFO - 2016-08-10 15:37:40 --> Controller Class Initialized
DEBUG - 2016-08-10 15:37:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:37:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:37:40 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:37:40 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:37:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:40 --> Model Class Initialized
INFO - 2016-08-10 15:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:37:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:37:40 --> Final output sent to browser
DEBUG - 2016-08-10 15:37:40 --> Total execution time: 0.6477
INFO - 2016-08-10 15:37:42 --> Config Class Initialized
INFO - 2016-08-10 15:37:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:37:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:37:42 --> Utf8 Class Initialized
INFO - 2016-08-10 15:37:43 --> URI Class Initialized
INFO - 2016-08-10 15:37:43 --> Router Class Initialized
INFO - 2016-08-10 15:37:43 --> Output Class Initialized
INFO - 2016-08-10 15:37:43 --> Security Class Initialized
DEBUG - 2016-08-10 15:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:37:43 --> Input Class Initialized
INFO - 2016-08-10 15:37:43 --> Language Class Initialized
INFO - 2016-08-10 15:37:43 --> Loader Class Initialized
INFO - 2016-08-10 15:37:43 --> Helper loaded: url_helper
INFO - 2016-08-10 15:37:43 --> Helper loaded: date_helper
INFO - 2016-08-10 15:37:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:37:43 --> Database Driver Class Initialized
INFO - 2016-08-10 15:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:37:43 --> Email Class Initialized
INFO - 2016-08-10 15:37:43 --> Model Class Initialized
INFO - 2016-08-10 15:37:43 --> Controller Class Initialized
DEBUG - 2016-08-10 15:37:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:37:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:37:43 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:37:43 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:37:43 --> Model Class Initialized
INFO - 2016-08-10 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-10 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:37:43 --> Final output sent to browser
DEBUG - 2016-08-10 15:37:43 --> Total execution time: 0.6652
INFO - 2016-08-10 15:38:25 --> Config Class Initialized
INFO - 2016-08-10 15:38:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:38:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:38:25 --> Utf8 Class Initialized
INFO - 2016-08-10 15:38:25 --> URI Class Initialized
INFO - 2016-08-10 15:38:26 --> Router Class Initialized
INFO - 2016-08-10 15:38:26 --> Output Class Initialized
INFO - 2016-08-10 15:38:26 --> Security Class Initialized
DEBUG - 2016-08-10 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:38:26 --> Input Class Initialized
INFO - 2016-08-10 15:38:26 --> Language Class Initialized
INFO - 2016-08-10 15:38:26 --> Loader Class Initialized
INFO - 2016-08-10 15:38:26 --> Helper loaded: url_helper
INFO - 2016-08-10 15:38:26 --> Helper loaded: date_helper
INFO - 2016-08-10 15:38:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:38:26 --> Database Driver Class Initialized
INFO - 2016-08-10 15:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:38:26 --> Email Class Initialized
INFO - 2016-08-10 15:38:26 --> Model Class Initialized
INFO - 2016-08-10 15:38:26 --> Controller Class Initialized
DEBUG - 2016-08-10 15:38:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:38:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:38:26 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:38:26 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:26 --> Model Class Initialized
INFO - 2016-08-10 15:38:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:38:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:38:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:38:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:38:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:38:26 --> Final output sent to browser
DEBUG - 2016-08-10 15:38:26 --> Total execution time: 0.6689
INFO - 2016-08-10 15:38:31 --> Config Class Initialized
INFO - 2016-08-10 15:38:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:38:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:38:31 --> Utf8 Class Initialized
INFO - 2016-08-10 15:38:31 --> URI Class Initialized
INFO - 2016-08-10 15:38:31 --> Router Class Initialized
INFO - 2016-08-10 15:38:31 --> Output Class Initialized
INFO - 2016-08-10 15:38:31 --> Security Class Initialized
DEBUG - 2016-08-10 15:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:38:31 --> Input Class Initialized
INFO - 2016-08-10 15:38:31 --> Language Class Initialized
INFO - 2016-08-10 15:38:31 --> Loader Class Initialized
INFO - 2016-08-10 15:38:31 --> Helper loaded: url_helper
INFO - 2016-08-10 15:38:31 --> Helper loaded: date_helper
INFO - 2016-08-10 15:38:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:38:31 --> Database Driver Class Initialized
INFO - 2016-08-10 15:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:38:32 --> Email Class Initialized
INFO - 2016-08-10 15:38:32 --> Model Class Initialized
INFO - 2016-08-10 15:38:32 --> Controller Class Initialized
DEBUG - 2016-08-10 15:38:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:38:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:38:32 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:38:32 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:32 --> Model Class Initialized
INFO - 2016-08-10 15:38:32 --> Helper loaded: file_helper
INFO - 2016-08-10 15:38:32 --> Config Class Initialized
INFO - 2016-08-10 15:38:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:38:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:38:32 --> Utf8 Class Initialized
INFO - 2016-08-10 15:38:32 --> URI Class Initialized
INFO - 2016-08-10 15:38:32 --> Router Class Initialized
INFO - 2016-08-10 15:38:32 --> Output Class Initialized
INFO - 2016-08-10 15:38:32 --> Security Class Initialized
DEBUG - 2016-08-10 15:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:38:32 --> Input Class Initialized
INFO - 2016-08-10 15:38:32 --> Language Class Initialized
INFO - 2016-08-10 15:38:32 --> Loader Class Initialized
INFO - 2016-08-10 15:38:32 --> Helper loaded: url_helper
INFO - 2016-08-10 15:38:32 --> Helper loaded: date_helper
INFO - 2016-08-10 15:38:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:38:32 --> Database Driver Class Initialized
INFO - 2016-08-10 15:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:38:32 --> Email Class Initialized
INFO - 2016-08-10 15:38:32 --> Model Class Initialized
INFO - 2016-08-10 15:38:32 --> Controller Class Initialized
DEBUG - 2016-08-10 15:38:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:38:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:38:32 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:38:32 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:32 --> Model Class Initialized
INFO - 2016-08-10 15:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:38:33 --> Final output sent to browser
DEBUG - 2016-08-10 15:38:33 --> Total execution time: 0.6546
INFO - 2016-08-10 15:38:33 --> Config Class Initialized
INFO - 2016-08-10 15:38:33 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:38:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:38:33 --> Utf8 Class Initialized
INFO - 2016-08-10 15:38:33 --> URI Class Initialized
INFO - 2016-08-10 15:38:33 --> Router Class Initialized
INFO - 2016-08-10 15:38:33 --> Output Class Initialized
INFO - 2016-08-10 15:38:33 --> Security Class Initialized
DEBUG - 2016-08-10 15:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:38:33 --> Input Class Initialized
INFO - 2016-08-10 15:38:33 --> Language Class Initialized
INFO - 2016-08-10 15:38:33 --> Loader Class Initialized
INFO - 2016-08-10 15:38:33 --> Helper loaded: url_helper
INFO - 2016-08-10 15:38:33 --> Helper loaded: date_helper
INFO - 2016-08-10 15:38:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:38:33 --> Database Driver Class Initialized
INFO - 2016-08-10 15:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:38:33 --> Email Class Initialized
INFO - 2016-08-10 15:38:33 --> Model Class Initialized
INFO - 2016-08-10 15:38:33 --> Controller Class Initialized
DEBUG - 2016-08-10 15:38:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:38:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:38:33 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:38:33 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:38:33 --> Model Class Initialized
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:38:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:38:33 --> Final output sent to browser
DEBUG - 2016-08-10 15:38:33 --> Total execution time: 0.7015
INFO - 2016-08-10 15:50:22 --> Config Class Initialized
INFO - 2016-08-10 15:50:22 --> Hooks Class Initialized
DEBUG - 2016-08-10 15:50:22 --> UTF-8 Support Enabled
INFO - 2016-08-10 15:50:22 --> Utf8 Class Initialized
INFO - 2016-08-10 15:50:22 --> URI Class Initialized
INFO - 2016-08-10 15:50:22 --> Router Class Initialized
INFO - 2016-08-10 15:50:22 --> Output Class Initialized
INFO - 2016-08-10 15:50:22 --> Security Class Initialized
DEBUG - 2016-08-10 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 15:50:22 --> Input Class Initialized
INFO - 2016-08-10 15:50:22 --> Language Class Initialized
INFO - 2016-08-10 15:50:22 --> Loader Class Initialized
INFO - 2016-08-10 15:50:22 --> Helper loaded: url_helper
INFO - 2016-08-10 15:50:23 --> Helper loaded: date_helper
INFO - 2016-08-10 15:50:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 15:50:23 --> Database Driver Class Initialized
INFO - 2016-08-10 15:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 15:50:23 --> Email Class Initialized
INFO - 2016-08-10 15:50:23 --> Model Class Initialized
INFO - 2016-08-10 15:50:23 --> Controller Class Initialized
DEBUG - 2016-08-10 15:50:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 15:50:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:50:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 15:50:23 --> Helper loaded: cookie_helper
INFO - 2016-08-10 15:50:23 --> Helper loaded: language_helper
DEBUG - 2016-08-10 15:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 15:50:23 --> Model Class Initialized
INFO - 2016-08-10 15:50:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 15:50:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 15:50:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 15:50:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 15:50:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 15:50:23 --> Final output sent to browser
DEBUG - 2016-08-10 15:50:23 --> Total execution time: 1.1282
INFO - 2016-08-10 16:11:06 --> Config Class Initialized
INFO - 2016-08-10 16:11:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 16:11:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 16:11:07 --> Utf8 Class Initialized
INFO - 2016-08-10 16:11:07 --> URI Class Initialized
INFO - 2016-08-10 16:11:07 --> Router Class Initialized
INFO - 2016-08-10 16:11:07 --> Output Class Initialized
INFO - 2016-08-10 16:11:07 --> Security Class Initialized
DEBUG - 2016-08-10 16:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 16:11:07 --> Input Class Initialized
INFO - 2016-08-10 16:11:07 --> Language Class Initialized
INFO - 2016-08-10 16:11:07 --> Loader Class Initialized
INFO - 2016-08-10 16:11:07 --> Helper loaded: url_helper
INFO - 2016-08-10 16:11:07 --> Helper loaded: date_helper
INFO - 2016-08-10 16:11:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 16:11:07 --> Database Driver Class Initialized
INFO - 2016-08-10 16:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 16:11:07 --> Email Class Initialized
INFO - 2016-08-10 16:11:07 --> Model Class Initialized
INFO - 2016-08-10 16:11:07 --> Controller Class Initialized
DEBUG - 2016-08-10 16:11:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 16:11:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:11:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 16:11:07 --> Helper loaded: cookie_helper
INFO - 2016-08-10 16:11:07 --> Helper loaded: language_helper
DEBUG - 2016-08-10 16:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:11:07 --> Model Class Initialized
INFO - 2016-08-10 16:11:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 16:11:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 16:11:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 16:11:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 16:11:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 16:11:07 --> Final output sent to browser
DEBUG - 2016-08-10 16:11:07 --> Total execution time: 1.1620
INFO - 2016-08-10 16:13:52 --> Config Class Initialized
INFO - 2016-08-10 16:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-10 16:13:52 --> UTF-8 Support Enabled
INFO - 2016-08-10 16:13:52 --> Utf8 Class Initialized
INFO - 2016-08-10 16:13:52 --> URI Class Initialized
INFO - 2016-08-10 16:13:52 --> Router Class Initialized
INFO - 2016-08-10 16:13:52 --> Output Class Initialized
INFO - 2016-08-10 16:13:52 --> Security Class Initialized
DEBUG - 2016-08-10 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 16:13:52 --> Input Class Initialized
INFO - 2016-08-10 16:13:52 --> Language Class Initialized
INFO - 2016-08-10 16:13:52 --> Loader Class Initialized
INFO - 2016-08-10 16:13:52 --> Helper loaded: url_helper
INFO - 2016-08-10 16:13:52 --> Helper loaded: date_helper
INFO - 2016-08-10 16:13:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 16:13:52 --> Database Driver Class Initialized
INFO - 2016-08-10 16:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 16:13:52 --> Email Class Initialized
INFO - 2016-08-10 16:13:53 --> Model Class Initialized
INFO - 2016-08-10 16:13:53 --> Controller Class Initialized
DEBUG - 2016-08-10 16:13:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 16:13:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:13:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 16:13:53 --> Helper loaded: cookie_helper
INFO - 2016-08-10 16:13:53 --> Helper loaded: language_helper
DEBUG - 2016-08-10 16:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:13:53 --> Model Class Initialized
INFO - 2016-08-10 16:13:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 16:13:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 16:13:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 16:13:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-10 16:13:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 16:13:53 --> Final output sent to browser
DEBUG - 2016-08-10 16:13:53 --> Total execution time: 0.7044
INFO - 2016-08-10 16:13:56 --> Config Class Initialized
INFO - 2016-08-10 16:13:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 16:13:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 16:13:56 --> Utf8 Class Initialized
INFO - 2016-08-10 16:13:56 --> URI Class Initialized
INFO - 2016-08-10 16:13:56 --> Router Class Initialized
INFO - 2016-08-10 16:13:57 --> Output Class Initialized
INFO - 2016-08-10 16:13:57 --> Security Class Initialized
DEBUG - 2016-08-10 16:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 16:13:57 --> Input Class Initialized
INFO - 2016-08-10 16:13:57 --> Language Class Initialized
INFO - 2016-08-10 16:13:57 --> Loader Class Initialized
INFO - 2016-08-10 16:13:57 --> Helper loaded: url_helper
INFO - 2016-08-10 16:13:57 --> Helper loaded: date_helper
INFO - 2016-08-10 16:13:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 16:13:57 --> Database Driver Class Initialized
INFO - 2016-08-10 16:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 16:13:57 --> Email Class Initialized
INFO - 2016-08-10 16:13:57 --> Model Class Initialized
INFO - 2016-08-10 16:13:57 --> Controller Class Initialized
DEBUG - 2016-08-10 16:13:57 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 16:13:57 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:13:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 16:13:57 --> Helper loaded: cookie_helper
INFO - 2016-08-10 16:13:57 --> Helper loaded: language_helper
DEBUG - 2016-08-10 16:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:13:57 --> Model Class Initialized
INFO - 2016-08-10 16:13:57 --> Final output sent to browser
DEBUG - 2016-08-10 16:13:57 --> Total execution time: 0.5788
INFO - 2016-08-10 16:18:56 --> Config Class Initialized
INFO - 2016-08-10 16:18:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 16:18:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 16:18:56 --> Utf8 Class Initialized
INFO - 2016-08-10 16:18:56 --> URI Class Initialized
INFO - 2016-08-10 16:18:56 --> Router Class Initialized
INFO - 2016-08-10 16:18:56 --> Output Class Initialized
INFO - 2016-08-10 16:18:56 --> Security Class Initialized
DEBUG - 2016-08-10 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 16:18:56 --> Input Class Initialized
INFO - 2016-08-10 16:18:56 --> Language Class Initialized
INFO - 2016-08-10 16:18:56 --> Loader Class Initialized
INFO - 2016-08-10 16:18:56 --> Helper loaded: url_helper
INFO - 2016-08-10 16:18:56 --> Helper loaded: date_helper
INFO - 2016-08-10 16:18:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 16:18:56 --> Database Driver Class Initialized
INFO - 2016-08-10 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 16:18:56 --> Email Class Initialized
INFO - 2016-08-10 16:18:56 --> Model Class Initialized
INFO - 2016-08-10 16:18:56 --> Controller Class Initialized
DEBUG - 2016-08-10 16:18:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 16:18:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:18:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 16:18:56 --> Helper loaded: cookie_helper
INFO - 2016-08-10 16:18:56 --> Helper loaded: language_helper
DEBUG - 2016-08-10 16:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:18:56 --> Model Class Initialized
INFO - 2016-08-10 16:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 16:18:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 16:18:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-10 16:18:57 --> Severity: Notice --> Undefined variable: user D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\view_kategori.php 43
ERROR - 2016-08-10 16:18:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\view_kategori.php 43
INFO - 2016-08-10 16:18:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-10 16:18:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 16:18:57 --> Final output sent to browser
DEBUG - 2016-08-10 16:18:57 --> Total execution time: 0.8527
INFO - 2016-08-10 16:20:58 --> Config Class Initialized
INFO - 2016-08-10 16:20:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 16:20:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 16:20:58 --> Utf8 Class Initialized
INFO - 2016-08-10 16:20:58 --> URI Class Initialized
INFO - 2016-08-10 16:20:58 --> Router Class Initialized
INFO - 2016-08-10 16:20:58 --> Output Class Initialized
INFO - 2016-08-10 16:20:58 --> Security Class Initialized
DEBUG - 2016-08-10 16:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 16:20:58 --> Input Class Initialized
INFO - 2016-08-10 16:20:58 --> Language Class Initialized
INFO - 2016-08-10 16:20:58 --> Loader Class Initialized
INFO - 2016-08-10 16:20:58 --> Helper loaded: url_helper
INFO - 2016-08-10 16:20:58 --> Helper loaded: date_helper
INFO - 2016-08-10 16:20:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 16:20:58 --> Database Driver Class Initialized
INFO - 2016-08-10 16:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 16:20:58 --> Email Class Initialized
INFO - 2016-08-10 16:20:58 --> Model Class Initialized
INFO - 2016-08-10 16:20:58 --> Controller Class Initialized
DEBUG - 2016-08-10 16:20:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 16:20:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:20:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 16:20:59 --> Helper loaded: cookie_helper
INFO - 2016-08-10 16:20:59 --> Helper loaded: language_helper
DEBUG - 2016-08-10 16:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 16:20:59 --> Model Class Initialized
INFO - 2016-08-10 16:20:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 16:20:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 16:20:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 16:20:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-10 16:20:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 16:20:59 --> Final output sent to browser
DEBUG - 2016-08-10 16:20:59 --> Total execution time: 0.7397
INFO - 2016-08-10 23:36:23 --> Config Class Initialized
INFO - 2016-08-10 23:36:23 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:36:23 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:36:23 --> Utf8 Class Initialized
INFO - 2016-08-10 23:36:23 --> URI Class Initialized
INFO - 2016-08-10 23:36:23 --> Router Class Initialized
INFO - 2016-08-10 23:36:23 --> Output Class Initialized
INFO - 2016-08-10 23:36:23 --> Security Class Initialized
DEBUG - 2016-08-10 23:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:36:24 --> Input Class Initialized
INFO - 2016-08-10 23:36:24 --> Language Class Initialized
INFO - 2016-08-10 23:36:24 --> Loader Class Initialized
INFO - 2016-08-10 23:36:24 --> Helper loaded: url_helper
INFO - 2016-08-10 23:36:24 --> Helper loaded: date_helper
INFO - 2016-08-10 23:36:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:36:24 --> Database Driver Class Initialized
INFO - 2016-08-10 23:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:36:24 --> Email Class Initialized
INFO - 2016-08-10 23:36:24 --> Model Class Initialized
INFO - 2016-08-10 23:36:24 --> Controller Class Initialized
DEBUG - 2016-08-10 23:36:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:36:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:36:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:36:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:25 --> Model Class Initialized
INFO - 2016-08-10 23:36:25 --> Config Class Initialized
INFO - 2016-08-10 23:36:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:36:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:36:25 --> Utf8 Class Initialized
INFO - 2016-08-10 23:36:25 --> URI Class Initialized
INFO - 2016-08-10 23:36:25 --> Router Class Initialized
INFO - 2016-08-10 23:36:25 --> Output Class Initialized
INFO - 2016-08-10 23:36:25 --> Security Class Initialized
DEBUG - 2016-08-10 23:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:36:25 --> Input Class Initialized
INFO - 2016-08-10 23:36:25 --> Language Class Initialized
INFO - 2016-08-10 23:36:25 --> Loader Class Initialized
INFO - 2016-08-10 23:36:25 --> Helper loaded: url_helper
INFO - 2016-08-10 23:36:25 --> Helper loaded: date_helper
INFO - 2016-08-10 23:36:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:36:25 --> Database Driver Class Initialized
INFO - 2016-08-10 23:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:36:25 --> Email Class Initialized
INFO - 2016-08-10 23:36:25 --> Model Class Initialized
INFO - 2016-08-10 23:36:25 --> Controller Class Initialized
DEBUG - 2016-08-10 23:36:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:36:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:36:25 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:36:25 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:25 --> Model Class Initialized
INFO - 2016-08-10 23:36:25 --> Helper loaded: form_helper
INFO - 2016-08-10 23:36:25 --> Form Validation Class Initialized
INFO - 2016-08-10 23:36:25 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 23:36:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-10 23:36:25 --> Final output sent to browser
DEBUG - 2016-08-10 23:36:25 --> Total execution time: 0.8736
INFO - 2016-08-10 23:36:47 --> Config Class Initialized
INFO - 2016-08-10 23:36:47 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:36:47 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:36:47 --> Utf8 Class Initialized
INFO - 2016-08-10 23:36:47 --> URI Class Initialized
INFO - 2016-08-10 23:36:47 --> Router Class Initialized
INFO - 2016-08-10 23:36:47 --> Output Class Initialized
INFO - 2016-08-10 23:36:47 --> Security Class Initialized
DEBUG - 2016-08-10 23:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:36:47 --> Input Class Initialized
INFO - 2016-08-10 23:36:47 --> Language Class Initialized
INFO - 2016-08-10 23:36:47 --> Loader Class Initialized
INFO - 2016-08-10 23:36:47 --> Helper loaded: url_helper
INFO - 2016-08-10 23:36:47 --> Helper loaded: date_helper
INFO - 2016-08-10 23:36:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:36:47 --> Database Driver Class Initialized
INFO - 2016-08-10 23:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:36:47 --> Email Class Initialized
INFO - 2016-08-10 23:36:47 --> Model Class Initialized
INFO - 2016-08-10 23:36:47 --> Controller Class Initialized
DEBUG - 2016-08-10 23:36:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:36:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:36:47 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:36:47 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:47 --> Model Class Initialized
INFO - 2016-08-10 23:36:47 --> Helper loaded: form_helper
INFO - 2016-08-10 23:36:47 --> Form Validation Class Initialized
INFO - 2016-08-10 23:36:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-10 23:36:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 23:36:47 --> Config Class Initialized
INFO - 2016-08-10 23:36:47 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:36:48 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:36:48 --> Utf8 Class Initialized
INFO - 2016-08-10 23:36:48 --> URI Class Initialized
INFO - 2016-08-10 23:36:48 --> Router Class Initialized
INFO - 2016-08-10 23:36:48 --> Output Class Initialized
INFO - 2016-08-10 23:36:48 --> Security Class Initialized
DEBUG - 2016-08-10 23:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:36:48 --> Input Class Initialized
INFO - 2016-08-10 23:36:48 --> Language Class Initialized
INFO - 2016-08-10 23:36:48 --> Loader Class Initialized
INFO - 2016-08-10 23:36:48 --> Helper loaded: url_helper
INFO - 2016-08-10 23:36:48 --> Helper loaded: date_helper
INFO - 2016-08-10 23:36:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:36:48 --> Database Driver Class Initialized
INFO - 2016-08-10 23:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:36:48 --> Email Class Initialized
INFO - 2016-08-10 23:36:48 --> Model Class Initialized
INFO - 2016-08-10 23:36:48 --> Controller Class Initialized
DEBUG - 2016-08-10 23:36:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:36:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:36:48 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:36:48 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:36:48 --> Model Class Initialized
INFO - 2016-08-10 23:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-10 23:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:36:48 --> Final output sent to browser
DEBUG - 2016-08-10 23:36:48 --> Total execution time: 0.7459
INFO - 2016-08-10 23:37:24 --> Config Class Initialized
INFO - 2016-08-10 23:37:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:37:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:37:24 --> Utf8 Class Initialized
INFO - 2016-08-10 23:37:24 --> URI Class Initialized
INFO - 2016-08-10 23:37:24 --> Router Class Initialized
INFO - 2016-08-10 23:37:24 --> Output Class Initialized
INFO - 2016-08-10 23:37:24 --> Security Class Initialized
DEBUG - 2016-08-10 23:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:37:24 --> Input Class Initialized
INFO - 2016-08-10 23:37:24 --> Language Class Initialized
INFO - 2016-08-10 23:37:24 --> Loader Class Initialized
INFO - 2016-08-10 23:37:24 --> Helper loaded: url_helper
INFO - 2016-08-10 23:37:24 --> Helper loaded: date_helper
INFO - 2016-08-10 23:37:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:37:24 --> Database Driver Class Initialized
INFO - 2016-08-10 23:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:37:24 --> Email Class Initialized
INFO - 2016-08-10 23:37:24 --> Model Class Initialized
INFO - 2016-08-10 23:37:24 --> Controller Class Initialized
DEBUG - 2016-08-10 23:37:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:37:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:37:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:37:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:37:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:37:24 --> Model Class Initialized
INFO - 2016-08-10 23:37:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:37:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:37:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:37:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-10 23:37:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:37:24 --> Final output sent to browser
DEBUG - 2016-08-10 23:37:24 --> Total execution time: 0.7817
INFO - 2016-08-10 23:57:16 --> Config Class Initialized
INFO - 2016-08-10 23:57:16 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:57:16 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:57:16 --> Utf8 Class Initialized
INFO - 2016-08-10 23:57:16 --> URI Class Initialized
INFO - 2016-08-10 23:57:16 --> Router Class Initialized
INFO - 2016-08-10 23:57:16 --> Output Class Initialized
INFO - 2016-08-10 23:57:16 --> Security Class Initialized
DEBUG - 2016-08-10 23:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:57:16 --> Input Class Initialized
INFO - 2016-08-10 23:57:16 --> Language Class Initialized
INFO - 2016-08-10 23:57:16 --> Loader Class Initialized
INFO - 2016-08-10 23:57:16 --> Helper loaded: url_helper
INFO - 2016-08-10 23:57:16 --> Helper loaded: date_helper
INFO - 2016-08-10 23:57:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:57:16 --> Database Driver Class Initialized
INFO - 2016-08-10 23:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:57:16 --> Email Class Initialized
INFO - 2016-08-10 23:57:16 --> Model Class Initialized
INFO - 2016-08-10 23:57:16 --> Controller Class Initialized
DEBUG - 2016-08-10 23:57:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:57:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:57:16 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:57:16 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:16 --> Model Class Initialized
INFO - 2016-08-10 23:57:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:57:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:57:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:57:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-10 23:57:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:57:16 --> Final output sent to browser
DEBUG - 2016-08-10 23:57:17 --> Total execution time: 0.7146
INFO - 2016-08-10 23:57:19 --> Config Class Initialized
INFO - 2016-08-10 23:57:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:57:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:57:19 --> Utf8 Class Initialized
INFO - 2016-08-10 23:57:19 --> URI Class Initialized
INFO - 2016-08-10 23:57:19 --> Router Class Initialized
INFO - 2016-08-10 23:57:19 --> Output Class Initialized
INFO - 2016-08-10 23:57:19 --> Security Class Initialized
DEBUG - 2016-08-10 23:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:57:19 --> Input Class Initialized
INFO - 2016-08-10 23:57:19 --> Language Class Initialized
INFO - 2016-08-10 23:57:19 --> Loader Class Initialized
INFO - 2016-08-10 23:57:19 --> Helper loaded: url_helper
INFO - 2016-08-10 23:57:19 --> Helper loaded: date_helper
INFO - 2016-08-10 23:57:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:57:19 --> Database Driver Class Initialized
INFO - 2016-08-10 23:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:57:19 --> Email Class Initialized
INFO - 2016-08-10 23:57:19 --> Model Class Initialized
INFO - 2016-08-10 23:57:19 --> Controller Class Initialized
DEBUG - 2016-08-10 23:57:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:57:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:57:19 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:57:19 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:20 --> Model Class Initialized
INFO - 2016-08-10 23:57:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:57:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:57:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:57:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-10 23:57:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:57:20 --> Final output sent to browser
DEBUG - 2016-08-10 23:57:20 --> Total execution time: 1.0746
INFO - 2016-08-10 23:57:23 --> Config Class Initialized
INFO - 2016-08-10 23:57:23 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:57:23 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:57:23 --> Utf8 Class Initialized
INFO - 2016-08-10 23:57:23 --> URI Class Initialized
INFO - 2016-08-10 23:57:23 --> Router Class Initialized
INFO - 2016-08-10 23:57:24 --> Output Class Initialized
INFO - 2016-08-10 23:57:24 --> Security Class Initialized
DEBUG - 2016-08-10 23:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:57:24 --> Input Class Initialized
INFO - 2016-08-10 23:57:24 --> Language Class Initialized
INFO - 2016-08-10 23:57:24 --> Loader Class Initialized
INFO - 2016-08-10 23:57:24 --> Helper loaded: url_helper
INFO - 2016-08-10 23:57:24 --> Helper loaded: date_helper
INFO - 2016-08-10 23:57:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:57:24 --> Database Driver Class Initialized
INFO - 2016-08-10 23:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:57:24 --> Email Class Initialized
INFO - 2016-08-10 23:57:24 --> Model Class Initialized
INFO - 2016-08-10 23:57:24 --> Controller Class Initialized
DEBUG - 2016-08-10 23:57:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:57:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:57:24 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:57:24 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:24 --> Model Class Initialized
INFO - 2016-08-10 23:57:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:57:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:57:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:57:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-10 23:57:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:57:24 --> Final output sent to browser
DEBUG - 2016-08-10 23:57:24 --> Total execution time: 0.7008
INFO - 2016-08-10 23:57:40 --> Config Class Initialized
INFO - 2016-08-10 23:57:40 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:57:40 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:57:40 --> Utf8 Class Initialized
INFO - 2016-08-10 23:57:40 --> URI Class Initialized
INFO - 2016-08-10 23:57:40 --> Router Class Initialized
INFO - 2016-08-10 23:57:40 --> Output Class Initialized
INFO - 2016-08-10 23:57:40 --> Security Class Initialized
DEBUG - 2016-08-10 23:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:57:40 --> Input Class Initialized
INFO - 2016-08-10 23:57:40 --> Language Class Initialized
INFO - 2016-08-10 23:57:40 --> Loader Class Initialized
INFO - 2016-08-10 23:57:40 --> Helper loaded: url_helper
INFO - 2016-08-10 23:57:40 --> Helper loaded: date_helper
INFO - 2016-08-10 23:57:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:57:40 --> Database Driver Class Initialized
INFO - 2016-08-10 23:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:57:40 --> Email Class Initialized
INFO - 2016-08-10 23:57:40 --> Model Class Initialized
INFO - 2016-08-10 23:57:40 --> Controller Class Initialized
DEBUG - 2016-08-10 23:57:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:57:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:57:40 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:57:40 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:40 --> Model Class Initialized
INFO - 2016-08-10 23:57:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:57:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:57:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:57:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-10 23:57:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:57:40 --> Final output sent to browser
DEBUG - 2016-08-10 23:57:40 --> Total execution time: 0.7007
INFO - 2016-08-10 23:57:51 --> Config Class Initialized
INFO - 2016-08-10 23:57:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 23:57:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 23:57:51 --> Utf8 Class Initialized
INFO - 2016-08-10 23:57:51 --> URI Class Initialized
INFO - 2016-08-10 23:57:51 --> Router Class Initialized
INFO - 2016-08-10 23:57:51 --> Output Class Initialized
INFO - 2016-08-10 23:57:51 --> Security Class Initialized
DEBUG - 2016-08-10 23:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 23:57:51 --> Input Class Initialized
INFO - 2016-08-10 23:57:51 --> Language Class Initialized
INFO - 2016-08-10 23:57:51 --> Loader Class Initialized
INFO - 2016-08-10 23:57:51 --> Helper loaded: url_helper
INFO - 2016-08-10 23:57:51 --> Helper loaded: date_helper
INFO - 2016-08-10 23:57:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-10 23:57:51 --> Database Driver Class Initialized
INFO - 2016-08-10 23:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 23:57:51 --> Email Class Initialized
INFO - 2016-08-10 23:57:51 --> Model Class Initialized
INFO - 2016-08-10 23:57:52 --> Controller Class Initialized
DEBUG - 2016-08-10 23:57:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-10 23:57:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-10 23:57:52 --> Helper loaded: cookie_helper
INFO - 2016-08-10 23:57:52 --> Helper loaded: language_helper
DEBUG - 2016-08-10 23:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-10 23:57:52 --> Model Class Initialized
INFO - 2016-08-10 23:57:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-10 23:57:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-10 23:57:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-10 23:57:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-10 23:57:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-10 23:57:52 --> Final output sent to browser
DEBUG - 2016-08-10 23:57:52 --> Total execution time: 0.7010
