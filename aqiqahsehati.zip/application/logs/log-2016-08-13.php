<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-13 08:35:28 --> Config Class Initialized
INFO - 2016-08-13 08:35:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:35:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:35:28 --> Utf8 Class Initialized
INFO - 2016-08-13 08:35:28 --> URI Class Initialized
INFO - 2016-08-13 08:35:28 --> Router Class Initialized
INFO - 2016-08-13 08:35:28 --> Output Class Initialized
INFO - 2016-08-13 08:35:28 --> Security Class Initialized
DEBUG - 2016-08-13 08:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:35:28 --> Input Class Initialized
INFO - 2016-08-13 08:35:28 --> Language Class Initialized
INFO - 2016-08-13 08:35:28 --> Loader Class Initialized
INFO - 2016-08-13 08:35:28 --> Helper loaded: url_helper
INFO - 2016-08-13 08:35:28 --> Helper loaded: date_helper
INFO - 2016-08-13 08:35:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 08:35:28 --> Database Driver Class Initialized
INFO - 2016-08-13 08:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:35:29 --> Email Class Initialized
INFO - 2016-08-13 08:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 08:35:29 --> Pagination Class Initialized
INFO - 2016-08-13 08:35:29 --> Model Class Initialized
INFO - 2016-08-13 08:35:29 --> Controller Class Initialized
INFO - 2016-08-13 08:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 08:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 08:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 08:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 08:35:29 --> Final output sent to browser
DEBUG - 2016-08-13 08:35:29 --> Total execution time: 1.2743
INFO - 2016-08-13 08:36:25 --> Config Class Initialized
INFO - 2016-08-13 08:36:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:36:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:36:25 --> Utf8 Class Initialized
INFO - 2016-08-13 08:36:25 --> URI Class Initialized
INFO - 2016-08-13 08:36:25 --> Router Class Initialized
INFO - 2016-08-13 08:36:25 --> Output Class Initialized
INFO - 2016-08-13 08:36:25 --> Security Class Initialized
DEBUG - 2016-08-13 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:36:25 --> Input Class Initialized
INFO - 2016-08-13 08:36:25 --> Language Class Initialized
INFO - 2016-08-13 08:36:25 --> Loader Class Initialized
INFO - 2016-08-13 08:36:25 --> Helper loaded: url_helper
INFO - 2016-08-13 08:36:25 --> Helper loaded: date_helper
INFO - 2016-08-13 08:36:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 08:36:25 --> Database Driver Class Initialized
INFO - 2016-08-13 08:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:36:25 --> Email Class Initialized
INFO - 2016-08-13 08:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 08:36:25 --> Pagination Class Initialized
INFO - 2016-08-13 08:36:25 --> Model Class Initialized
INFO - 2016-08-13 08:36:25 --> Controller Class Initialized
INFO - 2016-08-13 08:36:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 08:36:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 08:36:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 08:36:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 08:36:25 --> Final output sent to browser
DEBUG - 2016-08-13 08:36:25 --> Total execution time: 0.3232
INFO - 2016-08-13 08:36:39 --> Config Class Initialized
INFO - 2016-08-13 08:36:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:36:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:36:39 --> Utf8 Class Initialized
INFO - 2016-08-13 08:36:39 --> URI Class Initialized
INFO - 2016-08-13 08:36:39 --> Router Class Initialized
INFO - 2016-08-13 08:36:39 --> Output Class Initialized
INFO - 2016-08-13 08:36:39 --> Security Class Initialized
DEBUG - 2016-08-13 08:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:36:39 --> Input Class Initialized
INFO - 2016-08-13 08:36:39 --> Language Class Initialized
INFO - 2016-08-13 08:36:39 --> Loader Class Initialized
INFO - 2016-08-13 08:36:39 --> Helper loaded: url_helper
INFO - 2016-08-13 08:36:39 --> Helper loaded: date_helper
INFO - 2016-08-13 08:36:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 08:36:39 --> Database Driver Class Initialized
INFO - 2016-08-13 08:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:36:39 --> Email Class Initialized
INFO - 2016-08-13 08:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 08:36:39 --> Pagination Class Initialized
INFO - 2016-08-13 08:36:39 --> Model Class Initialized
INFO - 2016-08-13 08:36:39 --> Controller Class Initialized
INFO - 2016-08-13 08:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 08:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 08:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 08:36:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 08:36:39 --> Final output sent to browser
DEBUG - 2016-08-13 08:36:39 --> Total execution time: 0.2619
INFO - 2016-08-13 09:13:05 --> Config Class Initialized
INFO - 2016-08-13 09:13:05 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:13:05 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:13:05 --> Utf8 Class Initialized
INFO - 2016-08-13 09:13:05 --> URI Class Initialized
INFO - 2016-08-13 09:13:05 --> Router Class Initialized
INFO - 2016-08-13 09:13:05 --> Output Class Initialized
INFO - 2016-08-13 09:13:05 --> Security Class Initialized
DEBUG - 2016-08-13 09:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:13:05 --> Input Class Initialized
INFO - 2016-08-13 09:13:05 --> Language Class Initialized
INFO - 2016-08-13 09:13:05 --> Loader Class Initialized
INFO - 2016-08-13 09:13:05 --> Helper loaded: url_helper
INFO - 2016-08-13 09:13:05 --> Helper loaded: date_helper
INFO - 2016-08-13 09:13:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:13:05 --> Database Driver Class Initialized
INFO - 2016-08-13 09:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:13:05 --> Email Class Initialized
INFO - 2016-08-13 09:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:13:05 --> Pagination Class Initialized
INFO - 2016-08-13 09:13:05 --> Model Class Initialized
INFO - 2016-08-13 09:13:05 --> Controller Class Initialized
INFO - 2016-08-13 09:13:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:13:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:13:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:13:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:13:05 --> Final output sent to browser
DEBUG - 2016-08-13 09:13:05 --> Total execution time: 0.3947
INFO - 2016-08-13 09:13:06 --> Config Class Initialized
INFO - 2016-08-13 09:13:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:13:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:13:06 --> Utf8 Class Initialized
INFO - 2016-08-13 09:13:06 --> URI Class Initialized
INFO - 2016-08-13 09:13:06 --> Router Class Initialized
INFO - 2016-08-13 09:13:06 --> Output Class Initialized
INFO - 2016-08-13 09:13:06 --> Security Class Initialized
DEBUG - 2016-08-13 09:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:13:06 --> Input Class Initialized
INFO - 2016-08-13 09:13:06 --> Language Class Initialized
ERROR - 2016-08-13 09:13:06 --> 404 Page Not Found: Assets/css
INFO - 2016-08-13 09:13:12 --> Config Class Initialized
INFO - 2016-08-13 09:13:12 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:13:12 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:13:13 --> Utf8 Class Initialized
INFO - 2016-08-13 09:13:13 --> URI Class Initialized
INFO - 2016-08-13 09:13:13 --> Router Class Initialized
INFO - 2016-08-13 09:13:13 --> Output Class Initialized
INFO - 2016-08-13 09:13:13 --> Security Class Initialized
DEBUG - 2016-08-13 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:13:13 --> Input Class Initialized
INFO - 2016-08-13 09:13:13 --> Language Class Initialized
INFO - 2016-08-13 09:13:13 --> Loader Class Initialized
INFO - 2016-08-13 09:13:13 --> Helper loaded: url_helper
INFO - 2016-08-13 09:13:13 --> Helper loaded: date_helper
INFO - 2016-08-13 09:13:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:13:13 --> Database Driver Class Initialized
INFO - 2016-08-13 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:13:13 --> Email Class Initialized
INFO - 2016-08-13 09:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:13:13 --> Pagination Class Initialized
INFO - 2016-08-13 09:13:13 --> Model Class Initialized
INFO - 2016-08-13 09:13:13 --> Controller Class Initialized
INFO - 2016-08-13 09:13:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:13:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:13:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:13:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:13:13 --> Final output sent to browser
DEBUG - 2016-08-13 09:13:13 --> Total execution time: 0.3954
INFO - 2016-08-13 09:13:35 --> Config Class Initialized
INFO - 2016-08-13 09:13:35 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:13:35 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:13:35 --> Utf8 Class Initialized
INFO - 2016-08-13 09:13:35 --> URI Class Initialized
INFO - 2016-08-13 09:13:35 --> Router Class Initialized
INFO - 2016-08-13 09:13:35 --> Output Class Initialized
INFO - 2016-08-13 09:13:35 --> Security Class Initialized
DEBUG - 2016-08-13 09:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:13:35 --> Input Class Initialized
INFO - 2016-08-13 09:13:35 --> Language Class Initialized
INFO - 2016-08-13 09:13:36 --> Loader Class Initialized
INFO - 2016-08-13 09:13:36 --> Helper loaded: url_helper
INFO - 2016-08-13 09:13:36 --> Helper loaded: date_helper
INFO - 2016-08-13 09:13:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:13:36 --> Database Driver Class Initialized
INFO - 2016-08-13 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:13:36 --> Email Class Initialized
INFO - 2016-08-13 09:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:13:36 --> Pagination Class Initialized
INFO - 2016-08-13 09:13:36 --> Model Class Initialized
INFO - 2016-08-13 09:13:36 --> Controller Class Initialized
INFO - 2016-08-13 09:13:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:13:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:13:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:13:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:13:36 --> Final output sent to browser
DEBUG - 2016-08-13 09:13:36 --> Total execution time: 0.3009
INFO - 2016-08-13 09:14:34 --> Config Class Initialized
INFO - 2016-08-13 09:14:34 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:14:34 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:14:34 --> Utf8 Class Initialized
INFO - 2016-08-13 09:14:34 --> URI Class Initialized
INFO - 2016-08-13 09:14:34 --> Router Class Initialized
INFO - 2016-08-13 09:14:34 --> Output Class Initialized
INFO - 2016-08-13 09:14:34 --> Security Class Initialized
DEBUG - 2016-08-13 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:14:34 --> Input Class Initialized
INFO - 2016-08-13 09:14:34 --> Language Class Initialized
INFO - 2016-08-13 09:14:34 --> Loader Class Initialized
INFO - 2016-08-13 09:14:34 --> Helper loaded: url_helper
INFO - 2016-08-13 09:14:34 --> Helper loaded: date_helper
INFO - 2016-08-13 09:14:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:14:34 --> Database Driver Class Initialized
INFO - 2016-08-13 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:14:34 --> Email Class Initialized
INFO - 2016-08-13 09:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:14:34 --> Pagination Class Initialized
INFO - 2016-08-13 09:14:34 --> Model Class Initialized
INFO - 2016-08-13 09:14:34 --> Controller Class Initialized
INFO - 2016-08-13 09:14:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:14:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:14:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:14:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:14:34 --> Final output sent to browser
DEBUG - 2016-08-13 09:14:34 --> Total execution time: 0.3678
INFO - 2016-08-13 09:15:31 --> Config Class Initialized
INFO - 2016-08-13 09:15:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:15:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:15:31 --> Utf8 Class Initialized
INFO - 2016-08-13 09:15:31 --> URI Class Initialized
INFO - 2016-08-13 09:15:31 --> Router Class Initialized
INFO - 2016-08-13 09:15:31 --> Output Class Initialized
INFO - 2016-08-13 09:15:31 --> Security Class Initialized
DEBUG - 2016-08-13 09:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:15:31 --> Input Class Initialized
INFO - 2016-08-13 09:15:31 --> Language Class Initialized
INFO - 2016-08-13 09:15:31 --> Loader Class Initialized
INFO - 2016-08-13 09:15:31 --> Helper loaded: url_helper
INFO - 2016-08-13 09:15:31 --> Helper loaded: date_helper
INFO - 2016-08-13 09:15:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:15:31 --> Database Driver Class Initialized
INFO - 2016-08-13 09:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:15:31 --> Email Class Initialized
INFO - 2016-08-13 09:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:15:31 --> Pagination Class Initialized
INFO - 2016-08-13 09:15:31 --> Model Class Initialized
INFO - 2016-08-13 09:15:31 --> Controller Class Initialized
INFO - 2016-08-13 09:15:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:15:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:15:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:15:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:15:31 --> Final output sent to browser
DEBUG - 2016-08-13 09:15:31 --> Total execution time: 0.2691
INFO - 2016-08-13 09:16:05 --> Config Class Initialized
INFO - 2016-08-13 09:16:05 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:16:05 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:16:05 --> Utf8 Class Initialized
INFO - 2016-08-13 09:16:05 --> URI Class Initialized
INFO - 2016-08-13 09:16:05 --> Router Class Initialized
INFO - 2016-08-13 09:16:05 --> Output Class Initialized
INFO - 2016-08-13 09:16:05 --> Security Class Initialized
DEBUG - 2016-08-13 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:16:05 --> Input Class Initialized
INFO - 2016-08-13 09:16:05 --> Language Class Initialized
INFO - 2016-08-13 09:16:05 --> Loader Class Initialized
INFO - 2016-08-13 09:16:05 --> Helper loaded: url_helper
INFO - 2016-08-13 09:16:05 --> Helper loaded: date_helper
INFO - 2016-08-13 09:16:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:16:06 --> Database Driver Class Initialized
INFO - 2016-08-13 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:16:06 --> Email Class Initialized
INFO - 2016-08-13 09:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:16:06 --> Pagination Class Initialized
INFO - 2016-08-13 09:16:06 --> Model Class Initialized
INFO - 2016-08-13 09:16:06 --> Controller Class Initialized
INFO - 2016-08-13 09:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:16:06 --> Final output sent to browser
DEBUG - 2016-08-13 09:16:06 --> Total execution time: 0.3707
INFO - 2016-08-13 09:17:14 --> Config Class Initialized
INFO - 2016-08-13 09:17:14 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:17:14 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:17:14 --> Utf8 Class Initialized
INFO - 2016-08-13 09:17:14 --> URI Class Initialized
INFO - 2016-08-13 09:17:14 --> Router Class Initialized
INFO - 2016-08-13 09:17:14 --> Output Class Initialized
INFO - 2016-08-13 09:17:14 --> Security Class Initialized
DEBUG - 2016-08-13 09:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:17:14 --> Input Class Initialized
INFO - 2016-08-13 09:17:14 --> Language Class Initialized
INFO - 2016-08-13 09:17:14 --> Loader Class Initialized
INFO - 2016-08-13 09:17:14 --> Helper loaded: url_helper
INFO - 2016-08-13 09:17:15 --> Helper loaded: date_helper
INFO - 2016-08-13 09:17:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:17:15 --> Database Driver Class Initialized
INFO - 2016-08-13 09:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:17:15 --> Email Class Initialized
INFO - 2016-08-13 09:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:17:15 --> Pagination Class Initialized
INFO - 2016-08-13 09:17:15 --> Model Class Initialized
INFO - 2016-08-13 09:17:15 --> Controller Class Initialized
INFO - 2016-08-13 09:17:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:17:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:17:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:17:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:17:15 --> Final output sent to browser
DEBUG - 2016-08-13 09:17:15 --> Total execution time: 0.2771
INFO - 2016-08-13 09:26:58 --> Config Class Initialized
INFO - 2016-08-13 09:26:58 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:26:58 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:26:58 --> Utf8 Class Initialized
INFO - 2016-08-13 09:26:58 --> URI Class Initialized
INFO - 2016-08-13 09:26:58 --> Router Class Initialized
INFO - 2016-08-13 09:26:58 --> Output Class Initialized
INFO - 2016-08-13 09:26:58 --> Security Class Initialized
DEBUG - 2016-08-13 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:26:58 --> Input Class Initialized
INFO - 2016-08-13 09:26:58 --> Language Class Initialized
INFO - 2016-08-13 09:26:58 --> Loader Class Initialized
INFO - 2016-08-13 09:26:58 --> Helper loaded: url_helper
INFO - 2016-08-13 09:26:58 --> Helper loaded: date_helper
INFO - 2016-08-13 09:26:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:26:58 --> Database Driver Class Initialized
INFO - 2016-08-13 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:26:58 --> Email Class Initialized
INFO - 2016-08-13 09:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:26:58 --> Pagination Class Initialized
INFO - 2016-08-13 09:26:58 --> Model Class Initialized
INFO - 2016-08-13 09:26:58 --> Controller Class Initialized
INFO - 2016-08-13 09:26:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:26:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:26:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:26:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:26:59 --> Final output sent to browser
DEBUG - 2016-08-13 09:26:59 --> Total execution time: 0.3620
INFO - 2016-08-13 09:27:48 --> Config Class Initialized
INFO - 2016-08-13 09:27:48 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:27:48 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:27:48 --> Utf8 Class Initialized
INFO - 2016-08-13 09:27:48 --> URI Class Initialized
INFO - 2016-08-13 09:27:48 --> Router Class Initialized
INFO - 2016-08-13 09:27:48 --> Output Class Initialized
INFO - 2016-08-13 09:27:48 --> Security Class Initialized
DEBUG - 2016-08-13 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:27:48 --> Input Class Initialized
INFO - 2016-08-13 09:27:48 --> Language Class Initialized
INFO - 2016-08-13 09:27:48 --> Loader Class Initialized
INFO - 2016-08-13 09:27:48 --> Helper loaded: url_helper
INFO - 2016-08-13 09:27:48 --> Helper loaded: date_helper
INFO - 2016-08-13 09:27:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:27:48 --> Database Driver Class Initialized
INFO - 2016-08-13 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:27:48 --> Email Class Initialized
INFO - 2016-08-13 09:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:27:48 --> Pagination Class Initialized
INFO - 2016-08-13 09:27:48 --> Model Class Initialized
INFO - 2016-08-13 09:27:48 --> Controller Class Initialized
INFO - 2016-08-13 09:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:27:48 --> Final output sent to browser
DEBUG - 2016-08-13 09:27:48 --> Total execution time: 0.2964
INFO - 2016-08-13 09:29:38 --> Config Class Initialized
INFO - 2016-08-13 09:29:38 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:29:38 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:29:38 --> Utf8 Class Initialized
INFO - 2016-08-13 09:29:38 --> URI Class Initialized
INFO - 2016-08-13 09:29:38 --> Router Class Initialized
INFO - 2016-08-13 09:29:38 --> Output Class Initialized
INFO - 2016-08-13 09:29:38 --> Security Class Initialized
DEBUG - 2016-08-13 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:29:38 --> Input Class Initialized
INFO - 2016-08-13 09:29:38 --> Language Class Initialized
INFO - 2016-08-13 09:29:38 --> Loader Class Initialized
INFO - 2016-08-13 09:29:38 --> Helper loaded: url_helper
INFO - 2016-08-13 09:29:38 --> Helper loaded: date_helper
INFO - 2016-08-13 09:29:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:29:38 --> Database Driver Class Initialized
INFO - 2016-08-13 09:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:29:38 --> Email Class Initialized
INFO - 2016-08-13 09:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:29:38 --> Pagination Class Initialized
INFO - 2016-08-13 09:29:38 --> Model Class Initialized
INFO - 2016-08-13 09:29:38 --> Controller Class Initialized
INFO - 2016-08-13 09:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:29:39 --> Final output sent to browser
DEBUG - 2016-08-13 09:29:39 --> Total execution time: 0.3924
INFO - 2016-08-13 09:30:05 --> Config Class Initialized
INFO - 2016-08-13 09:30:05 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:30:05 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:30:05 --> Utf8 Class Initialized
INFO - 2016-08-13 09:30:05 --> URI Class Initialized
INFO - 2016-08-13 09:30:05 --> Router Class Initialized
INFO - 2016-08-13 09:30:05 --> Output Class Initialized
INFO - 2016-08-13 09:30:05 --> Security Class Initialized
DEBUG - 2016-08-13 09:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:30:05 --> Input Class Initialized
INFO - 2016-08-13 09:30:05 --> Language Class Initialized
INFO - 2016-08-13 09:30:05 --> Loader Class Initialized
INFO - 2016-08-13 09:30:05 --> Helper loaded: url_helper
INFO - 2016-08-13 09:30:05 --> Helper loaded: date_helper
INFO - 2016-08-13 09:30:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:30:05 --> Database Driver Class Initialized
INFO - 2016-08-13 09:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:30:05 --> Email Class Initialized
INFO - 2016-08-13 09:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:30:05 --> Pagination Class Initialized
INFO - 2016-08-13 09:30:05 --> Model Class Initialized
INFO - 2016-08-13 09:30:05 --> Controller Class Initialized
INFO - 2016-08-13 09:30:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:30:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:30:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:30:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:30:05 --> Final output sent to browser
DEBUG - 2016-08-13 09:30:05 --> Total execution time: 0.3897
INFO - 2016-08-13 09:30:21 --> Config Class Initialized
INFO - 2016-08-13 09:30:21 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:30:21 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:30:21 --> Utf8 Class Initialized
INFO - 2016-08-13 09:30:21 --> URI Class Initialized
INFO - 2016-08-13 09:30:21 --> Router Class Initialized
INFO - 2016-08-13 09:30:21 --> Output Class Initialized
INFO - 2016-08-13 09:30:21 --> Security Class Initialized
DEBUG - 2016-08-13 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:30:21 --> Input Class Initialized
INFO - 2016-08-13 09:30:21 --> Language Class Initialized
INFO - 2016-08-13 09:30:21 --> Loader Class Initialized
INFO - 2016-08-13 09:30:21 --> Helper loaded: url_helper
INFO - 2016-08-13 09:30:21 --> Helper loaded: date_helper
INFO - 2016-08-13 09:30:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:30:21 --> Database Driver Class Initialized
INFO - 2016-08-13 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:30:21 --> Email Class Initialized
INFO - 2016-08-13 09:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:30:21 --> Pagination Class Initialized
INFO - 2016-08-13 09:30:21 --> Model Class Initialized
INFO - 2016-08-13 09:30:21 --> Controller Class Initialized
INFO - 2016-08-13 09:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:30:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:30:21 --> Final output sent to browser
DEBUG - 2016-08-13 09:30:21 --> Total execution time: 0.4071
INFO - 2016-08-13 09:30:32 --> Config Class Initialized
INFO - 2016-08-13 09:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:30:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:30:32 --> Utf8 Class Initialized
INFO - 2016-08-13 09:30:32 --> URI Class Initialized
INFO - 2016-08-13 09:30:32 --> Router Class Initialized
INFO - 2016-08-13 09:30:32 --> Output Class Initialized
INFO - 2016-08-13 09:30:32 --> Security Class Initialized
DEBUG - 2016-08-13 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:30:32 --> Input Class Initialized
INFO - 2016-08-13 09:30:32 --> Language Class Initialized
INFO - 2016-08-13 09:30:32 --> Loader Class Initialized
INFO - 2016-08-13 09:30:32 --> Helper loaded: url_helper
INFO - 2016-08-13 09:30:32 --> Helper loaded: date_helper
INFO - 2016-08-13 09:30:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:30:32 --> Database Driver Class Initialized
INFO - 2016-08-13 09:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:30:32 --> Email Class Initialized
INFO - 2016-08-13 09:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:30:32 --> Pagination Class Initialized
INFO - 2016-08-13 09:30:32 --> Model Class Initialized
INFO - 2016-08-13 09:30:32 --> Controller Class Initialized
INFO - 2016-08-13 09:30:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:30:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:30:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:30:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:30:32 --> Final output sent to browser
DEBUG - 2016-08-13 09:30:32 --> Total execution time: 0.3695
INFO - 2016-08-13 09:39:06 --> Config Class Initialized
INFO - 2016-08-13 09:39:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:39:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:39:06 --> Utf8 Class Initialized
INFO - 2016-08-13 09:39:06 --> URI Class Initialized
INFO - 2016-08-13 09:39:06 --> Router Class Initialized
INFO - 2016-08-13 09:39:06 --> Output Class Initialized
INFO - 2016-08-13 09:39:06 --> Security Class Initialized
DEBUG - 2016-08-13 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:39:06 --> Input Class Initialized
INFO - 2016-08-13 09:39:07 --> Language Class Initialized
INFO - 2016-08-13 09:39:07 --> Loader Class Initialized
INFO - 2016-08-13 09:39:07 --> Helper loaded: url_helper
INFO - 2016-08-13 09:39:07 --> Helper loaded: date_helper
INFO - 2016-08-13 09:39:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:39:07 --> Database Driver Class Initialized
INFO - 2016-08-13 09:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:39:07 --> Email Class Initialized
INFO - 2016-08-13 09:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:39:07 --> Pagination Class Initialized
INFO - 2016-08-13 09:39:07 --> Model Class Initialized
INFO - 2016-08-13 09:39:07 --> Controller Class Initialized
INFO - 2016-08-13 09:39:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:39:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:39:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:39:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:39:07 --> Final output sent to browser
DEBUG - 2016-08-13 09:39:07 --> Total execution time: 0.3482
INFO - 2016-08-13 09:43:25 --> Config Class Initialized
INFO - 2016-08-13 09:43:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:43:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:43:25 --> Utf8 Class Initialized
INFO - 2016-08-13 09:43:25 --> URI Class Initialized
INFO - 2016-08-13 09:43:25 --> Router Class Initialized
INFO - 2016-08-13 09:43:25 --> Output Class Initialized
INFO - 2016-08-13 09:43:25 --> Security Class Initialized
DEBUG - 2016-08-13 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:43:25 --> Input Class Initialized
INFO - 2016-08-13 09:43:25 --> Language Class Initialized
INFO - 2016-08-13 09:43:25 --> Loader Class Initialized
INFO - 2016-08-13 09:43:25 --> Helper loaded: url_helper
INFO - 2016-08-13 09:43:25 --> Helper loaded: date_helper
INFO - 2016-08-13 09:43:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:43:25 --> Database Driver Class Initialized
INFO - 2016-08-13 09:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:43:25 --> Email Class Initialized
INFO - 2016-08-13 09:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:43:25 --> Pagination Class Initialized
INFO - 2016-08-13 09:43:25 --> Model Class Initialized
INFO - 2016-08-13 09:43:25 --> Controller Class Initialized
INFO - 2016-08-13 09:43:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:43:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:43:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:43:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:43:26 --> Final output sent to browser
DEBUG - 2016-08-13 09:43:26 --> Total execution time: 0.3027
INFO - 2016-08-13 09:43:58 --> Config Class Initialized
INFO - 2016-08-13 09:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:43:58 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:43:58 --> Utf8 Class Initialized
INFO - 2016-08-13 09:43:58 --> URI Class Initialized
INFO - 2016-08-13 09:43:58 --> Router Class Initialized
INFO - 2016-08-13 09:43:58 --> Output Class Initialized
INFO - 2016-08-13 09:43:58 --> Security Class Initialized
DEBUG - 2016-08-13 09:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:43:58 --> Input Class Initialized
INFO - 2016-08-13 09:43:58 --> Language Class Initialized
INFO - 2016-08-13 09:43:58 --> Loader Class Initialized
INFO - 2016-08-13 09:43:58 --> Helper loaded: url_helper
INFO - 2016-08-13 09:43:58 --> Helper loaded: date_helper
INFO - 2016-08-13 09:43:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:43:58 --> Database Driver Class Initialized
INFO - 2016-08-13 09:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:43:58 --> Email Class Initialized
INFO - 2016-08-13 09:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:43:58 --> Pagination Class Initialized
INFO - 2016-08-13 09:43:58 --> Model Class Initialized
INFO - 2016-08-13 09:43:58 --> Controller Class Initialized
INFO - 2016-08-13 09:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:43:58 --> Final output sent to browser
DEBUG - 2016-08-13 09:43:58 --> Total execution time: 0.3938
INFO - 2016-08-13 09:45:58 --> Config Class Initialized
INFO - 2016-08-13 09:45:58 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:45:58 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:45:58 --> Utf8 Class Initialized
INFO - 2016-08-13 09:45:58 --> URI Class Initialized
INFO - 2016-08-13 09:45:58 --> Router Class Initialized
INFO - 2016-08-13 09:45:58 --> Output Class Initialized
INFO - 2016-08-13 09:45:58 --> Security Class Initialized
DEBUG - 2016-08-13 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:45:58 --> Input Class Initialized
INFO - 2016-08-13 09:45:58 --> Language Class Initialized
INFO - 2016-08-13 09:45:58 --> Loader Class Initialized
INFO - 2016-08-13 09:45:58 --> Helper loaded: url_helper
INFO - 2016-08-13 09:45:58 --> Helper loaded: date_helper
INFO - 2016-08-13 09:45:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:45:58 --> Database Driver Class Initialized
INFO - 2016-08-13 09:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:45:58 --> Email Class Initialized
INFO - 2016-08-13 09:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:45:58 --> Pagination Class Initialized
INFO - 2016-08-13 09:45:58 --> Model Class Initialized
INFO - 2016-08-13 09:45:58 --> Controller Class Initialized
INFO - 2016-08-13 09:45:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:45:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:45:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:45:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:45:58 --> Final output sent to browser
DEBUG - 2016-08-13 09:45:58 --> Total execution time: 0.4129
INFO - 2016-08-13 09:46:02 --> Config Class Initialized
INFO - 2016-08-13 09:46:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:46:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:46:02 --> Utf8 Class Initialized
INFO - 2016-08-13 09:46:02 --> URI Class Initialized
INFO - 2016-08-13 09:46:02 --> Router Class Initialized
INFO - 2016-08-13 09:46:02 --> Output Class Initialized
INFO - 2016-08-13 09:46:02 --> Security Class Initialized
DEBUG - 2016-08-13 09:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:46:02 --> Input Class Initialized
INFO - 2016-08-13 09:46:02 --> Language Class Initialized
ERROR - 2016-08-13 09:46:02 --> 404 Page Not Found: Order/1101
INFO - 2016-08-13 09:46:49 --> Config Class Initialized
INFO - 2016-08-13 09:46:49 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:46:49 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:46:49 --> Utf8 Class Initialized
INFO - 2016-08-13 09:46:49 --> URI Class Initialized
INFO - 2016-08-13 09:46:49 --> Router Class Initialized
INFO - 2016-08-13 09:46:49 --> Output Class Initialized
INFO - 2016-08-13 09:46:49 --> Security Class Initialized
DEBUG - 2016-08-13 09:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:46:49 --> Input Class Initialized
INFO - 2016-08-13 09:46:49 --> Language Class Initialized
INFO - 2016-08-13 09:46:49 --> Loader Class Initialized
INFO - 2016-08-13 09:46:49 --> Helper loaded: url_helper
INFO - 2016-08-13 09:46:49 --> Helper loaded: date_helper
INFO - 2016-08-13 09:46:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:46:49 --> Database Driver Class Initialized
INFO - 2016-08-13 09:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:46:49 --> Email Class Initialized
INFO - 2016-08-13 09:46:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:46:49 --> Pagination Class Initialized
INFO - 2016-08-13 09:46:49 --> Model Class Initialized
INFO - 2016-08-13 09:46:49 --> Controller Class Initialized
INFO - 2016-08-13 09:46:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:46:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:46:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:46:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:46:50 --> Final output sent to browser
DEBUG - 2016-08-13 09:46:50 --> Total execution time: 0.3539
INFO - 2016-08-13 09:46:53 --> Config Class Initialized
INFO - 2016-08-13 09:46:53 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:46:53 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:46:53 --> Utf8 Class Initialized
INFO - 2016-08-13 09:46:53 --> URI Class Initialized
INFO - 2016-08-13 09:46:53 --> Router Class Initialized
INFO - 2016-08-13 09:46:53 --> Output Class Initialized
INFO - 2016-08-13 09:46:53 --> Security Class Initialized
DEBUG - 2016-08-13 09:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:46:53 --> Input Class Initialized
INFO - 2016-08-13 09:46:54 --> Language Class Initialized
INFO - 2016-08-13 09:46:54 --> Loader Class Initialized
INFO - 2016-08-13 09:46:54 --> Helper loaded: url_helper
INFO - 2016-08-13 09:46:54 --> Helper loaded: date_helper
INFO - 2016-08-13 09:46:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:46:54 --> Database Driver Class Initialized
INFO - 2016-08-13 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:46:54 --> Email Class Initialized
INFO - 2016-08-13 09:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:46:54 --> Pagination Class Initialized
INFO - 2016-08-13 09:46:54 --> Model Class Initialized
INFO - 2016-08-13 09:46:54 --> Controller Class Initialized
INFO - 2016-08-13 09:46:54 --> Final output sent to browser
DEBUG - 2016-08-13 09:46:54 --> Total execution time: 0.3735
INFO - 2016-08-13 09:47:15 --> Config Class Initialized
INFO - 2016-08-13 09:47:15 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:47:15 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:47:15 --> Utf8 Class Initialized
INFO - 2016-08-13 09:47:15 --> URI Class Initialized
INFO - 2016-08-13 09:47:15 --> Router Class Initialized
INFO - 2016-08-13 09:47:15 --> Output Class Initialized
INFO - 2016-08-13 09:47:15 --> Security Class Initialized
DEBUG - 2016-08-13 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:47:15 --> Input Class Initialized
INFO - 2016-08-13 09:47:15 --> Language Class Initialized
INFO - 2016-08-13 09:47:15 --> Loader Class Initialized
INFO - 2016-08-13 09:47:15 --> Helper loaded: url_helper
INFO - 2016-08-13 09:47:15 --> Helper loaded: date_helper
INFO - 2016-08-13 09:47:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:47:15 --> Database Driver Class Initialized
INFO - 2016-08-13 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:47:15 --> Email Class Initialized
INFO - 2016-08-13 09:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:47:15 --> Pagination Class Initialized
INFO - 2016-08-13 09:47:15 --> Model Class Initialized
INFO - 2016-08-13 09:47:15 --> Controller Class Initialized
INFO - 2016-08-13 09:47:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:47:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:47:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:47:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:47:16 --> Final output sent to browser
DEBUG - 2016-08-13 09:47:16 --> Total execution time: 0.3527
INFO - 2016-08-13 09:47:20 --> Config Class Initialized
INFO - 2016-08-13 09:47:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:47:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:47:20 --> Utf8 Class Initialized
INFO - 2016-08-13 09:47:20 --> URI Class Initialized
INFO - 2016-08-13 09:47:20 --> Router Class Initialized
INFO - 2016-08-13 09:47:20 --> Output Class Initialized
INFO - 2016-08-13 09:47:20 --> Security Class Initialized
DEBUG - 2016-08-13 09:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:47:21 --> Input Class Initialized
INFO - 2016-08-13 09:47:21 --> Language Class Initialized
INFO - 2016-08-13 09:47:21 --> Loader Class Initialized
INFO - 2016-08-13 09:47:21 --> Helper loaded: url_helper
INFO - 2016-08-13 09:47:21 --> Helper loaded: date_helper
INFO - 2016-08-13 09:47:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:47:21 --> Database Driver Class Initialized
INFO - 2016-08-13 09:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:47:21 --> Email Class Initialized
INFO - 2016-08-13 09:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:47:21 --> Pagination Class Initialized
INFO - 2016-08-13 09:47:21 --> Model Class Initialized
INFO - 2016-08-13 09:47:21 --> Controller Class Initialized
INFO - 2016-08-13 09:47:21 --> Final output sent to browser
DEBUG - 2016-08-13 09:47:21 --> Total execution time: 0.2798
INFO - 2016-08-13 09:47:47 --> Config Class Initialized
INFO - 2016-08-13 09:47:47 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:47:47 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:47:47 --> Utf8 Class Initialized
INFO - 2016-08-13 09:47:47 --> URI Class Initialized
INFO - 2016-08-13 09:47:47 --> Router Class Initialized
INFO - 2016-08-13 09:47:47 --> Output Class Initialized
INFO - 2016-08-13 09:47:47 --> Security Class Initialized
DEBUG - 2016-08-13 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:47:47 --> Input Class Initialized
INFO - 2016-08-13 09:47:47 --> Language Class Initialized
INFO - 2016-08-13 09:47:47 --> Loader Class Initialized
INFO - 2016-08-13 09:47:47 --> Helper loaded: url_helper
INFO - 2016-08-13 09:47:47 --> Helper loaded: date_helper
INFO - 2016-08-13 09:47:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:47:48 --> Database Driver Class Initialized
INFO - 2016-08-13 09:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:47:48 --> Email Class Initialized
INFO - 2016-08-13 09:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:47:48 --> Pagination Class Initialized
INFO - 2016-08-13 09:47:48 --> Model Class Initialized
INFO - 2016-08-13 09:47:48 --> Controller Class Initialized
INFO - 2016-08-13 09:47:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:47:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:47:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:47:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:47:48 --> Final output sent to browser
DEBUG - 2016-08-13 09:47:48 --> Total execution time: 0.5368
INFO - 2016-08-13 09:47:51 --> Config Class Initialized
INFO - 2016-08-13 09:47:51 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:47:51 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:47:51 --> Utf8 Class Initialized
INFO - 2016-08-13 09:47:51 --> URI Class Initialized
INFO - 2016-08-13 09:47:51 --> Router Class Initialized
INFO - 2016-08-13 09:47:51 --> Output Class Initialized
INFO - 2016-08-13 09:47:51 --> Security Class Initialized
DEBUG - 2016-08-13 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:47:51 --> Input Class Initialized
INFO - 2016-08-13 09:47:51 --> Language Class Initialized
INFO - 2016-08-13 09:47:51 --> Loader Class Initialized
INFO - 2016-08-13 09:47:51 --> Helper loaded: url_helper
INFO - 2016-08-13 09:47:51 --> Helper loaded: date_helper
INFO - 2016-08-13 09:47:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:47:51 --> Database Driver Class Initialized
INFO - 2016-08-13 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:47:51 --> Email Class Initialized
INFO - 2016-08-13 09:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:47:51 --> Pagination Class Initialized
INFO - 2016-08-13 09:47:51 --> Model Class Initialized
INFO - 2016-08-13 09:47:51 --> Controller Class Initialized
INFO - 2016-08-13 09:47:51 --> Final output sent to browser
DEBUG - 2016-08-13 09:47:51 --> Total execution time: 0.2643
INFO - 2016-08-13 09:48:04 --> Config Class Initialized
INFO - 2016-08-13 09:48:04 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:48:04 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:48:04 --> Utf8 Class Initialized
INFO - 2016-08-13 09:48:04 --> URI Class Initialized
INFO - 2016-08-13 09:48:04 --> Router Class Initialized
INFO - 2016-08-13 09:48:04 --> Output Class Initialized
INFO - 2016-08-13 09:48:04 --> Security Class Initialized
DEBUG - 2016-08-13 09:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:48:04 --> Input Class Initialized
INFO - 2016-08-13 09:48:04 --> Language Class Initialized
INFO - 2016-08-13 09:48:04 --> Loader Class Initialized
INFO - 2016-08-13 09:48:04 --> Helper loaded: url_helper
INFO - 2016-08-13 09:48:04 --> Helper loaded: date_helper
INFO - 2016-08-13 09:48:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:48:04 --> Database Driver Class Initialized
INFO - 2016-08-13 09:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:48:04 --> Email Class Initialized
INFO - 2016-08-13 09:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:48:04 --> Pagination Class Initialized
INFO - 2016-08-13 09:48:04 --> Model Class Initialized
INFO - 2016-08-13 09:48:04 --> Controller Class Initialized
INFO - 2016-08-13 09:48:04 --> Final output sent to browser
DEBUG - 2016-08-13 09:48:04 --> Total execution time: 0.3443
INFO - 2016-08-13 09:48:18 --> Config Class Initialized
INFO - 2016-08-13 09:48:18 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:48:18 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:48:18 --> Utf8 Class Initialized
INFO - 2016-08-13 09:48:18 --> URI Class Initialized
INFO - 2016-08-13 09:48:18 --> Router Class Initialized
INFO - 2016-08-13 09:48:18 --> Output Class Initialized
INFO - 2016-08-13 09:48:18 --> Security Class Initialized
DEBUG - 2016-08-13 09:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:48:18 --> Input Class Initialized
INFO - 2016-08-13 09:48:18 --> Language Class Initialized
INFO - 2016-08-13 09:48:18 --> Loader Class Initialized
INFO - 2016-08-13 09:48:18 --> Helper loaded: url_helper
INFO - 2016-08-13 09:48:18 --> Helper loaded: date_helper
INFO - 2016-08-13 09:48:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:48:18 --> Database Driver Class Initialized
INFO - 2016-08-13 09:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:48:18 --> Email Class Initialized
INFO - 2016-08-13 09:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:48:18 --> Pagination Class Initialized
INFO - 2016-08-13 09:48:18 --> Model Class Initialized
INFO - 2016-08-13 09:48:18 --> Controller Class Initialized
INFO - 2016-08-13 09:48:18 --> Final output sent to browser
DEBUG - 2016-08-13 09:48:18 --> Total execution time: 0.3092
INFO - 2016-08-13 09:48:33 --> Config Class Initialized
INFO - 2016-08-13 09:48:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:48:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:48:33 --> Utf8 Class Initialized
INFO - 2016-08-13 09:48:33 --> URI Class Initialized
INFO - 2016-08-13 09:48:33 --> Router Class Initialized
INFO - 2016-08-13 09:48:33 --> Output Class Initialized
INFO - 2016-08-13 09:48:33 --> Security Class Initialized
DEBUG - 2016-08-13 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:48:33 --> Input Class Initialized
INFO - 2016-08-13 09:48:33 --> Language Class Initialized
INFO - 2016-08-13 09:48:33 --> Loader Class Initialized
INFO - 2016-08-13 09:48:33 --> Helper loaded: url_helper
INFO - 2016-08-13 09:48:33 --> Helper loaded: date_helper
INFO - 2016-08-13 09:48:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:48:33 --> Database Driver Class Initialized
INFO - 2016-08-13 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:48:33 --> Email Class Initialized
INFO - 2016-08-13 09:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:48:33 --> Pagination Class Initialized
INFO - 2016-08-13 09:48:33 --> Model Class Initialized
INFO - 2016-08-13 09:48:33 --> Controller Class Initialized
INFO - 2016-08-13 09:48:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:48:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:48:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:48:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:48:33 --> Final output sent to browser
DEBUG - 2016-08-13 09:48:33 --> Total execution time: 0.5478
INFO - 2016-08-13 09:48:42 --> Config Class Initialized
INFO - 2016-08-13 09:48:42 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:48:42 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:48:42 --> Utf8 Class Initialized
INFO - 2016-08-13 09:48:42 --> URI Class Initialized
INFO - 2016-08-13 09:48:42 --> Router Class Initialized
INFO - 2016-08-13 09:48:42 --> Output Class Initialized
INFO - 2016-08-13 09:48:42 --> Security Class Initialized
DEBUG - 2016-08-13 09:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:48:42 --> Input Class Initialized
INFO - 2016-08-13 09:48:42 --> Language Class Initialized
INFO - 2016-08-13 09:48:42 --> Loader Class Initialized
INFO - 2016-08-13 09:48:42 --> Helper loaded: url_helper
INFO - 2016-08-13 09:48:42 --> Helper loaded: date_helper
INFO - 2016-08-13 09:48:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:48:42 --> Database Driver Class Initialized
INFO - 2016-08-13 09:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:48:42 --> Email Class Initialized
INFO - 2016-08-13 09:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:48:42 --> Pagination Class Initialized
INFO - 2016-08-13 09:48:42 --> Model Class Initialized
INFO - 2016-08-13 09:48:42 --> Controller Class Initialized
INFO - 2016-08-13 09:48:42 --> Final output sent to browser
DEBUG - 2016-08-13 09:48:42 --> Total execution time: 0.3100
INFO - 2016-08-13 09:48:52 --> Config Class Initialized
INFO - 2016-08-13 09:48:52 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:48:52 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:48:52 --> Utf8 Class Initialized
INFO - 2016-08-13 09:48:52 --> URI Class Initialized
INFO - 2016-08-13 09:48:52 --> Router Class Initialized
INFO - 2016-08-13 09:48:52 --> Output Class Initialized
INFO - 2016-08-13 09:48:52 --> Security Class Initialized
DEBUG - 2016-08-13 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:48:52 --> Input Class Initialized
INFO - 2016-08-13 09:48:52 --> Language Class Initialized
INFO - 2016-08-13 09:48:52 --> Loader Class Initialized
INFO - 2016-08-13 09:48:52 --> Helper loaded: url_helper
INFO - 2016-08-13 09:48:52 --> Helper loaded: date_helper
INFO - 2016-08-13 09:48:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:48:52 --> Database Driver Class Initialized
INFO - 2016-08-13 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:48:52 --> Email Class Initialized
INFO - 2016-08-13 09:48:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:48:52 --> Pagination Class Initialized
INFO - 2016-08-13 09:48:52 --> Model Class Initialized
INFO - 2016-08-13 09:48:52 --> Controller Class Initialized
INFO - 2016-08-13 09:48:52 --> Final output sent to browser
DEBUG - 2016-08-13 09:48:52 --> Total execution time: 0.2659
INFO - 2016-08-13 09:49:06 --> Config Class Initialized
INFO - 2016-08-13 09:49:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:49:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:49:06 --> Utf8 Class Initialized
INFO - 2016-08-13 09:49:06 --> URI Class Initialized
INFO - 2016-08-13 09:49:06 --> Router Class Initialized
INFO - 2016-08-13 09:49:06 --> Output Class Initialized
INFO - 2016-08-13 09:49:06 --> Security Class Initialized
DEBUG - 2016-08-13 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:49:06 --> Input Class Initialized
INFO - 2016-08-13 09:49:06 --> Language Class Initialized
INFO - 2016-08-13 09:49:06 --> Loader Class Initialized
INFO - 2016-08-13 09:49:06 --> Helper loaded: url_helper
INFO - 2016-08-13 09:49:06 --> Helper loaded: date_helper
INFO - 2016-08-13 09:49:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:49:06 --> Database Driver Class Initialized
INFO - 2016-08-13 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:49:06 --> Email Class Initialized
INFO - 2016-08-13 09:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:49:06 --> Pagination Class Initialized
INFO - 2016-08-13 09:49:06 --> Model Class Initialized
INFO - 2016-08-13 09:49:06 --> Controller Class Initialized
INFO - 2016-08-13 09:49:06 --> Final output sent to browser
DEBUG - 2016-08-13 09:49:06 --> Total execution time: 0.2670
INFO - 2016-08-13 09:49:37 --> Config Class Initialized
INFO - 2016-08-13 09:49:37 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:49:37 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:49:37 --> Utf8 Class Initialized
INFO - 2016-08-13 09:49:37 --> URI Class Initialized
INFO - 2016-08-13 09:49:37 --> Router Class Initialized
INFO - 2016-08-13 09:49:37 --> Output Class Initialized
INFO - 2016-08-13 09:49:37 --> Security Class Initialized
DEBUG - 2016-08-13 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:49:37 --> Input Class Initialized
INFO - 2016-08-13 09:49:37 --> Language Class Initialized
INFO - 2016-08-13 09:49:37 --> Loader Class Initialized
INFO - 2016-08-13 09:49:37 --> Helper loaded: url_helper
INFO - 2016-08-13 09:49:38 --> Helper loaded: date_helper
INFO - 2016-08-13 09:49:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:49:38 --> Database Driver Class Initialized
INFO - 2016-08-13 09:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:49:38 --> Email Class Initialized
INFO - 2016-08-13 09:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:49:38 --> Pagination Class Initialized
INFO - 2016-08-13 09:49:38 --> Model Class Initialized
INFO - 2016-08-13 09:49:38 --> Controller Class Initialized
INFO - 2016-08-13 09:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:49:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:49:38 --> Final output sent to browser
DEBUG - 2016-08-13 09:49:38 --> Total execution time: 0.3326
INFO - 2016-08-13 09:49:50 --> Config Class Initialized
INFO - 2016-08-13 09:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:49:50 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:49:50 --> Utf8 Class Initialized
INFO - 2016-08-13 09:49:50 --> URI Class Initialized
INFO - 2016-08-13 09:49:50 --> Router Class Initialized
INFO - 2016-08-13 09:49:50 --> Output Class Initialized
INFO - 2016-08-13 09:49:50 --> Security Class Initialized
DEBUG - 2016-08-13 09:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:49:50 --> Input Class Initialized
INFO - 2016-08-13 09:49:50 --> Language Class Initialized
INFO - 2016-08-13 09:49:50 --> Loader Class Initialized
INFO - 2016-08-13 09:49:50 --> Helper loaded: url_helper
INFO - 2016-08-13 09:49:50 --> Helper loaded: date_helper
INFO - 2016-08-13 09:49:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:49:50 --> Database Driver Class Initialized
INFO - 2016-08-13 09:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:49:51 --> Email Class Initialized
INFO - 2016-08-13 09:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:49:51 --> Pagination Class Initialized
INFO - 2016-08-13 09:49:51 --> Model Class Initialized
INFO - 2016-08-13 09:49:51 --> Controller Class Initialized
INFO - 2016-08-13 09:49:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:49:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:49:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:49:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:49:51 --> Final output sent to browser
DEBUG - 2016-08-13 09:49:51 --> Total execution time: 0.4558
INFO - 2016-08-13 09:49:56 --> Config Class Initialized
INFO - 2016-08-13 09:49:56 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:49:56 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:49:56 --> Utf8 Class Initialized
INFO - 2016-08-13 09:49:56 --> URI Class Initialized
INFO - 2016-08-13 09:49:56 --> Router Class Initialized
INFO - 2016-08-13 09:49:56 --> Output Class Initialized
INFO - 2016-08-13 09:49:56 --> Security Class Initialized
DEBUG - 2016-08-13 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:49:56 --> Input Class Initialized
INFO - 2016-08-13 09:49:56 --> Language Class Initialized
INFO - 2016-08-13 09:49:56 --> Loader Class Initialized
INFO - 2016-08-13 09:49:56 --> Helper loaded: url_helper
INFO - 2016-08-13 09:49:56 --> Helper loaded: date_helper
INFO - 2016-08-13 09:49:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:49:56 --> Database Driver Class Initialized
INFO - 2016-08-13 09:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:49:56 --> Email Class Initialized
INFO - 2016-08-13 09:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:49:56 --> Pagination Class Initialized
INFO - 2016-08-13 09:49:56 --> Model Class Initialized
INFO - 2016-08-13 09:49:56 --> Controller Class Initialized
INFO - 2016-08-13 09:49:56 --> Final output sent to browser
DEBUG - 2016-08-13 09:49:56 --> Total execution time: 0.2713
INFO - 2016-08-13 09:50:00 --> Config Class Initialized
INFO - 2016-08-13 09:50:00 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:50:00 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:50:00 --> Utf8 Class Initialized
INFO - 2016-08-13 09:50:01 --> URI Class Initialized
INFO - 2016-08-13 09:50:01 --> Router Class Initialized
INFO - 2016-08-13 09:50:01 --> Output Class Initialized
INFO - 2016-08-13 09:50:01 --> Security Class Initialized
DEBUG - 2016-08-13 09:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:50:01 --> Input Class Initialized
INFO - 2016-08-13 09:50:01 --> Language Class Initialized
INFO - 2016-08-13 09:50:01 --> Loader Class Initialized
INFO - 2016-08-13 09:50:01 --> Helper loaded: url_helper
INFO - 2016-08-13 09:50:01 --> Helper loaded: date_helper
INFO - 2016-08-13 09:50:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:50:01 --> Database Driver Class Initialized
INFO - 2016-08-13 09:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:50:01 --> Email Class Initialized
INFO - 2016-08-13 09:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:50:01 --> Pagination Class Initialized
INFO - 2016-08-13 09:50:01 --> Model Class Initialized
INFO - 2016-08-13 09:50:01 --> Controller Class Initialized
INFO - 2016-08-13 09:50:01 --> Final output sent to browser
DEBUG - 2016-08-13 09:50:01 --> Total execution time: 0.3327
INFO - 2016-08-13 09:50:48 --> Config Class Initialized
INFO - 2016-08-13 09:50:48 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:50:48 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:50:48 --> Utf8 Class Initialized
INFO - 2016-08-13 09:50:48 --> URI Class Initialized
INFO - 2016-08-13 09:50:48 --> Router Class Initialized
INFO - 2016-08-13 09:50:48 --> Output Class Initialized
INFO - 2016-08-13 09:50:48 --> Security Class Initialized
DEBUG - 2016-08-13 09:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:50:48 --> Input Class Initialized
INFO - 2016-08-13 09:50:48 --> Language Class Initialized
INFO - 2016-08-13 09:50:48 --> Loader Class Initialized
INFO - 2016-08-13 09:50:48 --> Helper loaded: url_helper
INFO - 2016-08-13 09:50:48 --> Helper loaded: date_helper
INFO - 2016-08-13 09:50:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:50:48 --> Database Driver Class Initialized
INFO - 2016-08-13 09:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:50:48 --> Email Class Initialized
INFO - 2016-08-13 09:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:50:48 --> Pagination Class Initialized
INFO - 2016-08-13 09:50:48 --> Model Class Initialized
INFO - 2016-08-13 09:50:49 --> Controller Class Initialized
INFO - 2016-08-13 09:50:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:50:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:50:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:50:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:50:49 --> Final output sent to browser
DEBUG - 2016-08-13 09:50:49 --> Total execution time: 0.4563
INFO - 2016-08-13 09:56:31 --> Config Class Initialized
INFO - 2016-08-13 09:56:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:56:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:56:31 --> Utf8 Class Initialized
INFO - 2016-08-13 09:56:31 --> URI Class Initialized
INFO - 2016-08-13 09:56:31 --> Router Class Initialized
INFO - 2016-08-13 09:56:31 --> Output Class Initialized
INFO - 2016-08-13 09:56:31 --> Security Class Initialized
DEBUG - 2016-08-13 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:56:31 --> Input Class Initialized
INFO - 2016-08-13 09:56:31 --> Language Class Initialized
INFO - 2016-08-13 09:56:31 --> Loader Class Initialized
INFO - 2016-08-13 09:56:31 --> Helper loaded: url_helper
INFO - 2016-08-13 09:56:31 --> Helper loaded: date_helper
INFO - 2016-08-13 09:56:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:56:31 --> Database Driver Class Initialized
INFO - 2016-08-13 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:56:31 --> Email Class Initialized
INFO - 2016-08-13 09:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:56:31 --> Pagination Class Initialized
INFO - 2016-08-13 09:56:31 --> Model Class Initialized
INFO - 2016-08-13 09:56:31 --> Controller Class Initialized
INFO - 2016-08-13 09:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:56:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:56:31 --> Final output sent to browser
DEBUG - 2016-08-13 09:56:31 --> Total execution time: 0.4148
INFO - 2016-08-13 09:56:38 --> Config Class Initialized
INFO - 2016-08-13 09:56:38 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:56:38 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:56:38 --> Utf8 Class Initialized
INFO - 2016-08-13 09:56:38 --> URI Class Initialized
INFO - 2016-08-13 09:56:38 --> Router Class Initialized
INFO - 2016-08-13 09:56:38 --> Output Class Initialized
INFO - 2016-08-13 09:56:38 --> Security Class Initialized
DEBUG - 2016-08-13 09:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:56:38 --> Input Class Initialized
INFO - 2016-08-13 09:56:38 --> Language Class Initialized
INFO - 2016-08-13 09:56:38 --> Loader Class Initialized
INFO - 2016-08-13 09:56:38 --> Helper loaded: url_helper
INFO - 2016-08-13 09:56:38 --> Helper loaded: date_helper
INFO - 2016-08-13 09:56:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:56:38 --> Database Driver Class Initialized
INFO - 2016-08-13 09:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:56:38 --> Email Class Initialized
INFO - 2016-08-13 09:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:56:38 --> Pagination Class Initialized
INFO - 2016-08-13 09:56:38 --> Model Class Initialized
INFO - 2016-08-13 09:56:38 --> Controller Class Initialized
INFO - 2016-08-13 09:56:38 --> Final output sent to browser
DEBUG - 2016-08-13 09:56:38 --> Total execution time: 0.2729
INFO - 2016-08-13 09:56:44 --> Config Class Initialized
INFO - 2016-08-13 09:56:44 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:56:44 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:56:44 --> Utf8 Class Initialized
INFO - 2016-08-13 09:56:44 --> URI Class Initialized
INFO - 2016-08-13 09:56:44 --> Router Class Initialized
INFO - 2016-08-13 09:56:44 --> Output Class Initialized
INFO - 2016-08-13 09:56:44 --> Security Class Initialized
DEBUG - 2016-08-13 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:56:44 --> Input Class Initialized
INFO - 2016-08-13 09:56:44 --> Language Class Initialized
ERROR - 2016-08-13 09:56:44 --> 404 Page Not Found: Undefined/3578110
INFO - 2016-08-13 09:56:51 --> Config Class Initialized
INFO - 2016-08-13 09:56:51 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:56:51 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:56:51 --> Utf8 Class Initialized
INFO - 2016-08-13 09:56:51 --> URI Class Initialized
INFO - 2016-08-13 09:56:51 --> Router Class Initialized
INFO - 2016-08-13 09:56:51 --> Output Class Initialized
INFO - 2016-08-13 09:56:51 --> Security Class Initialized
DEBUG - 2016-08-13 09:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:56:51 --> Input Class Initialized
INFO - 2016-08-13 09:56:51 --> Language Class Initialized
INFO - 2016-08-13 09:56:51 --> Loader Class Initialized
INFO - 2016-08-13 09:56:51 --> Helper loaded: url_helper
INFO - 2016-08-13 09:56:51 --> Helper loaded: date_helper
INFO - 2016-08-13 09:56:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:56:51 --> Database Driver Class Initialized
INFO - 2016-08-13 09:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:56:51 --> Email Class Initialized
INFO - 2016-08-13 09:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:56:51 --> Pagination Class Initialized
INFO - 2016-08-13 09:56:51 --> Model Class Initialized
INFO - 2016-08-13 09:56:51 --> Controller Class Initialized
INFO - 2016-08-13 09:56:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:56:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:56:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:56:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:56:51 --> Final output sent to browser
DEBUG - 2016-08-13 09:56:51 --> Total execution time: 0.3259
INFO - 2016-08-13 09:56:56 --> Config Class Initialized
INFO - 2016-08-13 09:56:56 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:56:56 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:56:56 --> Utf8 Class Initialized
INFO - 2016-08-13 09:56:56 --> URI Class Initialized
INFO - 2016-08-13 09:56:56 --> Router Class Initialized
INFO - 2016-08-13 09:56:56 --> Output Class Initialized
INFO - 2016-08-13 09:56:56 --> Security Class Initialized
DEBUG - 2016-08-13 09:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:56:56 --> Input Class Initialized
INFO - 2016-08-13 09:56:56 --> Language Class Initialized
INFO - 2016-08-13 09:56:56 --> Loader Class Initialized
INFO - 2016-08-13 09:56:56 --> Helper loaded: url_helper
INFO - 2016-08-13 09:56:56 --> Helper loaded: date_helper
INFO - 2016-08-13 09:56:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:56:56 --> Database Driver Class Initialized
INFO - 2016-08-13 09:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:56:56 --> Email Class Initialized
INFO - 2016-08-13 09:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:56:56 --> Pagination Class Initialized
INFO - 2016-08-13 09:56:56 --> Model Class Initialized
INFO - 2016-08-13 09:56:56 --> Controller Class Initialized
INFO - 2016-08-13 09:56:56 --> Final output sent to browser
DEBUG - 2016-08-13 09:56:56 --> Total execution time: 0.2818
INFO - 2016-08-13 09:57:00 --> Config Class Initialized
INFO - 2016-08-13 09:57:00 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:00 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:00 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:00 --> URI Class Initialized
INFO - 2016-08-13 09:57:00 --> Router Class Initialized
INFO - 2016-08-13 09:57:00 --> Output Class Initialized
INFO - 2016-08-13 09:57:00 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:00 --> Input Class Initialized
INFO - 2016-08-13 09:57:00 --> Language Class Initialized
ERROR - 2016-08-13 09:57:00 --> 404 Page Not Found: Undefined/1101021
INFO - 2016-08-13 09:57:18 --> Config Class Initialized
INFO - 2016-08-13 09:57:19 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:19 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:19 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:19 --> URI Class Initialized
INFO - 2016-08-13 09:57:19 --> Router Class Initialized
INFO - 2016-08-13 09:57:19 --> Output Class Initialized
INFO - 2016-08-13 09:57:19 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:19 --> Input Class Initialized
INFO - 2016-08-13 09:57:19 --> Language Class Initialized
INFO - 2016-08-13 09:57:19 --> Loader Class Initialized
INFO - 2016-08-13 09:57:19 --> Helper loaded: url_helper
INFO - 2016-08-13 09:57:19 --> Helper loaded: date_helper
INFO - 2016-08-13 09:57:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:57:19 --> Database Driver Class Initialized
INFO - 2016-08-13 09:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:57:19 --> Email Class Initialized
INFO - 2016-08-13 09:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:57:19 --> Pagination Class Initialized
INFO - 2016-08-13 09:57:19 --> Model Class Initialized
INFO - 2016-08-13 09:57:19 --> Controller Class Initialized
INFO - 2016-08-13 09:57:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:57:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:57:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:57:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:57:19 --> Final output sent to browser
DEBUG - 2016-08-13 09:57:19 --> Total execution time: 0.3315
INFO - 2016-08-13 09:57:25 --> Config Class Initialized
INFO - 2016-08-13 09:57:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:25 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:25 --> URI Class Initialized
INFO - 2016-08-13 09:57:25 --> Router Class Initialized
INFO - 2016-08-13 09:57:25 --> Output Class Initialized
INFO - 2016-08-13 09:57:25 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:25 --> Input Class Initialized
INFO - 2016-08-13 09:57:25 --> Language Class Initialized
INFO - 2016-08-13 09:57:25 --> Loader Class Initialized
INFO - 2016-08-13 09:57:25 --> Helper loaded: url_helper
INFO - 2016-08-13 09:57:25 --> Helper loaded: date_helper
INFO - 2016-08-13 09:57:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:57:25 --> Database Driver Class Initialized
INFO - 2016-08-13 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:57:25 --> Email Class Initialized
INFO - 2016-08-13 09:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:57:25 --> Pagination Class Initialized
INFO - 2016-08-13 09:57:25 --> Model Class Initialized
INFO - 2016-08-13 09:57:25 --> Controller Class Initialized
INFO - 2016-08-13 09:57:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 09:57:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 09:57:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 09:57:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 09:57:25 --> Final output sent to browser
DEBUG - 2016-08-13 09:57:25 --> Total execution time: 0.4518
INFO - 2016-08-13 09:57:29 --> Config Class Initialized
INFO - 2016-08-13 09:57:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:29 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:29 --> URI Class Initialized
INFO - 2016-08-13 09:57:29 --> Router Class Initialized
INFO - 2016-08-13 09:57:29 --> Output Class Initialized
INFO - 2016-08-13 09:57:29 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:29 --> Input Class Initialized
INFO - 2016-08-13 09:57:29 --> Language Class Initialized
INFO - 2016-08-13 09:57:29 --> Loader Class Initialized
INFO - 2016-08-13 09:57:29 --> Helper loaded: url_helper
INFO - 2016-08-13 09:57:29 --> Helper loaded: date_helper
INFO - 2016-08-13 09:57:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:57:29 --> Database Driver Class Initialized
INFO - 2016-08-13 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:57:29 --> Email Class Initialized
INFO - 2016-08-13 09:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:57:29 --> Pagination Class Initialized
INFO - 2016-08-13 09:57:29 --> Model Class Initialized
INFO - 2016-08-13 09:57:29 --> Controller Class Initialized
INFO - 2016-08-13 09:57:29 --> Final output sent to browser
DEBUG - 2016-08-13 09:57:29 --> Total execution time: 0.4427
INFO - 2016-08-13 09:57:32 --> Config Class Initialized
INFO - 2016-08-13 09:57:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:32 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:32 --> URI Class Initialized
INFO - 2016-08-13 09:57:32 --> Router Class Initialized
INFO - 2016-08-13 09:57:32 --> Output Class Initialized
INFO - 2016-08-13 09:57:32 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:32 --> Input Class Initialized
INFO - 2016-08-13 09:57:32 --> Language Class Initialized
INFO - 2016-08-13 09:57:32 --> Loader Class Initialized
INFO - 2016-08-13 09:57:32 --> Helper loaded: url_helper
INFO - 2016-08-13 09:57:32 --> Helper loaded: date_helper
INFO - 2016-08-13 09:57:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:57:32 --> Database Driver Class Initialized
INFO - 2016-08-13 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:57:32 --> Email Class Initialized
INFO - 2016-08-13 09:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:57:32 --> Pagination Class Initialized
INFO - 2016-08-13 09:57:32 --> Model Class Initialized
INFO - 2016-08-13 09:57:32 --> Controller Class Initialized
INFO - 2016-08-13 09:57:32 --> Final output sent to browser
DEBUG - 2016-08-13 09:57:32 --> Total execution time: 0.3194
INFO - 2016-08-13 09:57:34 --> Config Class Initialized
INFO - 2016-08-13 09:57:34 --> Hooks Class Initialized
DEBUG - 2016-08-13 09:57:34 --> UTF-8 Support Enabled
INFO - 2016-08-13 09:57:34 --> Utf8 Class Initialized
INFO - 2016-08-13 09:57:34 --> URI Class Initialized
INFO - 2016-08-13 09:57:35 --> Router Class Initialized
INFO - 2016-08-13 09:57:35 --> Output Class Initialized
INFO - 2016-08-13 09:57:35 --> Security Class Initialized
DEBUG - 2016-08-13 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 09:57:35 --> Input Class Initialized
INFO - 2016-08-13 09:57:35 --> Language Class Initialized
INFO - 2016-08-13 09:57:35 --> Loader Class Initialized
INFO - 2016-08-13 09:57:35 --> Helper loaded: url_helper
INFO - 2016-08-13 09:57:35 --> Helper loaded: date_helper
INFO - 2016-08-13 09:57:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 09:57:35 --> Database Driver Class Initialized
INFO - 2016-08-13 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 09:57:35 --> Email Class Initialized
INFO - 2016-08-13 09:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 09:57:35 --> Pagination Class Initialized
INFO - 2016-08-13 09:57:35 --> Model Class Initialized
INFO - 2016-08-13 09:57:35 --> Controller Class Initialized
INFO - 2016-08-13 09:57:35 --> Final output sent to browser
DEBUG - 2016-08-13 09:57:35 --> Total execution time: 0.2788
INFO - 2016-08-13 10:19:13 --> Config Class Initialized
INFO - 2016-08-13 10:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:19:14 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:19:14 --> Utf8 Class Initialized
INFO - 2016-08-13 10:19:14 --> URI Class Initialized
INFO - 2016-08-13 10:19:14 --> Router Class Initialized
INFO - 2016-08-13 10:19:14 --> Output Class Initialized
INFO - 2016-08-13 10:19:14 --> Security Class Initialized
DEBUG - 2016-08-13 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:19:14 --> Input Class Initialized
INFO - 2016-08-13 10:19:14 --> Language Class Initialized
INFO - 2016-08-13 10:19:14 --> Loader Class Initialized
INFO - 2016-08-13 10:19:14 --> Helper loaded: url_helper
INFO - 2016-08-13 10:19:14 --> Helper loaded: date_helper
INFO - 2016-08-13 10:19:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:19:14 --> Database Driver Class Initialized
INFO - 2016-08-13 10:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:19:14 --> Email Class Initialized
INFO - 2016-08-13 10:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:19:14 --> Pagination Class Initialized
INFO - 2016-08-13 10:19:14 --> Model Class Initialized
INFO - 2016-08-13 10:19:14 --> Controller Class Initialized
INFO - 2016-08-13 10:19:14 --> Final output sent to browser
DEBUG - 2016-08-13 10:19:14 --> Total execution time: 0.4720
INFO - 2016-08-13 10:20:45 --> Config Class Initialized
INFO - 2016-08-13 10:20:45 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:20:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:20:45 --> Utf8 Class Initialized
INFO - 2016-08-13 10:20:45 --> URI Class Initialized
INFO - 2016-08-13 10:20:45 --> Router Class Initialized
INFO - 2016-08-13 10:20:45 --> Output Class Initialized
INFO - 2016-08-13 10:20:45 --> Security Class Initialized
DEBUG - 2016-08-13 10:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:20:45 --> Input Class Initialized
INFO - 2016-08-13 10:20:45 --> Language Class Initialized
INFO - 2016-08-13 10:20:45 --> Loader Class Initialized
INFO - 2016-08-13 10:20:45 --> Helper loaded: url_helper
INFO - 2016-08-13 10:20:45 --> Helper loaded: date_helper
INFO - 2016-08-13 10:20:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:20:45 --> Database Driver Class Initialized
INFO - 2016-08-13 10:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:20:45 --> Email Class Initialized
INFO - 2016-08-13 10:20:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:20:46 --> Pagination Class Initialized
INFO - 2016-08-13 10:20:46 --> Model Class Initialized
INFO - 2016-08-13 10:20:46 --> Controller Class Initialized
DEBUG - 2016-08-13 10:20:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 10:20:51 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-13 10:20:51 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:51 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:20:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-13 10:20:57 --> Config Class Initialized
INFO - 2016-08-13 10:20:57 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:20:57 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:20:57 --> Utf8 Class Initialized
INFO - 2016-08-13 10:20:57 --> URI Class Initialized
INFO - 2016-08-13 10:20:57 --> Router Class Initialized
INFO - 2016-08-13 10:20:57 --> Output Class Initialized
INFO - 2016-08-13 10:20:57 --> Security Class Initialized
DEBUG - 2016-08-13 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:20:57 --> Input Class Initialized
INFO - 2016-08-13 10:20:57 --> Language Class Initialized
ERROR - 2016-08-13 10:20:57 --> 404 Page Not Found: Home/order
INFO - 2016-08-13 10:21:02 --> Config Class Initialized
INFO - 2016-08-13 10:21:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:21:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:21:02 --> Utf8 Class Initialized
INFO - 2016-08-13 10:21:02 --> URI Class Initialized
INFO - 2016-08-13 10:21:02 --> Router Class Initialized
INFO - 2016-08-13 10:21:02 --> Output Class Initialized
INFO - 2016-08-13 10:21:02 --> Security Class Initialized
DEBUG - 2016-08-13 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:21:02 --> Input Class Initialized
INFO - 2016-08-13 10:21:02 --> Language Class Initialized
INFO - 2016-08-13 10:21:02 --> Loader Class Initialized
INFO - 2016-08-13 10:21:02 --> Helper loaded: url_helper
INFO - 2016-08-13 10:21:02 --> Helper loaded: date_helper
INFO - 2016-08-13 10:21:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:21:03 --> Database Driver Class Initialized
INFO - 2016-08-13 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:21:03 --> Email Class Initialized
INFO - 2016-08-13 10:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:21:03 --> Pagination Class Initialized
INFO - 2016-08-13 10:21:03 --> Model Class Initialized
INFO - 2016-08-13 10:21:03 --> Controller Class Initialized
INFO - 2016-08-13 10:21:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:21:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:21:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 10:21:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:21:03 --> Final output sent to browser
DEBUG - 2016-08-13 10:21:03 --> Total execution time: 0.3309
INFO - 2016-08-13 10:23:40 --> Config Class Initialized
INFO - 2016-08-13 10:23:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:23:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:23:40 --> Utf8 Class Initialized
INFO - 2016-08-13 10:23:40 --> URI Class Initialized
INFO - 2016-08-13 10:23:40 --> Router Class Initialized
INFO - 2016-08-13 10:23:40 --> Output Class Initialized
INFO - 2016-08-13 10:23:40 --> Security Class Initialized
DEBUG - 2016-08-13 10:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:23:40 --> Input Class Initialized
INFO - 2016-08-13 10:23:40 --> Language Class Initialized
INFO - 2016-08-13 10:23:40 --> Loader Class Initialized
INFO - 2016-08-13 10:23:40 --> Helper loaded: url_helper
INFO - 2016-08-13 10:23:40 --> Helper loaded: date_helper
INFO - 2016-08-13 10:23:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:23:40 --> Database Driver Class Initialized
INFO - 2016-08-13 10:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:23:40 --> Email Class Initialized
INFO - 2016-08-13 10:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:23:40 --> Pagination Class Initialized
INFO - 2016-08-13 10:23:40 --> Model Class Initialized
INFO - 2016-08-13 10:23:40 --> Controller Class Initialized
INFO - 2016-08-13 10:23:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:23:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:23:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 10:23:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:23:40 --> Final output sent to browser
DEBUG - 2016-08-13 10:23:40 --> Total execution time: 0.7017
INFO - 2016-08-13 10:23:41 --> Config Class Initialized
INFO - 2016-08-13 10:23:41 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:23:41 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:23:41 --> Utf8 Class Initialized
INFO - 2016-08-13 10:23:41 --> URI Class Initialized
INFO - 2016-08-13 10:23:41 --> Router Class Initialized
INFO - 2016-08-13 10:23:41 --> Output Class Initialized
INFO - 2016-08-13 10:23:41 --> Security Class Initialized
DEBUG - 2016-08-13 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:23:41 --> Input Class Initialized
INFO - 2016-08-13 10:23:41 --> Language Class Initialized
ERROR - 2016-08-13 10:23:41 --> 404 Page Not Found: Assets/css
INFO - 2016-08-13 10:23:50 --> Config Class Initialized
INFO - 2016-08-13 10:23:50 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:23:50 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:23:50 --> Utf8 Class Initialized
INFO - 2016-08-13 10:23:50 --> URI Class Initialized
INFO - 2016-08-13 10:23:50 --> Router Class Initialized
INFO - 2016-08-13 10:23:50 --> Output Class Initialized
INFO - 2016-08-13 10:23:50 --> Security Class Initialized
DEBUG - 2016-08-13 10:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:23:50 --> Input Class Initialized
INFO - 2016-08-13 10:23:50 --> Language Class Initialized
INFO - 2016-08-13 10:23:50 --> Loader Class Initialized
INFO - 2016-08-13 10:23:50 --> Helper loaded: url_helper
INFO - 2016-08-13 10:23:50 --> Helper loaded: date_helper
INFO - 2016-08-13 10:23:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:23:50 --> Database Driver Class Initialized
INFO - 2016-08-13 10:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:23:50 --> Email Class Initialized
INFO - 2016-08-13 10:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:23:50 --> Pagination Class Initialized
INFO - 2016-08-13 10:23:50 --> Model Class Initialized
INFO - 2016-08-13 10:23:50 --> Controller Class Initialized
INFO - 2016-08-13 10:23:50 --> Final output sent to browser
DEBUG - 2016-08-13 10:23:50 --> Total execution time: 0.2909
INFO - 2016-08-13 10:23:53 --> Config Class Initialized
INFO - 2016-08-13 10:23:53 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:23:53 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:23:53 --> Utf8 Class Initialized
INFO - 2016-08-13 10:23:53 --> URI Class Initialized
INFO - 2016-08-13 10:23:53 --> Router Class Initialized
INFO - 2016-08-13 10:23:53 --> Output Class Initialized
INFO - 2016-08-13 10:23:53 --> Security Class Initialized
DEBUG - 2016-08-13 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:23:53 --> Input Class Initialized
INFO - 2016-08-13 10:23:53 --> Language Class Initialized
INFO - 2016-08-13 10:23:53 --> Loader Class Initialized
INFO - 2016-08-13 10:23:53 --> Helper loaded: url_helper
INFO - 2016-08-13 10:23:53 --> Helper loaded: date_helper
INFO - 2016-08-13 10:23:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:23:53 --> Database Driver Class Initialized
INFO - 2016-08-13 10:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:23:53 --> Email Class Initialized
INFO - 2016-08-13 10:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:23:53 --> Pagination Class Initialized
INFO - 2016-08-13 10:23:53 --> Model Class Initialized
INFO - 2016-08-13 10:23:53 --> Controller Class Initialized
INFO - 2016-08-13 10:23:53 --> Final output sent to browser
DEBUG - 2016-08-13 10:23:53 --> Total execution time: 0.2913
INFO - 2016-08-13 10:26:05 --> Config Class Initialized
INFO - 2016-08-13 10:26:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:26:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:26:06 --> Utf8 Class Initialized
INFO - 2016-08-13 10:26:06 --> URI Class Initialized
INFO - 2016-08-13 10:26:06 --> Router Class Initialized
INFO - 2016-08-13 10:26:06 --> Output Class Initialized
INFO - 2016-08-13 10:26:06 --> Security Class Initialized
DEBUG - 2016-08-13 10:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:26:06 --> Input Class Initialized
INFO - 2016-08-13 10:26:06 --> Language Class Initialized
INFO - 2016-08-13 10:26:06 --> Loader Class Initialized
INFO - 2016-08-13 10:26:06 --> Helper loaded: url_helper
INFO - 2016-08-13 10:26:06 --> Helper loaded: date_helper
INFO - 2016-08-13 10:26:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:26:06 --> Database Driver Class Initialized
INFO - 2016-08-13 10:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:26:06 --> Email Class Initialized
INFO - 2016-08-13 10:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:26:06 --> Pagination Class Initialized
INFO - 2016-08-13 10:26:06 --> Model Class Initialized
INFO - 2016-08-13 10:26:06 --> Controller Class Initialized
DEBUG - 2016-08-13 10:26:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 10:26:11 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-13 10:26:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-13 10:26:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-13 10:26:17 --> Config Class Initialized
INFO - 2016-08-13 10:26:17 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:26:17 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:26:17 --> Utf8 Class Initialized
INFO - 2016-08-13 10:26:17 --> URI Class Initialized
INFO - 2016-08-13 10:26:17 --> Router Class Initialized
INFO - 2016-08-13 10:26:17 --> Output Class Initialized
INFO - 2016-08-13 10:26:17 --> Security Class Initialized
DEBUG - 2016-08-13 10:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:26:17 --> Input Class Initialized
INFO - 2016-08-13 10:26:17 --> Language Class Initialized
INFO - 2016-08-13 10:26:17 --> Loader Class Initialized
INFO - 2016-08-13 10:26:17 --> Helper loaded: url_helper
INFO - 2016-08-13 10:26:17 --> Helper loaded: date_helper
INFO - 2016-08-13 10:26:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:26:17 --> Database Driver Class Initialized
INFO - 2016-08-13 10:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:26:17 --> Email Class Initialized
INFO - 2016-08-13 10:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:26:17 --> Pagination Class Initialized
INFO - 2016-08-13 10:26:17 --> Model Class Initialized
INFO - 2016-08-13 10:26:17 --> Controller Class Initialized
INFO - 2016-08-13 10:26:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:26:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:26:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 10:26:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:26:17 --> Final output sent to browser
DEBUG - 2016-08-13 10:26:17 --> Total execution time: 0.3426
INFO - 2016-08-13 10:28:46 --> Config Class Initialized
INFO - 2016-08-13 10:28:46 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:28:46 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:28:46 --> Utf8 Class Initialized
INFO - 2016-08-13 10:28:46 --> URI Class Initialized
INFO - 2016-08-13 10:28:46 --> Router Class Initialized
INFO - 2016-08-13 10:28:46 --> Output Class Initialized
INFO - 2016-08-13 10:28:46 --> Security Class Initialized
DEBUG - 2016-08-13 10:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:28:46 --> Input Class Initialized
INFO - 2016-08-13 10:28:47 --> Language Class Initialized
INFO - 2016-08-13 10:28:47 --> Loader Class Initialized
INFO - 2016-08-13 10:28:47 --> Helper loaded: url_helper
INFO - 2016-08-13 10:28:47 --> Helper loaded: date_helper
INFO - 2016-08-13 10:28:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:28:47 --> Database Driver Class Initialized
INFO - 2016-08-13 10:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:28:47 --> Email Class Initialized
INFO - 2016-08-13 10:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:28:47 --> Pagination Class Initialized
INFO - 2016-08-13 10:28:47 --> Model Class Initialized
INFO - 2016-08-13 10:28:47 --> Controller Class Initialized
INFO - 2016-08-13 10:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 10:28:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:28:47 --> Final output sent to browser
DEBUG - 2016-08-13 10:28:47 --> Total execution time: 0.4307
INFO - 2016-08-13 10:29:52 --> Config Class Initialized
INFO - 2016-08-13 10:29:52 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:29:52 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:29:52 --> Utf8 Class Initialized
INFO - 2016-08-13 10:29:52 --> URI Class Initialized
INFO - 2016-08-13 10:29:52 --> Router Class Initialized
INFO - 2016-08-13 10:29:52 --> Output Class Initialized
INFO - 2016-08-13 10:29:52 --> Security Class Initialized
DEBUG - 2016-08-13 10:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:29:52 --> Input Class Initialized
INFO - 2016-08-13 10:29:52 --> Language Class Initialized
INFO - 2016-08-13 10:29:52 --> Loader Class Initialized
INFO - 2016-08-13 10:29:52 --> Helper loaded: url_helper
INFO - 2016-08-13 10:29:52 --> Helper loaded: date_helper
INFO - 2016-08-13 10:29:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:29:52 --> Database Driver Class Initialized
INFO - 2016-08-13 10:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:29:52 --> Email Class Initialized
INFO - 2016-08-13 10:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:29:52 --> Pagination Class Initialized
INFO - 2016-08-13 10:29:52 --> Model Class Initialized
INFO - 2016-08-13 10:29:53 --> Controller Class Initialized
INFO - 2016-08-13 10:29:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:29:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:29:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 10:29:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:29:53 --> Final output sent to browser
DEBUG - 2016-08-13 10:29:53 --> Total execution time: 0.3773
INFO - 2016-08-13 10:31:20 --> Config Class Initialized
INFO - 2016-08-13 10:31:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:31:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:20 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:20 --> URI Class Initialized
INFO - 2016-08-13 10:31:20 --> Router Class Initialized
INFO - 2016-08-13 10:31:20 --> Output Class Initialized
INFO - 2016-08-13 10:31:20 --> Security Class Initialized
DEBUG - 2016-08-13 10:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:20 --> Input Class Initialized
INFO - 2016-08-13 10:31:20 --> Language Class Initialized
INFO - 2016-08-13 10:31:20 --> Loader Class Initialized
INFO - 2016-08-13 10:31:20 --> Helper loaded: url_helper
INFO - 2016-08-13 10:31:20 --> Helper loaded: date_helper
INFO - 2016-08-13 10:31:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:31:20 --> Database Driver Class Initialized
INFO - 2016-08-13 10:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:31:20 --> Email Class Initialized
INFO - 2016-08-13 10:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:31:20 --> Pagination Class Initialized
INFO - 2016-08-13 10:31:20 --> Model Class Initialized
INFO - 2016-08-13 10:31:20 --> Controller Class Initialized
INFO - 2016-08-13 10:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 10:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:31:20 --> Final output sent to browser
DEBUG - 2016-08-13 10:31:20 --> Total execution time: 0.3458
INFO - 2016-08-13 10:31:23 --> Config Class Initialized
INFO - 2016-08-13 10:31:23 --> Config Class Initialized
INFO - 2016-08-13 10:31:23 --> Hooks Class Initialized
INFO - 2016-08-13 10:31:23 --> Hooks Class Initialized
INFO - 2016-08-13 10:31:23 --> Config Class Initialized
INFO - 2016-08-13 10:31:23 --> Config Class Initialized
INFO - 2016-08-13 10:31:23 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:23 --> Hooks Class Initialized
INFO - 2016-08-13 10:31:23 --> Utf8 Class Initialized
DEBUG - 2016-08-13 10:31:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-13 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:23 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:23 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:23 --> URI Class Initialized
DEBUG - 2016-08-13 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:23 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:23 --> URI Class Initialized
INFO - 2016-08-13 10:31:23 --> URI Class Initialized
INFO - 2016-08-13 10:31:23 --> Router Class Initialized
INFO - 2016-08-13 10:31:23 --> URI Class Initialized
INFO - 2016-08-13 10:31:23 --> Output Class Initialized
INFO - 2016-08-13 10:31:23 --> Router Class Initialized
INFO - 2016-08-13 10:31:23 --> Config Class Initialized
INFO - 2016-08-13 10:31:23 --> Hooks Class Initialized
INFO - 2016-08-13 10:31:23 --> Router Class Initialized
INFO - 2016-08-13 10:31:23 --> Router Class Initialized
INFO - 2016-08-13 10:31:23 --> Output Class Initialized
INFO - 2016-08-13 10:31:23 --> Security Class Initialized
INFO - 2016-08-13 10:31:23 --> Security Class Initialized
INFO - 2016-08-13 10:31:23 --> Output Class Initialized
INFO - 2016-08-13 10:31:23 --> Output Class Initialized
DEBUG - 2016-08-13 10:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-13 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:23 --> Input Class Initialized
INFO - 2016-08-13 10:31:23 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:23 --> Security Class Initialized
DEBUG - 2016-08-13 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:23 --> Security Class Initialized
INFO - 2016-08-13 10:31:23 --> Input Class Initialized
INFO - 2016-08-13 10:31:23 --> Language Class Initialized
INFO - 2016-08-13 10:31:23 --> URI Class Initialized
DEBUG - 2016-08-13 10:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-13 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:23 --> Input Class Initialized
INFO - 2016-08-13 10:31:23 --> Language Class Initialized
INFO - 2016-08-13 10:31:23 --> Input Class Initialized
ERROR - 2016-08-13 10:31:23 --> 404 Page Not Found: Assets/css
INFO - 2016-08-13 10:31:23 --> Router Class Initialized
ERROR - 2016-08-13 10:31:24 --> 404 Page Not Found: Assets/css
INFO - 2016-08-13 10:31:24 --> Output Class Initialized
INFO - 2016-08-13 10:31:24 --> Language Class Initialized
INFO - 2016-08-13 10:31:24 --> Language Class Initialized
INFO - 2016-08-13 10:31:24 --> Security Class Initialized
ERROR - 2016-08-13 10:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-13 10:31:24 --> 404 Page Not Found: Assets/css
DEBUG - 2016-08-13 10:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:24 --> Input Class Initialized
INFO - 2016-08-13 10:31:24 --> Language Class Initialized
INFO - 2016-08-13 10:31:24 --> Loader Class Initialized
INFO - 2016-08-13 10:31:24 --> Helper loaded: url_helper
INFO - 2016-08-13 10:31:24 --> Helper loaded: date_helper
INFO - 2016-08-13 10:31:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:31:24 --> Database Driver Class Initialized
INFO - 2016-08-13 10:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:31:24 --> Email Class Initialized
INFO - 2016-08-13 10:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:31:24 --> Pagination Class Initialized
INFO - 2016-08-13 10:31:24 --> Model Class Initialized
INFO - 2016-08-13 10:31:24 --> Controller Class Initialized
INFO - 2016-08-13 10:31:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 10:31:24 --> Final output sent to browser
DEBUG - 2016-08-13 10:31:24 --> Total execution time: 0.3883
INFO - 2016-08-13 10:31:29 --> Config Class Initialized
INFO - 2016-08-13 10:31:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:31:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:29 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:29 --> URI Class Initialized
INFO - 2016-08-13 10:31:29 --> Router Class Initialized
INFO - 2016-08-13 10:31:29 --> Output Class Initialized
INFO - 2016-08-13 10:31:29 --> Security Class Initialized
DEBUG - 2016-08-13 10:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:29 --> Input Class Initialized
INFO - 2016-08-13 10:31:29 --> Language Class Initialized
INFO - 2016-08-13 10:31:29 --> Loader Class Initialized
INFO - 2016-08-13 10:31:29 --> Helper loaded: url_helper
INFO - 2016-08-13 10:31:29 --> Helper loaded: date_helper
INFO - 2016-08-13 10:31:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:31:29 --> Database Driver Class Initialized
INFO - 2016-08-13 10:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:31:29 --> Email Class Initialized
INFO - 2016-08-13 10:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:31:29 --> Pagination Class Initialized
INFO - 2016-08-13 10:31:29 --> Model Class Initialized
INFO - 2016-08-13 10:31:29 --> Controller Class Initialized
INFO - 2016-08-13 10:31:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 10:31:29 --> Final output sent to browser
DEBUG - 2016-08-13 10:31:29 --> Total execution time: 0.3134
INFO - 2016-08-13 10:31:54 --> Config Class Initialized
INFO - 2016-08-13 10:31:54 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:31:54 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:31:54 --> Utf8 Class Initialized
INFO - 2016-08-13 10:31:54 --> URI Class Initialized
INFO - 2016-08-13 10:31:54 --> Router Class Initialized
INFO - 2016-08-13 10:31:54 --> Output Class Initialized
INFO - 2016-08-13 10:31:54 --> Security Class Initialized
DEBUG - 2016-08-13 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:31:54 --> Input Class Initialized
INFO - 2016-08-13 10:31:54 --> Language Class Initialized
INFO - 2016-08-13 10:31:54 --> Loader Class Initialized
INFO - 2016-08-13 10:31:54 --> Helper loaded: url_helper
INFO - 2016-08-13 10:31:54 --> Helper loaded: date_helper
INFO - 2016-08-13 10:31:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:31:54 --> Database Driver Class Initialized
INFO - 2016-08-13 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:31:54 --> Email Class Initialized
INFO - 2016-08-13 10:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:31:54 --> Pagination Class Initialized
INFO - 2016-08-13 10:31:54 --> Model Class Initialized
INFO - 2016-08-13 10:31:54 --> Controller Class Initialized
INFO - 2016-08-13 10:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 10:31:54 --> Final output sent to browser
DEBUG - 2016-08-13 10:31:54 --> Total execution time: 0.3191
INFO - 2016-08-13 10:33:18 --> Config Class Initialized
INFO - 2016-08-13 10:33:18 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:33:18 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:33:18 --> Utf8 Class Initialized
INFO - 2016-08-13 10:33:18 --> URI Class Initialized
INFO - 2016-08-13 10:33:18 --> Router Class Initialized
INFO - 2016-08-13 10:33:19 --> Output Class Initialized
INFO - 2016-08-13 10:33:19 --> Security Class Initialized
DEBUG - 2016-08-13 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:33:19 --> Input Class Initialized
INFO - 2016-08-13 10:33:19 --> Language Class Initialized
INFO - 2016-08-13 10:33:19 --> Loader Class Initialized
INFO - 2016-08-13 10:33:19 --> Helper loaded: url_helper
INFO - 2016-08-13 10:33:19 --> Helper loaded: date_helper
INFO - 2016-08-13 10:33:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:33:19 --> Database Driver Class Initialized
INFO - 2016-08-13 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:33:19 --> Email Class Initialized
INFO - 2016-08-13 10:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:33:19 --> Pagination Class Initialized
INFO - 2016-08-13 10:33:19 --> Model Class Initialized
INFO - 2016-08-13 10:33:19 --> Controller Class Initialized
INFO - 2016-08-13 10:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 10:33:19 --> Final output sent to browser
DEBUG - 2016-08-13 10:33:19 --> Total execution time: 0.3152
INFO - 2016-08-13 10:33:25 --> Config Class Initialized
INFO - 2016-08-13 10:33:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:33:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:33:25 --> Utf8 Class Initialized
INFO - 2016-08-13 10:33:25 --> URI Class Initialized
INFO - 2016-08-13 10:33:25 --> Router Class Initialized
INFO - 2016-08-13 10:33:25 --> Output Class Initialized
INFO - 2016-08-13 10:33:25 --> Security Class Initialized
DEBUG - 2016-08-13 10:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:33:25 --> Input Class Initialized
INFO - 2016-08-13 10:33:25 --> Language Class Initialized
INFO - 2016-08-13 10:33:25 --> Loader Class Initialized
INFO - 2016-08-13 10:33:25 --> Helper loaded: url_helper
INFO - 2016-08-13 10:33:25 --> Helper loaded: date_helper
INFO - 2016-08-13 10:33:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:33:25 --> Database Driver Class Initialized
INFO - 2016-08-13 10:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:33:25 --> Email Class Initialized
INFO - 2016-08-13 10:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:33:25 --> Pagination Class Initialized
INFO - 2016-08-13 10:33:25 --> Model Class Initialized
INFO - 2016-08-13 10:33:25 --> Controller Class Initialized
INFO - 2016-08-13 10:33:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 10:33:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 10:33:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 10:33:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 10:33:25 --> Final output sent to browser
DEBUG - 2016-08-13 10:33:25 --> Total execution time: 0.3623
INFO - 2016-08-13 10:33:30 --> Config Class Initialized
INFO - 2016-08-13 10:33:30 --> Hooks Class Initialized
DEBUG - 2016-08-13 10:33:30 --> UTF-8 Support Enabled
INFO - 2016-08-13 10:33:30 --> Utf8 Class Initialized
INFO - 2016-08-13 10:33:30 --> URI Class Initialized
INFO - 2016-08-13 10:33:30 --> Router Class Initialized
INFO - 2016-08-13 10:33:30 --> Output Class Initialized
INFO - 2016-08-13 10:33:30 --> Security Class Initialized
DEBUG - 2016-08-13 10:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 10:33:30 --> Input Class Initialized
INFO - 2016-08-13 10:33:30 --> Language Class Initialized
INFO - 2016-08-13 10:33:30 --> Loader Class Initialized
INFO - 2016-08-13 10:33:30 --> Helper loaded: url_helper
INFO - 2016-08-13 10:33:30 --> Helper loaded: date_helper
INFO - 2016-08-13 10:33:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 10:33:30 --> Database Driver Class Initialized
INFO - 2016-08-13 10:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 10:33:30 --> Email Class Initialized
INFO - 2016-08-13 10:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 10:33:30 --> Pagination Class Initialized
INFO - 2016-08-13 10:33:30 --> Model Class Initialized
INFO - 2016-08-13 10:33:30 --> Controller Class Initialized
INFO - 2016-08-13 10:33:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 10:33:30 --> Final output sent to browser
DEBUG - 2016-08-13 10:33:30 --> Total execution time: 0.3243
INFO - 2016-08-13 11:38:30 --> Config Class Initialized
INFO - 2016-08-13 11:38:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 11:38:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 11:38:31 --> Utf8 Class Initialized
INFO - 2016-08-13 11:38:31 --> URI Class Initialized
INFO - 2016-08-13 11:38:31 --> Router Class Initialized
INFO - 2016-08-13 11:38:31 --> Output Class Initialized
INFO - 2016-08-13 11:38:31 --> Security Class Initialized
DEBUG - 2016-08-13 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 11:38:31 --> Input Class Initialized
INFO - 2016-08-13 11:38:31 --> Language Class Initialized
INFO - 2016-08-13 11:38:31 --> Loader Class Initialized
INFO - 2016-08-13 11:38:31 --> Helper loaded: url_helper
INFO - 2016-08-13 11:38:31 --> Helper loaded: date_helper
INFO - 2016-08-13 11:38:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 11:38:31 --> Database Driver Class Initialized
INFO - 2016-08-13 11:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 11:38:31 --> Email Class Initialized
INFO - 2016-08-13 11:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 11:38:31 --> Pagination Class Initialized
INFO - 2016-08-13 11:38:31 --> Model Class Initialized
INFO - 2016-08-13 11:38:31 --> Controller Class Initialized
DEBUG - 2016-08-13 11:38:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 11:38:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 11:38:31 --> Helper loaded: cookie_helper
INFO - 2016-08-13 11:38:31 --> Helper loaded: language_helper
DEBUG - 2016-08-13 11:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:31 --> Model Class Initialized
INFO - 2016-08-13 11:38:31 --> Config Class Initialized
INFO - 2016-08-13 11:38:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 11:38:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 11:38:31 --> Utf8 Class Initialized
INFO - 2016-08-13 11:38:31 --> URI Class Initialized
INFO - 2016-08-13 11:38:31 --> Router Class Initialized
INFO - 2016-08-13 11:38:31 --> Output Class Initialized
INFO - 2016-08-13 11:38:31 --> Security Class Initialized
DEBUG - 2016-08-13 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 11:38:31 --> Input Class Initialized
INFO - 2016-08-13 11:38:31 --> Language Class Initialized
INFO - 2016-08-13 11:38:31 --> Loader Class Initialized
INFO - 2016-08-13 11:38:31 --> Helper loaded: url_helper
INFO - 2016-08-13 11:38:31 --> Helper loaded: date_helper
INFO - 2016-08-13 11:38:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 11:38:32 --> Database Driver Class Initialized
INFO - 2016-08-13 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 11:38:32 --> Email Class Initialized
INFO - 2016-08-13 11:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 11:38:32 --> Pagination Class Initialized
INFO - 2016-08-13 11:38:32 --> Model Class Initialized
INFO - 2016-08-13 11:38:32 --> Controller Class Initialized
DEBUG - 2016-08-13 11:38:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 11:38:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 11:38:32 --> Helper loaded: cookie_helper
INFO - 2016-08-13 11:38:32 --> Helper loaded: language_helper
DEBUG - 2016-08-13 11:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:32 --> Model Class Initialized
INFO - 2016-08-13 11:38:32 --> Helper loaded: form_helper
INFO - 2016-08-13 11:38:32 --> Form Validation Class Initialized
INFO - 2016-08-13 11:38:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-13 11:38:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-13 11:38:32 --> Final output sent to browser
DEBUG - 2016-08-13 11:38:32 --> Total execution time: 0.8049
INFO - 2016-08-13 11:38:40 --> Config Class Initialized
INFO - 2016-08-13 11:38:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 11:38:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 11:38:40 --> Utf8 Class Initialized
INFO - 2016-08-13 11:38:40 --> URI Class Initialized
INFO - 2016-08-13 11:38:40 --> Router Class Initialized
INFO - 2016-08-13 11:38:40 --> Output Class Initialized
INFO - 2016-08-13 11:38:40 --> Security Class Initialized
DEBUG - 2016-08-13 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 11:38:40 --> Input Class Initialized
INFO - 2016-08-13 11:38:40 --> Language Class Initialized
INFO - 2016-08-13 11:38:40 --> Loader Class Initialized
INFO - 2016-08-13 11:38:40 --> Helper loaded: url_helper
INFO - 2016-08-13 11:38:40 --> Helper loaded: date_helper
INFO - 2016-08-13 11:38:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 11:38:40 --> Database Driver Class Initialized
INFO - 2016-08-13 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 11:38:40 --> Email Class Initialized
INFO - 2016-08-13 11:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 11:38:40 --> Pagination Class Initialized
INFO - 2016-08-13 11:38:40 --> Model Class Initialized
INFO - 2016-08-13 11:38:40 --> Controller Class Initialized
DEBUG - 2016-08-13 11:38:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 11:38:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 11:38:40 --> Helper loaded: cookie_helper
INFO - 2016-08-13 11:38:40 --> Helper loaded: language_helper
DEBUG - 2016-08-13 11:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:40 --> Model Class Initialized
INFO - 2016-08-13 11:38:40 --> Helper loaded: form_helper
INFO - 2016-08-13 11:38:40 --> Form Validation Class Initialized
INFO - 2016-08-13 11:38:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-13 11:38:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 11:38:41 --> Config Class Initialized
INFO - 2016-08-13 11:38:41 --> Hooks Class Initialized
DEBUG - 2016-08-13 11:38:41 --> UTF-8 Support Enabled
INFO - 2016-08-13 11:38:41 --> Utf8 Class Initialized
INFO - 2016-08-13 11:38:41 --> URI Class Initialized
INFO - 2016-08-13 11:38:41 --> Router Class Initialized
INFO - 2016-08-13 11:38:41 --> Output Class Initialized
INFO - 2016-08-13 11:38:41 --> Security Class Initialized
DEBUG - 2016-08-13 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 11:38:41 --> Input Class Initialized
INFO - 2016-08-13 11:38:41 --> Language Class Initialized
INFO - 2016-08-13 11:38:41 --> Loader Class Initialized
INFO - 2016-08-13 11:38:41 --> Helper loaded: url_helper
INFO - 2016-08-13 11:38:41 --> Helper loaded: date_helper
INFO - 2016-08-13 11:38:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 11:38:41 --> Database Driver Class Initialized
INFO - 2016-08-13 11:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 11:38:41 --> Email Class Initialized
INFO - 2016-08-13 11:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 11:38:41 --> Pagination Class Initialized
INFO - 2016-08-13 11:38:41 --> Model Class Initialized
INFO - 2016-08-13 11:38:41 --> Controller Class Initialized
DEBUG - 2016-08-13 11:38:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 11:38:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 11:38:41 --> Helper loaded: cookie_helper
INFO - 2016-08-13 11:38:41 --> Helper loaded: language_helper
DEBUG - 2016-08-13 11:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 11:38:41 --> Model Class Initialized
INFO - 2016-08-13 11:38:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 11:38:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 11:38:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 11:38:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 11:38:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 11:38:41 --> Final output sent to browser
DEBUG - 2016-08-13 11:38:41 --> Total execution time: 0.7619
INFO - 2016-08-13 12:21:37 --> Config Class Initialized
INFO - 2016-08-13 12:21:37 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:21:37 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:21:37 --> Utf8 Class Initialized
INFO - 2016-08-13 12:21:37 --> URI Class Initialized
INFO - 2016-08-13 12:21:37 --> Router Class Initialized
INFO - 2016-08-13 12:21:37 --> Output Class Initialized
INFO - 2016-08-13 12:21:37 --> Security Class Initialized
DEBUG - 2016-08-13 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:21:37 --> Input Class Initialized
INFO - 2016-08-13 12:21:37 --> Language Class Initialized
ERROR - 2016-08-13 12:21:37 --> 404 Page Not Found: Home/upload
INFO - 2016-08-13 12:22:18 --> Config Class Initialized
INFO - 2016-08-13 12:22:18 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:22:18 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:22:18 --> Utf8 Class Initialized
INFO - 2016-08-13 12:22:18 --> URI Class Initialized
INFO - 2016-08-13 12:22:18 --> Router Class Initialized
INFO - 2016-08-13 12:22:19 --> Output Class Initialized
INFO - 2016-08-13 12:22:19 --> Security Class Initialized
DEBUG - 2016-08-13 12:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:22:19 --> Input Class Initialized
INFO - 2016-08-13 12:22:19 --> Language Class Initialized
INFO - 2016-08-13 12:22:19 --> Loader Class Initialized
INFO - 2016-08-13 12:22:19 --> Helper loaded: url_helper
INFO - 2016-08-13 12:22:19 --> Helper loaded: date_helper
INFO - 2016-08-13 12:22:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:22:19 --> Database Driver Class Initialized
INFO - 2016-08-13 12:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:22:19 --> Email Class Initialized
INFO - 2016-08-13 12:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:22:19 --> Pagination Class Initialized
INFO - 2016-08-13 12:22:19 --> Model Class Initialized
INFO - 2016-08-13 12:22:19 --> Controller Class Initialized
INFO - 2016-08-13 12:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 12:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 12:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 12:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 12:22:19 --> Final output sent to browser
DEBUG - 2016-08-13 12:22:19 --> Total execution time: 0.5185
INFO - 2016-08-13 12:24:24 --> Config Class Initialized
INFO - 2016-08-13 12:24:24 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:24 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:24 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:24 --> URI Class Initialized
INFO - 2016-08-13 12:24:24 --> Router Class Initialized
INFO - 2016-08-13 12:24:24 --> Output Class Initialized
INFO - 2016-08-13 12:24:24 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:25 --> Input Class Initialized
INFO - 2016-08-13 12:24:25 --> Language Class Initialized
INFO - 2016-08-13 12:24:25 --> Loader Class Initialized
INFO - 2016-08-13 12:24:25 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:25 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:25 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:25 --> Email Class Initialized
INFO - 2016-08-13 12:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:25 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:25 --> Model Class Initialized
INFO - 2016-08-13 12:24:25 --> Controller Class Initialized
INFO - 2016-08-13 12:24:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 12:24:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 12:24:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-13 12:24:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 12:24:25 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:25 --> Total execution time: 0.3893
INFO - 2016-08-13 12:24:28 --> Config Class Initialized
INFO - 2016-08-13 12:24:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:28 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:28 --> URI Class Initialized
INFO - 2016-08-13 12:24:28 --> Router Class Initialized
INFO - 2016-08-13 12:24:28 --> Output Class Initialized
INFO - 2016-08-13 12:24:28 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:28 --> Input Class Initialized
INFO - 2016-08-13 12:24:28 --> Language Class Initialized
INFO - 2016-08-13 12:24:28 --> Loader Class Initialized
INFO - 2016-08-13 12:24:28 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:28 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:28 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:28 --> Email Class Initialized
INFO - 2016-08-13 12:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:28 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:28 --> Model Class Initialized
INFO - 2016-08-13 12:24:28 --> Controller Class Initialized
INFO - 2016-08-13 12:24:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 12:24:28 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:28 --> Total execution time: 0.3354
INFO - 2016-08-13 12:24:33 --> Config Class Initialized
INFO - 2016-08-13 12:24:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:33 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:33 --> URI Class Initialized
INFO - 2016-08-13 12:24:33 --> Router Class Initialized
INFO - 2016-08-13 12:24:33 --> Output Class Initialized
INFO - 2016-08-13 12:24:33 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:33 --> Input Class Initialized
INFO - 2016-08-13 12:24:33 --> Language Class Initialized
INFO - 2016-08-13 12:24:33 --> Loader Class Initialized
INFO - 2016-08-13 12:24:33 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:33 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:33 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:33 --> Email Class Initialized
INFO - 2016-08-13 12:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:33 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:33 --> Model Class Initialized
INFO - 2016-08-13 12:24:33 --> Controller Class Initialized
INFO - 2016-08-13 12:24:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-13 12:24:33 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:33 --> Total execution time: 0.4727
INFO - 2016-08-13 12:24:40 --> Config Class Initialized
INFO - 2016-08-13 12:24:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:40 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:40 --> URI Class Initialized
INFO - 2016-08-13 12:24:40 --> Router Class Initialized
INFO - 2016-08-13 12:24:40 --> Output Class Initialized
INFO - 2016-08-13 12:24:40 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:40 --> Input Class Initialized
INFO - 2016-08-13 12:24:40 --> Language Class Initialized
INFO - 2016-08-13 12:24:40 --> Loader Class Initialized
INFO - 2016-08-13 12:24:40 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:40 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:40 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:40 --> Email Class Initialized
INFO - 2016-08-13 12:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:40 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:40 --> Model Class Initialized
INFO - 2016-08-13 12:24:40 --> Controller Class Initialized
INFO - 2016-08-13 12:24:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 12:24:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 12:24:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 12:24:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 12:24:40 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:40 --> Total execution time: 0.3499
INFO - 2016-08-13 12:24:51 --> Config Class Initialized
INFO - 2016-08-13 12:24:51 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:51 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:51 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:51 --> URI Class Initialized
INFO - 2016-08-13 12:24:51 --> Router Class Initialized
INFO - 2016-08-13 12:24:51 --> Output Class Initialized
INFO - 2016-08-13 12:24:51 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:51 --> Input Class Initialized
INFO - 2016-08-13 12:24:51 --> Language Class Initialized
INFO - 2016-08-13 12:24:51 --> Loader Class Initialized
INFO - 2016-08-13 12:24:51 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:51 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:51 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:51 --> Email Class Initialized
INFO - 2016-08-13 12:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:51 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:51 --> Model Class Initialized
INFO - 2016-08-13 12:24:51 --> Controller Class Initialized
INFO - 2016-08-13 12:24:51 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:51 --> Total execution time: 0.3042
INFO - 2016-08-13 12:24:53 --> Config Class Initialized
INFO - 2016-08-13 12:24:53 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:53 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:53 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:53 --> URI Class Initialized
INFO - 2016-08-13 12:24:53 --> Router Class Initialized
INFO - 2016-08-13 12:24:53 --> Output Class Initialized
INFO - 2016-08-13 12:24:53 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:53 --> Input Class Initialized
INFO - 2016-08-13 12:24:53 --> Language Class Initialized
INFO - 2016-08-13 12:24:53 --> Loader Class Initialized
INFO - 2016-08-13 12:24:53 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:53 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:53 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:53 --> Email Class Initialized
INFO - 2016-08-13 12:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:53 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:53 --> Model Class Initialized
INFO - 2016-08-13 12:24:53 --> Controller Class Initialized
INFO - 2016-08-13 12:24:53 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:53 --> Total execution time: 0.3249
INFO - 2016-08-13 12:24:59 --> Config Class Initialized
INFO - 2016-08-13 12:24:59 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:24:59 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:24:59 --> Utf8 Class Initialized
INFO - 2016-08-13 12:24:59 --> URI Class Initialized
INFO - 2016-08-13 12:24:59 --> Router Class Initialized
INFO - 2016-08-13 12:24:59 --> Output Class Initialized
INFO - 2016-08-13 12:24:59 --> Security Class Initialized
DEBUG - 2016-08-13 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:24:59 --> Input Class Initialized
INFO - 2016-08-13 12:24:59 --> Language Class Initialized
INFO - 2016-08-13 12:24:59 --> Loader Class Initialized
INFO - 2016-08-13 12:24:59 --> Helper loaded: url_helper
INFO - 2016-08-13 12:24:59 --> Helper loaded: date_helper
INFO - 2016-08-13 12:24:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:24:59 --> Database Driver Class Initialized
INFO - 2016-08-13 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:24:59 --> Email Class Initialized
INFO - 2016-08-13 12:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:24:59 --> Pagination Class Initialized
INFO - 2016-08-13 12:24:59 --> Model Class Initialized
INFO - 2016-08-13 12:24:59 --> Controller Class Initialized
INFO - 2016-08-13 12:24:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 12:24:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 12:24:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 12:24:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 12:24:59 --> Final output sent to browser
DEBUG - 2016-08-13 12:24:59 --> Total execution time: 0.4094
INFO - 2016-08-13 12:43:27 --> Config Class Initialized
INFO - 2016-08-13 12:43:27 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:43:27 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:43:27 --> Utf8 Class Initialized
INFO - 2016-08-13 12:43:27 --> URI Class Initialized
INFO - 2016-08-13 12:43:27 --> Router Class Initialized
INFO - 2016-08-13 12:43:27 --> Output Class Initialized
INFO - 2016-08-13 12:43:27 --> Security Class Initialized
DEBUG - 2016-08-13 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:43:27 --> Input Class Initialized
INFO - 2016-08-13 12:43:27 --> Language Class Initialized
INFO - 2016-08-13 12:43:27 --> Loader Class Initialized
INFO - 2016-08-13 12:43:27 --> Helper loaded: url_helper
INFO - 2016-08-13 12:43:27 --> Helper loaded: date_helper
INFO - 2016-08-13 12:43:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:43:27 --> Database Driver Class Initialized
INFO - 2016-08-13 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:43:27 --> Email Class Initialized
INFO - 2016-08-13 12:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:43:27 --> Pagination Class Initialized
INFO - 2016-08-13 12:43:27 --> Model Class Initialized
INFO - 2016-08-13 12:43:27 --> Controller Class Initialized
INFO - 2016-08-13 12:43:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-13 12:43:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-13 12:43:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-13 12:43:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-13 12:43:27 --> Final output sent to browser
DEBUG - 2016-08-13 12:43:27 --> Total execution time: 0.4400
INFO - 2016-08-13 12:43:29 --> Config Class Initialized
INFO - 2016-08-13 12:43:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:43:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:43:29 --> Utf8 Class Initialized
INFO - 2016-08-13 12:43:29 --> URI Class Initialized
INFO - 2016-08-13 12:43:29 --> Router Class Initialized
INFO - 2016-08-13 12:43:29 --> Output Class Initialized
INFO - 2016-08-13 12:43:29 --> Security Class Initialized
DEBUG - 2016-08-13 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:43:29 --> Input Class Initialized
INFO - 2016-08-13 12:43:29 --> Language Class Initialized
INFO - 2016-08-13 12:43:29 --> Loader Class Initialized
INFO - 2016-08-13 12:43:29 --> Helper loaded: url_helper
INFO - 2016-08-13 12:43:29 --> Helper loaded: date_helper
INFO - 2016-08-13 12:43:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:43:29 --> Database Driver Class Initialized
INFO - 2016-08-13 12:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:43:29 --> Email Class Initialized
INFO - 2016-08-13 12:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:43:29 --> Pagination Class Initialized
INFO - 2016-08-13 12:43:29 --> Model Class Initialized
INFO - 2016-08-13 12:43:29 --> Controller Class Initialized
DEBUG - 2016-08-13 12:43:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:43:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:43:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:43:29 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:43:29 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:43:29 --> Model Class Initialized
INFO - 2016-08-13 12:43:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:43:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:43:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:43:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:43:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:43:29 --> Final output sent to browser
DEBUG - 2016-08-13 12:43:29 --> Total execution time: 0.5348
INFO - 2016-08-13 12:44:18 --> Config Class Initialized
INFO - 2016-08-13 12:44:18 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:44:18 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:44:18 --> Utf8 Class Initialized
INFO - 2016-08-13 12:44:18 --> URI Class Initialized
INFO - 2016-08-13 12:44:18 --> Router Class Initialized
INFO - 2016-08-13 12:44:18 --> Output Class Initialized
INFO - 2016-08-13 12:44:18 --> Security Class Initialized
DEBUG - 2016-08-13 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:44:18 --> Input Class Initialized
INFO - 2016-08-13 12:44:18 --> Language Class Initialized
INFO - 2016-08-13 12:44:18 --> Loader Class Initialized
INFO - 2016-08-13 12:44:18 --> Helper loaded: url_helper
INFO - 2016-08-13 12:44:18 --> Helper loaded: date_helper
INFO - 2016-08-13 12:44:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:44:18 --> Database Driver Class Initialized
INFO - 2016-08-13 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:44:18 --> Email Class Initialized
INFO - 2016-08-13 12:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:44:18 --> Pagination Class Initialized
INFO - 2016-08-13 12:44:19 --> Model Class Initialized
INFO - 2016-08-13 12:44:19 --> Controller Class Initialized
DEBUG - 2016-08-13 12:44:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:44:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:44:19 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:44:19 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:19 --> Model Class Initialized
INFO - 2016-08-13 12:44:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:44:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:44:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:44:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:44:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:44:19 --> Final output sent to browser
DEBUG - 2016-08-13 12:44:19 --> Total execution time: 0.4767
INFO - 2016-08-13 12:44:33 --> Config Class Initialized
INFO - 2016-08-13 12:44:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:44:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:44:33 --> Utf8 Class Initialized
INFO - 2016-08-13 12:44:33 --> URI Class Initialized
INFO - 2016-08-13 12:44:33 --> Router Class Initialized
INFO - 2016-08-13 12:44:33 --> Output Class Initialized
INFO - 2016-08-13 12:44:33 --> Security Class Initialized
DEBUG - 2016-08-13 12:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:44:33 --> Input Class Initialized
INFO - 2016-08-13 12:44:33 --> Language Class Initialized
INFO - 2016-08-13 12:44:33 --> Loader Class Initialized
INFO - 2016-08-13 12:44:33 --> Helper loaded: url_helper
INFO - 2016-08-13 12:44:33 --> Helper loaded: date_helper
INFO - 2016-08-13 12:44:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:44:33 --> Database Driver Class Initialized
INFO - 2016-08-13 12:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:44:33 --> Email Class Initialized
INFO - 2016-08-13 12:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:44:33 --> Pagination Class Initialized
INFO - 2016-08-13 12:44:33 --> Model Class Initialized
INFO - 2016-08-13 12:44:33 --> Controller Class Initialized
DEBUG - 2016-08-13 12:44:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:44:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:44:33 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:44:33 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:33 --> Model Class Initialized
INFO - 2016-08-13 12:44:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:44:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:44:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:44:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:44:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:44:33 --> Final output sent to browser
DEBUG - 2016-08-13 12:44:33 --> Total execution time: 0.4854
INFO - 2016-08-13 12:44:43 --> Config Class Initialized
INFO - 2016-08-13 12:44:43 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:44:43 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:44:43 --> Utf8 Class Initialized
INFO - 2016-08-13 12:44:43 --> URI Class Initialized
INFO - 2016-08-13 12:44:43 --> Router Class Initialized
INFO - 2016-08-13 12:44:43 --> Output Class Initialized
INFO - 2016-08-13 12:44:43 --> Security Class Initialized
DEBUG - 2016-08-13 12:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:44:43 --> Input Class Initialized
INFO - 2016-08-13 12:44:43 --> Language Class Initialized
INFO - 2016-08-13 12:44:43 --> Loader Class Initialized
INFO - 2016-08-13 12:44:43 --> Helper loaded: url_helper
INFO - 2016-08-13 12:44:43 --> Helper loaded: date_helper
INFO - 2016-08-13 12:44:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:44:43 --> Database Driver Class Initialized
INFO - 2016-08-13 12:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:44:43 --> Email Class Initialized
INFO - 2016-08-13 12:44:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:44:44 --> Pagination Class Initialized
INFO - 2016-08-13 12:44:44 --> Model Class Initialized
INFO - 2016-08-13 12:44:44 --> Controller Class Initialized
DEBUG - 2016-08-13 12:44:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:44:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:44:44 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:44:44 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:44 --> Model Class Initialized
INFO - 2016-08-13 12:44:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:44:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:44:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:44:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:44:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:44:44 --> Final output sent to browser
DEBUG - 2016-08-13 12:44:44 --> Total execution time: 0.4702
INFO - 2016-08-13 12:44:55 --> Config Class Initialized
INFO - 2016-08-13 12:44:55 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:44:55 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:44:55 --> Utf8 Class Initialized
INFO - 2016-08-13 12:44:55 --> URI Class Initialized
INFO - 2016-08-13 12:44:55 --> Router Class Initialized
INFO - 2016-08-13 12:44:55 --> Output Class Initialized
INFO - 2016-08-13 12:44:55 --> Security Class Initialized
DEBUG - 2016-08-13 12:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:44:55 --> Input Class Initialized
INFO - 2016-08-13 12:44:55 --> Language Class Initialized
INFO - 2016-08-13 12:44:55 --> Loader Class Initialized
INFO - 2016-08-13 12:44:55 --> Helper loaded: url_helper
INFO - 2016-08-13 12:44:55 --> Helper loaded: date_helper
INFO - 2016-08-13 12:44:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:44:55 --> Database Driver Class Initialized
INFO - 2016-08-13 12:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:44:55 --> Email Class Initialized
INFO - 2016-08-13 12:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:44:55 --> Pagination Class Initialized
INFO - 2016-08-13 12:44:55 --> Model Class Initialized
INFO - 2016-08-13 12:44:55 --> Controller Class Initialized
DEBUG - 2016-08-13 12:44:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:44:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:44:56 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:44:56 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:44:56 --> Model Class Initialized
INFO - 2016-08-13 12:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:44:56 --> Final output sent to browser
DEBUG - 2016-08-13 12:44:56 --> Total execution time: 0.8058
INFO - 2016-08-13 12:49:33 --> Config Class Initialized
INFO - 2016-08-13 12:49:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 12:49:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 12:49:33 --> Utf8 Class Initialized
INFO - 2016-08-13 12:49:33 --> URI Class Initialized
INFO - 2016-08-13 12:49:33 --> Router Class Initialized
INFO - 2016-08-13 12:49:33 --> Output Class Initialized
INFO - 2016-08-13 12:49:33 --> Security Class Initialized
DEBUG - 2016-08-13 12:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 12:49:33 --> Input Class Initialized
INFO - 2016-08-13 12:49:33 --> Language Class Initialized
INFO - 2016-08-13 12:49:33 --> Loader Class Initialized
INFO - 2016-08-13 12:49:33 --> Helper loaded: url_helper
INFO - 2016-08-13 12:49:33 --> Helper loaded: date_helper
INFO - 2016-08-13 12:49:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-13 12:49:33 --> Database Driver Class Initialized
INFO - 2016-08-13 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 12:49:33 --> Email Class Initialized
INFO - 2016-08-13 12:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-13 12:49:33 --> Pagination Class Initialized
INFO - 2016-08-13 12:49:33 --> Model Class Initialized
INFO - 2016-08-13 12:49:33 --> Controller Class Initialized
DEBUG - 2016-08-13 12:49:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-13 12:49:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:49:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-13 12:49:33 --> Helper loaded: cookie_helper
INFO - 2016-08-13 12:49:33 --> Helper loaded: language_helper
DEBUG - 2016-08-13 12:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-13 12:49:33 --> Model Class Initialized
INFO - 2016-08-13 12:49:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-13 12:49:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-13 12:49:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-13 12:49:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-13 12:49:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-13 12:49:34 --> Final output sent to browser
DEBUG - 2016-08-13 12:49:34 --> Total execution time: 0.8944
