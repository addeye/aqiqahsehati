<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-08-06 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-06 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-06 17:46:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-08-06 17:46:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-06 17:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-06 17:46:20 --> Total execution time: 0.0643
DEBUG - 2016-08-06 17:46:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-06 17:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-08-06 17:46:20 --> 404 Page Not Found: Assets/css
INFO - 2016-08-06 17:46:41 --> Config Class Initialized
INFO - 2016-08-06 17:46:41 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:46:41 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:46:41 --> Utf8 Class Initialized
INFO - 2016-08-06 17:46:41 --> URI Class Initialized
DEBUG - 2016-08-06 17:46:41 --> No URI present. Default controller set.
INFO - 2016-08-06 17:46:41 --> Router Class Initialized
INFO - 2016-08-06 17:46:41 --> Output Class Initialized
INFO - 2016-08-06 17:46:41 --> Security Class Initialized
DEBUG - 2016-08-06 17:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:46:41 --> Input Class Initialized
INFO - 2016-08-06 17:46:41 --> Language Class Initialized
INFO - 2016-08-06 17:46:41 --> Loader Class Initialized
INFO - 2016-08-06 17:46:41 --> Helper loaded: url_helper
INFO - 2016-08-06 17:46:41 --> Database Driver Class Initialized
INFO - 2016-08-06 17:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:46:41 --> Email Class Initialized
INFO - 2016-08-06 17:46:41 --> Controller Class Initialized
INFO - 2016-08-06 17:46:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-06 17:46:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-06 17:46:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-06 17:46:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-06 17:46:41 --> Final output sent to browser
DEBUG - 2016-08-06 17:46:41 --> Total execution time: 0.0823
INFO - 2016-08-06 17:46:45 --> Config Class Initialized
INFO - 2016-08-06 17:46:45 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:46:45 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:46:45 --> Utf8 Class Initialized
INFO - 2016-08-06 17:46:45 --> URI Class Initialized
INFO - 2016-08-06 17:46:45 --> Router Class Initialized
INFO - 2016-08-06 17:46:45 --> Output Class Initialized
INFO - 2016-08-06 17:46:45 --> Security Class Initialized
DEBUG - 2016-08-06 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:46:45 --> Input Class Initialized
INFO - 2016-08-06 17:46:45 --> Language Class Initialized
INFO - 2016-08-06 17:46:45 --> Loader Class Initialized
INFO - 2016-08-06 17:46:45 --> Helper loaded: url_helper
INFO - 2016-08-06 17:46:45 --> Database Driver Class Initialized
INFO - 2016-08-06 17:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:46:45 --> Email Class Initialized
INFO - 2016-08-06 17:46:45 --> Controller Class Initialized
INFO - 2016-08-06 17:46:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-06 17:46:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-06 17:46:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-06 17:46:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-06 17:46:45 --> Final output sent to browser
DEBUG - 2016-08-06 17:46:45 --> Total execution time: 0.0585
INFO - 2016-08-06 17:46:48 --> Config Class Initialized
INFO - 2016-08-06 17:46:48 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:46:48 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:46:48 --> Utf8 Class Initialized
INFO - 2016-08-06 17:46:48 --> URI Class Initialized
INFO - 2016-08-06 17:46:48 --> Router Class Initialized
INFO - 2016-08-06 17:46:48 --> Output Class Initialized
INFO - 2016-08-06 17:46:48 --> Security Class Initialized
DEBUG - 2016-08-06 17:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:46:48 --> Input Class Initialized
INFO - 2016-08-06 17:46:48 --> Language Class Initialized
INFO - 2016-08-06 17:46:48 --> Loader Class Initialized
INFO - 2016-08-06 17:46:48 --> Helper loaded: url_helper
INFO - 2016-08-06 17:46:48 --> Database Driver Class Initialized
INFO - 2016-08-06 17:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:46:48 --> Email Class Initialized
INFO - 2016-08-06 17:46:48 --> Controller Class Initialized
DEBUG - 2016-08-06 17:46:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:46:49 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 17:46:50 --> Config Class Initialized
INFO - 2016-08-06 17:46:50 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:46:50 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:46:50 --> Utf8 Class Initialized
INFO - 2016-08-06 17:46:50 --> URI Class Initialized
INFO - 2016-08-06 17:46:50 --> Router Class Initialized
INFO - 2016-08-06 17:46:50 --> Output Class Initialized
INFO - 2016-08-06 17:46:50 --> Security Class Initialized
DEBUG - 2016-08-06 17:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:46:50 --> Input Class Initialized
INFO - 2016-08-06 17:46:50 --> Language Class Initialized
INFO - 2016-08-06 17:46:50 --> Loader Class Initialized
INFO - 2016-08-06 17:46:50 --> Helper loaded: url_helper
INFO - 2016-08-06 17:46:50 --> Database Driver Class Initialized
INFO - 2016-08-06 17:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:46:50 --> Email Class Initialized
INFO - 2016-08-06 17:46:50 --> Controller Class Initialized
DEBUG - 2016-08-06 17:46:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:46:54 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 17:46:55 --> Config Class Initialized
INFO - 2016-08-06 17:46:55 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:46:55 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:46:55 --> Utf8 Class Initialized
INFO - 2016-08-06 17:46:55 --> URI Class Initialized
INFO - 2016-08-06 17:46:55 --> Router Class Initialized
INFO - 2016-08-06 17:46:55 --> Output Class Initialized
INFO - 2016-08-06 17:46:55 --> Security Class Initialized
DEBUG - 2016-08-06 17:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:46:55 --> Input Class Initialized
INFO - 2016-08-06 17:46:55 --> Language Class Initialized
INFO - 2016-08-06 17:46:55 --> Loader Class Initialized
INFO - 2016-08-06 17:46:55 --> Helper loaded: url_helper
INFO - 2016-08-06 17:46:55 --> Database Driver Class Initialized
INFO - 2016-08-06 17:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:46:55 --> Email Class Initialized
INFO - 2016-08-06 17:46:56 --> Controller Class Initialized
INFO - 2016-08-06 17:46:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-06 17:46:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-06 17:46:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-06 17:46:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-06 17:46:56 --> Final output sent to browser
DEBUG - 2016-08-06 17:46:56 --> Total execution time: 0.0665
INFO - 2016-08-06 17:52:43 --> Config Class Initialized
INFO - 2016-08-06 17:52:43 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:52:43 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:52:43 --> Utf8 Class Initialized
INFO - 2016-08-06 17:52:43 --> URI Class Initialized
INFO - 2016-08-06 17:52:43 --> Router Class Initialized
INFO - 2016-08-06 17:52:43 --> Output Class Initialized
INFO - 2016-08-06 17:52:43 --> Security Class Initialized
DEBUG - 2016-08-06 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:52:43 --> Input Class Initialized
INFO - 2016-08-06 17:52:43 --> Language Class Initialized
INFO - 2016-08-06 17:52:43 --> Loader Class Initialized
INFO - 2016-08-06 17:52:43 --> Helper loaded: url_helper
INFO - 2016-08-06 17:52:43 --> Database Driver Class Initialized
INFO - 2016-08-06 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:52:43 --> Email Class Initialized
INFO - 2016-08-06 17:52:43 --> Controller Class Initialized
ERROR - 2016-08-06 17:52:43 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 17:52:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:52:44 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 17:52:44 --> Config Class Initialized
INFO - 2016-08-06 17:52:44 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:52:44 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:52:44 --> Utf8 Class Initialized
INFO - 2016-08-06 17:52:44 --> URI Class Initialized
INFO - 2016-08-06 17:52:44 --> Router Class Initialized
INFO - 2016-08-06 17:52:44 --> Output Class Initialized
INFO - 2016-08-06 17:52:44 --> Security Class Initialized
DEBUG - 2016-08-06 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:52:44 --> Input Class Initialized
INFO - 2016-08-06 17:52:44 --> Language Class Initialized
INFO - 2016-08-06 17:52:44 --> Loader Class Initialized
INFO - 2016-08-06 17:52:44 --> Helper loaded: url_helper
INFO - 2016-08-06 17:52:44 --> Database Driver Class Initialized
INFO - 2016-08-06 17:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:52:45 --> Email Class Initialized
INFO - 2016-08-06 17:52:45 --> Controller Class Initialized
ERROR - 2016-08-06 17:52:45 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 17:52:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:52:45 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 17:53:41 --> Config Class Initialized
INFO - 2016-08-06 17:53:41 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:53:41 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:53:41 --> Utf8 Class Initialized
INFO - 2016-08-06 17:53:41 --> URI Class Initialized
INFO - 2016-08-06 17:53:41 --> Router Class Initialized
INFO - 2016-08-06 17:53:41 --> Output Class Initialized
INFO - 2016-08-06 17:53:41 --> Security Class Initialized
DEBUG - 2016-08-06 17:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:53:41 --> Input Class Initialized
INFO - 2016-08-06 17:53:41 --> Language Class Initialized
INFO - 2016-08-06 17:53:41 --> Loader Class Initialized
INFO - 2016-08-06 17:53:41 --> Helper loaded: url_helper
INFO - 2016-08-06 17:53:41 --> Database Driver Class Initialized
INFO - 2016-08-06 17:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:53:41 --> Email Class Initialized
INFO - 2016-08-06 17:53:41 --> Controller Class Initialized
ERROR - 2016-08-06 17:53:41 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 17:53:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:53:42 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 17:53:46 --> Final output sent to browser
DEBUG - 2016-08-06 17:53:46 --> Total execution time: 4.9640
INFO - 2016-08-06 17:55:35 --> Config Class Initialized
INFO - 2016-08-06 17:55:35 --> Hooks Class Initialized
DEBUG - 2016-08-06 17:55:35 --> UTF-8 Support Enabled
INFO - 2016-08-06 17:55:35 --> Utf8 Class Initialized
INFO - 2016-08-06 17:55:35 --> URI Class Initialized
INFO - 2016-08-06 17:55:35 --> Router Class Initialized
INFO - 2016-08-06 17:55:35 --> Output Class Initialized
INFO - 2016-08-06 17:55:35 --> Security Class Initialized
DEBUG - 2016-08-06 17:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 17:55:35 --> Input Class Initialized
INFO - 2016-08-06 17:55:35 --> Language Class Initialized
INFO - 2016-08-06 17:55:35 --> Loader Class Initialized
INFO - 2016-08-06 17:55:35 --> Helper loaded: url_helper
INFO - 2016-08-06 17:55:35 --> Database Driver Class Initialized
INFO - 2016-08-06 17:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 17:55:35 --> Email Class Initialized
INFO - 2016-08-06 17:55:35 --> Controller Class Initialized
ERROR - 2016-08-06 17:55:35 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 17:55:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 17:55:36 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:05:02 --> Config Class Initialized
INFO - 2016-08-06 18:05:02 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:05:02 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:05:02 --> Utf8 Class Initialized
INFO - 2016-08-06 18:05:02 --> URI Class Initialized
INFO - 2016-08-06 18:05:02 --> Router Class Initialized
INFO - 2016-08-06 18:05:02 --> Output Class Initialized
INFO - 2016-08-06 18:05:02 --> Security Class Initialized
DEBUG - 2016-08-06 18:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:05:02 --> Input Class Initialized
INFO - 2016-08-06 18:05:02 --> Language Class Initialized
INFO - 2016-08-06 18:05:02 --> Loader Class Initialized
INFO - 2016-08-06 18:05:02 --> Helper loaded: url_helper
INFO - 2016-08-06 18:05:02 --> Database Driver Class Initialized
INFO - 2016-08-06 18:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:05:02 --> Email Class Initialized
INFO - 2016-08-06 18:05:02 --> Controller Class Initialized
ERROR - 2016-08-06 18:05:02 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:05:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:05:02 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:09:12 --> Config Class Initialized
INFO - 2016-08-06 18:09:12 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:09:12 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:09:12 --> Utf8 Class Initialized
INFO - 2016-08-06 18:09:12 --> URI Class Initialized
INFO - 2016-08-06 18:09:12 --> Router Class Initialized
INFO - 2016-08-06 18:09:12 --> Output Class Initialized
INFO - 2016-08-06 18:09:12 --> Security Class Initialized
DEBUG - 2016-08-06 18:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:09:12 --> Input Class Initialized
INFO - 2016-08-06 18:09:12 --> Language Class Initialized
INFO - 2016-08-06 18:09:12 --> Loader Class Initialized
INFO - 2016-08-06 18:09:12 --> Helper loaded: url_helper
INFO - 2016-08-06 18:09:12 --> Database Driver Class Initialized
INFO - 2016-08-06 18:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:09:12 --> Email Class Initialized
INFO - 2016-08-06 18:09:12 --> Controller Class Initialized
ERROR - 2016-08-06 18:09:12 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:09:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:09:13 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:09:17 --> Config Class Initialized
INFO - 2016-08-06 18:09:17 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:09:17 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:09:17 --> Utf8 Class Initialized
INFO - 2016-08-06 18:09:17 --> URI Class Initialized
INFO - 2016-08-06 18:09:17 --> Router Class Initialized
INFO - 2016-08-06 18:09:17 --> Output Class Initialized
INFO - 2016-08-06 18:09:17 --> Security Class Initialized
DEBUG - 2016-08-06 18:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:09:17 --> Input Class Initialized
INFO - 2016-08-06 18:09:17 --> Language Class Initialized
INFO - 2016-08-06 18:09:17 --> Loader Class Initialized
INFO - 2016-08-06 18:09:17 --> Helper loaded: url_helper
INFO - 2016-08-06 18:09:17 --> Database Driver Class Initialized
INFO - 2016-08-06 18:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:09:17 --> Email Class Initialized
INFO - 2016-08-06 18:09:17 --> Controller Class Initialized
ERROR - 2016-08-06 18:09:17 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:09:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:09:18 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:15:12 --> Config Class Initialized
INFO - 2016-08-06 18:15:12 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:15:13 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:15:13 --> Utf8 Class Initialized
INFO - 2016-08-06 18:15:13 --> URI Class Initialized
INFO - 2016-08-06 18:15:13 --> Router Class Initialized
INFO - 2016-08-06 18:15:13 --> Output Class Initialized
INFO - 2016-08-06 18:15:13 --> Security Class Initialized
DEBUG - 2016-08-06 18:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:15:13 --> Input Class Initialized
INFO - 2016-08-06 18:15:13 --> Language Class Initialized
INFO - 2016-08-06 18:15:13 --> Loader Class Initialized
INFO - 2016-08-06 18:15:13 --> Helper loaded: url_helper
INFO - 2016-08-06 18:15:13 --> Database Driver Class Initialized
INFO - 2016-08-06 18:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:15:13 --> Email Class Initialized
INFO - 2016-08-06 18:15:13 --> Controller Class Initialized
ERROR - 2016-08-06 18:15:13 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:15:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:15:13 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:15:43 --> Config Class Initialized
INFO - 2016-08-06 18:15:43 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:15:43 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:15:43 --> Utf8 Class Initialized
INFO - 2016-08-06 18:15:43 --> URI Class Initialized
DEBUG - 2016-08-06 18:15:43 --> No URI present. Default controller set.
INFO - 2016-08-06 18:15:43 --> Router Class Initialized
INFO - 2016-08-06 18:15:43 --> Output Class Initialized
INFO - 2016-08-06 18:15:43 --> Security Class Initialized
DEBUG - 2016-08-06 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:15:43 --> Input Class Initialized
INFO - 2016-08-06 18:15:43 --> Language Class Initialized
INFO - 2016-08-06 18:15:43 --> Loader Class Initialized
INFO - 2016-08-06 18:15:43 --> Helper loaded: url_helper
INFO - 2016-08-06 18:15:43 --> Database Driver Class Initialized
INFO - 2016-08-06 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:15:43 --> Email Class Initialized
INFO - 2016-08-06 18:15:43 --> Controller Class Initialized
INFO - 2016-08-06 18:15:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-06 18:15:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-06 18:15:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-06 18:15:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-06 18:15:43 --> Final output sent to browser
DEBUG - 2016-08-06 18:15:43 --> Total execution time: 0.0664
INFO - 2016-08-06 18:15:55 --> Config Class Initialized
INFO - 2016-08-06 18:15:55 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:15:55 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:15:55 --> Utf8 Class Initialized
INFO - 2016-08-06 18:15:55 --> URI Class Initialized
INFO - 2016-08-06 18:15:55 --> Router Class Initialized
INFO - 2016-08-06 18:15:55 --> Output Class Initialized
INFO - 2016-08-06 18:15:55 --> Security Class Initialized
DEBUG - 2016-08-06 18:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:15:55 --> Input Class Initialized
INFO - 2016-08-06 18:15:55 --> Language Class Initialized
INFO - 2016-08-06 18:15:55 --> Loader Class Initialized
INFO - 2016-08-06 18:15:55 --> Helper loaded: url_helper
INFO - 2016-08-06 18:15:55 --> Database Driver Class Initialized
INFO - 2016-08-06 18:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:15:55 --> Email Class Initialized
INFO - 2016-08-06 18:15:55 --> Controller Class Initialized
ERROR - 2016-08-06 18:15:55 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:15:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:15:56 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:25:39 --> Config Class Initialized
INFO - 2016-08-06 18:25:39 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:25:39 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:25:39 --> Utf8 Class Initialized
INFO - 2016-08-06 18:25:39 --> URI Class Initialized
INFO - 2016-08-06 18:25:39 --> Router Class Initialized
INFO - 2016-08-06 18:25:39 --> Output Class Initialized
INFO - 2016-08-06 18:25:39 --> Security Class Initialized
DEBUG - 2016-08-06 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:25:39 --> Input Class Initialized
INFO - 2016-08-06 18:25:39 --> Language Class Initialized
INFO - 2016-08-06 18:25:39 --> Loader Class Initialized
INFO - 2016-08-06 18:25:39 --> Helper loaded: url_helper
INFO - 2016-08-06 18:25:39 --> Database Driver Class Initialized
INFO - 2016-08-06 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:25:39 --> Email Class Initialized
INFO - 2016-08-06 18:25:39 --> Controller Class Initialized
ERROR - 2016-08-06 18:25:39 --> Severity: Notice --> Undefined index: HTTP_REFERER D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 68
DEBUG - 2016-08-06 18:25:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:25:39 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:34:07 --> Config Class Initialized
INFO - 2016-08-06 18:34:07 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:34:07 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:34:07 --> Utf8 Class Initialized
INFO - 2016-08-06 18:34:07 --> URI Class Initialized
INFO - 2016-08-06 18:34:07 --> Router Class Initialized
INFO - 2016-08-06 18:34:07 --> Output Class Initialized
INFO - 2016-08-06 18:34:07 --> Security Class Initialized
DEBUG - 2016-08-06 18:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:34:07 --> Input Class Initialized
INFO - 2016-08-06 18:34:07 --> Language Class Initialized
INFO - 2016-08-06 18:34:07 --> Loader Class Initialized
INFO - 2016-08-06 18:34:07 --> Helper loaded: url_helper
INFO - 2016-08-06 18:34:07 --> Database Driver Class Initialized
INFO - 2016-08-06 18:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:34:07 --> Email Class Initialized
INFO - 2016-08-06 18:34:07 --> Controller Class Initialized
DEBUG - 2016-08-06 18:34:07 --> Email class already loaded. Second attempt ignored.
ERROR - 2016-08-06 18:34:07 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:140770FC:SSL routines:SSL23_GET_SERVER_HELLO:unknown protocol D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 1990
ERROR - 2016-08-06 18:34:07 --> Severity: Warning --> fsockopen(): Failed to enable crypto D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 1990
ERROR - 2016-08-06 18:34:07 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:587 (Unknown error) D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 1990
INFO - 2016-08-06 18:34:07 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:34:23 --> Config Class Initialized
INFO - 2016-08-06 18:34:23 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:34:23 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:34:23 --> Utf8 Class Initialized
INFO - 2016-08-06 18:34:23 --> URI Class Initialized
INFO - 2016-08-06 18:34:23 --> Router Class Initialized
INFO - 2016-08-06 18:34:23 --> Output Class Initialized
INFO - 2016-08-06 18:34:23 --> Security Class Initialized
DEBUG - 2016-08-06 18:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:34:23 --> Input Class Initialized
INFO - 2016-08-06 18:34:23 --> Language Class Initialized
INFO - 2016-08-06 18:34:23 --> Loader Class Initialized
INFO - 2016-08-06 18:34:23 --> Helper loaded: url_helper
INFO - 2016-08-06 18:34:23 --> Database Driver Class Initialized
INFO - 2016-08-06 18:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:34:23 --> Email Class Initialized
INFO - 2016-08-06 18:34:23 --> Controller Class Initialized
DEBUG - 2016-08-06 18:34:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:34:23 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:35:05 --> Config Class Initialized
INFO - 2016-08-06 18:35:05 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:35:05 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:35:05 --> Utf8 Class Initialized
INFO - 2016-08-06 18:35:05 --> URI Class Initialized
INFO - 2016-08-06 18:35:05 --> Router Class Initialized
INFO - 2016-08-06 18:35:05 --> Output Class Initialized
INFO - 2016-08-06 18:35:05 --> Security Class Initialized
DEBUG - 2016-08-06 18:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:35:05 --> Input Class Initialized
INFO - 2016-08-06 18:35:05 --> Language Class Initialized
INFO - 2016-08-06 18:35:05 --> Loader Class Initialized
INFO - 2016-08-06 18:35:05 --> Helper loaded: url_helper
INFO - 2016-08-06 18:35:05 --> Database Driver Class Initialized
INFO - 2016-08-06 18:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:35:05 --> Email Class Initialized
INFO - 2016-08-06 18:35:05 --> Controller Class Initialized
DEBUG - 2016-08-06 18:35:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:35:05 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:35:09 --> Final output sent to browser
DEBUG - 2016-08-06 18:35:09 --> Total execution time: 4.0139
INFO - 2016-08-06 18:44:08 --> Config Class Initialized
INFO - 2016-08-06 18:44:08 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:44:08 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:44:08 --> Utf8 Class Initialized
INFO - 2016-08-06 18:44:08 --> URI Class Initialized
INFO - 2016-08-06 18:44:08 --> Router Class Initialized
INFO - 2016-08-06 18:44:08 --> Output Class Initialized
INFO - 2016-08-06 18:44:08 --> Security Class Initialized
DEBUG - 2016-08-06 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:44:08 --> Input Class Initialized
INFO - 2016-08-06 18:44:08 --> Language Class Initialized
INFO - 2016-08-06 18:44:08 --> Loader Class Initialized
INFO - 2016-08-06 18:44:08 --> Helper loaded: url_helper
INFO - 2016-08-06 18:44:08 --> Database Driver Class Initialized
INFO - 2016-08-06 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:44:08 --> Email Class Initialized
INFO - 2016-08-06 18:44:08 --> Controller Class Initialized
DEBUG - 2016-08-06 18:44:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:44:09 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:44:12 --> Final output sent to browser
DEBUG - 2016-08-06 18:44:12 --> Total execution time: 3.6672
INFO - 2016-08-06 18:51:22 --> Config Class Initialized
INFO - 2016-08-06 18:51:22 --> Hooks Class Initialized
DEBUG - 2016-08-06 18:51:22 --> UTF-8 Support Enabled
INFO - 2016-08-06 18:51:22 --> Utf8 Class Initialized
INFO - 2016-08-06 18:51:22 --> URI Class Initialized
INFO - 2016-08-06 18:51:22 --> Router Class Initialized
INFO - 2016-08-06 18:51:22 --> Output Class Initialized
INFO - 2016-08-06 18:51:22 --> Security Class Initialized
DEBUG - 2016-08-06 18:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 18:51:22 --> Input Class Initialized
INFO - 2016-08-06 18:51:22 --> Language Class Initialized
INFO - 2016-08-06 18:51:22 --> Loader Class Initialized
INFO - 2016-08-06 18:51:22 --> Helper loaded: url_helper
INFO - 2016-08-06 18:51:22 --> Database Driver Class Initialized
INFO - 2016-08-06 18:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 18:51:22 --> Email Class Initialized
INFO - 2016-08-06 18:51:22 --> Controller Class Initialized
DEBUG - 2016-08-06 18:51:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 18:51:22 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 18:51:27 --> Final output sent to browser
DEBUG - 2016-08-06 18:51:27 --> Total execution time: 4.8993
INFO - 2016-08-06 19:05:09 --> Config Class Initialized
INFO - 2016-08-06 19:05:09 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:05:09 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:05:09 --> Utf8 Class Initialized
INFO - 2016-08-06 19:05:09 --> URI Class Initialized
INFO - 2016-08-06 19:05:09 --> Router Class Initialized
INFO - 2016-08-06 19:05:09 --> Output Class Initialized
INFO - 2016-08-06 19:05:09 --> Security Class Initialized
DEBUG - 2016-08-06 19:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:05:09 --> Input Class Initialized
INFO - 2016-08-06 19:05:09 --> Language Class Initialized
INFO - 2016-08-06 19:05:09 --> Loader Class Initialized
INFO - 2016-08-06 19:05:09 --> Helper loaded: url_helper
INFO - 2016-08-06 19:05:09 --> Database Driver Class Initialized
INFO - 2016-08-06 19:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:05:09 --> Email Class Initialized
INFO - 2016-08-06 19:05:09 --> Controller Class Initialized
DEBUG - 2016-08-06 19:05:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 19:05:15 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-06 19:05:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:19 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:19 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:19 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:19 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:20 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:20 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:20 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:20 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:05:21 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-06 19:07:03 --> Config Class Initialized
INFO - 2016-08-06 19:07:03 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:07:03 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:07:03 --> Utf8 Class Initialized
INFO - 2016-08-06 19:07:03 --> URI Class Initialized
INFO - 2016-08-06 19:07:03 --> Router Class Initialized
INFO - 2016-08-06 19:07:03 --> Output Class Initialized
INFO - 2016-08-06 19:07:03 --> Security Class Initialized
DEBUG - 2016-08-06 19:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:07:03 --> Input Class Initialized
INFO - 2016-08-06 19:07:03 --> Language Class Initialized
INFO - 2016-08-06 19:07:03 --> Loader Class Initialized
INFO - 2016-08-06 19:07:03 --> Helper loaded: url_helper
INFO - 2016-08-06 19:07:03 --> Database Driver Class Initialized
INFO - 2016-08-06 19:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:07:03 --> Email Class Initialized
INFO - 2016-08-06 19:07:03 --> Controller Class Initialized
DEBUG - 2016-08-06 19:07:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 19:07:09 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-06 19:07:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:07:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-06 19:08:15 --> Config Class Initialized
INFO - 2016-08-06 19:08:15 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:08:15 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:08:15 --> Utf8 Class Initialized
INFO - 2016-08-06 19:08:15 --> URI Class Initialized
INFO - 2016-08-06 19:08:15 --> Router Class Initialized
INFO - 2016-08-06 19:08:15 --> Output Class Initialized
INFO - 2016-08-06 19:08:15 --> Security Class Initialized
DEBUG - 2016-08-06 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:08:15 --> Input Class Initialized
INFO - 2016-08-06 19:08:15 --> Language Class Initialized
INFO - 2016-08-06 19:08:15 --> Loader Class Initialized
INFO - 2016-08-06 19:08:15 --> Helper loaded: url_helper
INFO - 2016-08-06 19:08:15 --> Database Driver Class Initialized
INFO - 2016-08-06 19:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:08:15 --> Email Class Initialized
INFO - 2016-08-06 19:08:15 --> Controller Class Initialized
DEBUG - 2016-08-06 19:08:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 19:08:20 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 19:13:29 --> Config Class Initialized
INFO - 2016-08-06 19:13:29 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:13:29 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:13:29 --> Utf8 Class Initialized
INFO - 2016-08-06 19:13:29 --> URI Class Initialized
INFO - 2016-08-06 19:13:29 --> Router Class Initialized
INFO - 2016-08-06 19:13:29 --> Output Class Initialized
INFO - 2016-08-06 19:13:29 --> Security Class Initialized
DEBUG - 2016-08-06 19:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:13:29 --> Input Class Initialized
INFO - 2016-08-06 19:13:29 --> Language Class Initialized
INFO - 2016-08-06 19:13:29 --> Loader Class Initialized
INFO - 2016-08-06 19:13:29 --> Helper loaded: url_helper
INFO - 2016-08-06 19:13:29 --> Database Driver Class Initialized
INFO - 2016-08-06 19:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:13:29 --> Email Class Initialized
INFO - 2016-08-06 19:13:29 --> Controller Class Initialized
DEBUG - 2016-08-06 19:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 19:13:34 --> Language file loaded: language/english/email_lang.php
INFO - 2016-08-06 19:25:24 --> Config Class Initialized
INFO - 2016-08-06 19:25:24 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:25:25 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:25:25 --> Utf8 Class Initialized
INFO - 2016-08-06 19:25:25 --> URI Class Initialized
INFO - 2016-08-06 19:25:25 --> Router Class Initialized
INFO - 2016-08-06 19:25:25 --> Output Class Initialized
INFO - 2016-08-06 19:25:25 --> Security Class Initialized
DEBUG - 2016-08-06 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:25:25 --> Input Class Initialized
INFO - 2016-08-06 19:25:25 --> Language Class Initialized
INFO - 2016-08-06 19:25:25 --> Loader Class Initialized
INFO - 2016-08-06 19:25:25 --> Helper loaded: url_helper
INFO - 2016-08-06 19:25:25 --> Database Driver Class Initialized
INFO - 2016-08-06 19:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:25:25 --> Email Class Initialized
INFO - 2016-08-06 19:25:25 --> Controller Class Initialized
DEBUG - 2016-08-06 19:25:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-06 19:25:30 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-06 19:25:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-06 19:25:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-06 19:44:56 --> Config Class Initialized
INFO - 2016-08-06 19:44:56 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:44:56 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:44:56 --> Utf8 Class Initialized
INFO - 2016-08-06 19:44:56 --> URI Class Initialized
INFO - 2016-08-06 19:44:56 --> Router Class Initialized
INFO - 2016-08-06 19:44:56 --> Output Class Initialized
INFO - 2016-08-06 19:44:56 --> Security Class Initialized
DEBUG - 2016-08-06 19:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:44:56 --> Input Class Initialized
INFO - 2016-08-06 19:44:56 --> Language Class Initialized
INFO - 2016-08-06 19:44:56 --> Loader Class Initialized
INFO - 2016-08-06 19:44:56 --> Helper loaded: url_helper
INFO - 2016-08-06 19:44:56 --> Database Driver Class Initialized
INFO - 2016-08-06 19:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-06 19:44:56 --> Email Class Initialized
INFO - 2016-08-06 19:44:56 --> Controller Class Initialized
INFO - 2016-08-06 19:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-06 19:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-06 19:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-06 19:44:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-06 19:44:56 --> Final output sent to browser
DEBUG - 2016-08-06 19:44:56 --> Total execution time: 0.2436
INFO - 2016-08-06 19:44:57 --> Config Class Initialized
INFO - 2016-08-06 19:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-06 19:44:57 --> UTF-8 Support Enabled
INFO - 2016-08-06 19:44:57 --> Utf8 Class Initialized
INFO - 2016-08-06 19:44:57 --> URI Class Initialized
INFO - 2016-08-06 19:44:57 --> Router Class Initialized
INFO - 2016-08-06 19:44:57 --> Output Class Initialized
INFO - 2016-08-06 19:44:57 --> Security Class Initialized
DEBUG - 2016-08-06 19:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-06 19:44:57 --> Input Class Initialized
INFO - 2016-08-06 19:44:57 --> Language Class Initialized
ERROR - 2016-08-06 19:44:57 --> 404 Page Not Found: Assets/css
