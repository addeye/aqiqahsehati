<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-12 00:01:42 --> Config Class Initialized
INFO - 2016-08-12 00:01:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:01:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:01:42 --> Utf8 Class Initialized
INFO - 2016-08-12 00:01:42 --> URI Class Initialized
INFO - 2016-08-12 00:01:42 --> Router Class Initialized
INFO - 2016-08-12 00:01:42 --> Output Class Initialized
INFO - 2016-08-12 00:01:42 --> Security Class Initialized
DEBUG - 2016-08-12 00:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:01:42 --> Input Class Initialized
INFO - 2016-08-12 00:01:42 --> Language Class Initialized
INFO - 2016-08-12 00:01:42 --> Loader Class Initialized
INFO - 2016-08-12 00:01:42 --> Helper loaded: url_helper
INFO - 2016-08-12 00:01:42 --> Helper loaded: date_helper
INFO - 2016-08-12 00:01:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:01:42 --> Database Driver Class Initialized
INFO - 2016-08-12 00:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:01:42 --> Email Class Initialized
INFO - 2016-08-12 00:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:01:42 --> Pagination Class Initialized
INFO - 2016-08-12 00:01:42 --> Model Class Initialized
INFO - 2016-08-12 00:01:42 --> Controller Class Initialized
INFO - 2016-08-12 00:01:42 --> Model Class Initialized
INFO - 2016-08-12 00:01:42 --> Helper loaded: text_helper
INFO - 2016-08-12 00:01:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:01:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:01:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-12 00:01:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:01:42 --> Final output sent to browser
DEBUG - 2016-08-12 00:01:42 --> Total execution time: 0.4096
INFO - 2016-08-12 00:01:43 --> Config Class Initialized
INFO - 2016-08-12 00:01:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:01:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:01:43 --> Utf8 Class Initialized
INFO - 2016-08-12 00:01:43 --> URI Class Initialized
INFO - 2016-08-12 00:01:43 --> Router Class Initialized
INFO - 2016-08-12 00:01:43 --> Output Class Initialized
INFO - 2016-08-12 00:01:43 --> Security Class Initialized
DEBUG - 2016-08-12 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:01:43 --> Input Class Initialized
INFO - 2016-08-12 00:01:43 --> Language Class Initialized
ERROR - 2016-08-12 00:01:43 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 00:03:01 --> Config Class Initialized
INFO - 2016-08-12 00:03:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:03:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:03:01 --> Utf8 Class Initialized
INFO - 2016-08-12 00:03:01 --> URI Class Initialized
INFO - 2016-08-12 00:03:01 --> Router Class Initialized
INFO - 2016-08-12 00:03:01 --> Output Class Initialized
INFO - 2016-08-12 00:03:01 --> Security Class Initialized
DEBUG - 2016-08-12 00:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:03:01 --> Input Class Initialized
INFO - 2016-08-12 00:03:01 --> Language Class Initialized
INFO - 2016-08-12 00:03:01 --> Loader Class Initialized
INFO - 2016-08-12 00:03:01 --> Helper loaded: url_helper
INFO - 2016-08-12 00:03:01 --> Helper loaded: date_helper
INFO - 2016-08-12 00:03:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:03:01 --> Database Driver Class Initialized
INFO - 2016-08-12 00:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:03:01 --> Email Class Initialized
INFO - 2016-08-12 00:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:03:01 --> Pagination Class Initialized
INFO - 2016-08-12 00:03:01 --> Model Class Initialized
INFO - 2016-08-12 00:03:01 --> Controller Class Initialized
INFO - 2016-08-12 00:03:01 --> Model Class Initialized
INFO - 2016-08-12 00:03:01 --> Helper loaded: text_helper
INFO - 2016-08-12 00:03:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:03:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:03:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-12 00:03:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:03:01 --> Final output sent to browser
DEBUG - 2016-08-12 00:03:02 --> Total execution time: 0.3153
INFO - 2016-08-12 00:04:13 --> Config Class Initialized
INFO - 2016-08-12 00:04:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:04:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:04:13 --> Utf8 Class Initialized
INFO - 2016-08-12 00:04:13 --> URI Class Initialized
INFO - 2016-08-12 00:04:13 --> Router Class Initialized
INFO - 2016-08-12 00:04:13 --> Output Class Initialized
INFO - 2016-08-12 00:04:13 --> Security Class Initialized
DEBUG - 2016-08-12 00:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:04:13 --> Input Class Initialized
INFO - 2016-08-12 00:04:13 --> Language Class Initialized
INFO - 2016-08-12 00:04:13 --> Loader Class Initialized
INFO - 2016-08-12 00:04:13 --> Helper loaded: url_helper
INFO - 2016-08-12 00:04:13 --> Helper loaded: date_helper
INFO - 2016-08-12 00:04:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:04:13 --> Database Driver Class Initialized
INFO - 2016-08-12 00:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:04:13 --> Email Class Initialized
INFO - 2016-08-12 00:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:04:14 --> Pagination Class Initialized
INFO - 2016-08-12 00:04:14 --> Model Class Initialized
INFO - 2016-08-12 00:04:14 --> Controller Class Initialized
INFO - 2016-08-12 00:04:14 --> Model Class Initialized
INFO - 2016-08-12 00:04:14 --> Helper loaded: text_helper
INFO - 2016-08-12 00:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-12 00:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:04:14 --> Final output sent to browser
DEBUG - 2016-08-12 00:04:14 --> Total execution time: 0.3691
INFO - 2016-08-12 00:04:14 --> Config Class Initialized
INFO - 2016-08-12 00:04:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:04:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:04:14 --> Utf8 Class Initialized
INFO - 2016-08-12 00:04:14 --> URI Class Initialized
INFO - 2016-08-12 00:04:14 --> Router Class Initialized
INFO - 2016-08-12 00:04:14 --> Output Class Initialized
INFO - 2016-08-12 00:04:14 --> Security Class Initialized
DEBUG - 2016-08-12 00:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:04:14 --> Input Class Initialized
INFO - 2016-08-12 00:04:14 --> Language Class Initialized
ERROR - 2016-08-12 00:04:14 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 00:05:12 --> Config Class Initialized
INFO - 2016-08-12 00:05:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:05:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:05:12 --> Utf8 Class Initialized
INFO - 2016-08-12 00:05:12 --> URI Class Initialized
INFO - 2016-08-12 00:05:12 --> Router Class Initialized
INFO - 2016-08-12 00:05:12 --> Output Class Initialized
INFO - 2016-08-12 00:05:12 --> Security Class Initialized
DEBUG - 2016-08-12 00:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:05:12 --> Input Class Initialized
INFO - 2016-08-12 00:05:12 --> Language Class Initialized
INFO - 2016-08-12 00:05:12 --> Loader Class Initialized
INFO - 2016-08-12 00:05:12 --> Helper loaded: url_helper
INFO - 2016-08-12 00:05:12 --> Helper loaded: date_helper
INFO - 2016-08-12 00:05:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:05:12 --> Database Driver Class Initialized
INFO - 2016-08-12 00:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:05:12 --> Email Class Initialized
INFO - 2016-08-12 00:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:05:12 --> Pagination Class Initialized
INFO - 2016-08-12 00:05:12 --> Model Class Initialized
INFO - 2016-08-12 00:05:12 --> Controller Class Initialized
INFO - 2016-08-12 00:05:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:05:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:05:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:05:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:05:13 --> Final output sent to browser
DEBUG - 2016-08-12 00:05:13 --> Total execution time: 0.3006
INFO - 2016-08-12 00:05:22 --> Config Class Initialized
INFO - 2016-08-12 00:05:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:05:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:05:22 --> Utf8 Class Initialized
INFO - 2016-08-12 00:05:22 --> URI Class Initialized
INFO - 2016-08-12 00:05:22 --> Router Class Initialized
INFO - 2016-08-12 00:05:22 --> Output Class Initialized
INFO - 2016-08-12 00:05:22 --> Security Class Initialized
DEBUG - 2016-08-12 00:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:05:22 --> Input Class Initialized
INFO - 2016-08-12 00:05:22 --> Language Class Initialized
ERROR - 2016-08-12 00:05:22 --> 404 Page Not Found: Page/index
INFO - 2016-08-12 00:05:27 --> Config Class Initialized
INFO - 2016-08-12 00:05:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:05:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:05:27 --> Utf8 Class Initialized
INFO - 2016-08-12 00:05:27 --> URI Class Initialized
INFO - 2016-08-12 00:05:27 --> Router Class Initialized
INFO - 2016-08-12 00:05:27 --> Output Class Initialized
INFO - 2016-08-12 00:05:27 --> Security Class Initialized
DEBUG - 2016-08-12 00:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:05:27 --> Input Class Initialized
INFO - 2016-08-12 00:05:27 --> Language Class Initialized
INFO - 2016-08-12 00:05:27 --> Loader Class Initialized
INFO - 2016-08-12 00:05:27 --> Helper loaded: url_helper
INFO - 2016-08-12 00:05:27 --> Helper loaded: date_helper
INFO - 2016-08-12 00:05:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:05:27 --> Database Driver Class Initialized
INFO - 2016-08-12 00:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:05:27 --> Email Class Initialized
INFO - 2016-08-12 00:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:05:27 --> Pagination Class Initialized
INFO - 2016-08-12 00:05:27 --> Model Class Initialized
INFO - 2016-08-12 00:05:27 --> Controller Class Initialized
INFO - 2016-08-12 00:05:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:05:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-12 00:05:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
ERROR - 2016-08-12 00:05:27 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 67
INFO - 2016-08-12 00:05:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:05:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:05:27 --> Final output sent to browser
DEBUG - 2016-08-12 00:05:27 --> Total execution time: 0.2805
INFO - 2016-08-12 00:05:30 --> Config Class Initialized
INFO - 2016-08-12 00:05:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:05:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:05:30 --> Utf8 Class Initialized
INFO - 2016-08-12 00:05:30 --> URI Class Initialized
INFO - 2016-08-12 00:05:30 --> Router Class Initialized
INFO - 2016-08-12 00:05:30 --> Output Class Initialized
INFO - 2016-08-12 00:05:30 --> Security Class Initialized
DEBUG - 2016-08-12 00:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:05:30 --> Input Class Initialized
INFO - 2016-08-12 00:05:30 --> Language Class Initialized
INFO - 2016-08-12 00:05:30 --> Loader Class Initialized
INFO - 2016-08-12 00:05:30 --> Helper loaded: url_helper
INFO - 2016-08-12 00:05:30 --> Helper loaded: date_helper
INFO - 2016-08-12 00:05:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:05:30 --> Database Driver Class Initialized
INFO - 2016-08-12 00:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:05:30 --> Email Class Initialized
INFO - 2016-08-12 00:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:05:30 --> Pagination Class Initialized
INFO - 2016-08-12 00:05:30 --> Model Class Initialized
INFO - 2016-08-12 00:05:30 --> Controller Class Initialized
INFO - 2016-08-12 00:05:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:05:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-12 00:05:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
ERROR - 2016-08-12 00:05:30 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 67
INFO - 2016-08-12 00:05:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:05:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:05:30 --> Final output sent to browser
DEBUG - 2016-08-12 00:05:30 --> Total execution time: 0.2875
INFO - 2016-08-12 00:05:44 --> Config Class Initialized
INFO - 2016-08-12 00:05:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:05:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:05:44 --> Utf8 Class Initialized
INFO - 2016-08-12 00:05:44 --> URI Class Initialized
INFO - 2016-08-12 00:05:44 --> Router Class Initialized
INFO - 2016-08-12 00:05:44 --> Output Class Initialized
INFO - 2016-08-12 00:05:44 --> Security Class Initialized
DEBUG - 2016-08-12 00:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:05:44 --> Input Class Initialized
INFO - 2016-08-12 00:05:44 --> Language Class Initialized
INFO - 2016-08-12 00:05:44 --> Loader Class Initialized
INFO - 2016-08-12 00:05:45 --> Helper loaded: url_helper
INFO - 2016-08-12 00:05:45 --> Helper loaded: date_helper
INFO - 2016-08-12 00:05:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:05:45 --> Database Driver Class Initialized
INFO - 2016-08-12 00:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:05:45 --> Email Class Initialized
INFO - 2016-08-12 00:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:05:45 --> Pagination Class Initialized
INFO - 2016-08-12 00:05:45 --> Model Class Initialized
INFO - 2016-08-12 00:05:45 --> Controller Class Initialized
INFO - 2016-08-12 00:05:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:05:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:05:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:05:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:05:45 --> Final output sent to browser
DEBUG - 2016-08-12 00:05:45 --> Total execution time: 0.2735
INFO - 2016-08-12 00:07:01 --> Config Class Initialized
INFO - 2016-08-12 00:07:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:07:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:07:01 --> Utf8 Class Initialized
INFO - 2016-08-12 00:07:01 --> URI Class Initialized
INFO - 2016-08-12 00:07:01 --> Router Class Initialized
INFO - 2016-08-12 00:07:01 --> Output Class Initialized
INFO - 2016-08-12 00:07:01 --> Security Class Initialized
DEBUG - 2016-08-12 00:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:07:01 --> Input Class Initialized
INFO - 2016-08-12 00:07:01 --> Language Class Initialized
INFO - 2016-08-12 00:07:01 --> Loader Class Initialized
INFO - 2016-08-12 00:07:01 --> Helper loaded: url_helper
INFO - 2016-08-12 00:07:01 --> Helper loaded: date_helper
INFO - 2016-08-12 00:07:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:07:01 --> Database Driver Class Initialized
INFO - 2016-08-12 00:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:07:01 --> Email Class Initialized
INFO - 2016-08-12 00:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:07:01 --> Pagination Class Initialized
INFO - 2016-08-12 00:07:01 --> Model Class Initialized
INFO - 2016-08-12 00:07:01 --> Controller Class Initialized
INFO - 2016-08-12 00:07:01 --> Model Class Initialized
INFO - 2016-08-12 00:07:01 --> Helper loaded: text_helper
INFO - 2016-08-12 00:07:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:07:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:07:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 00:07:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:07:02 --> Final output sent to browser
DEBUG - 2016-08-12 00:07:02 --> Total execution time: 0.3808
INFO - 2016-08-12 00:07:26 --> Config Class Initialized
INFO - 2016-08-12 00:07:26 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:07:26 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:07:26 --> Utf8 Class Initialized
INFO - 2016-08-12 00:07:26 --> URI Class Initialized
DEBUG - 2016-08-12 00:07:26 --> No URI present. Default controller set.
INFO - 2016-08-12 00:07:26 --> Router Class Initialized
INFO - 2016-08-12 00:07:26 --> Output Class Initialized
INFO - 2016-08-12 00:07:26 --> Security Class Initialized
DEBUG - 2016-08-12 00:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:07:26 --> Input Class Initialized
INFO - 2016-08-12 00:07:26 --> Language Class Initialized
INFO - 2016-08-12 00:07:26 --> Loader Class Initialized
INFO - 2016-08-12 00:07:26 --> Helper loaded: url_helper
INFO - 2016-08-12 00:07:26 --> Helper loaded: date_helper
INFO - 2016-08-12 00:07:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:07:26 --> Database Driver Class Initialized
INFO - 2016-08-12 00:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:07:26 --> Email Class Initialized
INFO - 2016-08-12 00:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:07:26 --> Pagination Class Initialized
INFO - 2016-08-12 00:07:26 --> Model Class Initialized
INFO - 2016-08-12 00:07:26 --> Controller Class Initialized
INFO - 2016-08-12 00:07:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:07:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:07:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 00:07:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:07:26 --> Final output sent to browser
DEBUG - 2016-08-12 00:07:26 --> Total execution time: 0.3417
INFO - 2016-08-12 00:07:33 --> Config Class Initialized
INFO - 2016-08-12 00:07:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:07:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:07:33 --> Utf8 Class Initialized
INFO - 2016-08-12 00:07:33 --> URI Class Initialized
INFO - 2016-08-12 00:07:33 --> Router Class Initialized
INFO - 2016-08-12 00:07:33 --> Output Class Initialized
INFO - 2016-08-12 00:07:33 --> Security Class Initialized
DEBUG - 2016-08-12 00:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:07:33 --> Input Class Initialized
INFO - 2016-08-12 00:07:33 --> Language Class Initialized
INFO - 2016-08-12 00:07:33 --> Loader Class Initialized
INFO - 2016-08-12 00:07:33 --> Helper loaded: url_helper
INFO - 2016-08-12 00:07:33 --> Helper loaded: date_helper
INFO - 2016-08-12 00:07:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:07:33 --> Database Driver Class Initialized
INFO - 2016-08-12 00:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:07:33 --> Email Class Initialized
INFO - 2016-08-12 00:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:07:33 --> Pagination Class Initialized
INFO - 2016-08-12 00:07:33 --> Model Class Initialized
INFO - 2016-08-12 00:07:33 --> Controller Class Initialized
INFO - 2016-08-12 00:07:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:07:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:07:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:07:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:07:33 --> Final output sent to browser
DEBUG - 2016-08-12 00:07:33 --> Total execution time: 0.2697
INFO - 2016-08-12 00:07:35 --> Config Class Initialized
INFO - 2016-08-12 00:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:07:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:07:35 --> Utf8 Class Initialized
INFO - 2016-08-12 00:07:35 --> URI Class Initialized
INFO - 2016-08-12 00:07:35 --> Router Class Initialized
INFO - 2016-08-12 00:07:35 --> Output Class Initialized
INFO - 2016-08-12 00:07:35 --> Security Class Initialized
DEBUG - 2016-08-12 00:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:07:35 --> Input Class Initialized
INFO - 2016-08-12 00:07:35 --> Language Class Initialized
INFO - 2016-08-12 00:07:35 --> Loader Class Initialized
INFO - 2016-08-12 00:07:35 --> Helper loaded: url_helper
INFO - 2016-08-12 00:07:35 --> Helper loaded: date_helper
INFO - 2016-08-12 00:07:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:07:35 --> Database Driver Class Initialized
INFO - 2016-08-12 00:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:07:35 --> Email Class Initialized
INFO - 2016-08-12 00:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:07:35 --> Pagination Class Initialized
INFO - 2016-08-12 00:07:35 --> Model Class Initialized
INFO - 2016-08-12 00:07:35 --> Controller Class Initialized
INFO - 2016-08-12 00:07:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:07:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:07:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:07:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:07:36 --> Final output sent to browser
DEBUG - 2016-08-12 00:07:36 --> Total execution time: 0.2754
INFO - 2016-08-12 00:08:10 --> Config Class Initialized
INFO - 2016-08-12 00:08:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:08:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:08:10 --> Utf8 Class Initialized
INFO - 2016-08-12 00:08:10 --> URI Class Initialized
INFO - 2016-08-12 00:08:10 --> Router Class Initialized
INFO - 2016-08-12 00:08:10 --> Output Class Initialized
INFO - 2016-08-12 00:08:10 --> Security Class Initialized
DEBUG - 2016-08-12 00:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:08:10 --> Input Class Initialized
INFO - 2016-08-12 00:08:10 --> Language Class Initialized
INFO - 2016-08-12 00:08:10 --> Loader Class Initialized
INFO - 2016-08-12 00:08:10 --> Helper loaded: url_helper
INFO - 2016-08-12 00:08:10 --> Helper loaded: date_helper
INFO - 2016-08-12 00:08:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:08:10 --> Database Driver Class Initialized
INFO - 2016-08-12 00:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:08:10 --> Email Class Initialized
INFO - 2016-08-12 00:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:08:10 --> Pagination Class Initialized
INFO - 2016-08-12 00:08:10 --> Model Class Initialized
INFO - 2016-08-12 00:08:10 --> Controller Class Initialized
INFO - 2016-08-12 00:08:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:08:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:08:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:08:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:08:11 --> Final output sent to browser
DEBUG - 2016-08-12 00:08:11 --> Total execution time: 0.3065
INFO - 2016-08-12 00:09:51 --> Config Class Initialized
INFO - 2016-08-12 00:09:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:09:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:09:51 --> Utf8 Class Initialized
INFO - 2016-08-12 00:09:51 --> URI Class Initialized
INFO - 2016-08-12 00:09:51 --> Router Class Initialized
INFO - 2016-08-12 00:09:51 --> Output Class Initialized
INFO - 2016-08-12 00:09:51 --> Security Class Initialized
DEBUG - 2016-08-12 00:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:09:51 --> Input Class Initialized
INFO - 2016-08-12 00:09:51 --> Language Class Initialized
INFO - 2016-08-12 00:09:51 --> Loader Class Initialized
INFO - 2016-08-12 00:09:51 --> Helper loaded: url_helper
INFO - 2016-08-12 00:09:51 --> Helper loaded: date_helper
INFO - 2016-08-12 00:09:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:09:51 --> Database Driver Class Initialized
INFO - 2016-08-12 00:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:09:51 --> Email Class Initialized
INFO - 2016-08-12 00:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:09:51 --> Pagination Class Initialized
INFO - 2016-08-12 00:09:51 --> Model Class Initialized
INFO - 2016-08-12 00:09:51 --> Controller Class Initialized
DEBUG - 2016-08-12 00:09:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:09:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:09:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:09:51 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:09:51 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:09:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:09:51 --> Model Class Initialized
INFO - 2016-08-12 00:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 00:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:09:51 --> Final output sent to browser
DEBUG - 2016-08-12 00:09:51 --> Total execution time: 0.3518
INFO - 2016-08-12 00:09:54 --> Config Class Initialized
INFO - 2016-08-12 00:09:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:09:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:09:54 --> Utf8 Class Initialized
INFO - 2016-08-12 00:09:54 --> URI Class Initialized
INFO - 2016-08-12 00:09:54 --> Router Class Initialized
INFO - 2016-08-12 00:09:54 --> Output Class Initialized
INFO - 2016-08-12 00:09:54 --> Security Class Initialized
DEBUG - 2016-08-12 00:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:09:55 --> Input Class Initialized
INFO - 2016-08-12 00:09:55 --> Language Class Initialized
INFO - 2016-08-12 00:09:55 --> Loader Class Initialized
INFO - 2016-08-12 00:09:55 --> Helper loaded: url_helper
INFO - 2016-08-12 00:09:55 --> Helper loaded: date_helper
INFO - 2016-08-12 00:09:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:09:55 --> Database Driver Class Initialized
INFO - 2016-08-12 00:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:09:55 --> Email Class Initialized
INFO - 2016-08-12 00:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:09:55 --> Pagination Class Initialized
INFO - 2016-08-12 00:09:55 --> Model Class Initialized
INFO - 2016-08-12 00:09:55 --> Controller Class Initialized
DEBUG - 2016-08-12 00:09:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:09:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:09:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:09:55 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:09:55 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:09:55 --> Model Class Initialized
INFO - 2016-08-12 00:09:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:09:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:09:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:09:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:09:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:09:55 --> Final output sent to browser
DEBUG - 2016-08-12 00:09:55 --> Total execution time: 0.3949
INFO - 2016-08-12 00:10:03 --> Config Class Initialized
INFO - 2016-08-12 00:10:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:10:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:10:03 --> Utf8 Class Initialized
INFO - 2016-08-12 00:10:03 --> URI Class Initialized
INFO - 2016-08-12 00:10:03 --> Router Class Initialized
INFO - 2016-08-12 00:10:03 --> Output Class Initialized
INFO - 2016-08-12 00:10:03 --> Security Class Initialized
DEBUG - 2016-08-12 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:10:03 --> Input Class Initialized
INFO - 2016-08-12 00:10:03 --> Language Class Initialized
INFO - 2016-08-12 00:10:03 --> Loader Class Initialized
INFO - 2016-08-12 00:10:03 --> Helper loaded: url_helper
INFO - 2016-08-12 00:10:03 --> Helper loaded: date_helper
INFO - 2016-08-12 00:10:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:10:03 --> Database Driver Class Initialized
INFO - 2016-08-12 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:10:04 --> Email Class Initialized
INFO - 2016-08-12 00:10:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:10:04 --> Pagination Class Initialized
INFO - 2016-08-12 00:10:04 --> Model Class Initialized
INFO - 2016-08-12 00:10:04 --> Controller Class Initialized
DEBUG - 2016-08-12 00:10:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:10:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:10:04 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:10:04 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:04 --> Model Class Initialized
INFO - 2016-08-12 00:10:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:10:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:10:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:10:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-12 00:10:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:10:04 --> Final output sent to browser
DEBUG - 2016-08-12 00:10:04 --> Total execution time: 0.5625
INFO - 2016-08-12 00:10:08 --> Config Class Initialized
INFO - 2016-08-12 00:10:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:10:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:10:08 --> Utf8 Class Initialized
INFO - 2016-08-12 00:10:08 --> URI Class Initialized
INFO - 2016-08-12 00:10:08 --> Router Class Initialized
INFO - 2016-08-12 00:10:08 --> Output Class Initialized
INFO - 2016-08-12 00:10:08 --> Security Class Initialized
DEBUG - 2016-08-12 00:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:10:08 --> Input Class Initialized
INFO - 2016-08-12 00:10:08 --> Language Class Initialized
INFO - 2016-08-12 00:10:08 --> Loader Class Initialized
INFO - 2016-08-12 00:10:08 --> Helper loaded: url_helper
INFO - 2016-08-12 00:10:08 --> Helper loaded: date_helper
INFO - 2016-08-12 00:10:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:10:08 --> Database Driver Class Initialized
INFO - 2016-08-12 00:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:10:08 --> Email Class Initialized
INFO - 2016-08-12 00:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:10:08 --> Pagination Class Initialized
INFO - 2016-08-12 00:10:08 --> Model Class Initialized
INFO - 2016-08-12 00:10:08 --> Controller Class Initialized
DEBUG - 2016-08-12 00:10:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:10:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:10:08 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:10:08 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:08 --> Model Class Initialized
INFO - 2016-08-12 00:10:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:10:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:10:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:10:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:10:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:10:08 --> Final output sent to browser
DEBUG - 2016-08-12 00:10:08 --> Total execution time: 0.3681
INFO - 2016-08-12 00:10:44 --> Config Class Initialized
INFO - 2016-08-12 00:10:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:10:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:10:44 --> Utf8 Class Initialized
INFO - 2016-08-12 00:10:44 --> URI Class Initialized
INFO - 2016-08-12 00:10:44 --> Router Class Initialized
INFO - 2016-08-12 00:10:44 --> Output Class Initialized
INFO - 2016-08-12 00:10:44 --> Security Class Initialized
DEBUG - 2016-08-12 00:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:10:44 --> Input Class Initialized
INFO - 2016-08-12 00:10:44 --> Language Class Initialized
INFO - 2016-08-12 00:10:44 --> Loader Class Initialized
INFO - 2016-08-12 00:10:44 --> Helper loaded: url_helper
INFO - 2016-08-12 00:10:44 --> Helper loaded: date_helper
INFO - 2016-08-12 00:10:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:10:44 --> Database Driver Class Initialized
INFO - 2016-08-12 00:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:10:44 --> Email Class Initialized
INFO - 2016-08-12 00:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:10:44 --> Pagination Class Initialized
INFO - 2016-08-12 00:10:44 --> Model Class Initialized
INFO - 2016-08-12 00:10:44 --> Controller Class Initialized
DEBUG - 2016-08-12 00:10:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:10:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:10:44 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:10:44 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:10:44 --> Model Class Initialized
INFO - 2016-08-12 00:10:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:10:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:10:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:10:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:10:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:10:44 --> Final output sent to browser
DEBUG - 2016-08-12 00:10:44 --> Total execution time: 0.3846
INFO - 2016-08-12 00:11:14 --> Config Class Initialized
INFO - 2016-08-12 00:11:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:11:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:11:14 --> Utf8 Class Initialized
INFO - 2016-08-12 00:11:14 --> URI Class Initialized
INFO - 2016-08-12 00:11:14 --> Router Class Initialized
INFO - 2016-08-12 00:11:14 --> Output Class Initialized
INFO - 2016-08-12 00:11:14 --> Security Class Initialized
DEBUG - 2016-08-12 00:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:11:14 --> Input Class Initialized
INFO - 2016-08-12 00:11:14 --> Language Class Initialized
INFO - 2016-08-12 00:11:14 --> Loader Class Initialized
INFO - 2016-08-12 00:11:14 --> Helper loaded: url_helper
INFO - 2016-08-12 00:11:14 --> Helper loaded: date_helper
INFO - 2016-08-12 00:11:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:11:14 --> Database Driver Class Initialized
INFO - 2016-08-12 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:11:14 --> Email Class Initialized
INFO - 2016-08-12 00:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:11:14 --> Pagination Class Initialized
INFO - 2016-08-12 00:11:14 --> Model Class Initialized
INFO - 2016-08-12 00:11:14 --> Controller Class Initialized
INFO - 2016-08-12 00:11:14 --> Model Class Initialized
INFO - 2016-08-12 00:11:14 --> Helper loaded: text_helper
INFO - 2016-08-12 00:11:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:11:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:11:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 00:11:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:11:14 --> Final output sent to browser
DEBUG - 2016-08-12 00:11:14 --> Total execution time: 0.3663
INFO - 2016-08-12 00:11:27 --> Config Class Initialized
INFO - 2016-08-12 00:11:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:11:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:11:28 --> Utf8 Class Initialized
INFO - 2016-08-12 00:11:28 --> URI Class Initialized
INFO - 2016-08-12 00:11:28 --> Router Class Initialized
INFO - 2016-08-12 00:11:28 --> Output Class Initialized
INFO - 2016-08-12 00:11:28 --> Security Class Initialized
DEBUG - 2016-08-12 00:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:11:28 --> Input Class Initialized
INFO - 2016-08-12 00:11:28 --> Language Class Initialized
INFO - 2016-08-12 00:11:28 --> Loader Class Initialized
INFO - 2016-08-12 00:11:28 --> Helper loaded: url_helper
INFO - 2016-08-12 00:11:28 --> Helper loaded: date_helper
INFO - 2016-08-12 00:11:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:11:28 --> Database Driver Class Initialized
INFO - 2016-08-12 00:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:11:28 --> Email Class Initialized
INFO - 2016-08-12 00:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:11:28 --> Pagination Class Initialized
INFO - 2016-08-12 00:11:28 --> Model Class Initialized
INFO - 2016-08-12 00:11:28 --> Controller Class Initialized
INFO - 2016-08-12 00:11:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:11:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:11:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:11:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:11:28 --> Final output sent to browser
DEBUG - 2016-08-12 00:11:28 --> Total execution time: 0.2849
INFO - 2016-08-12 00:11:40 --> Config Class Initialized
INFO - 2016-08-12 00:11:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:11:40 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:11:40 --> Utf8 Class Initialized
INFO - 2016-08-12 00:11:40 --> URI Class Initialized
INFO - 2016-08-12 00:11:40 --> Router Class Initialized
INFO - 2016-08-12 00:11:40 --> Output Class Initialized
INFO - 2016-08-12 00:11:40 --> Security Class Initialized
DEBUG - 2016-08-12 00:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:11:40 --> Input Class Initialized
INFO - 2016-08-12 00:11:40 --> Language Class Initialized
INFO - 2016-08-12 00:11:40 --> Loader Class Initialized
INFO - 2016-08-12 00:11:40 --> Helper loaded: url_helper
INFO - 2016-08-12 00:11:40 --> Helper loaded: date_helper
INFO - 2016-08-12 00:11:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:11:40 --> Database Driver Class Initialized
INFO - 2016-08-12 00:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:11:40 --> Email Class Initialized
INFO - 2016-08-12 00:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:11:40 --> Pagination Class Initialized
INFO - 2016-08-12 00:11:40 --> Model Class Initialized
INFO - 2016-08-12 00:11:40 --> Controller Class Initialized
INFO - 2016-08-12 00:11:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:11:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:11:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:11:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:11:40 --> Final output sent to browser
DEBUG - 2016-08-12 00:11:40 --> Total execution time: 0.3027
INFO - 2016-08-12 00:11:42 --> Config Class Initialized
INFO - 2016-08-12 00:11:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:11:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:11:43 --> Utf8 Class Initialized
INFO - 2016-08-12 00:11:43 --> URI Class Initialized
INFO - 2016-08-12 00:11:43 --> Router Class Initialized
INFO - 2016-08-12 00:11:43 --> Output Class Initialized
INFO - 2016-08-12 00:11:43 --> Security Class Initialized
DEBUG - 2016-08-12 00:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:11:43 --> Input Class Initialized
INFO - 2016-08-12 00:11:43 --> Language Class Initialized
INFO - 2016-08-12 00:11:43 --> Loader Class Initialized
INFO - 2016-08-12 00:11:43 --> Helper loaded: url_helper
INFO - 2016-08-12 00:11:43 --> Helper loaded: date_helper
INFO - 2016-08-12 00:11:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:11:43 --> Database Driver Class Initialized
INFO - 2016-08-12 00:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:11:43 --> Email Class Initialized
INFO - 2016-08-12 00:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:11:43 --> Pagination Class Initialized
INFO - 2016-08-12 00:11:43 --> Model Class Initialized
INFO - 2016-08-12 00:11:43 --> Controller Class Initialized
INFO - 2016-08-12 00:11:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:11:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:11:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:11:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:11:43 --> Final output sent to browser
DEBUG - 2016-08-12 00:11:43 --> Total execution time: 0.3886
INFO - 2016-08-12 00:16:15 --> Config Class Initialized
INFO - 2016-08-12 00:16:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:16:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:16:15 --> Utf8 Class Initialized
INFO - 2016-08-12 00:16:15 --> URI Class Initialized
INFO - 2016-08-12 00:16:15 --> Router Class Initialized
INFO - 2016-08-12 00:16:15 --> Output Class Initialized
INFO - 2016-08-12 00:16:15 --> Security Class Initialized
DEBUG - 2016-08-12 00:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:16:15 --> Input Class Initialized
INFO - 2016-08-12 00:16:15 --> Language Class Initialized
INFO - 2016-08-12 00:16:15 --> Loader Class Initialized
INFO - 2016-08-12 00:16:15 --> Helper loaded: url_helper
INFO - 2016-08-12 00:16:15 --> Helper loaded: date_helper
INFO - 2016-08-12 00:16:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:16:15 --> Database Driver Class Initialized
INFO - 2016-08-12 00:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:16:15 --> Email Class Initialized
INFO - 2016-08-12 00:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:16:15 --> Pagination Class Initialized
INFO - 2016-08-12 00:16:15 --> Model Class Initialized
INFO - 2016-08-12 00:16:15 --> Controller Class Initialized
INFO - 2016-08-12 00:16:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:16:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:16:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:16:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:16:15 --> Final output sent to browser
DEBUG - 2016-08-12 00:16:15 --> Total execution time: 0.2895
INFO - 2016-08-12 00:16:20 --> Config Class Initialized
INFO - 2016-08-12 00:16:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:16:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:16:20 --> Utf8 Class Initialized
INFO - 2016-08-12 00:16:20 --> URI Class Initialized
INFO - 2016-08-12 00:16:20 --> Router Class Initialized
INFO - 2016-08-12 00:16:20 --> Output Class Initialized
INFO - 2016-08-12 00:16:20 --> Security Class Initialized
DEBUG - 2016-08-12 00:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:16:20 --> Input Class Initialized
INFO - 2016-08-12 00:16:20 --> Language Class Initialized
INFO - 2016-08-12 00:16:20 --> Loader Class Initialized
INFO - 2016-08-12 00:16:20 --> Helper loaded: url_helper
INFO - 2016-08-12 00:16:20 --> Helper loaded: date_helper
INFO - 2016-08-12 00:16:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:16:20 --> Database Driver Class Initialized
INFO - 2016-08-12 00:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:16:20 --> Email Class Initialized
INFO - 2016-08-12 00:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:16:20 --> Pagination Class Initialized
INFO - 2016-08-12 00:16:20 --> Model Class Initialized
INFO - 2016-08-12 00:16:20 --> Controller Class Initialized
INFO - 2016-08-12 00:16:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:16:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:16:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:16:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:16:20 --> Final output sent to browser
DEBUG - 2016-08-12 00:16:20 --> Total execution time: 0.2987
INFO - 2016-08-12 00:16:23 --> Config Class Initialized
INFO - 2016-08-12 00:16:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:16:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:16:23 --> Utf8 Class Initialized
INFO - 2016-08-12 00:16:23 --> URI Class Initialized
INFO - 2016-08-12 00:16:23 --> Router Class Initialized
INFO - 2016-08-12 00:16:23 --> Output Class Initialized
INFO - 2016-08-12 00:16:23 --> Security Class Initialized
DEBUG - 2016-08-12 00:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:16:23 --> Input Class Initialized
INFO - 2016-08-12 00:16:23 --> Language Class Initialized
INFO - 2016-08-12 00:16:23 --> Loader Class Initialized
INFO - 2016-08-12 00:16:23 --> Helper loaded: url_helper
INFO - 2016-08-12 00:16:23 --> Helper loaded: date_helper
INFO - 2016-08-12 00:16:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:16:23 --> Database Driver Class Initialized
INFO - 2016-08-12 00:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:16:23 --> Email Class Initialized
INFO - 2016-08-12 00:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:16:23 --> Pagination Class Initialized
INFO - 2016-08-12 00:16:23 --> Model Class Initialized
INFO - 2016-08-12 00:16:23 --> Controller Class Initialized
INFO - 2016-08-12 00:16:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:16:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:16:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:16:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:16:23 --> Final output sent to browser
DEBUG - 2016-08-12 00:16:24 --> Total execution time: 0.2962
INFO - 2016-08-12 00:20:01 --> Config Class Initialized
INFO - 2016-08-12 00:20:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:20:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:20:01 --> Utf8 Class Initialized
INFO - 2016-08-12 00:20:01 --> URI Class Initialized
INFO - 2016-08-12 00:20:01 --> Router Class Initialized
INFO - 2016-08-12 00:20:01 --> Output Class Initialized
INFO - 2016-08-12 00:20:01 --> Security Class Initialized
DEBUG - 2016-08-12 00:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:20:01 --> Input Class Initialized
INFO - 2016-08-12 00:20:01 --> Language Class Initialized
INFO - 2016-08-12 00:20:01 --> Loader Class Initialized
INFO - 2016-08-12 00:20:01 --> Helper loaded: url_helper
INFO - 2016-08-12 00:20:01 --> Helper loaded: date_helper
INFO - 2016-08-12 00:20:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:20:01 --> Database Driver Class Initialized
INFO - 2016-08-12 00:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:20:01 --> Email Class Initialized
INFO - 2016-08-12 00:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:20:01 --> Pagination Class Initialized
INFO - 2016-08-12 00:20:01 --> Model Class Initialized
INFO - 2016-08-12 00:20:01 --> Controller Class Initialized
DEBUG - 2016-08-12 00:20:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:20:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:20:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:20:01 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:20:01 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:20:01 --> Model Class Initialized
INFO - 2016-08-12 00:20:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:20:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:20:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:20:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-12 00:20:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:20:01 --> Final output sent to browser
DEBUG - 2016-08-12 00:20:01 --> Total execution time: 0.4524
INFO - 2016-08-12 00:21:31 --> Config Class Initialized
INFO - 2016-08-12 00:21:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:21:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:21:31 --> Utf8 Class Initialized
INFO - 2016-08-12 00:21:31 --> URI Class Initialized
INFO - 2016-08-12 00:21:31 --> Router Class Initialized
INFO - 2016-08-12 00:21:31 --> Output Class Initialized
INFO - 2016-08-12 00:21:31 --> Security Class Initialized
DEBUG - 2016-08-12 00:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:21:31 --> Input Class Initialized
INFO - 2016-08-12 00:21:31 --> Language Class Initialized
ERROR - 2016-08-12 00:21:31 --> 404 Page Not Found: Content/%3C
INFO - 2016-08-12 00:22:34 --> Config Class Initialized
INFO - 2016-08-12 00:22:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:22:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:22:34 --> Utf8 Class Initialized
INFO - 2016-08-12 00:22:34 --> URI Class Initialized
INFO - 2016-08-12 00:22:34 --> Router Class Initialized
INFO - 2016-08-12 00:22:34 --> Output Class Initialized
INFO - 2016-08-12 00:22:34 --> Security Class Initialized
DEBUG - 2016-08-12 00:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:22:34 --> Input Class Initialized
INFO - 2016-08-12 00:22:34 --> Language Class Initialized
INFO - 2016-08-12 00:22:34 --> Loader Class Initialized
INFO - 2016-08-12 00:22:34 --> Helper loaded: url_helper
INFO - 2016-08-12 00:22:34 --> Helper loaded: date_helper
INFO - 2016-08-12 00:22:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:22:34 --> Database Driver Class Initialized
INFO - 2016-08-12 00:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:22:34 --> Email Class Initialized
INFO - 2016-08-12 00:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:22:34 --> Pagination Class Initialized
INFO - 2016-08-12 00:22:34 --> Model Class Initialized
INFO - 2016-08-12 00:22:34 --> Controller Class Initialized
DEBUG - 2016-08-12 00:22:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:22:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:22:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:22:34 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:22:34 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:22:34 --> Model Class Initialized
INFO - 2016-08-12 00:22:34 --> Upload Class Initialized
INFO - 2016-08-12 00:22:34 --> Config Class Initialized
INFO - 2016-08-12 00:22:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:22:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:22:34 --> Utf8 Class Initialized
INFO - 2016-08-12 00:22:34 --> URI Class Initialized
INFO - 2016-08-12 00:22:34 --> Router Class Initialized
INFO - 2016-08-12 00:22:34 --> Output Class Initialized
INFO - 2016-08-12 00:22:34 --> Security Class Initialized
DEBUG - 2016-08-12 00:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:22:34 --> Input Class Initialized
INFO - 2016-08-12 00:22:34 --> Language Class Initialized
INFO - 2016-08-12 00:22:34 --> Loader Class Initialized
INFO - 2016-08-12 00:22:34 --> Helper loaded: url_helper
INFO - 2016-08-12 00:22:34 --> Helper loaded: date_helper
INFO - 2016-08-12 00:22:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:22:34 --> Database Driver Class Initialized
INFO - 2016-08-12 00:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:22:34 --> Email Class Initialized
INFO - 2016-08-12 00:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:22:34 --> Pagination Class Initialized
INFO - 2016-08-12 00:22:34 --> Model Class Initialized
INFO - 2016-08-12 00:22:34 --> Controller Class Initialized
DEBUG - 2016-08-12 00:22:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:22:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:22:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:22:35 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:22:35 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:22:35 --> Model Class Initialized
INFO - 2016-08-12 00:22:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:22:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:22:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:22:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:22:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:22:35 --> Final output sent to browser
DEBUG - 2016-08-12 00:22:35 --> Total execution time: 0.4682
INFO - 2016-08-12 00:22:40 --> Config Class Initialized
INFO - 2016-08-12 00:22:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:22:40 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:22:40 --> Utf8 Class Initialized
INFO - 2016-08-12 00:22:40 --> URI Class Initialized
INFO - 2016-08-12 00:22:40 --> Router Class Initialized
INFO - 2016-08-12 00:22:40 --> Output Class Initialized
INFO - 2016-08-12 00:22:40 --> Security Class Initialized
DEBUG - 2016-08-12 00:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:22:40 --> Input Class Initialized
INFO - 2016-08-12 00:22:40 --> Language Class Initialized
INFO - 2016-08-12 00:22:40 --> Loader Class Initialized
INFO - 2016-08-12 00:22:40 --> Helper loaded: url_helper
INFO - 2016-08-12 00:22:40 --> Helper loaded: date_helper
INFO - 2016-08-12 00:22:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:22:40 --> Database Driver Class Initialized
INFO - 2016-08-12 00:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:22:40 --> Email Class Initialized
INFO - 2016-08-12 00:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:22:40 --> Pagination Class Initialized
INFO - 2016-08-12 00:22:40 --> Model Class Initialized
INFO - 2016-08-12 00:22:40 --> Controller Class Initialized
INFO - 2016-08-12 00:22:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:22:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:22:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:22:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:22:40 --> Final output sent to browser
DEBUG - 2016-08-12 00:22:40 --> Total execution time: 0.2970
INFO - 2016-08-12 00:22:44 --> Config Class Initialized
INFO - 2016-08-12 00:22:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:22:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:22:44 --> Utf8 Class Initialized
INFO - 2016-08-12 00:22:44 --> URI Class Initialized
INFO - 2016-08-12 00:22:44 --> Router Class Initialized
INFO - 2016-08-12 00:22:44 --> Output Class Initialized
INFO - 2016-08-12 00:22:44 --> Security Class Initialized
DEBUG - 2016-08-12 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:22:44 --> Input Class Initialized
INFO - 2016-08-12 00:22:44 --> Language Class Initialized
INFO - 2016-08-12 00:22:44 --> Loader Class Initialized
INFO - 2016-08-12 00:22:44 --> Helper loaded: url_helper
INFO - 2016-08-12 00:22:44 --> Helper loaded: date_helper
INFO - 2016-08-12 00:22:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:22:44 --> Database Driver Class Initialized
INFO - 2016-08-12 00:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:22:44 --> Email Class Initialized
INFO - 2016-08-12 00:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:22:44 --> Pagination Class Initialized
INFO - 2016-08-12 00:22:44 --> Model Class Initialized
INFO - 2016-08-12 00:22:44 --> Controller Class Initialized
INFO - 2016-08-12 00:22:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:22:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:22:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:22:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:22:44 --> Final output sent to browser
DEBUG - 2016-08-12 00:22:44 --> Total execution time: 0.2970
INFO - 2016-08-12 00:22:44 --> Config Class Initialized
INFO - 2016-08-12 00:22:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:22:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:22:44 --> Utf8 Class Initialized
INFO - 2016-08-12 00:22:44 --> URI Class Initialized
INFO - 2016-08-12 00:22:44 --> Router Class Initialized
INFO - 2016-08-12 00:22:44 --> Output Class Initialized
INFO - 2016-08-12 00:22:44 --> Security Class Initialized
DEBUG - 2016-08-12 00:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:22:44 --> Input Class Initialized
INFO - 2016-08-12 00:22:44 --> Language Class Initialized
INFO - 2016-08-12 00:22:44 --> Loader Class Initialized
INFO - 2016-08-12 00:22:44 --> Helper loaded: url_helper
INFO - 2016-08-12 00:22:44 --> Helper loaded: date_helper
INFO - 2016-08-12 00:22:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:22:44 --> Database Driver Class Initialized
INFO - 2016-08-12 00:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:22:44 --> Email Class Initialized
INFO - 2016-08-12 00:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:22:44 --> Pagination Class Initialized
INFO - 2016-08-12 00:22:45 --> Model Class Initialized
INFO - 2016-08-12 00:22:45 --> Controller Class Initialized
INFO - 2016-08-12 00:22:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:22:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-12 00:22:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
ERROR - 2016-08-12 00:22:45 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 67
INFO - 2016-08-12 00:22:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:22:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:22:45 --> Final output sent to browser
DEBUG - 2016-08-12 00:22:45 --> Total execution time: 0.4414
INFO - 2016-08-12 00:25:46 --> Config Class Initialized
INFO - 2016-08-12 00:25:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:25:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:25:46 --> Utf8 Class Initialized
INFO - 2016-08-12 00:25:46 --> URI Class Initialized
INFO - 2016-08-12 00:25:46 --> Router Class Initialized
INFO - 2016-08-12 00:25:46 --> Output Class Initialized
INFO - 2016-08-12 00:25:46 --> Security Class Initialized
DEBUG - 2016-08-12 00:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:25:46 --> Input Class Initialized
INFO - 2016-08-12 00:25:46 --> Language Class Initialized
INFO - 2016-08-12 00:25:46 --> Loader Class Initialized
INFO - 2016-08-12 00:25:46 --> Helper loaded: url_helper
INFO - 2016-08-12 00:25:46 --> Helper loaded: date_helper
INFO - 2016-08-12 00:25:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:25:46 --> Database Driver Class Initialized
INFO - 2016-08-12 00:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:25:46 --> Email Class Initialized
INFO - 2016-08-12 00:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:25:46 --> Pagination Class Initialized
INFO - 2016-08-12 00:25:46 --> Model Class Initialized
INFO - 2016-08-12 00:25:46 --> Controller Class Initialized
DEBUG - 2016-08-12 00:25:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:25:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:25:46 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:25:46 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:46 --> Model Class Initialized
INFO - 2016-08-12 00:25:47 --> Config Class Initialized
INFO - 2016-08-12 00:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:25:47 --> Utf8 Class Initialized
INFO - 2016-08-12 00:25:47 --> URI Class Initialized
INFO - 2016-08-12 00:25:47 --> Router Class Initialized
INFO - 2016-08-12 00:25:47 --> Output Class Initialized
INFO - 2016-08-12 00:25:47 --> Security Class Initialized
DEBUG - 2016-08-12 00:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:25:47 --> Input Class Initialized
INFO - 2016-08-12 00:25:47 --> Language Class Initialized
INFO - 2016-08-12 00:25:47 --> Loader Class Initialized
INFO - 2016-08-12 00:25:47 --> Helper loaded: url_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: date_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:25:47 --> Database Driver Class Initialized
INFO - 2016-08-12 00:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:25:47 --> Email Class Initialized
INFO - 2016-08-12 00:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:25:47 --> Pagination Class Initialized
INFO - 2016-08-12 00:25:47 --> Model Class Initialized
INFO - 2016-08-12 00:25:47 --> Controller Class Initialized
DEBUG - 2016-08-12 00:25:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:25:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:25:47 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:47 --> Model Class Initialized
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:25:47 --> Final output sent to browser
DEBUG - 2016-08-12 00:25:47 --> Total execution time: 0.4200
INFO - 2016-08-12 00:25:47 --> Config Class Initialized
INFO - 2016-08-12 00:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:25:47 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:25:47 --> Utf8 Class Initialized
INFO - 2016-08-12 00:25:47 --> URI Class Initialized
INFO - 2016-08-12 00:25:47 --> Router Class Initialized
INFO - 2016-08-12 00:25:47 --> Output Class Initialized
INFO - 2016-08-12 00:25:47 --> Security Class Initialized
DEBUG - 2016-08-12 00:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:25:47 --> Input Class Initialized
INFO - 2016-08-12 00:25:47 --> Language Class Initialized
INFO - 2016-08-12 00:25:47 --> Loader Class Initialized
INFO - 2016-08-12 00:25:47 --> Helper loaded: url_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: date_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:25:47 --> Database Driver Class Initialized
INFO - 2016-08-12 00:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:25:47 --> Email Class Initialized
INFO - 2016-08-12 00:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:25:47 --> Pagination Class Initialized
INFO - 2016-08-12 00:25:47 --> Model Class Initialized
INFO - 2016-08-12 00:25:47 --> Controller Class Initialized
DEBUG - 2016-08-12 00:25:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 00:25:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 00:25:47 --> Helper loaded: cookie_helper
INFO - 2016-08-12 00:25:47 --> Helper loaded: language_helper
DEBUG - 2016-08-12 00:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:25:47 --> Model Class Initialized
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 00:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 00:25:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 00:25:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 00:25:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 00:25:48 --> Final output sent to browser
DEBUG - 2016-08-12 00:25:48 --> Total execution time: 0.4987
INFO - 2016-08-12 00:25:59 --> Config Class Initialized
INFO - 2016-08-12 00:25:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:25:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:25:59 --> Utf8 Class Initialized
INFO - 2016-08-12 00:25:59 --> URI Class Initialized
INFO - 2016-08-12 00:25:59 --> Router Class Initialized
INFO - 2016-08-12 00:25:59 --> Output Class Initialized
INFO - 2016-08-12 00:25:59 --> Security Class Initialized
DEBUG - 2016-08-12 00:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:25:59 --> Input Class Initialized
INFO - 2016-08-12 00:25:59 --> Language Class Initialized
INFO - 2016-08-12 00:25:59 --> Loader Class Initialized
INFO - 2016-08-12 00:25:59 --> Helper loaded: url_helper
INFO - 2016-08-12 00:25:59 --> Helper loaded: date_helper
INFO - 2016-08-12 00:25:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:25:59 --> Database Driver Class Initialized
INFO - 2016-08-12 00:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:25:59 --> Email Class Initialized
INFO - 2016-08-12 00:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:25:59 --> Pagination Class Initialized
INFO - 2016-08-12 00:25:59 --> Model Class Initialized
INFO - 2016-08-12 00:25:59 --> Controller Class Initialized
INFO - 2016-08-12 00:25:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:25:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-12 00:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
ERROR - 2016-08-12 00:25:59 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 67
INFO - 2016-08-12 00:25:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:25:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:25:59 --> Final output sent to browser
DEBUG - 2016-08-12 00:25:59 --> Total execution time: 0.3370
INFO - 2016-08-12 00:26:08 --> Config Class Initialized
INFO - 2016-08-12 00:26:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:26:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:26:08 --> Utf8 Class Initialized
INFO - 2016-08-12 00:26:08 --> URI Class Initialized
DEBUG - 2016-08-12 00:26:08 --> No URI present. Default controller set.
INFO - 2016-08-12 00:26:08 --> Router Class Initialized
INFO - 2016-08-12 00:26:08 --> Output Class Initialized
INFO - 2016-08-12 00:26:08 --> Security Class Initialized
DEBUG - 2016-08-12 00:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:26:08 --> Input Class Initialized
INFO - 2016-08-12 00:26:08 --> Language Class Initialized
INFO - 2016-08-12 00:26:08 --> Loader Class Initialized
INFO - 2016-08-12 00:26:08 --> Helper loaded: url_helper
INFO - 2016-08-12 00:26:08 --> Helper loaded: date_helper
INFO - 2016-08-12 00:26:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:26:08 --> Database Driver Class Initialized
INFO - 2016-08-12 00:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:26:08 --> Email Class Initialized
INFO - 2016-08-12 00:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:26:08 --> Pagination Class Initialized
INFO - 2016-08-12 00:26:08 --> Model Class Initialized
INFO - 2016-08-12 00:26:08 --> Controller Class Initialized
INFO - 2016-08-12 00:26:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:26:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:26:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 00:26:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:26:08 --> Final output sent to browser
DEBUG - 2016-08-12 00:26:08 --> Total execution time: 0.3760
INFO - 2016-08-12 00:26:29 --> Config Class Initialized
INFO - 2016-08-12 00:26:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:26:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:26:29 --> Utf8 Class Initialized
INFO - 2016-08-12 00:26:29 --> URI Class Initialized
INFO - 2016-08-12 00:26:29 --> Router Class Initialized
INFO - 2016-08-12 00:26:29 --> Output Class Initialized
INFO - 2016-08-12 00:26:29 --> Security Class Initialized
DEBUG - 2016-08-12 00:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:26:29 --> Input Class Initialized
INFO - 2016-08-12 00:26:29 --> Language Class Initialized
INFO - 2016-08-12 00:26:29 --> Loader Class Initialized
INFO - 2016-08-12 00:26:29 --> Helper loaded: url_helper
INFO - 2016-08-12 00:26:29 --> Helper loaded: date_helper
INFO - 2016-08-12 00:26:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:26:29 --> Database Driver Class Initialized
INFO - 2016-08-12 00:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:26:29 --> Email Class Initialized
INFO - 2016-08-12 00:26:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:26:29 --> Pagination Class Initialized
INFO - 2016-08-12 00:26:29 --> Model Class Initialized
INFO - 2016-08-12 00:26:29 --> Controller Class Initialized
ERROR - 2016-08-12 00:26:29 --> 404 Page Not Found: 
INFO - 2016-08-12 00:26:31 --> Config Class Initialized
INFO - 2016-08-12 00:26:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:26:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:26:31 --> Utf8 Class Initialized
INFO - 2016-08-12 00:26:31 --> URI Class Initialized
DEBUG - 2016-08-12 00:26:31 --> No URI present. Default controller set.
INFO - 2016-08-12 00:26:31 --> Router Class Initialized
INFO - 2016-08-12 00:26:31 --> Output Class Initialized
INFO - 2016-08-12 00:26:31 --> Security Class Initialized
DEBUG - 2016-08-12 00:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:26:31 --> Input Class Initialized
INFO - 2016-08-12 00:26:31 --> Language Class Initialized
INFO - 2016-08-12 00:26:31 --> Loader Class Initialized
INFO - 2016-08-12 00:26:31 --> Helper loaded: url_helper
INFO - 2016-08-12 00:26:31 --> Helper loaded: date_helper
INFO - 2016-08-12 00:26:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:26:31 --> Database Driver Class Initialized
INFO - 2016-08-12 00:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:26:31 --> Email Class Initialized
INFO - 2016-08-12 00:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:26:31 --> Pagination Class Initialized
INFO - 2016-08-12 00:26:31 --> Model Class Initialized
INFO - 2016-08-12 00:26:31 --> Controller Class Initialized
INFO - 2016-08-12 00:26:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:26:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:26:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 00:26:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:26:31 --> Final output sent to browser
DEBUG - 2016-08-12 00:26:31 --> Total execution time: 0.3476
INFO - 2016-08-12 00:27:14 --> Config Class Initialized
INFO - 2016-08-12 00:27:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:27:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:27:14 --> Utf8 Class Initialized
INFO - 2016-08-12 00:27:14 --> URI Class Initialized
INFO - 2016-08-12 00:27:14 --> Router Class Initialized
INFO - 2016-08-12 00:27:14 --> Output Class Initialized
INFO - 2016-08-12 00:27:14 --> Security Class Initialized
DEBUG - 2016-08-12 00:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:27:14 --> Input Class Initialized
INFO - 2016-08-12 00:27:14 --> Language Class Initialized
INFO - 2016-08-12 00:27:14 --> Loader Class Initialized
INFO - 2016-08-12 00:27:14 --> Helper loaded: url_helper
INFO - 2016-08-12 00:27:14 --> Helper loaded: date_helper
INFO - 2016-08-12 00:27:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:27:14 --> Database Driver Class Initialized
INFO - 2016-08-12 00:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:27:15 --> Email Class Initialized
INFO - 2016-08-12 00:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:27:15 --> Pagination Class Initialized
INFO - 2016-08-12 00:27:15 --> Model Class Initialized
INFO - 2016-08-12 00:27:15 --> Controller Class Initialized
ERROR - 2016-08-12 00:27:15 --> 404 Page Not Found: 
INFO - 2016-08-12 00:27:35 --> Config Class Initialized
INFO - 2016-08-12 00:27:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:27:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:27:35 --> Utf8 Class Initialized
INFO - 2016-08-12 00:27:35 --> URI Class Initialized
INFO - 2016-08-12 00:27:35 --> Router Class Initialized
INFO - 2016-08-12 00:27:35 --> Output Class Initialized
INFO - 2016-08-12 00:27:35 --> Security Class Initialized
DEBUG - 2016-08-12 00:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:27:35 --> Input Class Initialized
INFO - 2016-08-12 00:27:35 --> Language Class Initialized
INFO - 2016-08-12 00:27:35 --> Loader Class Initialized
INFO - 2016-08-12 00:27:35 --> Helper loaded: url_helper
INFO - 2016-08-12 00:27:35 --> Helper loaded: date_helper
INFO - 2016-08-12 00:27:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:27:35 --> Database Driver Class Initialized
INFO - 2016-08-12 00:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:27:35 --> Email Class Initialized
INFO - 2016-08-12 00:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:27:35 --> Pagination Class Initialized
INFO - 2016-08-12 00:27:35 --> Model Class Initialized
INFO - 2016-08-12 00:27:35 --> Controller Class Initialized
ERROR - 2016-08-12 00:27:35 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::num_row() D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 27
INFO - 2016-08-12 00:28:48 --> Config Class Initialized
INFO - 2016-08-12 00:28:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:28:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:28:48 --> Utf8 Class Initialized
INFO - 2016-08-12 00:28:48 --> URI Class Initialized
INFO - 2016-08-12 00:28:48 --> Router Class Initialized
INFO - 2016-08-12 00:28:48 --> Output Class Initialized
INFO - 2016-08-12 00:28:48 --> Security Class Initialized
DEBUG - 2016-08-12 00:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:28:48 --> Input Class Initialized
INFO - 2016-08-12 00:28:48 --> Language Class Initialized
ERROR - 2016-08-12 00:28:48 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 27
INFO - 2016-08-12 00:29:02 --> Config Class Initialized
INFO - 2016-08-12 00:29:02 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:29:02 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:29:02 --> Utf8 Class Initialized
INFO - 2016-08-12 00:29:02 --> URI Class Initialized
INFO - 2016-08-12 00:29:02 --> Router Class Initialized
INFO - 2016-08-12 00:29:02 --> Output Class Initialized
INFO - 2016-08-12 00:29:02 --> Security Class Initialized
DEBUG - 2016-08-12 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:29:02 --> Input Class Initialized
INFO - 2016-08-12 00:29:02 --> Language Class Initialized
INFO - 2016-08-12 00:29:02 --> Loader Class Initialized
INFO - 2016-08-12 00:29:02 --> Helper loaded: url_helper
INFO - 2016-08-12 00:29:02 --> Helper loaded: date_helper
INFO - 2016-08-12 00:29:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:29:02 --> Database Driver Class Initialized
INFO - 2016-08-12 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:29:02 --> Email Class Initialized
INFO - 2016-08-12 00:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:29:02 --> Pagination Class Initialized
INFO - 2016-08-12 00:29:02 --> Model Class Initialized
INFO - 2016-08-12 00:29:02 --> Controller Class Initialized
ERROR - 2016-08-12 00:29:02 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::num_row() D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 26
INFO - 2016-08-12 00:29:28 --> Config Class Initialized
INFO - 2016-08-12 00:29:28 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:29:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:29:28 --> Utf8 Class Initialized
INFO - 2016-08-12 00:29:28 --> URI Class Initialized
INFO - 2016-08-12 00:29:28 --> Router Class Initialized
INFO - 2016-08-12 00:29:28 --> Output Class Initialized
INFO - 2016-08-12 00:29:28 --> Security Class Initialized
DEBUG - 2016-08-12 00:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:29:28 --> Input Class Initialized
INFO - 2016-08-12 00:29:28 --> Language Class Initialized
INFO - 2016-08-12 00:29:28 --> Loader Class Initialized
INFO - 2016-08-12 00:29:28 --> Helper loaded: url_helper
INFO - 2016-08-12 00:29:28 --> Helper loaded: date_helper
INFO - 2016-08-12 00:29:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:29:28 --> Database Driver Class Initialized
INFO - 2016-08-12 00:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:29:28 --> Email Class Initialized
INFO - 2016-08-12 00:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:29:28 --> Pagination Class Initialized
INFO - 2016-08-12 00:29:28 --> Model Class Initialized
INFO - 2016-08-12 00:29:28 --> Controller Class Initialized
INFO - 2016-08-12 00:29:28 --> Final output sent to browser
DEBUG - 2016-08-12 00:29:28 --> Total execution time: 0.3024
INFO - 2016-08-12 00:29:33 --> Config Class Initialized
INFO - 2016-08-12 00:29:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:29:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:29:33 --> Utf8 Class Initialized
INFO - 2016-08-12 00:29:33 --> URI Class Initialized
INFO - 2016-08-12 00:29:33 --> Router Class Initialized
INFO - 2016-08-12 00:29:33 --> Output Class Initialized
INFO - 2016-08-12 00:29:33 --> Security Class Initialized
DEBUG - 2016-08-12 00:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:29:33 --> Input Class Initialized
INFO - 2016-08-12 00:29:33 --> Language Class Initialized
INFO - 2016-08-12 00:29:33 --> Loader Class Initialized
INFO - 2016-08-12 00:29:33 --> Helper loaded: url_helper
INFO - 2016-08-12 00:29:33 --> Helper loaded: date_helper
INFO - 2016-08-12 00:29:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:29:33 --> Database Driver Class Initialized
INFO - 2016-08-12 00:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:29:33 --> Email Class Initialized
INFO - 2016-08-12 00:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:29:33 --> Pagination Class Initialized
INFO - 2016-08-12 00:29:33 --> Model Class Initialized
INFO - 2016-08-12 00:29:33 --> Controller Class Initialized
INFO - 2016-08-12 00:29:33 --> Final output sent to browser
DEBUG - 2016-08-12 00:29:33 --> Total execution time: 0.2724
INFO - 2016-08-12 00:29:46 --> Config Class Initialized
INFO - 2016-08-12 00:29:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:29:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:29:46 --> Utf8 Class Initialized
INFO - 2016-08-12 00:29:46 --> URI Class Initialized
INFO - 2016-08-12 00:29:46 --> Router Class Initialized
INFO - 2016-08-12 00:29:46 --> Output Class Initialized
INFO - 2016-08-12 00:29:46 --> Security Class Initialized
DEBUG - 2016-08-12 00:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:29:46 --> Input Class Initialized
INFO - 2016-08-12 00:29:46 --> Language Class Initialized
INFO - 2016-08-12 00:29:46 --> Loader Class Initialized
INFO - 2016-08-12 00:29:46 --> Helper loaded: url_helper
INFO - 2016-08-12 00:29:46 --> Helper loaded: date_helper
INFO - 2016-08-12 00:29:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:29:46 --> Database Driver Class Initialized
INFO - 2016-08-12 00:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:29:46 --> Email Class Initialized
INFO - 2016-08-12 00:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:29:46 --> Pagination Class Initialized
INFO - 2016-08-12 00:29:46 --> Model Class Initialized
INFO - 2016-08-12 00:29:46 --> Controller Class Initialized
INFO - 2016-08-12 00:29:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:29:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-12 00:29:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
ERROR - 2016-08-12 00:29:46 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 67
INFO - 2016-08-12 00:29:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:29:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:29:46 --> Final output sent to browser
DEBUG - 2016-08-12 00:29:46 --> Total execution time: 0.3346
INFO - 2016-08-12 00:30:00 --> Config Class Initialized
INFO - 2016-08-12 00:30:00 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:30:00 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:30:00 --> Utf8 Class Initialized
INFO - 2016-08-12 00:30:00 --> URI Class Initialized
INFO - 2016-08-12 00:30:00 --> Router Class Initialized
INFO - 2016-08-12 00:30:00 --> Output Class Initialized
INFO - 2016-08-12 00:30:00 --> Security Class Initialized
DEBUG - 2016-08-12 00:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:30:00 --> Input Class Initialized
INFO - 2016-08-12 00:30:00 --> Language Class Initialized
INFO - 2016-08-12 00:30:00 --> Loader Class Initialized
INFO - 2016-08-12 00:30:00 --> Helper loaded: url_helper
INFO - 2016-08-12 00:30:00 --> Helper loaded: date_helper
INFO - 2016-08-12 00:30:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:30:00 --> Database Driver Class Initialized
INFO - 2016-08-12 00:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:30:00 --> Email Class Initialized
INFO - 2016-08-12 00:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:30:00 --> Pagination Class Initialized
INFO - 2016-08-12 00:30:00 --> Model Class Initialized
INFO - 2016-08-12 00:30:00 --> Controller Class Initialized
ERROR - 2016-08-12 00:30:00 --> 404 Page Not Found: 
INFO - 2016-08-12 00:30:07 --> Config Class Initialized
INFO - 2016-08-12 00:30:07 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:30:07 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:30:07 --> Utf8 Class Initialized
INFO - 2016-08-12 00:30:07 --> URI Class Initialized
INFO - 2016-08-12 00:30:07 --> Router Class Initialized
INFO - 2016-08-12 00:30:07 --> Output Class Initialized
INFO - 2016-08-12 00:30:08 --> Security Class Initialized
DEBUG - 2016-08-12 00:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:30:08 --> Input Class Initialized
INFO - 2016-08-12 00:30:08 --> Language Class Initialized
INFO - 2016-08-12 00:30:08 --> Loader Class Initialized
INFO - 2016-08-12 00:30:08 --> Helper loaded: url_helper
INFO - 2016-08-12 00:30:08 --> Helper loaded: date_helper
INFO - 2016-08-12 00:30:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:30:08 --> Database Driver Class Initialized
INFO - 2016-08-12 00:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:30:08 --> Email Class Initialized
INFO - 2016-08-12 00:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:30:08 --> Pagination Class Initialized
INFO - 2016-08-12 00:30:08 --> Model Class Initialized
INFO - 2016-08-12 00:30:08 --> Controller Class Initialized
INFO - 2016-08-12 00:30:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:30:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:30:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:30:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:30:08 --> Final output sent to browser
DEBUG - 2016-08-12 00:30:08 --> Total execution time: 0.3195
INFO - 2016-08-12 00:30:13 --> Config Class Initialized
INFO - 2016-08-12 00:30:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:30:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:30:13 --> Utf8 Class Initialized
INFO - 2016-08-12 00:30:13 --> URI Class Initialized
INFO - 2016-08-12 00:30:13 --> Router Class Initialized
INFO - 2016-08-12 00:30:13 --> Output Class Initialized
INFO - 2016-08-12 00:30:13 --> Security Class Initialized
DEBUG - 2016-08-12 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:30:13 --> Input Class Initialized
INFO - 2016-08-12 00:30:13 --> Language Class Initialized
INFO - 2016-08-12 00:30:13 --> Loader Class Initialized
INFO - 2016-08-12 00:30:13 --> Helper loaded: url_helper
INFO - 2016-08-12 00:30:13 --> Helper loaded: date_helper
INFO - 2016-08-12 00:30:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:30:13 --> Database Driver Class Initialized
INFO - 2016-08-12 00:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:30:13 --> Email Class Initialized
INFO - 2016-08-12 00:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:30:13 --> Pagination Class Initialized
INFO - 2016-08-12 00:30:13 --> Model Class Initialized
INFO - 2016-08-12 00:30:13 --> Controller Class Initialized
ERROR - 2016-08-12 00:30:13 --> 404 Page Not Found: 
INFO - 2016-08-12 00:30:18 --> Config Class Initialized
INFO - 2016-08-12 00:30:18 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:30:18 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:30:18 --> Utf8 Class Initialized
INFO - 2016-08-12 00:30:18 --> URI Class Initialized
INFO - 2016-08-12 00:30:18 --> Router Class Initialized
INFO - 2016-08-12 00:30:18 --> Output Class Initialized
INFO - 2016-08-12 00:30:18 --> Security Class Initialized
DEBUG - 2016-08-12 00:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:30:18 --> Input Class Initialized
INFO - 2016-08-12 00:30:18 --> Language Class Initialized
INFO - 2016-08-12 00:30:18 --> Loader Class Initialized
INFO - 2016-08-12 00:30:18 --> Helper loaded: url_helper
INFO - 2016-08-12 00:30:18 --> Helper loaded: date_helper
INFO - 2016-08-12 00:30:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:30:18 --> Database Driver Class Initialized
INFO - 2016-08-12 00:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:30:18 --> Email Class Initialized
INFO - 2016-08-12 00:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:30:18 --> Pagination Class Initialized
INFO - 2016-08-12 00:30:18 --> Model Class Initialized
INFO - 2016-08-12 00:30:18 --> Controller Class Initialized
ERROR - 2016-08-12 00:30:18 --> 404 Page Not Found: 
INFO - 2016-08-12 00:30:25 --> Config Class Initialized
INFO - 2016-08-12 00:30:25 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:30:25 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:30:25 --> Utf8 Class Initialized
INFO - 2016-08-12 00:30:25 --> URI Class Initialized
INFO - 2016-08-12 00:30:25 --> Router Class Initialized
INFO - 2016-08-12 00:30:25 --> Output Class Initialized
INFO - 2016-08-12 00:30:25 --> Security Class Initialized
DEBUG - 2016-08-12 00:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:30:25 --> Input Class Initialized
INFO - 2016-08-12 00:30:25 --> Language Class Initialized
INFO - 2016-08-12 00:30:25 --> Loader Class Initialized
INFO - 2016-08-12 00:30:25 --> Helper loaded: url_helper
INFO - 2016-08-12 00:30:25 --> Helper loaded: date_helper
INFO - 2016-08-12 00:30:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:30:25 --> Database Driver Class Initialized
INFO - 2016-08-12 00:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:30:25 --> Email Class Initialized
INFO - 2016-08-12 00:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:30:25 --> Pagination Class Initialized
INFO - 2016-08-12 00:30:25 --> Model Class Initialized
INFO - 2016-08-12 00:30:25 --> Controller Class Initialized
INFO - 2016-08-12 00:30:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:30:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:30:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 00:30:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:30:25 --> Final output sent to browser
DEBUG - 2016-08-12 00:30:25 --> Total execution time: 0.3237
INFO - 2016-08-12 00:31:43 --> Config Class Initialized
INFO - 2016-08-12 00:31:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:31:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:31:43 --> Utf8 Class Initialized
INFO - 2016-08-12 00:31:43 --> URI Class Initialized
DEBUG - 2016-08-12 00:31:43 --> No URI present. Default controller set.
INFO - 2016-08-12 00:31:43 --> Router Class Initialized
INFO - 2016-08-12 00:31:43 --> Output Class Initialized
INFO - 2016-08-12 00:31:43 --> Security Class Initialized
DEBUG - 2016-08-12 00:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:31:43 --> Input Class Initialized
INFO - 2016-08-12 00:31:43 --> Language Class Initialized
INFO - 2016-08-12 00:31:43 --> Loader Class Initialized
INFO - 2016-08-12 00:31:43 --> Helper loaded: url_helper
INFO - 2016-08-12 00:31:43 --> Helper loaded: date_helper
INFO - 2016-08-12 00:31:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:31:44 --> Database Driver Class Initialized
INFO - 2016-08-12 00:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:31:44 --> Email Class Initialized
INFO - 2016-08-12 00:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:31:44 --> Pagination Class Initialized
INFO - 2016-08-12 00:31:44 --> Model Class Initialized
INFO - 2016-08-12 00:31:44 --> Controller Class Initialized
INFO - 2016-08-12 00:31:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:31:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:31:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 00:31:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:31:44 --> Final output sent to browser
DEBUG - 2016-08-12 00:31:44 --> Total execution time: 0.4019
INFO - 2016-08-12 00:32:58 --> Config Class Initialized
INFO - 2016-08-12 00:32:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:32:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:32:58 --> Utf8 Class Initialized
INFO - 2016-08-12 00:32:58 --> URI Class Initialized
INFO - 2016-08-12 00:32:58 --> Router Class Initialized
INFO - 2016-08-12 00:32:58 --> Output Class Initialized
INFO - 2016-08-12 00:32:58 --> Security Class Initialized
DEBUG - 2016-08-12 00:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:32:58 --> Input Class Initialized
INFO - 2016-08-12 00:32:58 --> Language Class Initialized
INFO - 2016-08-12 00:32:58 --> Loader Class Initialized
INFO - 2016-08-12 00:32:59 --> Helper loaded: url_helper
INFO - 2016-08-12 00:32:59 --> Helper loaded: date_helper
INFO - 2016-08-12 00:32:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:32:59 --> Database Driver Class Initialized
INFO - 2016-08-12 00:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:32:59 --> Email Class Initialized
INFO - 2016-08-12 00:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:32:59 --> Pagination Class Initialized
INFO - 2016-08-12 00:32:59 --> Model Class Initialized
INFO - 2016-08-12 00:32:59 --> Controller Class Initialized
INFO - 2016-08-12 00:32:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-12 00:32:59 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-12 00:32:59 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-12 00:33:29 --> Config Class Initialized
INFO - 2016-08-12 00:33:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:33:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:33:29 --> Utf8 Class Initialized
INFO - 2016-08-12 00:33:29 --> URI Class Initialized
INFO - 2016-08-12 00:33:29 --> Router Class Initialized
INFO - 2016-08-12 00:33:29 --> Output Class Initialized
INFO - 2016-08-12 00:33:29 --> Security Class Initialized
DEBUG - 2016-08-12 00:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:33:29 --> Input Class Initialized
INFO - 2016-08-12 00:33:29 --> Language Class Initialized
INFO - 2016-08-12 00:33:29 --> Loader Class Initialized
INFO - 2016-08-12 00:33:29 --> Helper loaded: url_helper
INFO - 2016-08-12 00:33:29 --> Helper loaded: date_helper
INFO - 2016-08-12 00:33:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:33:29 --> Database Driver Class Initialized
INFO - 2016-08-12 00:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:33:29 --> Email Class Initialized
INFO - 2016-08-12 00:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:33:29 --> Pagination Class Initialized
INFO - 2016-08-12 00:33:29 --> Model Class Initialized
INFO - 2016-08-12 00:33:29 --> Controller Class Initialized
INFO - 2016-08-12 00:33:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:33:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:33:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 00:33:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:33:29 --> Final output sent to browser
DEBUG - 2016-08-12 00:33:29 --> Total execution time: 0.3812
INFO - 2016-08-12 00:35:08 --> Config Class Initialized
INFO - 2016-08-12 00:35:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:35:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:35:08 --> Utf8 Class Initialized
INFO - 2016-08-12 00:35:08 --> URI Class Initialized
DEBUG - 2016-08-12 00:35:08 --> No URI present. Default controller set.
INFO - 2016-08-12 00:35:08 --> Router Class Initialized
INFO - 2016-08-12 00:35:08 --> Output Class Initialized
INFO - 2016-08-12 00:35:08 --> Security Class Initialized
DEBUG - 2016-08-12 00:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:35:08 --> Input Class Initialized
INFO - 2016-08-12 00:35:08 --> Language Class Initialized
INFO - 2016-08-12 00:35:08 --> Loader Class Initialized
INFO - 2016-08-12 00:35:08 --> Helper loaded: url_helper
INFO - 2016-08-12 00:35:08 --> Helper loaded: date_helper
INFO - 2016-08-12 00:35:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:35:08 --> Database Driver Class Initialized
INFO - 2016-08-12 00:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:35:08 --> Email Class Initialized
INFO - 2016-08-12 00:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:35:08 --> Pagination Class Initialized
INFO - 2016-08-12 00:35:08 --> Model Class Initialized
INFO - 2016-08-12 00:35:08 --> Controller Class Initialized
INFO - 2016-08-12 00:35:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:35:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:35:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 00:35:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:35:08 --> Final output sent to browser
DEBUG - 2016-08-12 00:35:08 --> Total execution time: 0.3425
INFO - 2016-08-12 00:41:54 --> Config Class Initialized
INFO - 2016-08-12 00:41:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:41:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:41:54 --> Utf8 Class Initialized
INFO - 2016-08-12 00:41:54 --> URI Class Initialized
INFO - 2016-08-12 00:41:54 --> Router Class Initialized
INFO - 2016-08-12 00:41:54 --> Output Class Initialized
INFO - 2016-08-12 00:41:54 --> Security Class Initialized
DEBUG - 2016-08-12 00:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:41:54 --> Input Class Initialized
INFO - 2016-08-12 00:41:54 --> Language Class Initialized
INFO - 2016-08-12 00:41:54 --> Loader Class Initialized
INFO - 2016-08-12 00:41:54 --> Helper loaded: url_helper
INFO - 2016-08-12 00:41:54 --> Helper loaded: date_helper
INFO - 2016-08-12 00:41:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:41:54 --> Database Driver Class Initialized
INFO - 2016-08-12 00:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:41:54 --> Email Class Initialized
INFO - 2016-08-12 00:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:41:54 --> Pagination Class Initialized
INFO - 2016-08-12 00:41:54 --> Model Class Initialized
INFO - 2016-08-12 00:41:54 --> Controller Class Initialized
INFO - 2016-08-12 00:41:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-12 00:41:54 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-12 00:41:54 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-12 00:42:17 --> Config Class Initialized
INFO - 2016-08-12 00:42:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:42:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:42:17 --> Utf8 Class Initialized
INFO - 2016-08-12 00:42:17 --> URI Class Initialized
INFO - 2016-08-12 00:42:17 --> Router Class Initialized
INFO - 2016-08-12 00:42:17 --> Output Class Initialized
INFO - 2016-08-12 00:42:17 --> Security Class Initialized
DEBUG - 2016-08-12 00:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:42:17 --> Input Class Initialized
INFO - 2016-08-12 00:42:17 --> Language Class Initialized
INFO - 2016-08-12 00:42:17 --> Loader Class Initialized
INFO - 2016-08-12 00:42:17 --> Helper loaded: url_helper
INFO - 2016-08-12 00:42:17 --> Helper loaded: date_helper
INFO - 2016-08-12 00:42:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:42:17 --> Database Driver Class Initialized
INFO - 2016-08-12 00:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:42:17 --> Email Class Initialized
INFO - 2016-08-12 00:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:42:17 --> Pagination Class Initialized
INFO - 2016-08-12 00:42:17 --> Model Class Initialized
INFO - 2016-08-12 00:42:17 --> Controller Class Initialized
INFO - 2016-08-12 00:42:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:42:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:42:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 00:42:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:42:17 --> Final output sent to browser
DEBUG - 2016-08-12 00:42:17 --> Total execution time: 0.3960
INFO - 2016-08-12 00:43:38 --> Config Class Initialized
INFO - 2016-08-12 00:43:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:43:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:43:38 --> Utf8 Class Initialized
INFO - 2016-08-12 00:43:38 --> URI Class Initialized
INFO - 2016-08-12 00:43:38 --> Router Class Initialized
INFO - 2016-08-12 00:43:38 --> Output Class Initialized
INFO - 2016-08-12 00:43:38 --> Security Class Initialized
DEBUG - 2016-08-12 00:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:43:38 --> Input Class Initialized
INFO - 2016-08-12 00:43:38 --> Language Class Initialized
INFO - 2016-08-12 00:43:38 --> Loader Class Initialized
INFO - 2016-08-12 00:43:38 --> Helper loaded: url_helper
INFO - 2016-08-12 00:43:38 --> Helper loaded: date_helper
INFO - 2016-08-12 00:43:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:43:38 --> Database Driver Class Initialized
INFO - 2016-08-12 00:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:43:38 --> Email Class Initialized
INFO - 2016-08-12 00:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:43:38 --> Pagination Class Initialized
INFO - 2016-08-12 00:43:38 --> Model Class Initialized
INFO - 2016-08-12 00:43:38 --> Controller Class Initialized
DEBUG - 2016-08-12 00:43:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 00:43:43 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-12 00:43:43 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:44 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:44 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:44 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:45 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:45 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:45 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:45 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:46 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:47 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:47 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:47 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:48 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:48 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:48 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:48 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 00:43:49 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-12 00:43:55 --> Config Class Initialized
INFO - 2016-08-12 00:43:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:43:55 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:43:55 --> Utf8 Class Initialized
INFO - 2016-08-12 00:43:55 --> URI Class Initialized
INFO - 2016-08-12 00:43:55 --> Router Class Initialized
INFO - 2016-08-12 00:43:55 --> Output Class Initialized
INFO - 2016-08-12 00:43:55 --> Security Class Initialized
DEBUG - 2016-08-12 00:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:43:55 --> Input Class Initialized
INFO - 2016-08-12 00:43:55 --> Language Class Initialized
INFO - 2016-08-12 00:43:56 --> Loader Class Initialized
INFO - 2016-08-12 00:43:56 --> Helper loaded: url_helper
INFO - 2016-08-12 00:43:56 --> Helper loaded: date_helper
INFO - 2016-08-12 00:43:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:43:56 --> Database Driver Class Initialized
INFO - 2016-08-12 00:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:43:56 --> Email Class Initialized
INFO - 2016-08-12 00:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:43:56 --> Pagination Class Initialized
INFO - 2016-08-12 00:43:56 --> Model Class Initialized
INFO - 2016-08-12 00:43:56 --> Controller Class Initialized
INFO - 2016-08-12 00:43:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:43:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:43:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 00:43:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:43:56 --> Final output sent to browser
DEBUG - 2016-08-12 00:43:56 --> Total execution time: 0.3700
INFO - 2016-08-12 00:48:50 --> Config Class Initialized
INFO - 2016-08-12 00:48:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:48:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:48:50 --> Utf8 Class Initialized
INFO - 2016-08-12 00:48:50 --> URI Class Initialized
INFO - 2016-08-12 00:48:50 --> Router Class Initialized
INFO - 2016-08-12 00:48:50 --> Output Class Initialized
INFO - 2016-08-12 00:48:50 --> Security Class Initialized
DEBUG - 2016-08-12 00:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:48:50 --> Input Class Initialized
INFO - 2016-08-12 00:48:50 --> Language Class Initialized
INFO - 2016-08-12 00:48:50 --> Loader Class Initialized
INFO - 2016-08-12 00:48:50 --> Helper loaded: url_helper
INFO - 2016-08-12 00:48:50 --> Helper loaded: date_helper
INFO - 2016-08-12 00:48:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:48:50 --> Database Driver Class Initialized
INFO - 2016-08-12 00:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:48:51 --> Email Class Initialized
INFO - 2016-08-12 00:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:48:51 --> Pagination Class Initialized
INFO - 2016-08-12 00:48:51 --> Model Class Initialized
INFO - 2016-08-12 00:48:51 --> Controller Class Initialized
INFO - 2016-08-12 00:48:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:48:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:48:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 00:48:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:48:51 --> Final output sent to browser
DEBUG - 2016-08-12 00:48:51 --> Total execution time: 0.3343
INFO - 2016-08-12 00:48:51 --> Config Class Initialized
INFO - 2016-08-12 00:48:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:48:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:48:51 --> Utf8 Class Initialized
INFO - 2016-08-12 00:48:51 --> URI Class Initialized
INFO - 2016-08-12 00:48:51 --> Router Class Initialized
INFO - 2016-08-12 00:48:51 --> Output Class Initialized
INFO - 2016-08-12 00:48:51 --> Security Class Initialized
DEBUG - 2016-08-12 00:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:48:51 --> Input Class Initialized
INFO - 2016-08-12 00:48:51 --> Language Class Initialized
ERROR - 2016-08-12 00:48:51 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 00:50:37 --> Config Class Initialized
INFO - 2016-08-12 00:50:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:50:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:50:37 --> Utf8 Class Initialized
INFO - 2016-08-12 00:50:37 --> URI Class Initialized
INFO - 2016-08-12 00:50:37 --> Router Class Initialized
INFO - 2016-08-12 00:50:37 --> Output Class Initialized
INFO - 2016-08-12 00:50:37 --> Security Class Initialized
DEBUG - 2016-08-12 00:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:50:37 --> Input Class Initialized
INFO - 2016-08-12 00:50:37 --> Language Class Initialized
INFO - 2016-08-12 00:50:37 --> Loader Class Initialized
INFO - 2016-08-12 00:50:37 --> Helper loaded: url_helper
INFO - 2016-08-12 00:50:37 --> Helper loaded: date_helper
INFO - 2016-08-12 00:50:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:50:37 --> Database Driver Class Initialized
INFO - 2016-08-12 00:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:50:37 --> Email Class Initialized
INFO - 2016-08-12 00:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:50:37 --> Pagination Class Initialized
INFO - 2016-08-12 00:50:37 --> Model Class Initialized
INFO - 2016-08-12 00:50:37 --> Controller Class Initialized
INFO - 2016-08-12 00:50:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-12 00:50:37 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-12 00:50:37 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-12 00:50:59 --> Config Class Initialized
INFO - 2016-08-12 00:50:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:50:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:50:59 --> Utf8 Class Initialized
INFO - 2016-08-12 00:50:59 --> URI Class Initialized
INFO - 2016-08-12 00:50:59 --> Router Class Initialized
INFO - 2016-08-12 00:50:59 --> Output Class Initialized
INFO - 2016-08-12 00:50:59 --> Security Class Initialized
DEBUG - 2016-08-12 00:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:50:59 --> Input Class Initialized
INFO - 2016-08-12 00:50:59 --> Language Class Initialized
INFO - 2016-08-12 00:50:59 --> Loader Class Initialized
INFO - 2016-08-12 00:50:59 --> Helper loaded: url_helper
INFO - 2016-08-12 00:50:59 --> Helper loaded: date_helper
INFO - 2016-08-12 00:50:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:50:59 --> Database Driver Class Initialized
INFO - 2016-08-12 00:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:51:00 --> Email Class Initialized
INFO - 2016-08-12 00:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:51:00 --> Pagination Class Initialized
INFO - 2016-08-12 00:51:00 --> Model Class Initialized
INFO - 2016-08-12 00:51:00 --> Controller Class Initialized
INFO - 2016-08-12 00:51:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:51:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:51:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 00:51:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:51:00 --> Final output sent to browser
DEBUG - 2016-08-12 00:51:00 --> Total execution time: 0.3601
INFO - 2016-08-12 00:52:50 --> Config Class Initialized
INFO - 2016-08-12 00:52:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:52:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:52:50 --> Utf8 Class Initialized
INFO - 2016-08-12 00:52:50 --> URI Class Initialized
INFO - 2016-08-12 00:52:50 --> Router Class Initialized
INFO - 2016-08-12 00:52:50 --> Output Class Initialized
INFO - 2016-08-12 00:52:50 --> Security Class Initialized
DEBUG - 2016-08-12 00:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:52:50 --> Input Class Initialized
INFO - 2016-08-12 00:52:50 --> Language Class Initialized
INFO - 2016-08-12 00:52:50 --> Loader Class Initialized
INFO - 2016-08-12 00:52:50 --> Helper loaded: url_helper
INFO - 2016-08-12 00:52:50 --> Helper loaded: date_helper
INFO - 2016-08-12 00:52:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:52:50 --> Database Driver Class Initialized
INFO - 2016-08-12 00:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:52:50 --> Email Class Initialized
INFO - 2016-08-12 00:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:52:50 --> Pagination Class Initialized
INFO - 2016-08-12 00:52:50 --> Model Class Initialized
INFO - 2016-08-12 00:52:50 --> Controller Class Initialized
INFO - 2016-08-12 00:52:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:52:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:52:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 00:52:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:52:50 --> Final output sent to browser
DEBUG - 2016-08-12 00:52:50 --> Total execution time: 0.3444
INFO - 2016-08-12 00:52:55 --> Config Class Initialized
INFO - 2016-08-12 00:52:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:52:55 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:52:55 --> Utf8 Class Initialized
INFO - 2016-08-12 00:52:55 --> URI Class Initialized
INFO - 2016-08-12 00:52:55 --> Router Class Initialized
INFO - 2016-08-12 00:52:55 --> Output Class Initialized
INFO - 2016-08-12 00:52:55 --> Security Class Initialized
DEBUG - 2016-08-12 00:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:52:55 --> Input Class Initialized
INFO - 2016-08-12 00:52:55 --> Language Class Initialized
INFO - 2016-08-12 00:52:55 --> Loader Class Initialized
INFO - 2016-08-12 00:52:55 --> Helper loaded: url_helper
INFO - 2016-08-12 00:52:55 --> Helper loaded: date_helper
INFO - 2016-08-12 00:52:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:52:55 --> Database Driver Class Initialized
INFO - 2016-08-12 00:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:52:55 --> Email Class Initialized
INFO - 2016-08-12 00:52:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:52:55 --> Pagination Class Initialized
INFO - 2016-08-12 00:52:56 --> Model Class Initialized
INFO - 2016-08-12 00:52:56 --> Controller Class Initialized
INFO - 2016-08-12 00:52:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:52:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:52:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 00:52:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:52:56 --> Final output sent to browser
DEBUG - 2016-08-12 00:52:56 --> Total execution time: 0.3474
INFO - 2016-08-12 00:56:22 --> Config Class Initialized
INFO - 2016-08-12 00:56:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:56:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:56:22 --> Utf8 Class Initialized
INFO - 2016-08-12 00:56:22 --> URI Class Initialized
INFO - 2016-08-12 00:56:22 --> Router Class Initialized
INFO - 2016-08-12 00:56:22 --> Output Class Initialized
INFO - 2016-08-12 00:56:22 --> Security Class Initialized
DEBUG - 2016-08-12 00:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:56:22 --> Input Class Initialized
INFO - 2016-08-12 00:56:22 --> Language Class Initialized
INFO - 2016-08-12 00:56:22 --> Loader Class Initialized
INFO - 2016-08-12 00:56:22 --> Helper loaded: url_helper
INFO - 2016-08-12 00:56:22 --> Helper loaded: date_helper
INFO - 2016-08-12 00:56:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:56:22 --> Database Driver Class Initialized
INFO - 2016-08-12 00:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:56:22 --> Email Class Initialized
INFO - 2016-08-12 00:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:56:22 --> Pagination Class Initialized
INFO - 2016-08-12 00:56:22 --> Model Class Initialized
INFO - 2016-08-12 00:56:22 --> Controller Class Initialized
INFO - 2016-08-12 00:56:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:56:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:56:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 00:56:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:56:23 --> Final output sent to browser
DEBUG - 2016-08-12 00:56:23 --> Total execution time: 0.3692
INFO - 2016-08-12 00:56:34 --> Config Class Initialized
INFO - 2016-08-12 00:56:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:56:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:56:35 --> Utf8 Class Initialized
INFO - 2016-08-12 00:56:35 --> URI Class Initialized
INFO - 2016-08-12 00:56:35 --> Router Class Initialized
INFO - 2016-08-12 00:56:35 --> Output Class Initialized
INFO - 2016-08-12 00:56:35 --> Security Class Initialized
DEBUG - 2016-08-12 00:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:56:35 --> Input Class Initialized
INFO - 2016-08-12 00:56:35 --> Language Class Initialized
INFO - 2016-08-12 00:56:35 --> Loader Class Initialized
INFO - 2016-08-12 00:56:35 --> Helper loaded: url_helper
INFO - 2016-08-12 00:56:35 --> Helper loaded: date_helper
INFO - 2016-08-12 00:56:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:56:35 --> Database Driver Class Initialized
INFO - 2016-08-12 00:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:56:35 --> Email Class Initialized
INFO - 2016-08-12 00:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:56:35 --> Pagination Class Initialized
INFO - 2016-08-12 00:56:35 --> Model Class Initialized
INFO - 2016-08-12 00:56:35 --> Controller Class Initialized
INFO - 2016-08-12 00:56:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:56:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:56:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 00:56:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:56:35 --> Final output sent to browser
DEBUG - 2016-08-12 00:56:35 --> Total execution time: 0.3525
INFO - 2016-08-12 00:56:37 --> Config Class Initialized
INFO - 2016-08-12 00:56:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 00:56:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 00:56:37 --> Utf8 Class Initialized
INFO - 2016-08-12 00:56:37 --> URI Class Initialized
INFO - 2016-08-12 00:56:37 --> Router Class Initialized
INFO - 2016-08-12 00:56:37 --> Output Class Initialized
INFO - 2016-08-12 00:56:37 --> Security Class Initialized
DEBUG - 2016-08-12 00:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 00:56:37 --> Input Class Initialized
INFO - 2016-08-12 00:56:37 --> Language Class Initialized
INFO - 2016-08-12 00:56:37 --> Loader Class Initialized
INFO - 2016-08-12 00:56:37 --> Helper loaded: url_helper
INFO - 2016-08-12 00:56:37 --> Helper loaded: date_helper
INFO - 2016-08-12 00:56:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 00:56:37 --> Database Driver Class Initialized
INFO - 2016-08-12 00:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 00:56:37 --> Email Class Initialized
INFO - 2016-08-12 00:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 00:56:37 --> Pagination Class Initialized
INFO - 2016-08-12 00:56:37 --> Model Class Initialized
INFO - 2016-08-12 00:56:37 --> Controller Class Initialized
INFO - 2016-08-12 00:56:37 --> Model Class Initialized
INFO - 2016-08-12 00:56:37 --> Helper loaded: text_helper
INFO - 2016-08-12 00:56:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 00:56:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 00:56:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 00:56:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 00:56:37 --> Final output sent to browser
DEBUG - 2016-08-12 00:56:37 --> Total execution time: 0.4676
INFO - 2016-08-12 01:12:56 --> Config Class Initialized
INFO - 2016-08-12 01:12:57 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:12:57 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:12:57 --> Utf8 Class Initialized
INFO - 2016-08-12 01:12:57 --> URI Class Initialized
INFO - 2016-08-12 01:12:57 --> Router Class Initialized
INFO - 2016-08-12 01:12:57 --> Output Class Initialized
INFO - 2016-08-12 01:12:57 --> Security Class Initialized
DEBUG - 2016-08-12 01:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:12:57 --> Input Class Initialized
INFO - 2016-08-12 01:12:57 --> Language Class Initialized
INFO - 2016-08-12 01:12:57 --> Loader Class Initialized
INFO - 2016-08-12 01:12:57 --> Helper loaded: url_helper
INFO - 2016-08-12 01:12:57 --> Helper loaded: date_helper
INFO - 2016-08-12 01:12:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:12:57 --> Database Driver Class Initialized
INFO - 2016-08-12 01:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:12:57 --> Email Class Initialized
INFO - 2016-08-12 01:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:12:57 --> Pagination Class Initialized
INFO - 2016-08-12 01:12:57 --> Model Class Initialized
INFO - 2016-08-12 01:12:57 --> Controller Class Initialized
INFO - 2016-08-12 01:12:57 --> Model Class Initialized
INFO - 2016-08-12 01:12:57 --> Helper loaded: text_helper
INFO - 2016-08-12 01:12:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:12:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:12:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 01:12:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:12:57 --> Final output sent to browser
DEBUG - 2016-08-12 01:12:57 --> Total execution time: 0.4688
INFO - 2016-08-12 01:13:00 --> Config Class Initialized
INFO - 2016-08-12 01:13:00 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:13:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:13:01 --> Utf8 Class Initialized
INFO - 2016-08-12 01:13:01 --> URI Class Initialized
INFO - 2016-08-12 01:13:01 --> Router Class Initialized
INFO - 2016-08-12 01:13:01 --> Output Class Initialized
INFO - 2016-08-12 01:13:01 --> Security Class Initialized
DEBUG - 2016-08-12 01:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:13:01 --> Input Class Initialized
INFO - 2016-08-12 01:13:01 --> Language Class Initialized
INFO - 2016-08-12 01:13:01 --> Loader Class Initialized
INFO - 2016-08-12 01:13:01 --> Helper loaded: url_helper
INFO - 2016-08-12 01:13:01 --> Helper loaded: date_helper
INFO - 2016-08-12 01:13:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:13:01 --> Database Driver Class Initialized
INFO - 2016-08-12 01:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:13:01 --> Email Class Initialized
INFO - 2016-08-12 01:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:13:01 --> Pagination Class Initialized
INFO - 2016-08-12 01:13:01 --> Model Class Initialized
INFO - 2016-08-12 01:13:01 --> Controller Class Initialized
DEBUG - 2016-08-12 01:13:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 01:13:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 01:13:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 01:13:01 --> Helper loaded: cookie_helper
INFO - 2016-08-12 01:13:01 --> Helper loaded: language_helper
DEBUG - 2016-08-12 01:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 01:13:01 --> Model Class Initialized
INFO - 2016-08-12 01:13:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 01:13:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 01:13:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 01:13:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 01:13:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 01:13:01 --> Final output sent to browser
DEBUG - 2016-08-12 01:13:01 --> Total execution time: 0.4318
INFO - 2016-08-12 01:16:12 --> Config Class Initialized
INFO - 2016-08-12 01:16:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:12 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:12 --> URI Class Initialized
INFO - 2016-08-12 01:16:12 --> Router Class Initialized
INFO - 2016-08-12 01:16:12 --> Output Class Initialized
INFO - 2016-08-12 01:16:12 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:12 --> Input Class Initialized
INFO - 2016-08-12 01:16:12 --> Language Class Initialized
INFO - 2016-08-12 01:16:12 --> Loader Class Initialized
INFO - 2016-08-12 01:16:12 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:12 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:12 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:12 --> Email Class Initialized
INFO - 2016-08-12 01:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:12 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:12 --> Model Class Initialized
INFO - 2016-08-12 01:16:12 --> Controller Class Initialized
INFO - 2016-08-12 01:16:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:16:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:16:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 01:16:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:16:12 --> Final output sent to browser
DEBUG - 2016-08-12 01:16:12 --> Total execution time: 0.3430
INFO - 2016-08-12 01:16:24 --> Config Class Initialized
INFO - 2016-08-12 01:16:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:24 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:24 --> URI Class Initialized
INFO - 2016-08-12 01:16:24 --> Router Class Initialized
INFO - 2016-08-12 01:16:24 --> Output Class Initialized
INFO - 2016-08-12 01:16:24 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:24 --> Input Class Initialized
INFO - 2016-08-12 01:16:24 --> Language Class Initialized
INFO - 2016-08-12 01:16:24 --> Loader Class Initialized
INFO - 2016-08-12 01:16:24 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:24 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:24 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:24 --> Email Class Initialized
INFO - 2016-08-12 01:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:24 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:24 --> Model Class Initialized
INFO - 2016-08-12 01:16:24 --> Controller Class Initialized
INFO - 2016-08-12 01:16:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:16:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:16:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 01:16:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:16:24 --> Final output sent to browser
DEBUG - 2016-08-12 01:16:24 --> Total execution time: 0.3406
INFO - 2016-08-12 01:16:27 --> Config Class Initialized
INFO - 2016-08-12 01:16:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:27 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:27 --> URI Class Initialized
INFO - 2016-08-12 01:16:27 --> Router Class Initialized
INFO - 2016-08-12 01:16:27 --> Output Class Initialized
INFO - 2016-08-12 01:16:27 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:27 --> Input Class Initialized
INFO - 2016-08-12 01:16:27 --> Language Class Initialized
INFO - 2016-08-12 01:16:27 --> Loader Class Initialized
INFO - 2016-08-12 01:16:27 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:27 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:27 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:27 --> Email Class Initialized
INFO - 2016-08-12 01:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:27 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:27 --> Model Class Initialized
INFO - 2016-08-12 01:16:27 --> Controller Class Initialized
INFO - 2016-08-12 01:16:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:16:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:16:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 01:16:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:16:28 --> Final output sent to browser
DEBUG - 2016-08-12 01:16:28 --> Total execution time: 0.4273
INFO - 2016-08-12 01:16:30 --> Config Class Initialized
INFO - 2016-08-12 01:16:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:30 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:30 --> URI Class Initialized
INFO - 2016-08-12 01:16:30 --> Router Class Initialized
INFO - 2016-08-12 01:16:30 --> Output Class Initialized
INFO - 2016-08-12 01:16:30 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:30 --> Input Class Initialized
INFO - 2016-08-12 01:16:30 --> Language Class Initialized
INFO - 2016-08-12 01:16:30 --> Loader Class Initialized
INFO - 2016-08-12 01:16:30 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:30 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:30 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:30 --> Email Class Initialized
INFO - 2016-08-12 01:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:30 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:30 --> Model Class Initialized
INFO - 2016-08-12 01:16:30 --> Controller Class Initialized
INFO - 2016-08-12 01:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 01:16:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:16:30 --> Final output sent to browser
DEBUG - 2016-08-12 01:16:30 --> Total execution time: 0.3518
INFO - 2016-08-12 01:16:41 --> Config Class Initialized
INFO - 2016-08-12 01:16:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:41 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:41 --> URI Class Initialized
INFO - 2016-08-12 01:16:41 --> Router Class Initialized
INFO - 2016-08-12 01:16:41 --> Output Class Initialized
INFO - 2016-08-12 01:16:41 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:41 --> Input Class Initialized
INFO - 2016-08-12 01:16:41 --> Language Class Initialized
INFO - 2016-08-12 01:16:41 --> Loader Class Initialized
INFO - 2016-08-12 01:16:41 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:41 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:41 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:41 --> Email Class Initialized
INFO - 2016-08-12 01:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:41 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:41 --> Model Class Initialized
INFO - 2016-08-12 01:16:41 --> Controller Class Initialized
INFO - 2016-08-12 01:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:16:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:16:41 --> Final output sent to browser
DEBUG - 2016-08-12 01:16:41 --> Total execution time: 0.3533
INFO - 2016-08-12 01:16:46 --> Config Class Initialized
INFO - 2016-08-12 01:16:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:16:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:16:46 --> Utf8 Class Initialized
INFO - 2016-08-12 01:16:46 --> URI Class Initialized
INFO - 2016-08-12 01:16:46 --> Router Class Initialized
INFO - 2016-08-12 01:16:46 --> Output Class Initialized
INFO - 2016-08-12 01:16:46 --> Security Class Initialized
DEBUG - 2016-08-12 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:16:46 --> Input Class Initialized
INFO - 2016-08-12 01:16:46 --> Language Class Initialized
INFO - 2016-08-12 01:16:46 --> Loader Class Initialized
INFO - 2016-08-12 01:16:46 --> Helper loaded: url_helper
INFO - 2016-08-12 01:16:46 --> Helper loaded: date_helper
INFO - 2016-08-12 01:16:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:16:46 --> Database Driver Class Initialized
INFO - 2016-08-12 01:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:16:46 --> Email Class Initialized
INFO - 2016-08-12 01:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:16:46 --> Pagination Class Initialized
INFO - 2016-08-12 01:16:46 --> Model Class Initialized
INFO - 2016-08-12 01:16:46 --> Controller Class Initialized
INFO - 2016-08-12 01:16:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-12 01:16:47 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-12 01:16:47 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-12 01:17:01 --> Config Class Initialized
INFO - 2016-08-12 01:17:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:17:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:17:01 --> Utf8 Class Initialized
INFO - 2016-08-12 01:17:01 --> URI Class Initialized
INFO - 2016-08-12 01:17:01 --> Router Class Initialized
INFO - 2016-08-12 01:17:01 --> Output Class Initialized
INFO - 2016-08-12 01:17:01 --> Security Class Initialized
DEBUG - 2016-08-12 01:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:17:01 --> Input Class Initialized
INFO - 2016-08-12 01:17:01 --> Language Class Initialized
INFO - 2016-08-12 01:17:01 --> Loader Class Initialized
INFO - 2016-08-12 01:17:01 --> Helper loaded: url_helper
INFO - 2016-08-12 01:17:01 --> Helper loaded: date_helper
INFO - 2016-08-12 01:17:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:17:01 --> Database Driver Class Initialized
INFO - 2016-08-12 01:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:17:01 --> Email Class Initialized
INFO - 2016-08-12 01:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:17:01 --> Pagination Class Initialized
INFO - 2016-08-12 01:17:01 --> Model Class Initialized
INFO - 2016-08-12 01:17:01 --> Controller Class Initialized
INFO - 2016-08-12 01:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:17:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-12 01:17:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:17:02 --> Final output sent to browser
DEBUG - 2016-08-12 01:17:02 --> Total execution time: 0.4145
INFO - 2016-08-12 01:17:44 --> Config Class Initialized
INFO - 2016-08-12 01:17:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:17:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:17:44 --> Utf8 Class Initialized
INFO - 2016-08-12 01:17:44 --> URI Class Initialized
INFO - 2016-08-12 01:17:44 --> Router Class Initialized
INFO - 2016-08-12 01:17:44 --> Output Class Initialized
INFO - 2016-08-12 01:17:44 --> Security Class Initialized
DEBUG - 2016-08-12 01:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:17:44 --> Input Class Initialized
INFO - 2016-08-12 01:17:44 --> Language Class Initialized
INFO - 2016-08-12 01:17:44 --> Loader Class Initialized
INFO - 2016-08-12 01:17:44 --> Helper loaded: url_helper
INFO - 2016-08-12 01:17:44 --> Helper loaded: date_helper
INFO - 2016-08-12 01:17:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:17:44 --> Database Driver Class Initialized
INFO - 2016-08-12 01:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:17:44 --> Email Class Initialized
INFO - 2016-08-12 01:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:17:44 --> Pagination Class Initialized
INFO - 2016-08-12 01:17:44 --> Model Class Initialized
INFO - 2016-08-12 01:17:44 --> Controller Class Initialized
DEBUG - 2016-08-12 01:17:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 01:17:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 01:17:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 01:17:44 --> Helper loaded: cookie_helper
INFO - 2016-08-12 01:17:44 --> Helper loaded: language_helper
DEBUG - 2016-08-12 01:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 01:17:45 --> Model Class Initialized
INFO - 2016-08-12 01:17:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 01:17:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 01:17:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 01:17:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 01:17:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 01:17:45 --> Final output sent to browser
DEBUG - 2016-08-12 01:17:45 --> Total execution time: 0.4662
INFO - 2016-08-12 01:18:06 --> Config Class Initialized
INFO - 2016-08-12 01:18:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:18:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:18:06 --> Utf8 Class Initialized
INFO - 2016-08-12 01:18:06 --> URI Class Initialized
INFO - 2016-08-12 01:18:06 --> Router Class Initialized
INFO - 2016-08-12 01:18:06 --> Output Class Initialized
INFO - 2016-08-12 01:18:06 --> Security Class Initialized
DEBUG - 2016-08-12 01:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:18:06 --> Input Class Initialized
INFO - 2016-08-12 01:18:06 --> Language Class Initialized
INFO - 2016-08-12 01:18:06 --> Loader Class Initialized
INFO - 2016-08-12 01:18:06 --> Helper loaded: url_helper
INFO - 2016-08-12 01:18:06 --> Helper loaded: date_helper
INFO - 2016-08-12 01:18:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:18:06 --> Database Driver Class Initialized
INFO - 2016-08-12 01:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:18:06 --> Email Class Initialized
INFO - 2016-08-12 01:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:18:06 --> Pagination Class Initialized
INFO - 2016-08-12 01:18:06 --> Model Class Initialized
INFO - 2016-08-12 01:18:06 --> Controller Class Initialized
INFO - 2016-08-12 01:18:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 01:18:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 01:18:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 01:18:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 01:18:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 01:18:06 --> Final output sent to browser
DEBUG - 2016-08-12 01:18:06 --> Total execution time: 0.4706
INFO - 2016-08-12 01:18:34 --> Config Class Initialized
INFO - 2016-08-12 01:18:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:18:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:18:34 --> Utf8 Class Initialized
INFO - 2016-08-12 01:18:34 --> URI Class Initialized
INFO - 2016-08-12 01:18:34 --> Router Class Initialized
INFO - 2016-08-12 01:18:34 --> Output Class Initialized
INFO - 2016-08-12 01:18:34 --> Security Class Initialized
DEBUG - 2016-08-12 01:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:18:34 --> Input Class Initialized
INFO - 2016-08-12 01:18:35 --> Language Class Initialized
INFO - 2016-08-12 01:18:35 --> Config Class Initialized
INFO - 2016-08-12 01:18:35 --> Hooks Class Initialized
INFO - 2016-08-12 01:18:35 --> Loader Class Initialized
INFO - 2016-08-12 01:18:35 --> Helper loaded: url_helper
DEBUG - 2016-08-12 01:18:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:18:35 --> Utf8 Class Initialized
INFO - 2016-08-12 01:18:35 --> Helper loaded: date_helper
INFO - 2016-08-12 01:18:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:18:35 --> URI Class Initialized
INFO - 2016-08-12 01:18:35 --> Router Class Initialized
INFO - 2016-08-12 01:18:35 --> Database Driver Class Initialized
INFO - 2016-08-12 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:18:35 --> Output Class Initialized
INFO - 2016-08-12 01:18:35 --> Email Class Initialized
INFO - 2016-08-12 01:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:18:35 --> Pagination Class Initialized
INFO - 2016-08-12 01:18:35 --> Model Class Initialized
INFO - 2016-08-12 01:18:35 --> Controller Class Initialized
INFO - 2016-08-12 01:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 01:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 01:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 01:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 01:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 01:18:35 --> Final output sent to browser
DEBUG - 2016-08-12 01:18:35 --> Total execution time: 1.0288
INFO - 2016-08-12 01:18:35 --> Security Class Initialized
DEBUG - 2016-08-12 01:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:18:36 --> Input Class Initialized
INFO - 2016-08-12 01:18:36 --> Language Class Initialized
INFO - 2016-08-12 01:18:36 --> Loader Class Initialized
INFO - 2016-08-12 01:18:36 --> Helper loaded: url_helper
INFO - 2016-08-12 01:18:36 --> Helper loaded: date_helper
INFO - 2016-08-12 01:18:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:18:36 --> Database Driver Class Initialized
INFO - 2016-08-12 01:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:18:36 --> Email Class Initialized
INFO - 2016-08-12 01:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:18:36 --> Pagination Class Initialized
INFO - 2016-08-12 01:18:36 --> Model Class Initialized
INFO - 2016-08-12 01:18:36 --> Controller Class Initialized
INFO - 2016-08-12 01:18:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:18:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:18:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-12 01:18:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:18:37 --> Final output sent to browser
DEBUG - 2016-08-12 01:18:37 --> Total execution time: 2.2314
INFO - 2016-08-12 01:25:12 --> Config Class Initialized
INFO - 2016-08-12 01:25:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:25:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:25:12 --> Utf8 Class Initialized
INFO - 2016-08-12 01:25:12 --> URI Class Initialized
INFO - 2016-08-12 01:25:12 --> Router Class Initialized
INFO - 2016-08-12 01:25:12 --> Output Class Initialized
INFO - 2016-08-12 01:25:12 --> Security Class Initialized
DEBUG - 2016-08-12 01:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:25:12 --> Input Class Initialized
INFO - 2016-08-12 01:25:12 --> Language Class Initialized
INFO - 2016-08-12 01:25:12 --> Loader Class Initialized
INFO - 2016-08-12 01:25:12 --> Helper loaded: url_helper
INFO - 2016-08-12 01:25:12 --> Helper loaded: date_helper
INFO - 2016-08-12 01:25:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:25:12 --> Database Driver Class Initialized
INFO - 2016-08-12 01:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:25:12 --> Email Class Initialized
INFO - 2016-08-12 01:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:25:13 --> Pagination Class Initialized
INFO - 2016-08-12 01:25:13 --> Model Class Initialized
INFO - 2016-08-12 01:25:13 --> Controller Class Initialized
INFO - 2016-08-12 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:25:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:25:13 --> Final output sent to browser
DEBUG - 2016-08-12 01:25:13 --> Total execution time: 0.4777
INFO - 2016-08-12 01:25:13 --> Config Class Initialized
INFO - 2016-08-12 01:25:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:25:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:25:13 --> Utf8 Class Initialized
INFO - 2016-08-12 01:25:13 --> URI Class Initialized
INFO - 2016-08-12 01:25:13 --> Router Class Initialized
INFO - 2016-08-12 01:25:13 --> Output Class Initialized
INFO - 2016-08-12 01:25:13 --> Security Class Initialized
DEBUG - 2016-08-12 01:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:25:13 --> Input Class Initialized
INFO - 2016-08-12 01:25:13 --> Language Class Initialized
ERROR - 2016-08-12 01:25:13 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 01:28:08 --> Config Class Initialized
INFO - 2016-08-12 01:28:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:28:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:28:08 --> Utf8 Class Initialized
INFO - 2016-08-12 01:28:08 --> URI Class Initialized
INFO - 2016-08-12 01:28:08 --> Router Class Initialized
INFO - 2016-08-12 01:28:08 --> Output Class Initialized
INFO - 2016-08-12 01:28:08 --> Security Class Initialized
DEBUG - 2016-08-12 01:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:28:08 --> Input Class Initialized
INFO - 2016-08-12 01:28:08 --> Language Class Initialized
INFO - 2016-08-12 01:28:08 --> Loader Class Initialized
INFO - 2016-08-12 01:28:08 --> Helper loaded: url_helper
INFO - 2016-08-12 01:28:08 --> Helper loaded: date_helper
INFO - 2016-08-12 01:28:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:28:08 --> Database Driver Class Initialized
INFO - 2016-08-12 01:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:28:08 --> Email Class Initialized
INFO - 2016-08-12 01:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:28:08 --> Pagination Class Initialized
INFO - 2016-08-12 01:28:08 --> Model Class Initialized
INFO - 2016-08-12 01:28:08 --> Controller Class Initialized
INFO - 2016-08-12 01:28:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:28:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:28:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:28:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:28:08 --> Final output sent to browser
DEBUG - 2016-08-12 01:28:08 --> Total execution time: 0.3802
INFO - 2016-08-12 01:28:09 --> Config Class Initialized
INFO - 2016-08-12 01:28:09 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:28:09 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:28:09 --> Utf8 Class Initialized
INFO - 2016-08-12 01:28:09 --> URI Class Initialized
INFO - 2016-08-12 01:28:09 --> Router Class Initialized
INFO - 2016-08-12 01:28:09 --> Output Class Initialized
INFO - 2016-08-12 01:28:09 --> Security Class Initialized
DEBUG - 2016-08-12 01:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:28:09 --> Input Class Initialized
INFO - 2016-08-12 01:28:09 --> Language Class Initialized
ERROR - 2016-08-12 01:28:09 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 01:28:13 --> Config Class Initialized
INFO - 2016-08-12 01:28:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:28:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:28:13 --> Utf8 Class Initialized
INFO - 2016-08-12 01:28:14 --> URI Class Initialized
INFO - 2016-08-12 01:28:14 --> Router Class Initialized
INFO - 2016-08-12 01:28:14 --> Output Class Initialized
INFO - 2016-08-12 01:28:14 --> Security Class Initialized
DEBUG - 2016-08-12 01:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:28:14 --> Input Class Initialized
INFO - 2016-08-12 01:28:14 --> Language Class Initialized
ERROR - 2016-08-12 01:28:14 --> 404 Page Not Found: Kontak/index
INFO - 2016-08-12 01:28:19 --> Config Class Initialized
INFO - 2016-08-12 01:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:28:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:28:19 --> Utf8 Class Initialized
INFO - 2016-08-12 01:28:19 --> URI Class Initialized
INFO - 2016-08-12 01:28:19 --> Router Class Initialized
INFO - 2016-08-12 01:28:19 --> Output Class Initialized
INFO - 2016-08-12 01:28:19 --> Security Class Initialized
DEBUG - 2016-08-12 01:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:28:19 --> Input Class Initialized
INFO - 2016-08-12 01:28:19 --> Language Class Initialized
INFO - 2016-08-12 01:28:19 --> Loader Class Initialized
INFO - 2016-08-12 01:28:19 --> Helper loaded: url_helper
INFO - 2016-08-12 01:28:19 --> Helper loaded: date_helper
INFO - 2016-08-12 01:28:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:28:19 --> Database Driver Class Initialized
INFO - 2016-08-12 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:28:19 --> Email Class Initialized
INFO - 2016-08-12 01:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:28:19 --> Pagination Class Initialized
INFO - 2016-08-12 01:28:19 --> Model Class Initialized
INFO - 2016-08-12 01:28:19 --> Controller Class Initialized
INFO - 2016-08-12 01:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:28:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:28:19 --> Final output sent to browser
DEBUG - 2016-08-12 01:28:19 --> Total execution time: 0.3694
INFO - 2016-08-12 01:30:17 --> Config Class Initialized
INFO - 2016-08-12 01:30:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:30:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:30:17 --> Utf8 Class Initialized
INFO - 2016-08-12 01:30:17 --> URI Class Initialized
INFO - 2016-08-12 01:30:17 --> Router Class Initialized
INFO - 2016-08-12 01:30:17 --> Output Class Initialized
INFO - 2016-08-12 01:30:17 --> Security Class Initialized
DEBUG - 2016-08-12 01:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:30:17 --> Input Class Initialized
INFO - 2016-08-12 01:30:17 --> Language Class Initialized
INFO - 2016-08-12 01:30:17 --> Loader Class Initialized
INFO - 2016-08-12 01:30:17 --> Helper loaded: url_helper
INFO - 2016-08-12 01:30:17 --> Helper loaded: date_helper
INFO - 2016-08-12 01:30:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:30:17 --> Database Driver Class Initialized
INFO - 2016-08-12 01:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:30:17 --> Email Class Initialized
INFO - 2016-08-12 01:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:30:17 --> Pagination Class Initialized
INFO - 2016-08-12 01:30:17 --> Model Class Initialized
INFO - 2016-08-12 01:30:17 --> Controller Class Initialized
INFO - 2016-08-12 01:30:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:30:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:30:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:30:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:30:17 --> Final output sent to browser
DEBUG - 2016-08-12 01:30:17 --> Total execution time: 0.3717
INFO - 2016-08-12 01:30:20 --> Config Class Initialized
INFO - 2016-08-12 01:30:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:30:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:30:20 --> Utf8 Class Initialized
INFO - 2016-08-12 01:30:20 --> URI Class Initialized
INFO - 2016-08-12 01:30:20 --> Router Class Initialized
INFO - 2016-08-12 01:30:20 --> Output Class Initialized
INFO - 2016-08-12 01:30:20 --> Security Class Initialized
DEBUG - 2016-08-12 01:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:30:20 --> Input Class Initialized
INFO - 2016-08-12 01:30:20 --> Language Class Initialized
INFO - 2016-08-12 01:30:20 --> Loader Class Initialized
INFO - 2016-08-12 01:30:20 --> Helper loaded: url_helper
INFO - 2016-08-12 01:30:20 --> Helper loaded: date_helper
INFO - 2016-08-12 01:30:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:30:20 --> Database Driver Class Initialized
INFO - 2016-08-12 01:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:30:20 --> Email Class Initialized
INFO - 2016-08-12 01:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:30:20 --> Pagination Class Initialized
INFO - 2016-08-12 01:30:20 --> Model Class Initialized
INFO - 2016-08-12 01:30:20 --> Controller Class Initialized
INFO - 2016-08-12 01:30:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:30:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:30:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:30:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:30:20 --> Final output sent to browser
DEBUG - 2016-08-12 01:30:20 --> Total execution time: 0.3919
INFO - 2016-08-12 01:31:23 --> Config Class Initialized
INFO - 2016-08-12 01:31:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:23 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:23 --> URI Class Initialized
INFO - 2016-08-12 01:31:23 --> Router Class Initialized
INFO - 2016-08-12 01:31:23 --> Output Class Initialized
INFO - 2016-08-12 01:31:23 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:23 --> Input Class Initialized
INFO - 2016-08-12 01:31:23 --> Language Class Initialized
ERROR - 2016-08-12 01:31:23 --> 404 Page Not Found: Home/kontak
INFO - 2016-08-12 01:31:36 --> Config Class Initialized
INFO - 2016-08-12 01:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:36 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:36 --> URI Class Initialized
INFO - 2016-08-12 01:31:36 --> Router Class Initialized
INFO - 2016-08-12 01:31:36 --> Output Class Initialized
INFO - 2016-08-12 01:31:36 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:36 --> Input Class Initialized
INFO - 2016-08-12 01:31:36 --> Language Class Initialized
ERROR - 2016-08-12 01:31:36 --> 404 Page Not Found: Home/kontak
INFO - 2016-08-12 01:31:38 --> Config Class Initialized
INFO - 2016-08-12 01:31:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:38 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:38 --> URI Class Initialized
INFO - 2016-08-12 01:31:38 --> Router Class Initialized
INFO - 2016-08-12 01:31:38 --> Output Class Initialized
INFO - 2016-08-12 01:31:38 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:38 --> Input Class Initialized
INFO - 2016-08-12 01:31:38 --> Language Class Initialized
INFO - 2016-08-12 01:31:38 --> Loader Class Initialized
INFO - 2016-08-12 01:31:38 --> Helper loaded: url_helper
INFO - 2016-08-12 01:31:38 --> Helper loaded: date_helper
INFO - 2016-08-12 01:31:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:31:38 --> Database Driver Class Initialized
INFO - 2016-08-12 01:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:31:39 --> Email Class Initialized
INFO - 2016-08-12 01:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:31:39 --> Pagination Class Initialized
INFO - 2016-08-12 01:31:39 --> Model Class Initialized
INFO - 2016-08-12 01:31:39 --> Controller Class Initialized
INFO - 2016-08-12 01:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:31:39 --> Final output sent to browser
DEBUG - 2016-08-12 01:31:39 --> Total execution time: 0.3766
INFO - 2016-08-12 01:31:41 --> Config Class Initialized
INFO - 2016-08-12 01:31:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:41 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:41 --> URI Class Initialized
INFO - 2016-08-12 01:31:41 --> Router Class Initialized
INFO - 2016-08-12 01:31:41 --> Output Class Initialized
INFO - 2016-08-12 01:31:41 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:41 --> Input Class Initialized
INFO - 2016-08-12 01:31:41 --> Language Class Initialized
INFO - 2016-08-12 01:31:41 --> Loader Class Initialized
INFO - 2016-08-12 01:31:41 --> Helper loaded: url_helper
INFO - 2016-08-12 01:31:41 --> Helper loaded: date_helper
INFO - 2016-08-12 01:31:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:31:41 --> Database Driver Class Initialized
INFO - 2016-08-12 01:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:31:41 --> Email Class Initialized
INFO - 2016-08-12 01:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:31:41 --> Pagination Class Initialized
INFO - 2016-08-12 01:31:41 --> Model Class Initialized
INFO - 2016-08-12 01:31:41 --> Controller Class Initialized
INFO - 2016-08-12 01:31:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:31:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:31:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:31:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:31:41 --> Final output sent to browser
DEBUG - 2016-08-12 01:31:41 --> Total execution time: 0.3753
INFO - 2016-08-12 01:31:42 --> Config Class Initialized
INFO - 2016-08-12 01:31:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:42 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:43 --> URI Class Initialized
INFO - 2016-08-12 01:31:43 --> Router Class Initialized
INFO - 2016-08-12 01:31:43 --> Output Class Initialized
INFO - 2016-08-12 01:31:43 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:43 --> Input Class Initialized
INFO - 2016-08-12 01:31:43 --> Language Class Initialized
INFO - 2016-08-12 01:31:43 --> Loader Class Initialized
INFO - 2016-08-12 01:31:43 --> Helper loaded: url_helper
INFO - 2016-08-12 01:31:43 --> Helper loaded: date_helper
INFO - 2016-08-12 01:31:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:31:43 --> Database Driver Class Initialized
INFO - 2016-08-12 01:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:31:43 --> Email Class Initialized
INFO - 2016-08-12 01:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:31:43 --> Pagination Class Initialized
INFO - 2016-08-12 01:31:43 --> Model Class Initialized
INFO - 2016-08-12 01:31:43 --> Controller Class Initialized
INFO - 2016-08-12 01:31:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:31:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:31:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:31:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:31:43 --> Final output sent to browser
DEBUG - 2016-08-12 01:31:43 --> Total execution time: 0.4596
INFO - 2016-08-12 01:31:51 --> Config Class Initialized
INFO - 2016-08-12 01:31:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:51 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:51 --> URI Class Initialized
INFO - 2016-08-12 01:31:51 --> Router Class Initialized
INFO - 2016-08-12 01:31:51 --> Output Class Initialized
INFO - 2016-08-12 01:31:51 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:51 --> Input Class Initialized
INFO - 2016-08-12 01:31:51 --> Language Class Initialized
INFO - 2016-08-12 01:31:51 --> Loader Class Initialized
INFO - 2016-08-12 01:31:51 --> Helper loaded: url_helper
INFO - 2016-08-12 01:31:51 --> Helper loaded: date_helper
INFO - 2016-08-12 01:31:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:31:51 --> Database Driver Class Initialized
INFO - 2016-08-12 01:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:31:51 --> Email Class Initialized
INFO - 2016-08-12 01:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:31:51 --> Pagination Class Initialized
INFO - 2016-08-12 01:31:51 --> Model Class Initialized
INFO - 2016-08-12 01:31:51 --> Controller Class Initialized
INFO - 2016-08-12 01:31:51 --> Model Class Initialized
INFO - 2016-08-12 01:31:51 --> Helper loaded: text_helper
INFO - 2016-08-12 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 01:31:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:31:51 --> Final output sent to browser
DEBUG - 2016-08-12 01:31:51 --> Total execution time: 0.4419
INFO - 2016-08-12 01:31:54 --> Config Class Initialized
INFO - 2016-08-12 01:31:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:31:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:31:54 --> Utf8 Class Initialized
INFO - 2016-08-12 01:31:54 --> URI Class Initialized
INFO - 2016-08-12 01:31:54 --> Router Class Initialized
INFO - 2016-08-12 01:31:54 --> Output Class Initialized
INFO - 2016-08-12 01:31:54 --> Security Class Initialized
DEBUG - 2016-08-12 01:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:31:54 --> Input Class Initialized
INFO - 2016-08-12 01:31:54 --> Language Class Initialized
INFO - 2016-08-12 01:31:54 --> Loader Class Initialized
INFO - 2016-08-12 01:31:54 --> Helper loaded: url_helper
INFO - 2016-08-12 01:31:54 --> Helper loaded: date_helper
INFO - 2016-08-12 01:31:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:31:54 --> Database Driver Class Initialized
INFO - 2016-08-12 01:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:31:54 --> Email Class Initialized
INFO - 2016-08-12 01:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:31:54 --> Pagination Class Initialized
INFO - 2016-08-12 01:31:54 --> Model Class Initialized
INFO - 2016-08-12 01:31:54 --> Controller Class Initialized
INFO - 2016-08-12 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 01:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:31:54 --> Final output sent to browser
DEBUG - 2016-08-12 01:31:54 --> Total execution time: 0.3757
INFO - 2016-08-12 01:32:22 --> Config Class Initialized
INFO - 2016-08-12 01:32:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 01:32:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 01:32:22 --> Utf8 Class Initialized
INFO - 2016-08-12 01:32:22 --> URI Class Initialized
INFO - 2016-08-12 01:32:22 --> Router Class Initialized
INFO - 2016-08-12 01:32:22 --> Output Class Initialized
INFO - 2016-08-12 01:32:22 --> Security Class Initialized
DEBUG - 2016-08-12 01:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 01:32:22 --> Input Class Initialized
INFO - 2016-08-12 01:32:22 --> Language Class Initialized
INFO - 2016-08-12 01:32:22 --> Loader Class Initialized
INFO - 2016-08-12 01:32:22 --> Helper loaded: url_helper
INFO - 2016-08-12 01:32:22 --> Helper loaded: date_helper
INFO - 2016-08-12 01:32:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 01:32:22 --> Database Driver Class Initialized
INFO - 2016-08-12 01:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 01:32:22 --> Email Class Initialized
INFO - 2016-08-12 01:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 01:32:22 --> Pagination Class Initialized
INFO - 2016-08-12 01:32:22 --> Model Class Initialized
INFO - 2016-08-12 01:32:22 --> Controller Class Initialized
INFO - 2016-08-12 01:32:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 01:32:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 01:32:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 01:32:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 01:32:22 --> Final output sent to browser
DEBUG - 2016-08-12 01:32:22 --> Total execution time: 0.3791
INFO - 2016-08-12 08:58:20 --> Config Class Initialized
INFO - 2016-08-12 08:58:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:58:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:58:20 --> Utf8 Class Initialized
INFO - 2016-08-12 08:58:20 --> URI Class Initialized
INFO - 2016-08-12 08:58:20 --> Router Class Initialized
INFO - 2016-08-12 08:58:20 --> Output Class Initialized
INFO - 2016-08-12 08:58:20 --> Security Class Initialized
DEBUG - 2016-08-12 08:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:58:20 --> Input Class Initialized
INFO - 2016-08-12 08:58:20 --> Language Class Initialized
INFO - 2016-08-12 08:58:20 --> Loader Class Initialized
INFO - 2016-08-12 08:58:20 --> Helper loaded: url_helper
INFO - 2016-08-12 08:58:20 --> Helper loaded: date_helper
INFO - 2016-08-12 08:58:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:58:20 --> Database Driver Class Initialized
INFO - 2016-08-12 08:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:58:20 --> Email Class Initialized
INFO - 2016-08-12 08:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:58:20 --> Pagination Class Initialized
INFO - 2016-08-12 08:58:20 --> Model Class Initialized
INFO - 2016-08-12 08:58:20 --> Controller Class Initialized
INFO - 2016-08-12 08:58:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 08:58:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 08:58:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 08:58:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 08:58:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 08:58:20 --> Final output sent to browser
DEBUG - 2016-08-12 08:58:20 --> Total execution time: 0.3856
INFO - 2016-08-12 08:58:34 --> Config Class Initialized
INFO - 2016-08-12 08:58:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:58:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:58:34 --> Utf8 Class Initialized
INFO - 2016-08-12 08:58:34 --> URI Class Initialized
INFO - 2016-08-12 08:58:34 --> Router Class Initialized
INFO - 2016-08-12 08:58:34 --> Output Class Initialized
INFO - 2016-08-12 08:58:34 --> Security Class Initialized
DEBUG - 2016-08-12 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:58:34 --> Input Class Initialized
INFO - 2016-08-12 08:58:34 --> Language Class Initialized
INFO - 2016-08-12 08:58:34 --> Loader Class Initialized
INFO - 2016-08-12 08:58:34 --> Helper loaded: url_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: date_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:58:34 --> Database Driver Class Initialized
INFO - 2016-08-12 08:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:58:34 --> Email Class Initialized
INFO - 2016-08-12 08:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:58:34 --> Pagination Class Initialized
INFO - 2016-08-12 08:58:34 --> Model Class Initialized
INFO - 2016-08-12 08:58:34 --> Controller Class Initialized
DEBUG - 2016-08-12 08:58:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 08:58:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 08:58:34 --> Helper loaded: cookie_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: language_helper
DEBUG - 2016-08-12 08:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:34 --> Model Class Initialized
INFO - 2016-08-12 08:58:34 --> Config Class Initialized
INFO - 2016-08-12 08:58:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:58:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:58:34 --> Utf8 Class Initialized
INFO - 2016-08-12 08:58:34 --> URI Class Initialized
INFO - 2016-08-12 08:58:34 --> Router Class Initialized
INFO - 2016-08-12 08:58:34 --> Output Class Initialized
INFO - 2016-08-12 08:58:34 --> Security Class Initialized
DEBUG - 2016-08-12 08:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:58:34 --> Input Class Initialized
INFO - 2016-08-12 08:58:34 --> Language Class Initialized
INFO - 2016-08-12 08:58:34 --> Loader Class Initialized
INFO - 2016-08-12 08:58:34 --> Helper loaded: url_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: date_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:58:34 --> Database Driver Class Initialized
INFO - 2016-08-12 08:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:58:34 --> Email Class Initialized
INFO - 2016-08-12 08:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:58:34 --> Pagination Class Initialized
INFO - 2016-08-12 08:58:34 --> Model Class Initialized
INFO - 2016-08-12 08:58:34 --> Controller Class Initialized
DEBUG - 2016-08-12 08:58:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 08:58:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 08:58:34 --> Helper loaded: cookie_helper
INFO - 2016-08-12 08:58:34 --> Helper loaded: language_helper
DEBUG - 2016-08-12 08:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:34 --> Model Class Initialized
INFO - 2016-08-12 08:58:35 --> Helper loaded: form_helper
INFO - 2016-08-12 08:58:35 --> Form Validation Class Initialized
INFO - 2016-08-12 08:58:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 08:58:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-12 08:58:35 --> Final output sent to browser
DEBUG - 2016-08-12 08:58:35 --> Total execution time: 0.7039
INFO - 2016-08-12 08:58:40 --> Config Class Initialized
INFO - 2016-08-12 08:58:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:58:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:58:41 --> Utf8 Class Initialized
INFO - 2016-08-12 08:58:41 --> URI Class Initialized
INFO - 2016-08-12 08:58:41 --> Router Class Initialized
INFO - 2016-08-12 08:58:41 --> Output Class Initialized
INFO - 2016-08-12 08:58:41 --> Security Class Initialized
DEBUG - 2016-08-12 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:58:41 --> Input Class Initialized
INFO - 2016-08-12 08:58:41 --> Language Class Initialized
INFO - 2016-08-12 08:58:41 --> Loader Class Initialized
INFO - 2016-08-12 08:58:41 --> Helper loaded: url_helper
INFO - 2016-08-12 08:58:41 --> Helper loaded: date_helper
INFO - 2016-08-12 08:58:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:58:41 --> Database Driver Class Initialized
INFO - 2016-08-12 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:58:41 --> Email Class Initialized
INFO - 2016-08-12 08:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:58:41 --> Pagination Class Initialized
INFO - 2016-08-12 08:58:41 --> Model Class Initialized
INFO - 2016-08-12 08:58:41 --> Controller Class Initialized
DEBUG - 2016-08-12 08:58:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 08:58:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 08:58:41 --> Helper loaded: cookie_helper
INFO - 2016-08-12 08:58:41 --> Helper loaded: language_helper
DEBUG - 2016-08-12 08:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:41 --> Model Class Initialized
INFO - 2016-08-12 08:58:41 --> Helper loaded: form_helper
INFO - 2016-08-12 08:58:41 --> Form Validation Class Initialized
INFO - 2016-08-12 08:58:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 08:58:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 08:58:41 --> Config Class Initialized
INFO - 2016-08-12 08:58:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:58:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:58:41 --> Utf8 Class Initialized
INFO - 2016-08-12 08:58:41 --> URI Class Initialized
INFO - 2016-08-12 08:58:41 --> Router Class Initialized
INFO - 2016-08-12 08:58:41 --> Output Class Initialized
INFO - 2016-08-12 08:58:41 --> Security Class Initialized
DEBUG - 2016-08-12 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:58:41 --> Input Class Initialized
INFO - 2016-08-12 08:58:41 --> Language Class Initialized
INFO - 2016-08-12 08:58:41 --> Loader Class Initialized
INFO - 2016-08-12 08:58:41 --> Helper loaded: url_helper
INFO - 2016-08-12 08:58:42 --> Helper loaded: date_helper
INFO - 2016-08-12 08:58:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:58:42 --> Database Driver Class Initialized
INFO - 2016-08-12 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:58:42 --> Email Class Initialized
INFO - 2016-08-12 08:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:58:42 --> Pagination Class Initialized
INFO - 2016-08-12 08:58:42 --> Model Class Initialized
INFO - 2016-08-12 08:58:42 --> Controller Class Initialized
DEBUG - 2016-08-12 08:58:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 08:58:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 08:58:42 --> Helper loaded: cookie_helper
INFO - 2016-08-12 08:58:42 --> Helper loaded: language_helper
DEBUG - 2016-08-12 08:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 08:58:42 --> Model Class Initialized
INFO - 2016-08-12 08:58:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 08:58:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 08:58:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 08:58:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 08:58:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 08:58:42 --> Final output sent to browser
DEBUG - 2016-08-12 08:58:42 --> Total execution time: 0.6306
INFO - 2016-08-12 08:59:22 --> Config Class Initialized
INFO - 2016-08-12 08:59:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:59:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:59:22 --> Utf8 Class Initialized
INFO - 2016-08-12 08:59:22 --> URI Class Initialized
INFO - 2016-08-12 08:59:22 --> Router Class Initialized
INFO - 2016-08-12 08:59:22 --> Output Class Initialized
INFO - 2016-08-12 08:59:22 --> Security Class Initialized
DEBUG - 2016-08-12 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:59:22 --> Input Class Initialized
INFO - 2016-08-12 08:59:22 --> Language Class Initialized
INFO - 2016-08-12 08:59:22 --> Loader Class Initialized
INFO - 2016-08-12 08:59:22 --> Helper loaded: url_helper
INFO - 2016-08-12 08:59:22 --> Helper loaded: date_helper
INFO - 2016-08-12 08:59:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:59:22 --> Database Driver Class Initialized
INFO - 2016-08-12 08:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:59:22 --> Email Class Initialized
INFO - 2016-08-12 08:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:59:22 --> Pagination Class Initialized
INFO - 2016-08-12 08:59:23 --> Model Class Initialized
INFO - 2016-08-12 08:59:23 --> Controller Class Initialized
INFO - 2016-08-12 08:59:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 08:59:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 08:59:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 08:59:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 08:59:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 08:59:23 --> Final output sent to browser
DEBUG - 2016-08-12 08:59:23 --> Total execution time: 0.3979
INFO - 2016-08-12 08:59:57 --> Config Class Initialized
INFO - 2016-08-12 08:59:57 --> Hooks Class Initialized
DEBUG - 2016-08-12 08:59:57 --> UTF-8 Support Enabled
INFO - 2016-08-12 08:59:57 --> Utf8 Class Initialized
INFO - 2016-08-12 08:59:57 --> URI Class Initialized
INFO - 2016-08-12 08:59:57 --> Router Class Initialized
INFO - 2016-08-12 08:59:57 --> Output Class Initialized
INFO - 2016-08-12 08:59:57 --> Security Class Initialized
DEBUG - 2016-08-12 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 08:59:57 --> Input Class Initialized
INFO - 2016-08-12 08:59:57 --> Language Class Initialized
INFO - 2016-08-12 08:59:57 --> Loader Class Initialized
INFO - 2016-08-12 08:59:57 --> Helper loaded: url_helper
INFO - 2016-08-12 08:59:57 --> Helper loaded: date_helper
INFO - 2016-08-12 08:59:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 08:59:57 --> Database Driver Class Initialized
INFO - 2016-08-12 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 08:59:58 --> Email Class Initialized
INFO - 2016-08-12 08:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 08:59:58 --> Pagination Class Initialized
INFO - 2016-08-12 08:59:58 --> Model Class Initialized
INFO - 2016-08-12 08:59:58 --> Controller Class Initialized
DEBUG - 2016-08-12 08:59:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:00:03 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-08-12 09:00:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:04 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:04 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:04 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
ERROR - 2016-08-12 09:00:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 D:\xampp\htdocs\aqiqahsehati\system\libraries\Email.php 2172
INFO - 2016-08-12 09:00:09 --> Config Class Initialized
INFO - 2016-08-12 09:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:00:09 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:00:09 --> Utf8 Class Initialized
INFO - 2016-08-12 09:00:09 --> URI Class Initialized
INFO - 2016-08-12 09:00:09 --> Router Class Initialized
INFO - 2016-08-12 09:00:09 --> Output Class Initialized
INFO - 2016-08-12 09:00:09 --> Security Class Initialized
DEBUG - 2016-08-12 09:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:00:09 --> Input Class Initialized
INFO - 2016-08-12 09:00:09 --> Language Class Initialized
INFO - 2016-08-12 09:00:09 --> Loader Class Initialized
INFO - 2016-08-12 09:00:09 --> Helper loaded: url_helper
INFO - 2016-08-12 09:00:09 --> Helper loaded: date_helper
INFO - 2016-08-12 09:00:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:00:09 --> Database Driver Class Initialized
INFO - 2016-08-12 09:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:00:09 --> Email Class Initialized
INFO - 2016-08-12 09:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:00:09 --> Pagination Class Initialized
INFO - 2016-08-12 09:00:09 --> Model Class Initialized
INFO - 2016-08-12 09:00:09 --> Controller Class Initialized
INFO - 2016-08-12 09:00:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 09:00:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 09:00:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 09:00:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 09:00:09 --> Final output sent to browser
DEBUG - 2016-08-12 09:00:09 --> Total execution time: 0.3844
INFO - 2016-08-12 09:00:13 --> Config Class Initialized
INFO - 2016-08-12 09:00:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:00:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:00:13 --> Utf8 Class Initialized
INFO - 2016-08-12 09:00:13 --> URI Class Initialized
INFO - 2016-08-12 09:00:13 --> Router Class Initialized
INFO - 2016-08-12 09:00:13 --> Output Class Initialized
INFO - 2016-08-12 09:00:13 --> Security Class Initialized
DEBUG - 2016-08-12 09:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:00:13 --> Input Class Initialized
INFO - 2016-08-12 09:00:13 --> Language Class Initialized
INFO - 2016-08-12 09:00:13 --> Loader Class Initialized
INFO - 2016-08-12 09:00:13 --> Helper loaded: url_helper
INFO - 2016-08-12 09:00:13 --> Helper loaded: date_helper
INFO - 2016-08-12 09:00:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:00:13 --> Database Driver Class Initialized
INFO - 2016-08-12 09:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:00:13 --> Email Class Initialized
INFO - 2016-08-12 09:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:00:13 --> Pagination Class Initialized
INFO - 2016-08-12 09:00:13 --> Model Class Initialized
INFO - 2016-08-12 09:00:13 --> Controller Class Initialized
INFO - 2016-08-12 09:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:00:13 --> Final output sent to browser
DEBUG - 2016-08-12 09:00:13 --> Total execution time: 0.4052
INFO - 2016-08-12 09:06:56 --> Config Class Initialized
INFO - 2016-08-12 09:06:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:06:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:06:56 --> Utf8 Class Initialized
INFO - 2016-08-12 09:06:56 --> URI Class Initialized
INFO - 2016-08-12 09:06:56 --> Router Class Initialized
INFO - 2016-08-12 09:06:56 --> Output Class Initialized
INFO - 2016-08-12 09:06:56 --> Security Class Initialized
DEBUG - 2016-08-12 09:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:06:56 --> Input Class Initialized
INFO - 2016-08-12 09:06:56 --> Language Class Initialized
INFO - 2016-08-12 09:06:57 --> Loader Class Initialized
INFO - 2016-08-12 09:06:57 --> Helper loaded: url_helper
INFO - 2016-08-12 09:06:57 --> Helper loaded: date_helper
INFO - 2016-08-12 09:06:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:06:57 --> Database Driver Class Initialized
INFO - 2016-08-12 09:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:06:57 --> Email Class Initialized
INFO - 2016-08-12 09:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:06:57 --> Pagination Class Initialized
INFO - 2016-08-12 09:06:57 --> Model Class Initialized
INFO - 2016-08-12 09:06:57 --> Controller Class Initialized
INFO - 2016-08-12 09:06:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:06:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:06:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:06:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:06:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:06:57 --> Final output sent to browser
DEBUG - 2016-08-12 09:06:57 --> Total execution time: 0.4745
INFO - 2016-08-12 09:07:13 --> Config Class Initialized
INFO - 2016-08-12 09:07:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:13 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:13 --> URI Class Initialized
INFO - 2016-08-12 09:07:13 --> Router Class Initialized
INFO - 2016-08-12 09:07:13 --> Output Class Initialized
INFO - 2016-08-12 09:07:13 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:13 --> Input Class Initialized
INFO - 2016-08-12 09:07:13 --> Language Class Initialized
INFO - 2016-08-12 09:07:13 --> Loader Class Initialized
INFO - 2016-08-12 09:07:13 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:13 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:13 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:13 --> Email Class Initialized
INFO - 2016-08-12 09:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:13 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:13 --> Model Class Initialized
INFO - 2016-08-12 09:07:13 --> Controller Class Initialized
INFO - 2016-08-12 09:07:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:07:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:13 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:13 --> Total execution time: 0.4184
INFO - 2016-08-12 09:07:20 --> Config Class Initialized
INFO - 2016-08-12 09:07:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:20 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:20 --> URI Class Initialized
INFO - 2016-08-12 09:07:20 --> Router Class Initialized
INFO - 2016-08-12 09:07:20 --> Output Class Initialized
INFO - 2016-08-12 09:07:20 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:20 --> Input Class Initialized
INFO - 2016-08-12 09:07:20 --> Language Class Initialized
INFO - 2016-08-12 09:07:20 --> Loader Class Initialized
INFO - 2016-08-12 09:07:20 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:20 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:20 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:20 --> Email Class Initialized
INFO - 2016-08-12 09:07:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:20 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:20 --> Model Class Initialized
INFO - 2016-08-12 09:07:20 --> Controller Class Initialized
INFO - 2016-08-12 09:07:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:07:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:20 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:20 --> Total execution time: 0.3992
INFO - 2016-08-12 09:07:32 --> Config Class Initialized
INFO - 2016-08-12 09:07:32 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:32 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:32 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:32 --> URI Class Initialized
DEBUG - 2016-08-12 09:07:32 --> No URI present. Default controller set.
INFO - 2016-08-12 09:07:32 --> Router Class Initialized
INFO - 2016-08-12 09:07:32 --> Output Class Initialized
INFO - 2016-08-12 09:07:32 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:32 --> Input Class Initialized
INFO - 2016-08-12 09:07:32 --> Language Class Initialized
INFO - 2016-08-12 09:07:32 --> Loader Class Initialized
INFO - 2016-08-12 09:07:32 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:32 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:32 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:32 --> Email Class Initialized
INFO - 2016-08-12 09:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:32 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:32 --> Model Class Initialized
INFO - 2016-08-12 09:07:32 --> Controller Class Initialized
INFO - 2016-08-12 09:07:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 09:07:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 09:07:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 09:07:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 09:07:32 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:32 --> Total execution time: 0.5090
INFO - 2016-08-12 09:07:38 --> Config Class Initialized
INFO - 2016-08-12 09:07:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:38 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:38 --> URI Class Initialized
INFO - 2016-08-12 09:07:38 --> Router Class Initialized
INFO - 2016-08-12 09:07:38 --> Output Class Initialized
INFO - 2016-08-12 09:07:38 --> Security Class Initialized
INFO - 2016-08-12 09:07:38 --> Config Class Initialized
INFO - 2016-08-12 09:07:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:39 --> Input Class Initialized
DEBUG - 2016-08-12 09:07:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:39 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:39 --> Language Class Initialized
INFO - 2016-08-12 09:07:39 --> URI Class Initialized
INFO - 2016-08-12 09:07:39 --> Loader Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:39 --> Router Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:39 --> Output Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:39 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:39 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:39 --> Input Class Initialized
INFO - 2016-08-12 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:39 --> Language Class Initialized
INFO - 2016-08-12 09:07:39 --> Email Class Initialized
INFO - 2016-08-12 09:07:39 --> Loader Class Initialized
INFO - 2016-08-12 09:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:39 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:39 --> Model Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:39 --> Controller Class Initialized
INFO - 2016-08-12 09:07:39 --> Helper loaded: tanggal_indonesia_helper
DEBUG - 2016-08-12 09:07:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
INFO - 2016-08-12 09:07:39 --> Database Driver Class Initialized
DEBUG - 2016-08-12 09:07:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:07:39 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:07:39 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:39 --> Model Class Initialized
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:39 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:39 --> Total execution time: 0.5089
INFO - 2016-08-12 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:39 --> Email Class Initialized
INFO - 2016-08-12 09:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:39 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:39 --> Model Class Initialized
INFO - 2016-08-12 09:07:39 --> Controller Class Initialized
DEBUG - 2016-08-12 09:07:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:07:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:07:39 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:07:39 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:07:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:39 --> Model Class Initialized
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:07:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:39 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:39 --> Total execution time: 0.6641
INFO - 2016-08-12 09:07:45 --> Config Class Initialized
INFO - 2016-08-12 09:07:45 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:45 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:45 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:45 --> URI Class Initialized
INFO - 2016-08-12 09:07:45 --> Router Class Initialized
INFO - 2016-08-12 09:07:45 --> Output Class Initialized
INFO - 2016-08-12 09:07:45 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:45 --> Input Class Initialized
INFO - 2016-08-12 09:07:45 --> Language Class Initialized
INFO - 2016-08-12 09:07:45 --> Loader Class Initialized
INFO - 2016-08-12 09:07:45 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:45 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:45 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:45 --> Email Class Initialized
INFO - 2016-08-12 09:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:45 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:45 --> Model Class Initialized
INFO - 2016-08-12 09:07:45 --> Controller Class Initialized
INFO - 2016-08-12 09:07:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:07:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:45 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:45 --> Total execution time: 0.4053
INFO - 2016-08-12 09:07:48 --> Config Class Initialized
INFO - 2016-08-12 09:07:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:07:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:07:48 --> Utf8 Class Initialized
INFO - 2016-08-12 09:07:48 --> URI Class Initialized
INFO - 2016-08-12 09:07:48 --> Router Class Initialized
INFO - 2016-08-12 09:07:48 --> Output Class Initialized
INFO - 2016-08-12 09:07:48 --> Security Class Initialized
DEBUG - 2016-08-12 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:07:48 --> Input Class Initialized
INFO - 2016-08-12 09:07:48 --> Language Class Initialized
INFO - 2016-08-12 09:07:48 --> Loader Class Initialized
INFO - 2016-08-12 09:07:48 --> Helper loaded: url_helper
INFO - 2016-08-12 09:07:48 --> Helper loaded: date_helper
INFO - 2016-08-12 09:07:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:07:48 --> Database Driver Class Initialized
INFO - 2016-08-12 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:07:48 --> Email Class Initialized
INFO - 2016-08-12 09:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:07:48 --> Pagination Class Initialized
INFO - 2016-08-12 09:07:48 --> Model Class Initialized
INFO - 2016-08-12 09:07:48 --> Controller Class Initialized
DEBUG - 2016-08-12 09:07:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:07:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:07:48 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:07:48 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:07:48 --> Model Class Initialized
INFO - 2016-08-12 09:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:07:48 --> Final output sent to browser
DEBUG - 2016-08-12 09:07:48 --> Total execution time: 0.5112
INFO - 2016-08-12 09:08:22 --> Config Class Initialized
INFO - 2016-08-12 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:08:22 --> Utf8 Class Initialized
INFO - 2016-08-12 09:08:22 --> URI Class Initialized
INFO - 2016-08-12 09:08:22 --> Router Class Initialized
INFO - 2016-08-12 09:08:22 --> Output Class Initialized
INFO - 2016-08-12 09:08:22 --> Security Class Initialized
DEBUG - 2016-08-12 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:08:22 --> Input Class Initialized
INFO - 2016-08-12 09:08:22 --> Language Class Initialized
INFO - 2016-08-12 09:08:22 --> Loader Class Initialized
INFO - 2016-08-12 09:08:22 --> Helper loaded: url_helper
INFO - 2016-08-12 09:08:22 --> Helper loaded: date_helper
INFO - 2016-08-12 09:08:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:08:22 --> Database Driver Class Initialized
INFO - 2016-08-12 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:08:22 --> Email Class Initialized
INFO - 2016-08-12 09:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:08:22 --> Pagination Class Initialized
INFO - 2016-08-12 09:08:22 --> Model Class Initialized
INFO - 2016-08-12 09:08:22 --> Controller Class Initialized
INFO - 2016-08-12 09:08:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:08:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:08:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:08:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:08:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:08:22 --> Final output sent to browser
DEBUG - 2016-08-12 09:08:22 --> Total execution time: 0.4058
INFO - 2016-08-12 09:08:25 --> Config Class Initialized
INFO - 2016-08-12 09:08:25 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:08:25 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:08:25 --> Utf8 Class Initialized
INFO - 2016-08-12 09:08:25 --> URI Class Initialized
INFO - 2016-08-12 09:08:25 --> Router Class Initialized
INFO - 2016-08-12 09:08:25 --> Output Class Initialized
INFO - 2016-08-12 09:08:25 --> Security Class Initialized
DEBUG - 2016-08-12 09:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:08:25 --> Input Class Initialized
INFO - 2016-08-12 09:08:25 --> Language Class Initialized
INFO - 2016-08-12 09:08:25 --> Loader Class Initialized
INFO - 2016-08-12 09:08:25 --> Helper loaded: url_helper
INFO - 2016-08-12 09:08:25 --> Helper loaded: date_helper
INFO - 2016-08-12 09:08:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:08:25 --> Database Driver Class Initialized
INFO - 2016-08-12 09:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:08:25 --> Email Class Initialized
INFO - 2016-08-12 09:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:08:25 --> Pagination Class Initialized
INFO - 2016-08-12 09:08:25 --> Model Class Initialized
INFO - 2016-08-12 09:08:25 --> Controller Class Initialized
DEBUG - 2016-08-12 09:08:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:08:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:08:25 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:08:25 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:25 --> Model Class Initialized
INFO - 2016-08-12 09:08:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:08:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:08:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:08:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:08:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:08:25 --> Final output sent to browser
DEBUG - 2016-08-12 09:08:25 --> Total execution time: 0.5289
INFO - 2016-08-12 09:08:28 --> Config Class Initialized
INFO - 2016-08-12 09:08:28 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:08:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:08:28 --> Utf8 Class Initialized
INFO - 2016-08-12 09:08:28 --> URI Class Initialized
INFO - 2016-08-12 09:08:28 --> Router Class Initialized
INFO - 2016-08-12 09:08:28 --> Output Class Initialized
INFO - 2016-08-12 09:08:28 --> Security Class Initialized
DEBUG - 2016-08-12 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:08:28 --> Input Class Initialized
INFO - 2016-08-12 09:08:28 --> Language Class Initialized
INFO - 2016-08-12 09:08:28 --> Loader Class Initialized
INFO - 2016-08-12 09:08:28 --> Helper loaded: url_helper
INFO - 2016-08-12 09:08:28 --> Helper loaded: date_helper
INFO - 2016-08-12 09:08:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:08:28 --> Database Driver Class Initialized
INFO - 2016-08-12 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:08:28 --> Email Class Initialized
INFO - 2016-08-12 09:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:08:28 --> Pagination Class Initialized
INFO - 2016-08-12 09:08:28 --> Model Class Initialized
INFO - 2016-08-12 09:08:28 --> Controller Class Initialized
DEBUG - 2016-08-12 09:08:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:08:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:08:28 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:08:28 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:28 --> Model Class Initialized
INFO - 2016-08-12 09:08:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:08:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:08:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:08:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-12 09:08:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:08:28 --> Final output sent to browser
DEBUG - 2016-08-12 09:08:28 --> Total execution time: 0.5783
INFO - 2016-08-12 09:08:31 --> Config Class Initialized
INFO - 2016-08-12 09:08:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:08:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:08:31 --> Utf8 Class Initialized
INFO - 2016-08-12 09:08:31 --> URI Class Initialized
INFO - 2016-08-12 09:08:31 --> Router Class Initialized
INFO - 2016-08-12 09:08:31 --> Output Class Initialized
INFO - 2016-08-12 09:08:31 --> Security Class Initialized
DEBUG - 2016-08-12 09:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:08:31 --> Input Class Initialized
INFO - 2016-08-12 09:08:31 --> Language Class Initialized
INFO - 2016-08-12 09:08:31 --> Loader Class Initialized
INFO - 2016-08-12 09:08:31 --> Helper loaded: url_helper
INFO - 2016-08-12 09:08:31 --> Helper loaded: date_helper
INFO - 2016-08-12 09:08:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:08:31 --> Database Driver Class Initialized
INFO - 2016-08-12 09:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:08:31 --> Email Class Initialized
INFO - 2016-08-12 09:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:08:31 --> Pagination Class Initialized
INFO - 2016-08-12 09:08:31 --> Model Class Initialized
INFO - 2016-08-12 09:08:31 --> Controller Class Initialized
DEBUG - 2016-08-12 09:08:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:08:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:08:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:08:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:08:31 --> Model Class Initialized
INFO - 2016-08-12 09:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:08:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:08:31 --> Final output sent to browser
DEBUG - 2016-08-12 09:08:31 --> Total execution time: 0.5415
INFO - 2016-08-12 09:09:41 --> Config Class Initialized
INFO - 2016-08-12 09:09:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:09:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:09:41 --> Utf8 Class Initialized
INFO - 2016-08-12 09:09:41 --> URI Class Initialized
INFO - 2016-08-12 09:09:41 --> Router Class Initialized
INFO - 2016-08-12 09:09:41 --> Output Class Initialized
INFO - 2016-08-12 09:09:41 --> Security Class Initialized
DEBUG - 2016-08-12 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:09:41 --> Input Class Initialized
INFO - 2016-08-12 09:09:41 --> Language Class Initialized
INFO - 2016-08-12 09:09:41 --> Loader Class Initialized
INFO - 2016-08-12 09:09:41 --> Helper loaded: url_helper
INFO - 2016-08-12 09:09:41 --> Helper loaded: date_helper
INFO - 2016-08-12 09:09:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:09:41 --> Database Driver Class Initialized
INFO - 2016-08-12 09:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:09:42 --> Email Class Initialized
INFO - 2016-08-12 09:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:09:42 --> Pagination Class Initialized
INFO - 2016-08-12 09:09:42 --> Model Class Initialized
INFO - 2016-08-12 09:09:42 --> Controller Class Initialized
DEBUG - 2016-08-12 09:09:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:09:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:09:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:09:42 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:09:42 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:09:42 --> Model Class Initialized
INFO - 2016-08-12 09:09:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:09:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:09:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:09:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:09:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:09:42 --> Final output sent to browser
DEBUG - 2016-08-12 09:09:42 --> Total execution time: 0.5368
INFO - 2016-08-12 09:09:46 --> Config Class Initialized
INFO - 2016-08-12 09:09:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:09:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:09:47 --> Utf8 Class Initialized
INFO - 2016-08-12 09:09:47 --> URI Class Initialized
INFO - 2016-08-12 09:09:47 --> Router Class Initialized
INFO - 2016-08-12 09:09:47 --> Output Class Initialized
INFO - 2016-08-12 09:09:47 --> Security Class Initialized
DEBUG - 2016-08-12 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:09:47 --> Input Class Initialized
INFO - 2016-08-12 09:09:47 --> Language Class Initialized
INFO - 2016-08-12 09:09:47 --> Loader Class Initialized
INFO - 2016-08-12 09:09:47 --> Helper loaded: url_helper
INFO - 2016-08-12 09:09:47 --> Helper loaded: date_helper
INFO - 2016-08-12 09:09:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:09:47 --> Database Driver Class Initialized
INFO - 2016-08-12 09:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:09:47 --> Email Class Initialized
INFO - 2016-08-12 09:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:09:47 --> Pagination Class Initialized
INFO - 2016-08-12 09:09:47 --> Model Class Initialized
INFO - 2016-08-12 09:09:47 --> Controller Class Initialized
INFO - 2016-08-12 09:09:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:09:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:09:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:09:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:09:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:09:47 --> Final output sent to browser
DEBUG - 2016-08-12 09:09:47 --> Total execution time: 0.4169
INFO - 2016-08-12 09:09:51 --> Config Class Initialized
INFO - 2016-08-12 09:09:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:09:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:09:51 --> Utf8 Class Initialized
INFO - 2016-08-12 09:09:51 --> URI Class Initialized
INFO - 2016-08-12 09:09:51 --> Router Class Initialized
INFO - 2016-08-12 09:09:51 --> Output Class Initialized
INFO - 2016-08-12 09:09:51 --> Security Class Initialized
DEBUG - 2016-08-12 09:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:09:51 --> Input Class Initialized
INFO - 2016-08-12 09:09:51 --> Language Class Initialized
INFO - 2016-08-12 09:09:51 --> Loader Class Initialized
INFO - 2016-08-12 09:09:51 --> Helper loaded: url_helper
INFO - 2016-08-12 09:09:51 --> Helper loaded: date_helper
INFO - 2016-08-12 09:09:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:09:51 --> Database Driver Class Initialized
INFO - 2016-08-12 09:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:09:51 --> Email Class Initialized
INFO - 2016-08-12 09:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:09:51 --> Pagination Class Initialized
INFO - 2016-08-12 09:09:51 --> Model Class Initialized
INFO - 2016-08-12 09:09:51 --> Controller Class Initialized
INFO - 2016-08-12 09:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:09:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:09:51 --> Final output sent to browser
DEBUG - 2016-08-12 09:09:51 --> Total execution time: 0.4500
INFO - 2016-08-12 09:10:24 --> Config Class Initialized
INFO - 2016-08-12 09:10:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:10:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:10:24 --> Utf8 Class Initialized
INFO - 2016-08-12 09:10:24 --> URI Class Initialized
INFO - 2016-08-12 09:10:24 --> Router Class Initialized
INFO - 2016-08-12 09:10:24 --> Output Class Initialized
INFO - 2016-08-12 09:10:24 --> Security Class Initialized
DEBUG - 2016-08-12 09:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:10:24 --> Input Class Initialized
INFO - 2016-08-12 09:10:24 --> Language Class Initialized
INFO - 2016-08-12 09:10:24 --> Loader Class Initialized
INFO - 2016-08-12 09:10:24 --> Helper loaded: url_helper
INFO - 2016-08-12 09:10:24 --> Helper loaded: date_helper
INFO - 2016-08-12 09:10:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:10:24 --> Database Driver Class Initialized
INFO - 2016-08-12 09:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:10:24 --> Email Class Initialized
INFO - 2016-08-12 09:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:10:24 --> Pagination Class Initialized
INFO - 2016-08-12 09:10:25 --> Model Class Initialized
INFO - 2016-08-12 09:10:25 --> Controller Class Initialized
DEBUG - 2016-08-12 09:10:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:10:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:10:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:10:25 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:10:25 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:10:25 --> Model Class Initialized
INFO - 2016-08-12 09:10:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:10:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:10:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:10:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:10:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:10:25 --> Final output sent to browser
DEBUG - 2016-08-12 09:10:25 --> Total execution time: 0.5825
INFO - 2016-08-12 09:11:04 --> Config Class Initialized
INFO - 2016-08-12 09:11:04 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:11:04 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:11:04 --> Utf8 Class Initialized
INFO - 2016-08-12 09:11:04 --> URI Class Initialized
INFO - 2016-08-12 09:11:04 --> Router Class Initialized
INFO - 2016-08-12 09:11:04 --> Output Class Initialized
INFO - 2016-08-12 09:11:04 --> Security Class Initialized
DEBUG - 2016-08-12 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:11:04 --> Input Class Initialized
INFO - 2016-08-12 09:11:04 --> Language Class Initialized
INFO - 2016-08-12 09:11:04 --> Loader Class Initialized
INFO - 2016-08-12 09:11:04 --> Helper loaded: url_helper
INFO - 2016-08-12 09:11:04 --> Helper loaded: date_helper
INFO - 2016-08-12 09:11:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:11:04 --> Database Driver Class Initialized
INFO - 2016-08-12 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:11:04 --> Email Class Initialized
INFO - 2016-08-12 09:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:11:04 --> Pagination Class Initialized
INFO - 2016-08-12 09:11:04 --> Model Class Initialized
INFO - 2016-08-12 09:11:05 --> Controller Class Initialized
DEBUG - 2016-08-12 09:11:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:11:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:11:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:11:05 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:11:05 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:11:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:11:05 --> Model Class Initialized
INFO - 2016-08-12 09:11:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:11:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:11:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:11:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:11:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:11:05 --> Final output sent to browser
DEBUG - 2016-08-12 09:11:05 --> Total execution time: 0.5423
INFO - 2016-08-12 09:11:51 --> Config Class Initialized
INFO - 2016-08-12 09:11:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:11:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:11:51 --> Utf8 Class Initialized
INFO - 2016-08-12 09:11:51 --> URI Class Initialized
INFO - 2016-08-12 09:11:51 --> Router Class Initialized
INFO - 2016-08-12 09:11:51 --> Output Class Initialized
INFO - 2016-08-12 09:11:51 --> Security Class Initialized
DEBUG - 2016-08-12 09:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:11:51 --> Input Class Initialized
INFO - 2016-08-12 09:11:51 --> Language Class Initialized
INFO - 2016-08-12 09:11:51 --> Loader Class Initialized
INFO - 2016-08-12 09:11:51 --> Helper loaded: url_helper
INFO - 2016-08-12 09:11:51 --> Helper loaded: date_helper
INFO - 2016-08-12 09:11:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:11:51 --> Database Driver Class Initialized
INFO - 2016-08-12 09:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:11:51 --> Email Class Initialized
INFO - 2016-08-12 09:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:11:51 --> Pagination Class Initialized
INFO - 2016-08-12 09:11:51 --> Model Class Initialized
INFO - 2016-08-12 09:11:51 --> Controller Class Initialized
DEBUG - 2016-08-12 09:11:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:11:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:11:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:11:51 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:11:51 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:11:51 --> Model Class Initialized
INFO - 2016-08-12 09:11:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:11:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:11:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:11:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:11:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:11:51 --> Final output sent to browser
DEBUG - 2016-08-12 09:11:51 --> Total execution time: 0.5319
INFO - 2016-08-12 09:12:38 --> Config Class Initialized
INFO - 2016-08-12 09:12:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:12:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:12:38 --> Utf8 Class Initialized
INFO - 2016-08-12 09:12:38 --> URI Class Initialized
INFO - 2016-08-12 09:12:38 --> Router Class Initialized
INFO - 2016-08-12 09:12:38 --> Output Class Initialized
INFO - 2016-08-12 09:12:38 --> Security Class Initialized
DEBUG - 2016-08-12 09:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:12:38 --> Input Class Initialized
INFO - 2016-08-12 09:12:38 --> Language Class Initialized
INFO - 2016-08-12 09:12:38 --> Loader Class Initialized
INFO - 2016-08-12 09:12:39 --> Helper loaded: url_helper
INFO - 2016-08-12 09:12:39 --> Helper loaded: date_helper
INFO - 2016-08-12 09:12:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:12:39 --> Database Driver Class Initialized
INFO - 2016-08-12 09:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:12:39 --> Email Class Initialized
INFO - 2016-08-12 09:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:12:39 --> Pagination Class Initialized
INFO - 2016-08-12 09:12:39 --> Model Class Initialized
INFO - 2016-08-12 09:12:39 --> Controller Class Initialized
DEBUG - 2016-08-12 09:12:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:12:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:12:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:12:39 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:12:39 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:12:39 --> Model Class Initialized
INFO - 2016-08-12 09:12:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:12:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:12:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:12:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:12:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:12:39 --> Final output sent to browser
DEBUG - 2016-08-12 09:12:39 --> Total execution time: 0.5611
INFO - 2016-08-12 09:13:11 --> Config Class Initialized
INFO - 2016-08-12 09:13:11 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:11 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:11 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:11 --> URI Class Initialized
INFO - 2016-08-12 09:13:11 --> Router Class Initialized
INFO - 2016-08-12 09:13:11 --> Output Class Initialized
INFO - 2016-08-12 09:13:11 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:11 --> Input Class Initialized
INFO - 2016-08-12 09:13:11 --> Language Class Initialized
INFO - 2016-08-12 09:13:11 --> Loader Class Initialized
INFO - 2016-08-12 09:13:11 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:11 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:11 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:11 --> Email Class Initialized
INFO - 2016-08-12 09:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:11 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:11 --> Model Class Initialized
INFO - 2016-08-12 09:13:11 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:11 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:11 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:11 --> Model Class Initialized
INFO - 2016-08-12 09:13:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:13:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:11 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:11 --> Total execution time: 0.5750
INFO - 2016-08-12 09:13:23 --> Config Class Initialized
INFO - 2016-08-12 09:13:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:23 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:23 --> URI Class Initialized
INFO - 2016-08-12 09:13:23 --> Router Class Initialized
INFO - 2016-08-12 09:13:23 --> Output Class Initialized
INFO - 2016-08-12 09:13:23 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:23 --> Input Class Initialized
INFO - 2016-08-12 09:13:23 --> Language Class Initialized
INFO - 2016-08-12 09:13:23 --> Loader Class Initialized
INFO - 2016-08-12 09:13:23 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:23 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:23 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:23 --> Email Class Initialized
INFO - 2016-08-12 09:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:23 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:23 --> Model Class Initialized
INFO - 2016-08-12 09:13:23 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:24 --> Config Class Initialized
INFO - 2016-08-12 09:13:24 --> Hooks Class Initialized
INFO - 2016-08-12 09:13:24 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:24 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:24 --> Utf8 Class Initialized
DEBUG - 2016-08-12 09:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:24 --> URI Class Initialized
INFO - 2016-08-12 09:13:24 --> Model Class Initialized
INFO - 2016-08-12 09:13:24 --> Router Class Initialized
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:24 --> Output Class Initialized
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:24 --> Security Class Initialized
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
DEBUG - 2016-08-12 09:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:24 --> Input Class Initialized
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:24 --> Final output sent to browser
INFO - 2016-08-12 09:13:24 --> Language Class Initialized
DEBUG - 2016-08-12 09:13:24 --> Total execution time: 0.5485
INFO - 2016-08-12 09:13:24 --> Loader Class Initialized
INFO - 2016-08-12 09:13:24 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:24 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:24 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:24 --> Email Class Initialized
INFO - 2016-08-12 09:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:24 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:24 --> Model Class Initialized
INFO - 2016-08-12 09:13:24 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:24 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:24 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:24 --> Model Class Initialized
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:13:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:24 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:24 --> Total execution time: 0.5413
INFO - 2016-08-12 09:13:30 --> Config Class Initialized
INFO - 2016-08-12 09:13:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:30 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:30 --> URI Class Initialized
INFO - 2016-08-12 09:13:30 --> Router Class Initialized
INFO - 2016-08-12 09:13:30 --> Output Class Initialized
INFO - 2016-08-12 09:13:30 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:31 --> Input Class Initialized
INFO - 2016-08-12 09:13:31 --> Language Class Initialized
INFO - 2016-08-12 09:13:31 --> Loader Class Initialized
INFO - 2016-08-12 09:13:31 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:31 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:31 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:31 --> Email Class Initialized
INFO - 2016-08-12 09:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:31 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:31 --> Model Class Initialized
INFO - 2016-08-12 09:13:31 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:31 --> Model Class Initialized
INFO - 2016-08-12 09:13:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:13:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:31 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:31 --> Total execution time: 0.5684
INFO - 2016-08-12 09:13:33 --> Config Class Initialized
INFO - 2016-08-12 09:13:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:33 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:33 --> URI Class Initialized
INFO - 2016-08-12 09:13:33 --> Router Class Initialized
INFO - 2016-08-12 09:13:33 --> Output Class Initialized
INFO - 2016-08-12 09:13:33 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:33 --> Input Class Initialized
INFO - 2016-08-12 09:13:34 --> Language Class Initialized
INFO - 2016-08-12 09:13:34 --> Loader Class Initialized
INFO - 2016-08-12 09:13:34 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:34 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:34 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:34 --> Email Class Initialized
INFO - 2016-08-12 09:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:34 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:34 --> Model Class Initialized
INFO - 2016-08-12 09:13:34 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:34 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:34 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:34 --> Model Class Initialized
INFO - 2016-08-12 09:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:34 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:34 --> Total execution time: 0.5534
INFO - 2016-08-12 09:13:36 --> Config Class Initialized
INFO - 2016-08-12 09:13:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:36 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:36 --> URI Class Initialized
INFO - 2016-08-12 09:13:36 --> Router Class Initialized
INFO - 2016-08-12 09:13:37 --> Output Class Initialized
INFO - 2016-08-12 09:13:37 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:37 --> Input Class Initialized
INFO - 2016-08-12 09:13:37 --> Language Class Initialized
INFO - 2016-08-12 09:13:37 --> Loader Class Initialized
INFO - 2016-08-12 09:13:37 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:37 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:37 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:37 --> Email Class Initialized
INFO - 2016-08-12 09:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:37 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:37 --> Model Class Initialized
INFO - 2016-08-12 09:13:37 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:37 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:37 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:37 --> Model Class Initialized
INFO - 2016-08-12 09:13:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:13:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:37 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:37 --> Total execution time: 0.5517
INFO - 2016-08-12 09:13:39 --> Config Class Initialized
INFO - 2016-08-12 09:13:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:39 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:39 --> URI Class Initialized
INFO - 2016-08-12 09:13:39 --> Router Class Initialized
INFO - 2016-08-12 09:13:39 --> Output Class Initialized
INFO - 2016-08-12 09:13:39 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:39 --> Input Class Initialized
INFO - 2016-08-12 09:13:39 --> Language Class Initialized
INFO - 2016-08-12 09:13:39 --> Loader Class Initialized
INFO - 2016-08-12 09:13:39 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:39 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:39 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:39 --> Email Class Initialized
INFO - 2016-08-12 09:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:39 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:39 --> Model Class Initialized
INFO - 2016-08-12 09:13:39 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:39 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:39 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:39 --> Model Class Initialized
INFO - 2016-08-12 09:13:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:13:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:40 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:40 --> Total execution time: 0.5975
INFO - 2016-08-12 09:13:51 --> Config Class Initialized
INFO - 2016-08-12 09:13:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:51 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:51 --> URI Class Initialized
INFO - 2016-08-12 09:13:51 --> Router Class Initialized
INFO - 2016-08-12 09:13:51 --> Output Class Initialized
INFO - 2016-08-12 09:13:51 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:52 --> Input Class Initialized
INFO - 2016-08-12 09:13:52 --> Language Class Initialized
INFO - 2016-08-12 09:13:52 --> Loader Class Initialized
INFO - 2016-08-12 09:13:52 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:52 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:52 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:52 --> Email Class Initialized
INFO - 2016-08-12 09:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:52 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:52 --> Model Class Initialized
INFO - 2016-08-12 09:13:52 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:52 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:52 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:52 --> Model Class Initialized
INFO - 2016-08-12 09:13:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:13:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:52 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:52 --> Total execution time: 0.5663
INFO - 2016-08-12 09:13:55 --> Config Class Initialized
INFO - 2016-08-12 09:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:13:55 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:13:55 --> Utf8 Class Initialized
INFO - 2016-08-12 09:13:55 --> URI Class Initialized
INFO - 2016-08-12 09:13:55 --> Router Class Initialized
INFO - 2016-08-12 09:13:55 --> Output Class Initialized
INFO - 2016-08-12 09:13:55 --> Security Class Initialized
DEBUG - 2016-08-12 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:13:56 --> Input Class Initialized
INFO - 2016-08-12 09:13:56 --> Language Class Initialized
INFO - 2016-08-12 09:13:56 --> Loader Class Initialized
INFO - 2016-08-12 09:13:56 --> Helper loaded: url_helper
INFO - 2016-08-12 09:13:56 --> Helper loaded: date_helper
INFO - 2016-08-12 09:13:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:13:56 --> Database Driver Class Initialized
INFO - 2016-08-12 09:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:13:56 --> Email Class Initialized
INFO - 2016-08-12 09:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:13:56 --> Pagination Class Initialized
INFO - 2016-08-12 09:13:56 --> Model Class Initialized
INFO - 2016-08-12 09:13:56 --> Controller Class Initialized
DEBUG - 2016-08-12 09:13:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:13:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:13:56 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:13:56 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:13:56 --> Model Class Initialized
INFO - 2016-08-12 09:13:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:13:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:13:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:13:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 09:13:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:13:56 --> Final output sent to browser
DEBUG - 2016-08-12 09:13:56 --> Total execution time: 0.5794
INFO - 2016-08-12 09:14:07 --> Config Class Initialized
INFO - 2016-08-12 09:14:07 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:14:07 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:14:07 --> Utf8 Class Initialized
INFO - 2016-08-12 09:14:07 --> URI Class Initialized
INFO - 2016-08-12 09:14:07 --> Router Class Initialized
INFO - 2016-08-12 09:14:07 --> Output Class Initialized
INFO - 2016-08-12 09:14:07 --> Security Class Initialized
DEBUG - 2016-08-12 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:14:07 --> Input Class Initialized
INFO - 2016-08-12 09:14:07 --> Language Class Initialized
INFO - 2016-08-12 09:14:07 --> Loader Class Initialized
INFO - 2016-08-12 09:14:07 --> Helper loaded: url_helper
INFO - 2016-08-12 09:14:07 --> Helper loaded: date_helper
INFO - 2016-08-12 09:14:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:14:07 --> Database Driver Class Initialized
INFO - 2016-08-12 09:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:14:07 --> Email Class Initialized
INFO - 2016-08-12 09:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:14:07 --> Pagination Class Initialized
INFO - 2016-08-12 09:14:07 --> Model Class Initialized
INFO - 2016-08-12 09:14:07 --> Controller Class Initialized
DEBUG - 2016-08-12 09:14:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:14:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:14:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:14:07 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:14:08 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:14:08 --> Model Class Initialized
INFO - 2016-08-12 09:14:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:14:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:14:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:14:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-12 09:14:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:14:08 --> Final output sent to browser
DEBUG - 2016-08-12 09:14:08 --> Total execution time: 0.5577
INFO - 2016-08-12 09:16:44 --> Config Class Initialized
INFO - 2016-08-12 09:16:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:16:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:16:44 --> Utf8 Class Initialized
INFO - 2016-08-12 09:16:44 --> URI Class Initialized
INFO - 2016-08-12 09:16:44 --> Router Class Initialized
INFO - 2016-08-12 09:16:44 --> Output Class Initialized
INFO - 2016-08-12 09:16:44 --> Security Class Initialized
DEBUG - 2016-08-12 09:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:16:44 --> Input Class Initialized
INFO - 2016-08-12 09:16:44 --> Language Class Initialized
INFO - 2016-08-12 09:16:44 --> Loader Class Initialized
INFO - 2016-08-12 09:16:44 --> Helper loaded: url_helper
INFO - 2016-08-12 09:16:44 --> Helper loaded: date_helper
INFO - 2016-08-12 09:16:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:16:44 --> Database Driver Class Initialized
INFO - 2016-08-12 09:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:16:44 --> Email Class Initialized
INFO - 2016-08-12 09:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:16:45 --> Pagination Class Initialized
INFO - 2016-08-12 09:16:45 --> Model Class Initialized
INFO - 2016-08-12 09:16:45 --> Controller Class Initialized
DEBUG - 2016-08-12 09:16:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:16:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:16:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:16:45 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:16:45 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:16:45 --> Model Class Initialized
INFO - 2016-08-12 09:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-12 09:16:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:16:45 --> Final output sent to browser
DEBUG - 2016-08-12 09:16:45 --> Total execution time: 0.5693
INFO - 2016-08-12 09:16:50 --> Config Class Initialized
INFO - 2016-08-12 09:16:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:16:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:16:50 --> Utf8 Class Initialized
INFO - 2016-08-12 09:16:50 --> URI Class Initialized
INFO - 2016-08-12 09:16:50 --> Router Class Initialized
INFO - 2016-08-12 09:16:50 --> Output Class Initialized
INFO - 2016-08-12 09:16:50 --> Security Class Initialized
DEBUG - 2016-08-12 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:16:50 --> Input Class Initialized
INFO - 2016-08-12 09:16:50 --> Language Class Initialized
INFO - 2016-08-12 09:16:50 --> Loader Class Initialized
INFO - 2016-08-12 09:16:50 --> Helper loaded: url_helper
INFO - 2016-08-12 09:16:50 --> Helper loaded: date_helper
INFO - 2016-08-12 09:16:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:16:50 --> Database Driver Class Initialized
INFO - 2016-08-12 09:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:16:50 --> Email Class Initialized
INFO - 2016-08-12 09:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:16:51 --> Pagination Class Initialized
INFO - 2016-08-12 09:16:51 --> Model Class Initialized
INFO - 2016-08-12 09:16:51 --> Controller Class Initialized
DEBUG - 2016-08-12 09:16:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:16:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:16:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:16:51 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:16:51 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:16:51 --> Model Class Initialized
INFO - 2016-08-12 09:16:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:16:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:16:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:16:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:16:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:16:51 --> Final output sent to browser
DEBUG - 2016-08-12 09:16:51 --> Total execution time: 0.5878
INFO - 2016-08-12 09:29:07 --> Config Class Initialized
INFO - 2016-08-12 09:29:07 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:29:07 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:29:07 --> Utf8 Class Initialized
INFO - 2016-08-12 09:29:07 --> URI Class Initialized
INFO - 2016-08-12 09:29:07 --> Router Class Initialized
INFO - 2016-08-12 09:29:07 --> Output Class Initialized
INFO - 2016-08-12 09:29:07 --> Security Class Initialized
DEBUG - 2016-08-12 09:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:29:07 --> Input Class Initialized
INFO - 2016-08-12 09:29:07 --> Language Class Initialized
INFO - 2016-08-12 09:29:07 --> Loader Class Initialized
INFO - 2016-08-12 09:29:07 --> Helper loaded: url_helper
INFO - 2016-08-12 09:29:07 --> Helper loaded: date_helper
INFO - 2016-08-12 09:29:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:29:07 --> Database Driver Class Initialized
INFO - 2016-08-12 09:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:29:07 --> Email Class Initialized
INFO - 2016-08-12 09:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:29:07 --> Pagination Class Initialized
INFO - 2016-08-12 09:29:07 --> Model Class Initialized
INFO - 2016-08-12 09:29:07 --> Controller Class Initialized
DEBUG - 2016-08-12 09:29:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:29:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:29:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:29:07 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:29:07 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:29:07 --> Model Class Initialized
INFO - 2016-08-12 09:29:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:29:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:29:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:29:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:29:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:29:07 --> Final output sent to browser
DEBUG - 2016-08-12 09:29:07 --> Total execution time: 0.6353
INFO - 2016-08-12 09:30:21 --> Config Class Initialized
INFO - 2016-08-12 09:30:21 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:30:21 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:30:21 --> Utf8 Class Initialized
INFO - 2016-08-12 09:30:21 --> URI Class Initialized
INFO - 2016-08-12 09:30:21 --> Router Class Initialized
INFO - 2016-08-12 09:30:21 --> Output Class Initialized
INFO - 2016-08-12 09:30:21 --> Security Class Initialized
DEBUG - 2016-08-12 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:30:21 --> Input Class Initialized
INFO - 2016-08-12 09:30:21 --> Language Class Initialized
INFO - 2016-08-12 09:30:21 --> Loader Class Initialized
INFO - 2016-08-12 09:30:21 --> Helper loaded: url_helper
INFO - 2016-08-12 09:30:21 --> Helper loaded: date_helper
INFO - 2016-08-12 09:30:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:30:21 --> Database Driver Class Initialized
INFO - 2016-08-12 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:30:21 --> Email Class Initialized
INFO - 2016-08-12 09:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:30:21 --> Pagination Class Initialized
INFO - 2016-08-12 09:30:21 --> Model Class Initialized
INFO - 2016-08-12 09:30:21 --> Controller Class Initialized
DEBUG - 2016-08-12 09:30:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:30:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:30:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:30:21 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:30:21 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:30:22 --> Model Class Initialized
INFO - 2016-08-12 09:30:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:30:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:30:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:30:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:30:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:30:22 --> Final output sent to browser
DEBUG - 2016-08-12 09:30:22 --> Total execution time: 0.6954
INFO - 2016-08-12 09:31:38 --> Config Class Initialized
INFO - 2016-08-12 09:31:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:31:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:31:38 --> Utf8 Class Initialized
INFO - 2016-08-12 09:31:38 --> URI Class Initialized
INFO - 2016-08-12 09:31:38 --> Router Class Initialized
INFO - 2016-08-12 09:31:38 --> Output Class Initialized
INFO - 2016-08-12 09:31:38 --> Security Class Initialized
DEBUG - 2016-08-12 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:31:38 --> Input Class Initialized
INFO - 2016-08-12 09:31:38 --> Language Class Initialized
INFO - 2016-08-12 09:31:38 --> Loader Class Initialized
INFO - 2016-08-12 09:31:38 --> Helper loaded: url_helper
INFO - 2016-08-12 09:31:38 --> Helper loaded: date_helper
INFO - 2016-08-12 09:31:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:31:38 --> Database Driver Class Initialized
INFO - 2016-08-12 09:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:31:38 --> Email Class Initialized
INFO - 2016-08-12 09:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:31:38 --> Pagination Class Initialized
INFO - 2016-08-12 09:31:38 --> Model Class Initialized
INFO - 2016-08-12 09:31:38 --> Controller Class Initialized
DEBUG - 2016-08-12 09:31:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:31:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:31:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:31:39 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:31:39 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:31:39 --> Model Class Initialized
INFO - 2016-08-12 09:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:31:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:31:39 --> Final output sent to browser
DEBUG - 2016-08-12 09:31:39 --> Total execution time: 0.6535
INFO - 2016-08-12 09:31:41 --> Config Class Initialized
INFO - 2016-08-12 09:31:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:31:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:31:41 --> Utf8 Class Initialized
INFO - 2016-08-12 09:31:41 --> URI Class Initialized
INFO - 2016-08-12 09:31:41 --> Router Class Initialized
INFO - 2016-08-12 09:31:41 --> Output Class Initialized
INFO - 2016-08-12 09:31:41 --> Security Class Initialized
DEBUG - 2016-08-12 09:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:31:41 --> Input Class Initialized
INFO - 2016-08-12 09:31:41 --> Language Class Initialized
ERROR - 2016-08-12 09:31:41 --> 404 Page Not Found: Fitur/detai_buku_tamu
INFO - 2016-08-12 09:31:57 --> Config Class Initialized
INFO - 2016-08-12 09:31:57 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:31:57 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:31:57 --> Utf8 Class Initialized
INFO - 2016-08-12 09:31:57 --> URI Class Initialized
INFO - 2016-08-12 09:31:57 --> Router Class Initialized
INFO - 2016-08-12 09:31:57 --> Output Class Initialized
INFO - 2016-08-12 09:31:57 --> Security Class Initialized
DEBUG - 2016-08-12 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:31:58 --> Input Class Initialized
INFO - 2016-08-12 09:31:58 --> Language Class Initialized
INFO - 2016-08-12 09:31:58 --> Loader Class Initialized
INFO - 2016-08-12 09:31:58 --> Helper loaded: url_helper
INFO - 2016-08-12 09:31:58 --> Helper loaded: date_helper
INFO - 2016-08-12 09:31:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:31:58 --> Database Driver Class Initialized
INFO - 2016-08-12 09:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:31:58 --> Email Class Initialized
INFO - 2016-08-12 09:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:31:58 --> Pagination Class Initialized
INFO - 2016-08-12 09:31:58 --> Model Class Initialized
INFO - 2016-08-12 09:31:58 --> Controller Class Initialized
DEBUG - 2016-08-12 09:31:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:31:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:31:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:31:58 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:31:58 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:31:58 --> Model Class Initialized
INFO - 2016-08-12 09:31:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:31:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:31:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:31:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:31:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:31:58 --> Final output sent to browser
DEBUG - 2016-08-12 09:31:58 --> Total execution time: 0.6017
INFO - 2016-08-12 09:31:59 --> Config Class Initialized
INFO - 2016-08-12 09:31:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:31:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:31:59 --> Utf8 Class Initialized
INFO - 2016-08-12 09:31:59 --> URI Class Initialized
INFO - 2016-08-12 09:31:59 --> Router Class Initialized
INFO - 2016-08-12 09:31:59 --> Output Class Initialized
INFO - 2016-08-12 09:31:59 --> Security Class Initialized
DEBUG - 2016-08-12 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:32:00 --> Input Class Initialized
INFO - 2016-08-12 09:32:00 --> Language Class Initialized
INFO - 2016-08-12 09:32:00 --> Loader Class Initialized
INFO - 2016-08-12 09:32:00 --> Helper loaded: url_helper
INFO - 2016-08-12 09:32:00 --> Helper loaded: date_helper
INFO - 2016-08-12 09:32:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:32:00 --> Database Driver Class Initialized
INFO - 2016-08-12 09:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:32:00 --> Email Class Initialized
INFO - 2016-08-12 09:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:32:00 --> Pagination Class Initialized
INFO - 2016-08-12 09:32:00 --> Model Class Initialized
INFO - 2016-08-12 09:32:00 --> Controller Class Initialized
DEBUG - 2016-08-12 09:32:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:32:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:32:00 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:32:00 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:32:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:00 --> Model Class Initialized
INFO - 2016-08-12 09:32:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:32:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:32:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:32:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:32:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:32:00 --> Final output sent to browser
DEBUG - 2016-08-12 09:32:00 --> Total execution time: 0.6337
INFO - 2016-08-12 09:32:02 --> Config Class Initialized
INFO - 2016-08-12 09:32:02 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:32:02 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:32:02 --> Utf8 Class Initialized
INFO - 2016-08-12 09:32:02 --> URI Class Initialized
INFO - 2016-08-12 09:32:02 --> Router Class Initialized
INFO - 2016-08-12 09:32:02 --> Output Class Initialized
INFO - 2016-08-12 09:32:02 --> Security Class Initialized
DEBUG - 2016-08-12 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:32:02 --> Input Class Initialized
INFO - 2016-08-12 09:32:02 --> Language Class Initialized
INFO - 2016-08-12 09:32:02 --> Loader Class Initialized
INFO - 2016-08-12 09:32:02 --> Helper loaded: url_helper
INFO - 2016-08-12 09:32:02 --> Helper loaded: date_helper
INFO - 2016-08-12 09:32:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:32:02 --> Database Driver Class Initialized
INFO - 2016-08-12 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:32:02 --> Email Class Initialized
INFO - 2016-08-12 09:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:32:02 --> Pagination Class Initialized
INFO - 2016-08-12 09:32:02 --> Model Class Initialized
INFO - 2016-08-12 09:32:02 --> Controller Class Initialized
DEBUG - 2016-08-12 09:32:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:32:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:32:02 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:32:02 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:02 --> Model Class Initialized
INFO - 2016-08-12 09:32:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:32:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:32:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:32:42 --> Config Class Initialized
INFO - 2016-08-12 09:32:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:32:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:32:42 --> Utf8 Class Initialized
INFO - 2016-08-12 09:32:42 --> URI Class Initialized
INFO - 2016-08-12 09:32:42 --> Router Class Initialized
INFO - 2016-08-12 09:32:42 --> Output Class Initialized
INFO - 2016-08-12 09:32:42 --> Security Class Initialized
DEBUG - 2016-08-12 09:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:32:42 --> Input Class Initialized
INFO - 2016-08-12 09:32:42 --> Language Class Initialized
INFO - 2016-08-12 09:32:42 --> Loader Class Initialized
INFO - 2016-08-12 09:32:42 --> Helper loaded: url_helper
INFO - 2016-08-12 09:32:42 --> Helper loaded: date_helper
INFO - 2016-08-12 09:32:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:32:42 --> Database Driver Class Initialized
INFO - 2016-08-12 09:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:32:42 --> Email Class Initialized
INFO - 2016-08-12 09:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:32:42 --> Pagination Class Initialized
INFO - 2016-08-12 09:32:42 --> Model Class Initialized
INFO - 2016-08-12 09:32:42 --> Controller Class Initialized
DEBUG - 2016-08-12 09:32:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:32:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:32:42 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:32:42 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:32:42 --> Model Class Initialized
INFO - 2016-08-12 09:32:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:32:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:32:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-12 09:32:43 --> Severity: Notice --> Undefined variable: kategori D:\xampp\htdocs\aqiqahsehati\application\views\admin\buku_tamu\detail_buku_tamu.php 26
ERROR - 2016-08-12 09:32:43 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\buku_tamu\detail_buku_tamu.php 26
INFO - 2016-08-12 09:36:06 --> Config Class Initialized
INFO - 2016-08-12 09:36:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:36:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:36:06 --> Utf8 Class Initialized
INFO - 2016-08-12 09:36:06 --> URI Class Initialized
INFO - 2016-08-12 09:36:06 --> Router Class Initialized
INFO - 2016-08-12 09:36:06 --> Output Class Initialized
INFO - 2016-08-12 09:36:06 --> Security Class Initialized
DEBUG - 2016-08-12 09:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:36:06 --> Input Class Initialized
INFO - 2016-08-12 09:36:06 --> Language Class Initialized
INFO - 2016-08-12 09:36:06 --> Loader Class Initialized
INFO - 2016-08-12 09:36:06 --> Helper loaded: url_helper
INFO - 2016-08-12 09:36:06 --> Helper loaded: date_helper
INFO - 2016-08-12 09:36:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:36:06 --> Database Driver Class Initialized
INFO - 2016-08-12 09:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:36:06 --> Email Class Initialized
INFO - 2016-08-12 09:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:36:06 --> Pagination Class Initialized
INFO - 2016-08-12 09:36:06 --> Model Class Initialized
INFO - 2016-08-12 09:36:06 --> Controller Class Initialized
DEBUG - 2016-08-12 09:36:07 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:36:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:36:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:36:07 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:36:07 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:36:07 --> Model Class Initialized
INFO - 2016-08-12 09:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:36:07 --> Final output sent to browser
DEBUG - 2016-08-12 09:36:07 --> Total execution time: 0.6407
INFO - 2016-08-12 09:36:44 --> Config Class Initialized
INFO - 2016-08-12 09:36:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:36:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:36:44 --> Utf8 Class Initialized
INFO - 2016-08-12 09:36:44 --> URI Class Initialized
INFO - 2016-08-12 09:36:44 --> Router Class Initialized
INFO - 2016-08-12 09:36:44 --> Output Class Initialized
INFO - 2016-08-12 09:36:44 --> Security Class Initialized
DEBUG - 2016-08-12 09:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:36:44 --> Input Class Initialized
INFO - 2016-08-12 09:36:44 --> Language Class Initialized
INFO - 2016-08-12 09:36:44 --> Loader Class Initialized
INFO - 2016-08-12 09:36:44 --> Helper loaded: url_helper
INFO - 2016-08-12 09:36:44 --> Helper loaded: date_helper
INFO - 2016-08-12 09:36:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:36:44 --> Database Driver Class Initialized
INFO - 2016-08-12 09:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:36:44 --> Email Class Initialized
INFO - 2016-08-12 09:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:36:44 --> Pagination Class Initialized
INFO - 2016-08-12 09:36:44 --> Model Class Initialized
INFO - 2016-08-12 09:36:44 --> Controller Class Initialized
DEBUG - 2016-08-12 09:36:44 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:36:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:36:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:36:44 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:36:44 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:36:44 --> Model Class Initialized
INFO - 2016-08-12 09:36:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:36:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:36:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:36:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:36:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:36:44 --> Final output sent to browser
DEBUG - 2016-08-12 09:36:44 --> Total execution time: 0.6720
INFO - 2016-08-12 09:38:14 --> Config Class Initialized
INFO - 2016-08-12 09:38:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:38:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:38:14 --> Utf8 Class Initialized
INFO - 2016-08-12 09:38:14 --> URI Class Initialized
INFO - 2016-08-12 09:38:14 --> Router Class Initialized
INFO - 2016-08-12 09:38:14 --> Output Class Initialized
INFO - 2016-08-12 09:38:14 --> Security Class Initialized
DEBUG - 2016-08-12 09:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:38:14 --> Input Class Initialized
INFO - 2016-08-12 09:38:14 --> Language Class Initialized
INFO - 2016-08-12 09:38:14 --> Loader Class Initialized
INFO - 2016-08-12 09:38:14 --> Helper loaded: url_helper
INFO - 2016-08-12 09:38:14 --> Helper loaded: date_helper
INFO - 2016-08-12 09:38:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:38:14 --> Database Driver Class Initialized
INFO - 2016-08-12 09:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:38:14 --> Email Class Initialized
INFO - 2016-08-12 09:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:38:14 --> Pagination Class Initialized
INFO - 2016-08-12 09:38:14 --> Model Class Initialized
INFO - 2016-08-12 09:38:14 --> Controller Class Initialized
DEBUG - 2016-08-12 09:38:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:38:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:38:14 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:38:14 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:14 --> Model Class Initialized
INFO - 2016-08-12 09:38:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:38:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:38:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:38:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:38:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:38:14 --> Final output sent to browser
DEBUG - 2016-08-12 09:38:14 --> Total execution time: 0.6116
INFO - 2016-08-12 09:38:35 --> Config Class Initialized
INFO - 2016-08-12 09:38:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:38:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:38:35 --> Utf8 Class Initialized
INFO - 2016-08-12 09:38:35 --> URI Class Initialized
INFO - 2016-08-12 09:38:35 --> Router Class Initialized
INFO - 2016-08-12 09:38:35 --> Output Class Initialized
INFO - 2016-08-12 09:38:35 --> Security Class Initialized
DEBUG - 2016-08-12 09:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:38:35 --> Input Class Initialized
INFO - 2016-08-12 09:38:35 --> Language Class Initialized
INFO - 2016-08-12 09:38:35 --> Loader Class Initialized
INFO - 2016-08-12 09:38:35 --> Helper loaded: url_helper
INFO - 2016-08-12 09:38:35 --> Helper loaded: date_helper
INFO - 2016-08-12 09:38:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:38:35 --> Database Driver Class Initialized
INFO - 2016-08-12 09:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:38:35 --> Email Class Initialized
INFO - 2016-08-12 09:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:38:35 --> Pagination Class Initialized
INFO - 2016-08-12 09:38:35 --> Model Class Initialized
INFO - 2016-08-12 09:38:35 --> Controller Class Initialized
DEBUG - 2016-08-12 09:38:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:38:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:38:35 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:38:35 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:35 --> Model Class Initialized
INFO - 2016-08-12 09:38:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:38:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:38:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:38:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:38:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:38:35 --> Final output sent to browser
DEBUG - 2016-08-12 09:38:35 --> Total execution time: 0.6222
INFO - 2016-08-12 09:38:47 --> Config Class Initialized
INFO - 2016-08-12 09:38:47 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:38:47 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:38:47 --> Utf8 Class Initialized
INFO - 2016-08-12 09:38:47 --> URI Class Initialized
INFO - 2016-08-12 09:38:47 --> Router Class Initialized
INFO - 2016-08-12 09:38:47 --> Output Class Initialized
INFO - 2016-08-12 09:38:47 --> Security Class Initialized
DEBUG - 2016-08-12 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:38:47 --> Input Class Initialized
INFO - 2016-08-12 09:38:47 --> Language Class Initialized
INFO - 2016-08-12 09:38:47 --> Loader Class Initialized
INFO - 2016-08-12 09:38:47 --> Helper loaded: url_helper
INFO - 2016-08-12 09:38:47 --> Helper loaded: date_helper
INFO - 2016-08-12 09:38:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:38:48 --> Database Driver Class Initialized
INFO - 2016-08-12 09:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:38:48 --> Email Class Initialized
INFO - 2016-08-12 09:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:38:48 --> Pagination Class Initialized
INFO - 2016-08-12 09:38:48 --> Model Class Initialized
INFO - 2016-08-12 09:38:48 --> Controller Class Initialized
DEBUG - 2016-08-12 09:38:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:38:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:38:48 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:38:48 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:38:48 --> Model Class Initialized
INFO - 2016-08-12 09:38:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:38:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:38:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:38:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:38:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:38:48 --> Final output sent to browser
DEBUG - 2016-08-12 09:38:48 --> Total execution time: 1.3098
INFO - 2016-08-12 09:39:08 --> Config Class Initialized
INFO - 2016-08-12 09:39:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:39:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:39:08 --> Utf8 Class Initialized
INFO - 2016-08-12 09:39:08 --> URI Class Initialized
INFO - 2016-08-12 09:39:08 --> Router Class Initialized
INFO - 2016-08-12 09:39:08 --> Output Class Initialized
INFO - 2016-08-12 09:39:08 --> Security Class Initialized
DEBUG - 2016-08-12 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:39:08 --> Input Class Initialized
INFO - 2016-08-12 09:39:08 --> Language Class Initialized
INFO - 2016-08-12 09:39:08 --> Loader Class Initialized
INFO - 2016-08-12 09:39:09 --> Helper loaded: url_helper
INFO - 2016-08-12 09:39:09 --> Helper loaded: date_helper
INFO - 2016-08-12 09:39:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:39:09 --> Database Driver Class Initialized
INFO - 2016-08-12 09:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:39:09 --> Email Class Initialized
INFO - 2016-08-12 09:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:39:09 --> Pagination Class Initialized
INFO - 2016-08-12 09:39:09 --> Model Class Initialized
INFO - 2016-08-12 09:39:09 --> Controller Class Initialized
DEBUG - 2016-08-12 09:39:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:39:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:39:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:39:09 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:39:09 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:39:09 --> Model Class Initialized
INFO - 2016-08-12 09:39:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:39:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:39:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:39:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:39:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:39:09 --> Final output sent to browser
DEBUG - 2016-08-12 09:39:09 --> Total execution time: 0.6580
INFO - 2016-08-12 09:39:39 --> Config Class Initialized
INFO - 2016-08-12 09:39:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:39:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:39:39 --> Utf8 Class Initialized
INFO - 2016-08-12 09:39:39 --> URI Class Initialized
INFO - 2016-08-12 09:39:39 --> Router Class Initialized
INFO - 2016-08-12 09:39:39 --> Output Class Initialized
INFO - 2016-08-12 09:39:39 --> Security Class Initialized
DEBUG - 2016-08-12 09:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:39:39 --> Input Class Initialized
INFO - 2016-08-12 09:39:39 --> Language Class Initialized
INFO - 2016-08-12 09:39:40 --> Loader Class Initialized
INFO - 2016-08-12 09:39:40 --> Helper loaded: url_helper
INFO - 2016-08-12 09:39:40 --> Helper loaded: date_helper
INFO - 2016-08-12 09:39:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:39:40 --> Database Driver Class Initialized
INFO - 2016-08-12 09:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:39:40 --> Email Class Initialized
INFO - 2016-08-12 09:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:39:40 --> Pagination Class Initialized
INFO - 2016-08-12 09:39:40 --> Model Class Initialized
INFO - 2016-08-12 09:39:40 --> Controller Class Initialized
DEBUG - 2016-08-12 09:39:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:39:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:39:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:39:40 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:39:40 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:39:40 --> Model Class Initialized
INFO - 2016-08-12 09:39:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:39:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:39:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:39:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:39:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:39:40 --> Final output sent to browser
DEBUG - 2016-08-12 09:39:40 --> Total execution time: 0.6356
INFO - 2016-08-12 09:41:16 --> Config Class Initialized
INFO - 2016-08-12 09:41:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:41:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:41:16 --> Utf8 Class Initialized
INFO - 2016-08-12 09:41:16 --> URI Class Initialized
INFO - 2016-08-12 09:41:16 --> Router Class Initialized
INFO - 2016-08-12 09:41:16 --> Output Class Initialized
INFO - 2016-08-12 09:41:17 --> Security Class Initialized
DEBUG - 2016-08-12 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:41:17 --> Input Class Initialized
INFO - 2016-08-12 09:41:17 --> Language Class Initialized
INFO - 2016-08-12 09:41:17 --> Loader Class Initialized
INFO - 2016-08-12 09:41:17 --> Helper loaded: url_helper
INFO - 2016-08-12 09:41:17 --> Helper loaded: date_helper
INFO - 2016-08-12 09:41:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:41:17 --> Database Driver Class Initialized
INFO - 2016-08-12 09:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:41:17 --> Email Class Initialized
INFO - 2016-08-12 09:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:41:17 --> Pagination Class Initialized
INFO - 2016-08-12 09:41:17 --> Model Class Initialized
INFO - 2016-08-12 09:41:17 --> Controller Class Initialized
DEBUG - 2016-08-12 09:41:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:41:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:41:17 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:41:17 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:17 --> Model Class Initialized
INFO - 2016-08-12 09:41:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:41:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:41:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:41:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:41:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:41:17 --> Final output sent to browser
DEBUG - 2016-08-12 09:41:17 --> Total execution time: 0.6068
INFO - 2016-08-12 09:41:20 --> Config Class Initialized
INFO - 2016-08-12 09:41:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:41:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:41:20 --> Utf8 Class Initialized
INFO - 2016-08-12 09:41:23 --> Config Class Initialized
INFO - 2016-08-12 09:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:41:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:41:23 --> Utf8 Class Initialized
INFO - 2016-08-12 09:41:23 --> URI Class Initialized
INFO - 2016-08-12 09:41:23 --> Router Class Initialized
INFO - 2016-08-12 09:41:23 --> Output Class Initialized
INFO - 2016-08-12 09:41:23 --> Security Class Initialized
DEBUG - 2016-08-12 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:41:23 --> Input Class Initialized
INFO - 2016-08-12 09:41:23 --> Language Class Initialized
INFO - 2016-08-12 09:41:23 --> Loader Class Initialized
INFO - 2016-08-12 09:41:23 --> Helper loaded: url_helper
INFO - 2016-08-12 09:41:23 --> Helper loaded: date_helper
INFO - 2016-08-12 09:41:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:41:24 --> Database Driver Class Initialized
INFO - 2016-08-12 09:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:41:24 --> Email Class Initialized
INFO - 2016-08-12 09:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:41:24 --> Pagination Class Initialized
INFO - 2016-08-12 09:41:24 --> Model Class Initialized
INFO - 2016-08-12 09:41:24 --> Controller Class Initialized
DEBUG - 2016-08-12 09:41:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:41:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:41:24 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:41:24 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:24 --> Model Class Initialized
INFO - 2016-08-12 09:41:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:41:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:41:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:41:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:41:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:41:24 --> Final output sent to browser
DEBUG - 2016-08-12 09:41:24 --> Total execution time: 0.6842
INFO - 2016-08-12 09:41:39 --> Config Class Initialized
INFO - 2016-08-12 09:41:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:41:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:41:39 --> Utf8 Class Initialized
INFO - 2016-08-12 09:41:39 --> URI Class Initialized
INFO - 2016-08-12 09:41:39 --> Router Class Initialized
INFO - 2016-08-12 09:41:39 --> Output Class Initialized
INFO - 2016-08-12 09:41:39 --> Security Class Initialized
DEBUG - 2016-08-12 09:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:41:39 --> Input Class Initialized
INFO - 2016-08-12 09:41:39 --> Language Class Initialized
INFO - 2016-08-12 09:41:39 --> Loader Class Initialized
INFO - 2016-08-12 09:41:39 --> Helper loaded: url_helper
INFO - 2016-08-12 09:41:40 --> Helper loaded: date_helper
INFO - 2016-08-12 09:41:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:41:40 --> Database Driver Class Initialized
INFO - 2016-08-12 09:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:41:40 --> Email Class Initialized
INFO - 2016-08-12 09:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:41:40 --> Pagination Class Initialized
INFO - 2016-08-12 09:41:40 --> Model Class Initialized
INFO - 2016-08-12 09:41:40 --> Controller Class Initialized
DEBUG - 2016-08-12 09:41:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:41:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:41:40 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:41:40 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:41:40 --> Model Class Initialized
INFO - 2016-08-12 09:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:41:40 --> Final output sent to browser
DEBUG - 2016-08-12 09:41:40 --> Total execution time: 0.7254
INFO - 2016-08-12 09:42:30 --> Config Class Initialized
INFO - 2016-08-12 09:42:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:42:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:42:30 --> Utf8 Class Initialized
INFO - 2016-08-12 09:42:30 --> URI Class Initialized
INFO - 2016-08-12 09:42:30 --> Router Class Initialized
INFO - 2016-08-12 09:42:30 --> Output Class Initialized
INFO - 2016-08-12 09:42:30 --> Security Class Initialized
DEBUG - 2016-08-12 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:42:30 --> Input Class Initialized
INFO - 2016-08-12 09:42:30 --> Language Class Initialized
INFO - 2016-08-12 09:42:30 --> Loader Class Initialized
INFO - 2016-08-12 09:42:30 --> Helper loaded: url_helper
INFO - 2016-08-12 09:42:30 --> Helper loaded: date_helper
INFO - 2016-08-12 09:42:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:42:31 --> Database Driver Class Initialized
INFO - 2016-08-12 09:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:42:31 --> Email Class Initialized
INFO - 2016-08-12 09:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:42:31 --> Pagination Class Initialized
INFO - 2016-08-12 09:42:31 --> Model Class Initialized
INFO - 2016-08-12 09:42:31 --> Controller Class Initialized
DEBUG - 2016-08-12 09:42:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:42:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:42:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:42:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:42:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:42:31 --> Model Class Initialized
INFO - 2016-08-12 09:42:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:42:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:42:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:42:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:42:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:42:31 --> Final output sent to browser
DEBUG - 2016-08-12 09:42:31 --> Total execution time: 0.7859
INFO - 2016-08-12 09:42:46 --> Config Class Initialized
INFO - 2016-08-12 09:42:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:42:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:42:46 --> Utf8 Class Initialized
INFO - 2016-08-12 09:42:46 --> URI Class Initialized
INFO - 2016-08-12 09:42:46 --> Router Class Initialized
INFO - 2016-08-12 09:42:46 --> Output Class Initialized
INFO - 2016-08-12 09:42:46 --> Security Class Initialized
DEBUG - 2016-08-12 09:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:42:46 --> Input Class Initialized
INFO - 2016-08-12 09:42:46 --> Language Class Initialized
INFO - 2016-08-12 09:42:46 --> Loader Class Initialized
INFO - 2016-08-12 09:42:46 --> Helper loaded: url_helper
INFO - 2016-08-12 09:42:46 --> Helper loaded: date_helper
INFO - 2016-08-12 09:42:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:42:46 --> Database Driver Class Initialized
INFO - 2016-08-12 09:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:42:46 --> Email Class Initialized
INFO - 2016-08-12 09:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:42:46 --> Pagination Class Initialized
INFO - 2016-08-12 09:42:46 --> Model Class Initialized
INFO - 2016-08-12 09:42:46 --> Controller Class Initialized
DEBUG - 2016-08-12 09:42:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:42:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:42:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:42:46 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:42:46 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:42:46 --> Model Class Initialized
INFO - 2016-08-12 09:42:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:42:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:42:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:42:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:42:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:42:46 --> Final output sent to browser
DEBUG - 2016-08-12 09:42:46 --> Total execution time: 0.6386
INFO - 2016-08-12 09:43:48 --> Config Class Initialized
INFO - 2016-08-12 09:43:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:43:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:43:48 --> Utf8 Class Initialized
INFO - 2016-08-12 09:43:48 --> URI Class Initialized
INFO - 2016-08-12 09:43:48 --> Router Class Initialized
INFO - 2016-08-12 09:43:48 --> Output Class Initialized
INFO - 2016-08-12 09:43:49 --> Security Class Initialized
DEBUG - 2016-08-12 09:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:43:49 --> Input Class Initialized
INFO - 2016-08-12 09:43:49 --> Language Class Initialized
INFO - 2016-08-12 09:43:49 --> Loader Class Initialized
INFO - 2016-08-12 09:43:49 --> Helper loaded: url_helper
INFO - 2016-08-12 09:43:49 --> Helper loaded: date_helper
INFO - 2016-08-12 09:43:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:43:49 --> Database Driver Class Initialized
INFO - 2016-08-12 09:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:43:49 --> Email Class Initialized
INFO - 2016-08-12 09:43:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:43:49 --> Pagination Class Initialized
INFO - 2016-08-12 09:43:49 --> Model Class Initialized
INFO - 2016-08-12 09:43:49 --> Controller Class Initialized
DEBUG - 2016-08-12 09:43:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:43:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:43:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:43:49 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:43:49 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:43:49 --> Model Class Initialized
INFO - 2016-08-12 09:43:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:43:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:43:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:43:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-12 09:43:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:43:49 --> Final output sent to browser
DEBUG - 2016-08-12 09:43:49 --> Total execution time: 0.6298
INFO - 2016-08-12 09:43:50 --> Config Class Initialized
INFO - 2016-08-12 09:43:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:43:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:43:50 --> Utf8 Class Initialized
INFO - 2016-08-12 09:43:51 --> URI Class Initialized
INFO - 2016-08-12 09:43:51 --> Router Class Initialized
INFO - 2016-08-12 09:43:51 --> Output Class Initialized
INFO - 2016-08-12 09:43:51 --> Security Class Initialized
DEBUG - 2016-08-12 09:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:43:51 --> Input Class Initialized
INFO - 2016-08-12 09:43:51 --> Language Class Initialized
INFO - 2016-08-12 09:43:51 --> Loader Class Initialized
INFO - 2016-08-12 09:43:51 --> Helper loaded: url_helper
INFO - 2016-08-12 09:43:51 --> Helper loaded: date_helper
INFO - 2016-08-12 09:43:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:43:51 --> Database Driver Class Initialized
INFO - 2016-08-12 09:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:43:51 --> Email Class Initialized
INFO - 2016-08-12 09:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:43:51 --> Pagination Class Initialized
INFO - 2016-08-12 09:43:51 --> Model Class Initialized
INFO - 2016-08-12 09:43:51 --> Controller Class Initialized
DEBUG - 2016-08-12 09:43:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:43:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:43:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:43:51 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:43:51 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:43:51 --> Model Class Initialized
INFO - 2016-08-12 09:43:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:43:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:43:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:43:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:43:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:43:51 --> Final output sent to browser
DEBUG - 2016-08-12 09:43:51 --> Total execution time: 0.6848
INFO - 2016-08-12 09:44:02 --> Config Class Initialized
INFO - 2016-08-12 09:44:02 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:44:02 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:44:02 --> Utf8 Class Initialized
INFO - 2016-08-12 09:44:02 --> URI Class Initialized
INFO - 2016-08-12 09:44:02 --> Router Class Initialized
INFO - 2016-08-12 09:44:02 --> Output Class Initialized
INFO - 2016-08-12 09:44:02 --> Security Class Initialized
DEBUG - 2016-08-12 09:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:44:02 --> Input Class Initialized
INFO - 2016-08-12 09:44:02 --> Language Class Initialized
INFO - 2016-08-12 09:44:02 --> Loader Class Initialized
INFO - 2016-08-12 09:44:02 --> Helper loaded: url_helper
INFO - 2016-08-12 09:44:02 --> Helper loaded: date_helper
INFO - 2016-08-12 09:44:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:44:02 --> Database Driver Class Initialized
INFO - 2016-08-12 09:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:44:03 --> Email Class Initialized
INFO - 2016-08-12 09:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:44:03 --> Pagination Class Initialized
INFO - 2016-08-12 09:44:03 --> Model Class Initialized
INFO - 2016-08-12 09:44:03 --> Controller Class Initialized
DEBUG - 2016-08-12 09:44:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:44:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:44:03 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:44:03 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:03 --> Model Class Initialized
INFO - 2016-08-12 09:44:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:44:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:44:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:44:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/detail_buku_tamu.php
INFO - 2016-08-12 09:44:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:44:03 --> Final output sent to browser
DEBUG - 2016-08-12 09:44:03 --> Total execution time: 0.6391
INFO - 2016-08-12 09:44:05 --> Config Class Initialized
INFO - 2016-08-12 09:44:05 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:44:05 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:44:05 --> Utf8 Class Initialized
INFO - 2016-08-12 09:44:05 --> URI Class Initialized
INFO - 2016-08-12 09:44:05 --> Router Class Initialized
INFO - 2016-08-12 09:44:05 --> Output Class Initialized
INFO - 2016-08-12 09:44:05 --> Security Class Initialized
DEBUG - 2016-08-12 09:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:44:05 --> Input Class Initialized
INFO - 2016-08-12 09:44:05 --> Language Class Initialized
INFO - 2016-08-12 09:44:05 --> Loader Class Initialized
INFO - 2016-08-12 09:44:05 --> Helper loaded: url_helper
INFO - 2016-08-12 09:44:05 --> Helper loaded: date_helper
INFO - 2016-08-12 09:44:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:44:05 --> Database Driver Class Initialized
INFO - 2016-08-12 09:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:44:05 --> Email Class Initialized
INFO - 2016-08-12 09:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:44:05 --> Pagination Class Initialized
INFO - 2016-08-12 09:44:05 --> Model Class Initialized
INFO - 2016-08-12 09:44:05 --> Controller Class Initialized
DEBUG - 2016-08-12 09:44:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:44:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:44:05 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:44:05 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:05 --> Model Class Initialized
INFO - 2016-08-12 09:44:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:44:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:44:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:44:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:44:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:44:05 --> Final output sent to browser
DEBUG - 2016-08-12 09:44:06 --> Total execution time: 0.6577
INFO - 2016-08-12 09:44:30 --> Config Class Initialized
INFO - 2016-08-12 09:44:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:44:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:44:30 --> Utf8 Class Initialized
INFO - 2016-08-12 09:44:30 --> URI Class Initialized
INFO - 2016-08-12 09:44:30 --> Router Class Initialized
INFO - 2016-08-12 09:44:30 --> Output Class Initialized
INFO - 2016-08-12 09:44:30 --> Security Class Initialized
DEBUG - 2016-08-12 09:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:44:30 --> Input Class Initialized
INFO - 2016-08-12 09:44:30 --> Language Class Initialized
INFO - 2016-08-12 09:44:30 --> Loader Class Initialized
INFO - 2016-08-12 09:44:30 --> Helper loaded: url_helper
INFO - 2016-08-12 09:44:30 --> Helper loaded: date_helper
INFO - 2016-08-12 09:44:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:44:30 --> Database Driver Class Initialized
INFO - 2016-08-12 09:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:44:30 --> Email Class Initialized
INFO - 2016-08-12 09:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:44:30 --> Pagination Class Initialized
INFO - 2016-08-12 09:44:30 --> Model Class Initialized
INFO - 2016-08-12 09:44:30 --> Controller Class Initialized
DEBUG - 2016-08-12 09:44:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:44:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:44:30 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:44:30 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:44:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:30 --> Model Class Initialized
INFO - 2016-08-12 09:44:31 --> Config Class Initialized
INFO - 2016-08-12 09:44:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:44:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:44:31 --> Utf8 Class Initialized
INFO - 2016-08-12 09:44:31 --> URI Class Initialized
INFO - 2016-08-12 09:44:31 --> Router Class Initialized
INFO - 2016-08-12 09:44:31 --> Output Class Initialized
INFO - 2016-08-12 09:44:31 --> Security Class Initialized
DEBUG - 2016-08-12 09:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:44:31 --> Input Class Initialized
INFO - 2016-08-12 09:44:31 --> Language Class Initialized
INFO - 2016-08-12 09:44:31 --> Loader Class Initialized
INFO - 2016-08-12 09:44:31 --> Helper loaded: url_helper
INFO - 2016-08-12 09:44:31 --> Helper loaded: date_helper
INFO - 2016-08-12 09:44:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:44:31 --> Database Driver Class Initialized
INFO - 2016-08-12 09:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:44:31 --> Email Class Initialized
INFO - 2016-08-12 09:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:44:31 --> Pagination Class Initialized
INFO - 2016-08-12 09:44:31 --> Model Class Initialized
INFO - 2016-08-12 09:44:31 --> Controller Class Initialized
DEBUG - 2016-08-12 09:44:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:44:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:44:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:44:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:31 --> Model Class Initialized
INFO - 2016-08-12 09:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:44:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:44:31 --> Final output sent to browser
DEBUG - 2016-08-12 09:44:31 --> Total execution time: 0.7101
INFO - 2016-08-12 09:44:31 --> Config Class Initialized
INFO - 2016-08-12 09:44:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:44:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:44:31 --> Utf8 Class Initialized
INFO - 2016-08-12 09:44:31 --> URI Class Initialized
INFO - 2016-08-12 09:44:31 --> Router Class Initialized
INFO - 2016-08-12 09:44:32 --> Output Class Initialized
INFO - 2016-08-12 09:44:32 --> Security Class Initialized
DEBUG - 2016-08-12 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:44:32 --> Input Class Initialized
INFO - 2016-08-12 09:44:32 --> Language Class Initialized
INFO - 2016-08-12 09:44:32 --> Loader Class Initialized
INFO - 2016-08-12 09:44:32 --> Helper loaded: url_helper
INFO - 2016-08-12 09:44:32 --> Helper loaded: date_helper
INFO - 2016-08-12 09:44:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:44:32 --> Database Driver Class Initialized
INFO - 2016-08-12 09:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:44:32 --> Email Class Initialized
INFO - 2016-08-12 09:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:44:32 --> Pagination Class Initialized
INFO - 2016-08-12 09:44:32 --> Model Class Initialized
INFO - 2016-08-12 09:44:32 --> Controller Class Initialized
DEBUG - 2016-08-12 09:44:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:44:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:44:32 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:44:32 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:44:32 --> Model Class Initialized
INFO - 2016-08-12 09:44:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:44:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:44:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:44:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:44:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:44:32 --> Final output sent to browser
DEBUG - 2016-08-12 09:44:32 --> Total execution time: 0.7046
INFO - 2016-08-12 09:45:43 --> Config Class Initialized
INFO - 2016-08-12 09:45:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:45:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:45:43 --> Utf8 Class Initialized
INFO - 2016-08-12 09:45:43 --> URI Class Initialized
INFO - 2016-08-12 09:45:43 --> Router Class Initialized
INFO - 2016-08-12 09:45:43 --> Output Class Initialized
INFO - 2016-08-12 09:45:43 --> Security Class Initialized
DEBUG - 2016-08-12 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:45:43 --> Input Class Initialized
INFO - 2016-08-12 09:45:43 --> Language Class Initialized
INFO - 2016-08-12 09:45:43 --> Loader Class Initialized
INFO - 2016-08-12 09:45:43 --> Helper loaded: url_helper
INFO - 2016-08-12 09:45:43 --> Helper loaded: date_helper
INFO - 2016-08-12 09:45:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:45:43 --> Database Driver Class Initialized
INFO - 2016-08-12 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:45:43 --> Email Class Initialized
INFO - 2016-08-12 09:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:45:43 --> Pagination Class Initialized
INFO - 2016-08-12 09:45:43 --> Model Class Initialized
INFO - 2016-08-12 09:45:43 --> Controller Class Initialized
INFO - 2016-08-12 09:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 09:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 09:45:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 09:45:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 09:45:44 --> Final output sent to browser
DEBUG - 2016-08-12 09:45:44 --> Total execution time: 0.5177
INFO - 2016-08-12 09:45:44 --> Config Class Initialized
INFO - 2016-08-12 09:45:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:45:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:45:44 --> Utf8 Class Initialized
INFO - 2016-08-12 09:45:44 --> URI Class Initialized
INFO - 2016-08-12 09:45:44 --> Router Class Initialized
INFO - 2016-08-12 09:45:44 --> Output Class Initialized
INFO - 2016-08-12 09:45:44 --> Security Class Initialized
DEBUG - 2016-08-12 09:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:45:44 --> Input Class Initialized
INFO - 2016-08-12 09:45:44 --> Language Class Initialized
ERROR - 2016-08-12 09:45:44 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 09:55:52 --> Config Class Initialized
INFO - 2016-08-12 09:55:52 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:55:52 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:55:52 --> Utf8 Class Initialized
INFO - 2016-08-12 09:55:52 --> URI Class Initialized
INFO - 2016-08-12 09:55:52 --> Router Class Initialized
INFO - 2016-08-12 09:55:52 --> Output Class Initialized
INFO - 2016-08-12 09:55:52 --> Security Class Initialized
DEBUG - 2016-08-12 09:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:55:52 --> Input Class Initialized
INFO - 2016-08-12 09:55:52 --> Language Class Initialized
INFO - 2016-08-12 09:55:52 --> Loader Class Initialized
INFO - 2016-08-12 09:55:52 --> Helper loaded: url_helper
INFO - 2016-08-12 09:55:52 --> Helper loaded: date_helper
INFO - 2016-08-12 09:55:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:55:52 --> Database Driver Class Initialized
INFO - 2016-08-12 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:55:52 --> Email Class Initialized
INFO - 2016-08-12 09:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:55:52 --> Pagination Class Initialized
INFO - 2016-08-12 09:55:52 --> Model Class Initialized
INFO - 2016-08-12 09:55:52 --> Controller Class Initialized
DEBUG - 2016-08-12 09:55:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 09:55:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:55:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 09:55:52 --> Helper loaded: cookie_helper
INFO - 2016-08-12 09:55:52 --> Helper loaded: language_helper
DEBUG - 2016-08-12 09:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 09:55:52 --> Model Class Initialized
INFO - 2016-08-12 09:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 09:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 09:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 09:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 09:55:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 09:55:52 --> Final output sent to browser
DEBUG - 2016-08-12 09:55:52 --> Total execution time: 0.6904
INFO - 2016-08-12 09:59:36 --> Config Class Initialized
INFO - 2016-08-12 09:59:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:59:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:59:36 --> Utf8 Class Initialized
INFO - 2016-08-12 09:59:36 --> URI Class Initialized
INFO - 2016-08-12 09:59:36 --> Router Class Initialized
INFO - 2016-08-12 09:59:36 --> Output Class Initialized
INFO - 2016-08-12 09:59:36 --> Security Class Initialized
DEBUG - 2016-08-12 09:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:59:36 --> Input Class Initialized
INFO - 2016-08-12 09:59:36 --> Language Class Initialized
INFO - 2016-08-12 09:59:36 --> Loader Class Initialized
INFO - 2016-08-12 09:59:36 --> Helper loaded: url_helper
INFO - 2016-08-12 09:59:36 --> Helper loaded: date_helper
INFO - 2016-08-12 09:59:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 09:59:36 --> Database Driver Class Initialized
INFO - 2016-08-12 09:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 09:59:36 --> Email Class Initialized
INFO - 2016-08-12 09:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 09:59:37 --> Pagination Class Initialized
INFO - 2016-08-12 09:59:37 --> Model Class Initialized
INFO - 2016-08-12 09:59:37 --> Controller Class Initialized
INFO - 2016-08-12 09:59:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 09:59:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 09:59:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 09:59:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 09:59:37 --> Final output sent to browser
DEBUG - 2016-08-12 09:59:37 --> Total execution time: 0.4998
INFO - 2016-08-12 09:59:37 --> Config Class Initialized
INFO - 2016-08-12 09:59:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 09:59:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 09:59:37 --> Utf8 Class Initialized
INFO - 2016-08-12 09:59:37 --> URI Class Initialized
INFO - 2016-08-12 09:59:37 --> Router Class Initialized
INFO - 2016-08-12 09:59:37 --> Output Class Initialized
INFO - 2016-08-12 09:59:38 --> Security Class Initialized
DEBUG - 2016-08-12 09:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 09:59:38 --> Input Class Initialized
INFO - 2016-08-12 09:59:38 --> Language Class Initialized
ERROR - 2016-08-12 09:59:38 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 10:01:20 --> Config Class Initialized
INFO - 2016-08-12 10:01:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 10:01:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 10:01:20 --> Utf8 Class Initialized
INFO - 2016-08-12 10:01:20 --> URI Class Initialized
INFO - 2016-08-12 10:01:20 --> Router Class Initialized
INFO - 2016-08-12 10:01:20 --> Output Class Initialized
INFO - 2016-08-12 10:01:20 --> Security Class Initialized
DEBUG - 2016-08-12 10:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 10:01:20 --> Input Class Initialized
INFO - 2016-08-12 10:01:20 --> Language Class Initialized
ERROR - 2016-08-12 10:01:20 --> 404 Page Not Found: Home/order
INFO - 2016-08-12 10:01:24 --> Config Class Initialized
INFO - 2016-08-12 10:01:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 10:01:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 10:01:24 --> Utf8 Class Initialized
INFO - 2016-08-12 10:01:24 --> URI Class Initialized
DEBUG - 2016-08-12 10:01:24 --> No URI present. Default controller set.
INFO - 2016-08-12 10:01:24 --> Router Class Initialized
INFO - 2016-08-12 10:01:24 --> Output Class Initialized
INFO - 2016-08-12 10:01:24 --> Security Class Initialized
DEBUG - 2016-08-12 10:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 10:01:24 --> Input Class Initialized
INFO - 2016-08-12 10:01:24 --> Language Class Initialized
INFO - 2016-08-12 10:01:24 --> Loader Class Initialized
INFO - 2016-08-12 10:01:24 --> Helper loaded: url_helper
INFO - 2016-08-12 10:01:24 --> Helper loaded: date_helper
INFO - 2016-08-12 10:01:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 10:01:24 --> Database Driver Class Initialized
INFO - 2016-08-12 10:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 10:01:24 --> Email Class Initialized
INFO - 2016-08-12 10:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 10:01:24 --> Pagination Class Initialized
INFO - 2016-08-12 10:01:24 --> Model Class Initialized
INFO - 2016-08-12 10:01:24 --> Controller Class Initialized
INFO - 2016-08-12 10:01:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 10:01:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 10:01:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 10:01:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 10:01:24 --> Final output sent to browser
DEBUG - 2016-08-12 10:01:24 --> Total execution time: 0.5038
INFO - 2016-08-12 10:01:26 --> Config Class Initialized
INFO - 2016-08-12 10:01:26 --> Hooks Class Initialized
DEBUG - 2016-08-12 10:01:26 --> UTF-8 Support Enabled
INFO - 2016-08-12 10:01:27 --> Utf8 Class Initialized
INFO - 2016-08-12 10:01:27 --> URI Class Initialized
INFO - 2016-08-12 10:01:27 --> Router Class Initialized
INFO - 2016-08-12 10:01:27 --> Output Class Initialized
INFO - 2016-08-12 10:01:27 --> Security Class Initialized
DEBUG - 2016-08-12 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 10:01:27 --> Input Class Initialized
INFO - 2016-08-12 10:01:27 --> Language Class Initialized
INFO - 2016-08-12 10:01:27 --> Loader Class Initialized
INFO - 2016-08-12 10:01:27 --> Helper loaded: url_helper
INFO - 2016-08-12 10:01:27 --> Helper loaded: date_helper
INFO - 2016-08-12 10:01:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 10:01:27 --> Database Driver Class Initialized
INFO - 2016-08-12 10:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 10:01:27 --> Email Class Initialized
INFO - 2016-08-12 10:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 10:01:27 --> Pagination Class Initialized
INFO - 2016-08-12 10:01:27 --> Model Class Initialized
INFO - 2016-08-12 10:01:27 --> Controller Class Initialized
INFO - 2016-08-12 10:01:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 10:01:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 10:01:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 10:01:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 10:01:27 --> Final output sent to browser
DEBUG - 2016-08-12 10:01:27 --> Total execution time: 0.4911
INFO - 2016-08-12 11:00:12 --> Config Class Initialized
INFO - 2016-08-12 11:00:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 11:00:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 11:00:12 --> Utf8 Class Initialized
INFO - 2016-08-12 11:00:12 --> URI Class Initialized
DEBUG - 2016-08-12 11:00:12 --> No URI present. Default controller set.
INFO - 2016-08-12 11:00:12 --> Router Class Initialized
INFO - 2016-08-12 11:00:13 --> Output Class Initialized
INFO - 2016-08-12 11:00:13 --> Security Class Initialized
DEBUG - 2016-08-12 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 11:00:13 --> Input Class Initialized
INFO - 2016-08-12 11:00:13 --> Language Class Initialized
INFO - 2016-08-12 11:00:13 --> Loader Class Initialized
INFO - 2016-08-12 11:00:13 --> Helper loaded: url_helper
INFO - 2016-08-12 11:00:13 --> Helper loaded: date_helper
INFO - 2016-08-12 11:00:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 11:00:13 --> Database Driver Class Initialized
INFO - 2016-08-12 11:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 11:00:13 --> Email Class Initialized
INFO - 2016-08-12 11:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 11:00:13 --> Pagination Class Initialized
INFO - 2016-08-12 11:00:13 --> Model Class Initialized
INFO - 2016-08-12 11:00:13 --> Controller Class Initialized
INFO - 2016-08-12 11:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 11:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 11:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 11:00:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 11:00:13 --> Final output sent to browser
DEBUG - 2016-08-12 11:00:13 --> Total execution time: 0.5957
INFO - 2016-08-12 11:11:36 --> Config Class Initialized
INFO - 2016-08-12 11:11:36 --> Config Class Initialized
INFO - 2016-08-12 11:11:36 --> Hooks Class Initialized
INFO - 2016-08-12 11:11:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-12 11:11:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 11:11:36 --> Utf8 Class Initialized
INFO - 2016-08-12 11:11:36 --> Utf8 Class Initialized
INFO - 2016-08-12 11:11:36 --> URI Class Initialized
INFO - 2016-08-12 11:11:36 --> URI Class Initialized
DEBUG - 2016-08-12 11:11:36 --> No URI present. Default controller set.
INFO - 2016-08-12 11:11:36 --> Router Class Initialized
INFO - 2016-08-12 11:11:36 --> Router Class Initialized
INFO - 2016-08-12 11:11:36 --> Output Class Initialized
INFO - 2016-08-12 11:11:36 --> Output Class Initialized
INFO - 2016-08-12 11:11:37 --> Security Class Initialized
DEBUG - 2016-08-12 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 11:11:37 --> Input Class Initialized
INFO - 2016-08-12 11:11:37 --> Language Class Initialized
INFO - 2016-08-12 11:11:37 --> Loader Class Initialized
INFO - 2016-08-12 11:11:37 --> Helper loaded: url_helper
INFO - 2016-08-12 11:11:37 --> Helper loaded: date_helper
INFO - 2016-08-12 11:11:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 11:11:37 --> Security Class Initialized
INFO - 2016-08-12 11:11:37 --> Database Driver Class Initialized
DEBUG - 2016-08-12 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 11:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 11:11:37 --> Input Class Initialized
INFO - 2016-08-12 11:11:37 --> Email Class Initialized
INFO - 2016-08-12 11:11:37 --> Language Class Initialized
INFO - 2016-08-12 11:11:38 --> Loader Class Initialized
INFO - 2016-08-12 11:11:38 --> Helper loaded: url_helper
INFO - 2016-08-12 11:11:38 --> Helper loaded: date_helper
INFO - 2016-08-12 11:11:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 11:11:38 --> Database Driver Class Initialized
INFO - 2016-08-12 11:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 11:11:38 --> Pagination Class Initialized
INFO - 2016-08-12 11:11:38 --> Model Class Initialized
INFO - 2016-08-12 11:11:38 --> Controller Class Initialized
DEBUG - 2016-08-12 11:11:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 11:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 11:11:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 11:11:38 --> Helper loaded: cookie_helper
INFO - 2016-08-12 11:11:38 --> Helper loaded: language_helper
DEBUG - 2016-08-12 11:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 11:11:38 --> Model Class Initialized
INFO - 2016-08-12 11:11:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 11:11:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 11:11:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 11:11:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 11:11:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 11:11:38 --> Final output sent to browser
DEBUG - 2016-08-12 11:11:39 --> Total execution time: 2.4344
INFO - 2016-08-12 11:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 11:11:39 --> Email Class Initialized
INFO - 2016-08-12 11:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 11:11:39 --> Pagination Class Initialized
INFO - 2016-08-12 11:11:39 --> Model Class Initialized
INFO - 2016-08-12 11:11:39 --> Controller Class Initialized
INFO - 2016-08-12 11:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 11:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 11:11:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 11:11:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 11:11:40 --> Final output sent to browser
DEBUG - 2016-08-12 11:11:40 --> Total execution time: 3.5543
INFO - 2016-08-12 12:50:00 --> Config Class Initialized
INFO - 2016-08-12 12:50:00 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:50:00 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:50:00 --> Utf8 Class Initialized
INFO - 2016-08-12 12:50:00 --> URI Class Initialized
INFO - 2016-08-12 12:50:00 --> Router Class Initialized
INFO - 2016-08-12 12:50:00 --> Output Class Initialized
INFO - 2016-08-12 12:50:00 --> Security Class Initialized
DEBUG - 2016-08-12 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:50:00 --> Input Class Initialized
INFO - 2016-08-12 12:50:00 --> Language Class Initialized
INFO - 2016-08-12 12:50:00 --> Loader Class Initialized
INFO - 2016-08-12 12:50:00 --> Helper loaded: url_helper
INFO - 2016-08-12 12:50:00 --> Helper loaded: date_helper
INFO - 2016-08-12 12:50:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:50:00 --> Database Driver Class Initialized
INFO - 2016-08-12 12:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:50:01 --> Email Class Initialized
INFO - 2016-08-12 12:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:50:01 --> Pagination Class Initialized
INFO - 2016-08-12 12:50:01 --> Model Class Initialized
INFO - 2016-08-12 12:50:01 --> Controller Class Initialized
DEBUG - 2016-08-12 12:50:01 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:50:01 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:50:01 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:50:01 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:50:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:01 --> Model Class Initialized
INFO - 2016-08-12 12:50:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:50:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:50:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:50:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 12:50:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:50:01 --> Final output sent to browser
DEBUG - 2016-08-12 12:50:01 --> Total execution time: 0.7473
INFO - 2016-08-12 12:50:37 --> Config Class Initialized
INFO - 2016-08-12 12:50:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:50:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:50:37 --> Utf8 Class Initialized
INFO - 2016-08-12 12:50:37 --> URI Class Initialized
INFO - 2016-08-12 12:50:37 --> Router Class Initialized
INFO - 2016-08-12 12:50:37 --> Output Class Initialized
INFO - 2016-08-12 12:50:38 --> Security Class Initialized
DEBUG - 2016-08-12 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:50:38 --> Input Class Initialized
INFO - 2016-08-12 12:50:38 --> Language Class Initialized
INFO - 2016-08-12 12:50:38 --> Loader Class Initialized
INFO - 2016-08-12 12:50:38 --> Helper loaded: url_helper
INFO - 2016-08-12 12:50:38 --> Helper loaded: date_helper
INFO - 2016-08-12 12:50:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:50:38 --> Database Driver Class Initialized
INFO - 2016-08-12 12:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:50:38 --> Email Class Initialized
INFO - 2016-08-12 12:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:50:38 --> Pagination Class Initialized
INFO - 2016-08-12 12:50:38 --> Model Class Initialized
INFO - 2016-08-12 12:50:38 --> Controller Class Initialized
DEBUG - 2016-08-12 12:50:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:50:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:50:38 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:50:38 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:38 --> Model Class Initialized
INFO - 2016-08-12 12:50:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:50:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:50:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:50:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 12:50:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:50:38 --> Final output sent to browser
DEBUG - 2016-08-12 12:50:38 --> Total execution time: 0.6389
INFO - 2016-08-12 12:50:44 --> Config Class Initialized
INFO - 2016-08-12 12:50:44 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:50:44 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:50:44 --> Utf8 Class Initialized
INFO - 2016-08-12 12:50:44 --> URI Class Initialized
INFO - 2016-08-12 12:50:44 --> Router Class Initialized
INFO - 2016-08-12 12:50:44 --> Output Class Initialized
INFO - 2016-08-12 12:50:44 --> Security Class Initialized
DEBUG - 2016-08-12 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:50:44 --> Input Class Initialized
INFO - 2016-08-12 12:50:44 --> Language Class Initialized
INFO - 2016-08-12 12:50:44 --> Loader Class Initialized
INFO - 2016-08-12 12:50:44 --> Helper loaded: url_helper
INFO - 2016-08-12 12:50:44 --> Helper loaded: date_helper
INFO - 2016-08-12 12:50:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:50:44 --> Database Driver Class Initialized
INFO - 2016-08-12 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:50:44 --> Email Class Initialized
INFO - 2016-08-12 12:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:50:45 --> Pagination Class Initialized
INFO - 2016-08-12 12:50:45 --> Model Class Initialized
INFO - 2016-08-12 12:50:45 --> Controller Class Initialized
DEBUG - 2016-08-12 12:50:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:50:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:50:45 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:50:45 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:50:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:45 --> Model Class Initialized
INFO - 2016-08-12 12:50:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:50:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:50:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:50:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 12:50:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:50:45 --> Final output sent to browser
DEBUG - 2016-08-12 12:50:45 --> Total execution time: 0.7432
INFO - 2016-08-12 12:50:49 --> Config Class Initialized
INFO - 2016-08-12 12:50:49 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:50:49 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:50:49 --> Utf8 Class Initialized
INFO - 2016-08-12 12:50:49 --> URI Class Initialized
INFO - 2016-08-12 12:50:49 --> Router Class Initialized
INFO - 2016-08-12 12:50:49 --> Output Class Initialized
INFO - 2016-08-12 12:50:49 --> Security Class Initialized
DEBUG - 2016-08-12 12:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:50:50 --> Input Class Initialized
INFO - 2016-08-12 12:50:50 --> Language Class Initialized
INFO - 2016-08-12 12:50:50 --> Loader Class Initialized
INFO - 2016-08-12 12:50:50 --> Helper loaded: url_helper
INFO - 2016-08-12 12:50:50 --> Helper loaded: date_helper
INFO - 2016-08-12 12:50:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:50:50 --> Database Driver Class Initialized
INFO - 2016-08-12 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:50:50 --> Email Class Initialized
INFO - 2016-08-12 12:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:50:50 --> Pagination Class Initialized
INFO - 2016-08-12 12:50:50 --> Model Class Initialized
INFO - 2016-08-12 12:50:50 --> Controller Class Initialized
DEBUG - 2016-08-12 12:50:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:50:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:50:50 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:50:50 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:50:50 --> Model Class Initialized
INFO - 2016-08-12 12:50:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:50:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:50:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:50:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 12:50:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:50:50 --> Final output sent to browser
DEBUG - 2016-08-12 12:50:50 --> Total execution time: 0.6390
INFO - 2016-08-12 12:51:48 --> Config Class Initialized
INFO - 2016-08-12 12:51:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:51:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:51:48 --> Utf8 Class Initialized
INFO - 2016-08-12 12:51:48 --> URI Class Initialized
INFO - 2016-08-12 12:51:48 --> Router Class Initialized
INFO - 2016-08-12 12:51:48 --> Output Class Initialized
INFO - 2016-08-12 12:51:48 --> Security Class Initialized
DEBUG - 2016-08-12 12:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:51:48 --> Input Class Initialized
INFO - 2016-08-12 12:51:48 --> Language Class Initialized
INFO - 2016-08-12 12:51:48 --> Loader Class Initialized
INFO - 2016-08-12 12:51:48 --> Helper loaded: url_helper
INFO - 2016-08-12 12:51:48 --> Helper loaded: date_helper
INFO - 2016-08-12 12:51:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:51:48 --> Database Driver Class Initialized
INFO - 2016-08-12 12:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:51:48 --> Email Class Initialized
INFO - 2016-08-12 12:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:51:48 --> Pagination Class Initialized
INFO - 2016-08-12 12:51:48 --> Model Class Initialized
INFO - 2016-08-12 12:51:48 --> Controller Class Initialized
DEBUG - 2016-08-12 12:51:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:51:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:51:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:51:49 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:51:49 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:51:49 --> Model Class Initialized
INFO - 2016-08-12 12:51:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:51:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:51:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:51:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 12:51:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:51:49 --> Final output sent to browser
DEBUG - 2016-08-12 12:51:49 --> Total execution time: 0.6759
INFO - 2016-08-12 12:51:52 --> Config Class Initialized
INFO - 2016-08-12 12:51:52 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:51:52 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:51:52 --> Utf8 Class Initialized
INFO - 2016-08-12 12:51:52 --> URI Class Initialized
INFO - 2016-08-12 12:51:52 --> Router Class Initialized
INFO - 2016-08-12 12:51:52 --> Output Class Initialized
INFO - 2016-08-12 12:51:52 --> Security Class Initialized
DEBUG - 2016-08-12 12:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:51:53 --> Input Class Initialized
INFO - 2016-08-12 12:51:53 --> Language Class Initialized
INFO - 2016-08-12 12:51:53 --> Loader Class Initialized
INFO - 2016-08-12 12:51:53 --> Helper loaded: url_helper
INFO - 2016-08-12 12:51:53 --> Helper loaded: date_helper
INFO - 2016-08-12 12:51:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:51:53 --> Database Driver Class Initialized
INFO - 2016-08-12 12:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:51:53 --> Email Class Initialized
INFO - 2016-08-12 12:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:51:53 --> Pagination Class Initialized
INFO - 2016-08-12 12:51:53 --> Model Class Initialized
INFO - 2016-08-12 12:51:53 --> Controller Class Initialized
DEBUG - 2016-08-12 12:51:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 12:51:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:51:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 12:51:53 --> Helper loaded: cookie_helper
INFO - 2016-08-12 12:51:53 --> Helper loaded: language_helper
DEBUG - 2016-08-12 12:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 12:51:53 --> Model Class Initialized
INFO - 2016-08-12 12:51:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 12:51:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 12:51:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 12:51:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 12:51:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 12:51:53 --> Final output sent to browser
DEBUG - 2016-08-12 12:51:53 --> Total execution time: 0.6827
INFO - 2016-08-12 12:58:09 --> Config Class Initialized
INFO - 2016-08-12 12:58:09 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:09 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:09 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:09 --> URI Class Initialized
INFO - 2016-08-12 12:58:09 --> Router Class Initialized
INFO - 2016-08-12 12:58:09 --> Output Class Initialized
INFO - 2016-08-12 12:58:09 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:09 --> Input Class Initialized
INFO - 2016-08-12 12:58:09 --> Language Class Initialized
INFO - 2016-08-12 12:58:09 --> Loader Class Initialized
INFO - 2016-08-12 12:58:09 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:10 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:10 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:10 --> Email Class Initialized
INFO - 2016-08-12 12:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:10 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:10 --> Model Class Initialized
INFO - 2016-08-12 12:58:10 --> Controller Class Initialized
INFO - 2016-08-12 12:58:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 12:58:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:10 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:10 --> Total execution time: 0.6754
INFO - 2016-08-12 12:58:10 --> Config Class Initialized
INFO - 2016-08-12 12:58:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:10 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:10 --> URI Class Initialized
INFO - 2016-08-12 12:58:10 --> Router Class Initialized
INFO - 2016-08-12 12:58:10 --> Output Class Initialized
INFO - 2016-08-12 12:58:10 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:11 --> Input Class Initialized
INFO - 2016-08-12 12:58:11 --> Language Class Initialized
ERROR - 2016-08-12 12:58:11 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 12:58:13 --> Config Class Initialized
INFO - 2016-08-12 12:58:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:14 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:14 --> URI Class Initialized
INFO - 2016-08-12 12:58:14 --> Router Class Initialized
INFO - 2016-08-12 12:58:14 --> Output Class Initialized
INFO - 2016-08-12 12:58:14 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:14 --> Input Class Initialized
INFO - 2016-08-12 12:58:14 --> Language Class Initialized
INFO - 2016-08-12 12:58:14 --> Loader Class Initialized
INFO - 2016-08-12 12:58:14 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:14 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:14 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:14 --> Email Class Initialized
INFO - 2016-08-12 12:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:14 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:14 --> Model Class Initialized
INFO - 2016-08-12 12:58:14 --> Controller Class Initialized
INFO - 2016-08-12 12:58:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 12:58:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:14 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:14 --> Total execution time: 0.9682
INFO - 2016-08-12 12:58:17 --> Config Class Initialized
INFO - 2016-08-12 12:58:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:17 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:17 --> URI Class Initialized
INFO - 2016-08-12 12:58:17 --> Router Class Initialized
INFO - 2016-08-12 12:58:17 --> Output Class Initialized
INFO - 2016-08-12 12:58:17 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:17 --> Input Class Initialized
INFO - 2016-08-12 12:58:17 --> Language Class Initialized
INFO - 2016-08-12 12:58:17 --> Loader Class Initialized
INFO - 2016-08-12 12:58:17 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:17 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:17 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:17 --> Email Class Initialized
INFO - 2016-08-12 12:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:17 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:17 --> Model Class Initialized
INFO - 2016-08-12 12:58:17 --> Controller Class Initialized
INFO - 2016-08-12 12:58:17 --> Model Class Initialized
INFO - 2016-08-12 12:58:17 --> Helper loaded: text_helper
INFO - 2016-08-12 12:58:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 12:58:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:17 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:17 --> Total execution time: 0.7216
INFO - 2016-08-12 12:58:31 --> Config Class Initialized
INFO - 2016-08-12 12:58:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:31 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:31 --> URI Class Initialized
INFO - 2016-08-12 12:58:31 --> Router Class Initialized
INFO - 2016-08-12 12:58:31 --> Output Class Initialized
INFO - 2016-08-12 12:58:31 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:31 --> Input Class Initialized
INFO - 2016-08-12 12:58:31 --> Language Class Initialized
INFO - 2016-08-12 12:58:31 --> Loader Class Initialized
INFO - 2016-08-12 12:58:31 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:31 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:31 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:31 --> Email Class Initialized
INFO - 2016-08-12 12:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:31 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:31 --> Model Class Initialized
INFO - 2016-08-12 12:58:31 --> Controller Class Initialized
INFO - 2016-08-12 12:58:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 12:58:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:31 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:31 --> Total execution time: 0.6536
INFO - 2016-08-12 12:58:36 --> Config Class Initialized
INFO - 2016-08-12 12:58:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:36 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:36 --> URI Class Initialized
INFO - 2016-08-12 12:58:36 --> Router Class Initialized
INFO - 2016-08-12 12:58:36 --> Output Class Initialized
INFO - 2016-08-12 12:58:36 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:36 --> Input Class Initialized
INFO - 2016-08-12 12:58:36 --> Language Class Initialized
INFO - 2016-08-12 12:58:36 --> Loader Class Initialized
INFO - 2016-08-12 12:58:36 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:36 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:36 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:37 --> Email Class Initialized
INFO - 2016-08-12 12:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:37 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:37 --> Model Class Initialized
INFO - 2016-08-12 12:58:37 --> Controller Class Initialized
INFO - 2016-08-12 12:58:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-12 12:58:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:37 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:37 --> Total execution time: 0.5959
INFO - 2016-08-12 12:58:41 --> Config Class Initialized
INFO - 2016-08-12 12:58:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 12:58:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 12:58:41 --> Utf8 Class Initialized
INFO - 2016-08-12 12:58:41 --> URI Class Initialized
INFO - 2016-08-12 12:58:41 --> Router Class Initialized
INFO - 2016-08-12 12:58:41 --> Output Class Initialized
INFO - 2016-08-12 12:58:41 --> Security Class Initialized
DEBUG - 2016-08-12 12:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 12:58:41 --> Input Class Initialized
INFO - 2016-08-12 12:58:41 --> Language Class Initialized
INFO - 2016-08-12 12:58:41 --> Loader Class Initialized
INFO - 2016-08-12 12:58:41 --> Helper loaded: url_helper
INFO - 2016-08-12 12:58:41 --> Helper loaded: date_helper
INFO - 2016-08-12 12:58:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 12:58:41 --> Database Driver Class Initialized
INFO - 2016-08-12 12:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 12:58:41 --> Email Class Initialized
INFO - 2016-08-12 12:58:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 12:58:41 --> Pagination Class Initialized
INFO - 2016-08-12 12:58:41 --> Model Class Initialized
INFO - 2016-08-12 12:58:41 --> Controller Class Initialized
INFO - 2016-08-12 12:58:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 12:58:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 12:58:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 12:58:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 12:58:41 --> Final output sent to browser
DEBUG - 2016-08-12 12:58:41 --> Total execution time: 0.5038
INFO - 2016-08-12 14:34:24 --> Config Class Initialized
INFO - 2016-08-12 14:34:25 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:34:25 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:34:25 --> Utf8 Class Initialized
INFO - 2016-08-12 14:34:26 --> URI Class Initialized
DEBUG - 2016-08-12 14:34:26 --> No URI present. Default controller set.
INFO - 2016-08-12 14:34:26 --> Router Class Initialized
INFO - 2016-08-12 14:34:26 --> Output Class Initialized
INFO - 2016-08-12 14:34:26 --> Security Class Initialized
DEBUG - 2016-08-12 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:34:26 --> Input Class Initialized
INFO - 2016-08-12 14:34:26 --> Language Class Initialized
INFO - 2016-08-12 14:34:26 --> Loader Class Initialized
INFO - 2016-08-12 14:34:26 --> Helper loaded: url_helper
INFO - 2016-08-12 14:34:26 --> Helper loaded: date_helper
INFO - 2016-08-12 14:34:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:34:27 --> Database Driver Class Initialized
ERROR - 2016-08-12 14:34:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\aqiqahsehati\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2016-08-12 14:34:29 --> Unable to connect to the database
INFO - 2016-08-12 14:34:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-12 14:35:27 --> Config Class Initialized
INFO - 2016-08-12 14:35:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:35:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:35:27 --> Utf8 Class Initialized
INFO - 2016-08-12 14:35:27 --> URI Class Initialized
DEBUG - 2016-08-12 14:35:27 --> No URI present. Default controller set.
INFO - 2016-08-12 14:35:27 --> Router Class Initialized
INFO - 2016-08-12 14:35:27 --> Output Class Initialized
INFO - 2016-08-12 14:35:27 --> Security Class Initialized
DEBUG - 2016-08-12 14:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:35:27 --> Input Class Initialized
INFO - 2016-08-12 14:35:27 --> Language Class Initialized
INFO - 2016-08-12 14:35:27 --> Loader Class Initialized
INFO - 2016-08-12 14:35:27 --> Helper loaded: url_helper
INFO - 2016-08-12 14:35:27 --> Helper loaded: date_helper
INFO - 2016-08-12 14:35:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:35:27 --> Database Driver Class Initialized
INFO - 2016-08-12 14:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:35:28 --> Email Class Initialized
INFO - 2016-08-12 14:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:35:28 --> Pagination Class Initialized
INFO - 2016-08-12 14:35:28 --> Model Class Initialized
INFO - 2016-08-12 14:35:28 --> Controller Class Initialized
INFO - 2016-08-12 14:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 14:35:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:35:29 --> Final output sent to browser
DEBUG - 2016-08-12 14:35:29 --> Total execution time: 2.0366
INFO - 2016-08-12 14:35:46 --> Config Class Initialized
INFO - 2016-08-12 14:35:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:35:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:35:46 --> Utf8 Class Initialized
INFO - 2016-08-12 14:35:46 --> URI Class Initialized
INFO - 2016-08-12 14:35:46 --> Router Class Initialized
INFO - 2016-08-12 14:35:46 --> Output Class Initialized
INFO - 2016-08-12 14:35:46 --> Security Class Initialized
DEBUG - 2016-08-12 14:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:35:46 --> Input Class Initialized
INFO - 2016-08-12 14:35:46 --> Language Class Initialized
INFO - 2016-08-12 14:35:46 --> Loader Class Initialized
INFO - 2016-08-12 14:35:46 --> Helper loaded: url_helper
INFO - 2016-08-12 14:35:46 --> Helper loaded: date_helper
INFO - 2016-08-12 14:35:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:35:46 --> Database Driver Class Initialized
INFO - 2016-08-12 14:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:35:46 --> Email Class Initialized
INFO - 2016-08-12 14:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:35:46 --> Pagination Class Initialized
INFO - 2016-08-12 14:35:46 --> Model Class Initialized
INFO - 2016-08-12 14:35:46 --> Controller Class Initialized
INFO - 2016-08-12 14:35:47 --> Model Class Initialized
INFO - 2016-08-12 14:35:47 --> Helper loaded: text_helper
INFO - 2016-08-12 14:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:35:47 --> Final output sent to browser
DEBUG - 2016-08-12 14:35:47 --> Total execution time: 1.0350
INFO - 2016-08-12 14:35:48 --> Config Class Initialized
INFO - 2016-08-12 14:35:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:35:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:35:48 --> Utf8 Class Initialized
INFO - 2016-08-12 14:35:48 --> URI Class Initialized
INFO - 2016-08-12 14:35:48 --> Router Class Initialized
INFO - 2016-08-12 14:35:48 --> Output Class Initialized
INFO - 2016-08-12 14:35:48 --> Security Class Initialized
DEBUG - 2016-08-12 14:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:35:48 --> Input Class Initialized
INFO - 2016-08-12 14:35:48 --> Language Class Initialized
ERROR - 2016-08-12 14:35:48 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 14:35:53 --> Config Class Initialized
INFO - 2016-08-12 14:35:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:35:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:35:53 --> Utf8 Class Initialized
INFO - 2016-08-12 14:35:53 --> URI Class Initialized
INFO - 2016-08-12 14:35:53 --> Router Class Initialized
INFO - 2016-08-12 14:35:53 --> Output Class Initialized
INFO - 2016-08-12 14:35:53 --> Security Class Initialized
DEBUG - 2016-08-12 14:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:35:53 --> Input Class Initialized
INFO - 2016-08-12 14:35:53 --> Language Class Initialized
INFO - 2016-08-12 14:35:53 --> Loader Class Initialized
INFO - 2016-08-12 14:35:53 --> Helper loaded: url_helper
INFO - 2016-08-12 14:35:53 --> Helper loaded: date_helper
INFO - 2016-08-12 14:35:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:35:53 --> Database Driver Class Initialized
INFO - 2016-08-12 14:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:35:53 --> Email Class Initialized
INFO - 2016-08-12 14:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:35:53 --> Pagination Class Initialized
INFO - 2016-08-12 14:35:53 --> Model Class Initialized
INFO - 2016-08-12 14:35:53 --> Controller Class Initialized
INFO - 2016-08-12 14:35:53 --> Model Class Initialized
INFO - 2016-08-12 14:35:53 --> Helper loaded: text_helper
INFO - 2016-08-12 14:35:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:35:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:35:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:35:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:35:53 --> Final output sent to browser
DEBUG - 2016-08-12 14:35:53 --> Total execution time: 0.5605
INFO - 2016-08-12 14:35:54 --> Config Class Initialized
INFO - 2016-08-12 14:35:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:35:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:35:54 --> Utf8 Class Initialized
INFO - 2016-08-12 14:35:54 --> URI Class Initialized
INFO - 2016-08-12 14:35:54 --> Router Class Initialized
INFO - 2016-08-12 14:35:54 --> Output Class Initialized
INFO - 2016-08-12 14:35:54 --> Security Class Initialized
DEBUG - 2016-08-12 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:35:54 --> Input Class Initialized
INFO - 2016-08-12 14:35:54 --> Language Class Initialized
ERROR - 2016-08-12 14:35:54 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 14:36:03 --> Config Class Initialized
INFO - 2016-08-12 14:36:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:03 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:03 --> URI Class Initialized
INFO - 2016-08-12 14:36:03 --> Router Class Initialized
INFO - 2016-08-12 14:36:03 --> Output Class Initialized
INFO - 2016-08-12 14:36:03 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:03 --> Input Class Initialized
INFO - 2016-08-12 14:36:03 --> Language Class Initialized
INFO - 2016-08-12 14:36:03 --> Loader Class Initialized
INFO - 2016-08-12 14:36:03 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:03 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:03 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:03 --> Email Class Initialized
INFO - 2016-08-12 14:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:03 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:03 --> Model Class Initialized
INFO - 2016-08-12 14:36:03 --> Controller Class Initialized
INFO - 2016-08-12 14:36:03 --> Model Class Initialized
INFO - 2016-08-12 14:36:03 --> Helper loaded: text_helper
INFO - 2016-08-12 14:36:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:36:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:36:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:36:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:36:03 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:03 --> Total execution time: 0.5954
INFO - 2016-08-12 14:36:07 --> Config Class Initialized
INFO - 2016-08-12 14:36:07 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:07 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:07 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:07 --> URI Class Initialized
INFO - 2016-08-12 14:36:07 --> Router Class Initialized
INFO - 2016-08-12 14:36:07 --> Output Class Initialized
INFO - 2016-08-12 14:36:07 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:07 --> Input Class Initialized
INFO - 2016-08-12 14:36:07 --> Language Class Initialized
INFO - 2016-08-12 14:36:07 --> Loader Class Initialized
INFO - 2016-08-12 14:36:07 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:07 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:07 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:07 --> Email Class Initialized
INFO - 2016-08-12 14:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:07 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:07 --> Model Class Initialized
INFO - 2016-08-12 14:36:07 --> Controller Class Initialized
INFO - 2016-08-12 14:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 14:36:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:36:07 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:07 --> Total execution time: 0.8129
INFO - 2016-08-12 14:36:10 --> Config Class Initialized
INFO - 2016-08-12 14:36:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:10 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:10 --> URI Class Initialized
INFO - 2016-08-12 14:36:10 --> Router Class Initialized
INFO - 2016-08-12 14:36:10 --> Output Class Initialized
INFO - 2016-08-12 14:36:10 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:10 --> Input Class Initialized
INFO - 2016-08-12 14:36:10 --> Language Class Initialized
INFO - 2016-08-12 14:36:10 --> Loader Class Initialized
INFO - 2016-08-12 14:36:10 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:10 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:10 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:10 --> Email Class Initialized
INFO - 2016-08-12 14:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:10 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:10 --> Model Class Initialized
INFO - 2016-08-12 14:36:10 --> Controller Class Initialized
INFO - 2016-08-12 14:36:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:36:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:36:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 14:36:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:36:10 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:10 --> Total execution time: 0.5001
INFO - 2016-08-12 14:36:12 --> Config Class Initialized
INFO - 2016-08-12 14:36:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:12 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:12 --> URI Class Initialized
INFO - 2016-08-12 14:36:12 --> Router Class Initialized
INFO - 2016-08-12 14:36:12 --> Output Class Initialized
INFO - 2016-08-12 14:36:12 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:12 --> Input Class Initialized
INFO - 2016-08-12 14:36:12 --> Language Class Initialized
INFO - 2016-08-12 14:36:12 --> Loader Class Initialized
INFO - 2016-08-12 14:36:12 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:12 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:12 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:12 --> Email Class Initialized
INFO - 2016-08-12 14:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:13 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:13 --> Model Class Initialized
INFO - 2016-08-12 14:36:13 --> Controller Class Initialized
INFO - 2016-08-12 14:36:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:36:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:36:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 14:36:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:36:13 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:13 --> Total execution time: 0.5768
INFO - 2016-08-12 14:36:39 --> Config Class Initialized
INFO - 2016-08-12 14:36:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:39 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:39 --> URI Class Initialized
INFO - 2016-08-12 14:36:40 --> Router Class Initialized
INFO - 2016-08-12 14:36:40 --> Output Class Initialized
INFO - 2016-08-12 14:36:40 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:40 --> Input Class Initialized
INFO - 2016-08-12 14:36:40 --> Language Class Initialized
INFO - 2016-08-12 14:36:40 --> Loader Class Initialized
INFO - 2016-08-12 14:36:40 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:40 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:40 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:40 --> Email Class Initialized
INFO - 2016-08-12 14:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:40 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:40 --> Model Class Initialized
INFO - 2016-08-12 14:36:40 --> Controller Class Initialized
DEBUG - 2016-08-12 14:36:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:36:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:36:40 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:36:41 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:41 --> Model Class Initialized
INFO - 2016-08-12 14:36:41 --> Config Class Initialized
INFO - 2016-08-12 14:36:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:41 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:41 --> URI Class Initialized
INFO - 2016-08-12 14:36:41 --> Router Class Initialized
INFO - 2016-08-12 14:36:41 --> Output Class Initialized
INFO - 2016-08-12 14:36:41 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:41 --> Input Class Initialized
INFO - 2016-08-12 14:36:41 --> Language Class Initialized
INFO - 2016-08-12 14:36:41 --> Loader Class Initialized
INFO - 2016-08-12 14:36:41 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:41 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:42 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:42 --> Email Class Initialized
INFO - 2016-08-12 14:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:42 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:42 --> Model Class Initialized
INFO - 2016-08-12 14:36:42 --> Controller Class Initialized
DEBUG - 2016-08-12 14:36:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:36:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:36:42 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:36:42 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:42 --> Model Class Initialized
INFO - 2016-08-12 14:36:42 --> Helper loaded: form_helper
INFO - 2016-08-12 14:36:42 --> Form Validation Class Initialized
INFO - 2016-08-12 14:36:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 14:36:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-12 14:36:43 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:43 --> Total execution time: 1.6362
INFO - 2016-08-12 14:36:47 --> Config Class Initialized
INFO - 2016-08-12 14:36:47 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:47 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:47 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:47 --> URI Class Initialized
INFO - 2016-08-12 14:36:47 --> Router Class Initialized
INFO - 2016-08-12 14:36:47 --> Output Class Initialized
INFO - 2016-08-12 14:36:47 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:47 --> Input Class Initialized
INFO - 2016-08-12 14:36:48 --> Language Class Initialized
INFO - 2016-08-12 14:36:48 --> Loader Class Initialized
INFO - 2016-08-12 14:36:48 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:48 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:48 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:48 --> Email Class Initialized
INFO - 2016-08-12 14:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:48 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:48 --> Model Class Initialized
INFO - 2016-08-12 14:36:48 --> Controller Class Initialized
DEBUG - 2016-08-12 14:36:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:36:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:36:48 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:36:48 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:36:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:48 --> Model Class Initialized
INFO - 2016-08-12 14:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 14:36:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:36:48 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:48 --> Total execution time: 0.8975
INFO - 2016-08-12 14:36:51 --> Config Class Initialized
INFO - 2016-08-12 14:36:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:51 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:51 --> URI Class Initialized
INFO - 2016-08-12 14:36:51 --> Router Class Initialized
INFO - 2016-08-12 14:36:51 --> Output Class Initialized
INFO - 2016-08-12 14:36:51 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:51 --> Input Class Initialized
INFO - 2016-08-12 14:36:51 --> Language Class Initialized
ERROR - 2016-08-12 14:36:51 --> 404 Page Not Found: Admin/index
INFO - 2016-08-12 14:36:55 --> Config Class Initialized
INFO - 2016-08-12 14:36:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:36:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:36:56 --> Utf8 Class Initialized
INFO - 2016-08-12 14:36:56 --> URI Class Initialized
INFO - 2016-08-12 14:36:56 --> Router Class Initialized
INFO - 2016-08-12 14:36:56 --> Output Class Initialized
INFO - 2016-08-12 14:36:56 --> Security Class Initialized
DEBUG - 2016-08-12 14:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:36:56 --> Input Class Initialized
INFO - 2016-08-12 14:36:56 --> Language Class Initialized
INFO - 2016-08-12 14:36:56 --> Loader Class Initialized
INFO - 2016-08-12 14:36:56 --> Helper loaded: url_helper
INFO - 2016-08-12 14:36:56 --> Helper loaded: date_helper
INFO - 2016-08-12 14:36:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:36:56 --> Database Driver Class Initialized
INFO - 2016-08-12 14:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:36:56 --> Email Class Initialized
INFO - 2016-08-12 14:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:36:56 --> Pagination Class Initialized
INFO - 2016-08-12 14:36:56 --> Model Class Initialized
INFO - 2016-08-12 14:36:56 --> Controller Class Initialized
DEBUG - 2016-08-12 14:36:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:36:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:36:56 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:36:56 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:36:56 --> Model Class Initialized
INFO - 2016-08-12 14:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 14:36:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:36:56 --> Final output sent to browser
DEBUG - 2016-08-12 14:36:56 --> Total execution time: 0.6334
INFO - 2016-08-12 14:37:00 --> Config Class Initialized
INFO - 2016-08-12 14:37:00 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:37:00 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:37:00 --> Utf8 Class Initialized
INFO - 2016-08-12 14:37:00 --> URI Class Initialized
INFO - 2016-08-12 14:37:00 --> Router Class Initialized
INFO - 2016-08-12 14:37:00 --> Output Class Initialized
INFO - 2016-08-12 14:37:00 --> Security Class Initialized
DEBUG - 2016-08-12 14:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:37:00 --> Input Class Initialized
INFO - 2016-08-12 14:37:00 --> Language Class Initialized
INFO - 2016-08-12 14:37:00 --> Loader Class Initialized
INFO - 2016-08-12 14:37:00 --> Helper loaded: url_helper
INFO - 2016-08-12 14:37:00 --> Helper loaded: date_helper
INFO - 2016-08-12 14:37:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:37:00 --> Database Driver Class Initialized
INFO - 2016-08-12 14:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:37:00 --> Email Class Initialized
INFO - 2016-08-12 14:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:37:00 --> Pagination Class Initialized
INFO - 2016-08-12 14:37:00 --> Model Class Initialized
INFO - 2016-08-12 14:37:00 --> Controller Class Initialized
DEBUG - 2016-08-12 14:37:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:37:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:37:00 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:37:00 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:00 --> Model Class Initialized
INFO - 2016-08-12 14:37:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:37:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:37:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:37:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 14:37:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:37:01 --> Final output sent to browser
DEBUG - 2016-08-12 14:37:01 --> Total execution time: 0.6880
INFO - 2016-08-12 14:37:03 --> Config Class Initialized
INFO - 2016-08-12 14:37:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:37:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:37:03 --> Utf8 Class Initialized
INFO - 2016-08-12 14:37:03 --> URI Class Initialized
INFO - 2016-08-12 14:37:03 --> Router Class Initialized
INFO - 2016-08-12 14:37:03 --> Output Class Initialized
INFO - 2016-08-12 14:37:03 --> Security Class Initialized
DEBUG - 2016-08-12 14:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:37:03 --> Input Class Initialized
INFO - 2016-08-12 14:37:03 --> Language Class Initialized
INFO - 2016-08-12 14:37:03 --> Loader Class Initialized
INFO - 2016-08-12 14:37:03 --> Helper loaded: url_helper
INFO - 2016-08-12 14:37:03 --> Helper loaded: date_helper
INFO - 2016-08-12 14:37:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:37:03 --> Database Driver Class Initialized
INFO - 2016-08-12 14:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:37:03 --> Email Class Initialized
INFO - 2016-08-12 14:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:37:03 --> Pagination Class Initialized
INFO - 2016-08-12 14:37:03 --> Model Class Initialized
INFO - 2016-08-12 14:37:03 --> Controller Class Initialized
DEBUG - 2016-08-12 14:37:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:37:03 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:37:03 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:04 --> Model Class Initialized
INFO - 2016-08-12 14:37:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:37:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:37:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:37:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 14:37:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:37:04 --> Final output sent to browser
DEBUG - 2016-08-12 14:37:04 --> Total execution time: 0.8590
INFO - 2016-08-12 14:37:11 --> Config Class Initialized
INFO - 2016-08-12 14:37:11 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:37:11 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:37:11 --> Utf8 Class Initialized
INFO - 2016-08-12 14:37:11 --> URI Class Initialized
INFO - 2016-08-12 14:37:11 --> Router Class Initialized
INFO - 2016-08-12 14:37:11 --> Output Class Initialized
INFO - 2016-08-12 14:37:11 --> Security Class Initialized
DEBUG - 2016-08-12 14:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:37:11 --> Input Class Initialized
INFO - 2016-08-12 14:37:11 --> Language Class Initialized
INFO - 2016-08-12 14:37:11 --> Loader Class Initialized
INFO - 2016-08-12 14:37:11 --> Helper loaded: url_helper
INFO - 2016-08-12 14:37:11 --> Helper loaded: date_helper
INFO - 2016-08-12 14:37:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:37:11 --> Database Driver Class Initialized
INFO - 2016-08-12 14:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:37:11 --> Email Class Initialized
INFO - 2016-08-12 14:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:37:11 --> Pagination Class Initialized
INFO - 2016-08-12 14:37:11 --> Model Class Initialized
INFO - 2016-08-12 14:37:11 --> Controller Class Initialized
DEBUG - 2016-08-12 14:37:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:37:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:37:11 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:37:11 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:11 --> Model Class Initialized
INFO - 2016-08-12 14:37:11 --> Helper loaded: form_helper
INFO - 2016-08-12 14:37:11 --> Form Validation Class Initialized
INFO - 2016-08-12 14:37:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 14:37:12 --> Config Class Initialized
INFO - 2016-08-12 14:37:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:37:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:37:12 --> Utf8 Class Initialized
INFO - 2016-08-12 14:37:12 --> URI Class Initialized
INFO - 2016-08-12 14:37:12 --> Router Class Initialized
INFO - 2016-08-12 14:37:12 --> Output Class Initialized
INFO - 2016-08-12 14:37:12 --> Security Class Initialized
DEBUG - 2016-08-12 14:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:37:12 --> Input Class Initialized
INFO - 2016-08-12 14:37:12 --> Language Class Initialized
INFO - 2016-08-12 14:37:12 --> Loader Class Initialized
INFO - 2016-08-12 14:37:12 --> Helper loaded: url_helper
INFO - 2016-08-12 14:37:12 --> Helper loaded: date_helper
INFO - 2016-08-12 14:37:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:37:12 --> Database Driver Class Initialized
INFO - 2016-08-12 14:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:37:12 --> Email Class Initialized
INFO - 2016-08-12 14:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:37:12 --> Pagination Class Initialized
INFO - 2016-08-12 14:37:12 --> Model Class Initialized
INFO - 2016-08-12 14:37:12 --> Controller Class Initialized
DEBUG - 2016-08-12 14:37:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:37:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:37:12 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:37:12 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:37:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:12 --> Model Class Initialized
INFO - 2016-08-12 14:37:12 --> Helper loaded: form_helper
INFO - 2016-08-12 14:37:12 --> Form Validation Class Initialized
INFO - 2016-08-12 14:37:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 14:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-12 14:37:12 --> Final output sent to browser
DEBUG - 2016-08-12 14:37:12 --> Total execution time: 0.7071
INFO - 2016-08-12 14:37:14 --> Config Class Initialized
INFO - 2016-08-12 14:37:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:37:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:37:14 --> Utf8 Class Initialized
INFO - 2016-08-12 14:37:14 --> URI Class Initialized
INFO - 2016-08-12 14:37:14 --> Router Class Initialized
INFO - 2016-08-12 14:37:14 --> Output Class Initialized
INFO - 2016-08-12 14:37:14 --> Security Class Initialized
DEBUG - 2016-08-12 14:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:37:14 --> Input Class Initialized
INFO - 2016-08-12 14:37:14 --> Language Class Initialized
INFO - 2016-08-12 14:37:14 --> Loader Class Initialized
INFO - 2016-08-12 14:37:14 --> Helper loaded: url_helper
INFO - 2016-08-12 14:37:14 --> Helper loaded: date_helper
INFO - 2016-08-12 14:37:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:37:14 --> Database Driver Class Initialized
INFO - 2016-08-12 14:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:37:14 --> Email Class Initialized
INFO - 2016-08-12 14:37:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:37:14 --> Pagination Class Initialized
INFO - 2016-08-12 14:37:14 --> Model Class Initialized
INFO - 2016-08-12 14:37:14 --> Controller Class Initialized
DEBUG - 2016-08-12 14:37:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:37:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:37:14 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:37:15 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:37:15 --> Model Class Initialized
INFO - 2016-08-12 14:37:15 --> Helper loaded: form_helper
INFO - 2016-08-12 14:37:15 --> Form Validation Class Initialized
INFO - 2016-08-12 14:37:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 14:37:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-12 14:37:15 --> Final output sent to browser
DEBUG - 2016-08-12 14:37:15 --> Total execution time: 0.6506
INFO - 2016-08-12 14:42:41 --> Config Class Initialized
INFO - 2016-08-12 14:42:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:42:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:42:42 --> Utf8 Class Initialized
INFO - 2016-08-12 14:42:42 --> URI Class Initialized
INFO - 2016-08-12 14:42:42 --> Router Class Initialized
INFO - 2016-08-12 14:42:42 --> Output Class Initialized
INFO - 2016-08-12 14:42:42 --> Security Class Initialized
DEBUG - 2016-08-12 14:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:42:42 --> Input Class Initialized
INFO - 2016-08-12 14:42:42 --> Language Class Initialized
INFO - 2016-08-12 14:42:42 --> Loader Class Initialized
INFO - 2016-08-12 14:42:42 --> Helper loaded: url_helper
INFO - 2016-08-12 14:42:42 --> Helper loaded: date_helper
INFO - 2016-08-12 14:42:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:42:42 --> Database Driver Class Initialized
INFO - 2016-08-12 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:42:42 --> Email Class Initialized
INFO - 2016-08-12 14:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:42:42 --> Pagination Class Initialized
INFO - 2016-08-12 14:42:42 --> Model Class Initialized
INFO - 2016-08-12 14:42:42 --> Controller Class Initialized
INFO - 2016-08-12 14:42:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:42:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:42:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 14:42:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:42:42 --> Final output sent to browser
DEBUG - 2016-08-12 14:42:42 --> Total execution time: 0.7674
INFO - 2016-08-12 14:42:43 --> Config Class Initialized
INFO - 2016-08-12 14:42:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:42:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:42:43 --> Utf8 Class Initialized
INFO - 2016-08-12 14:42:43 --> URI Class Initialized
INFO - 2016-08-12 14:42:43 --> Router Class Initialized
INFO - 2016-08-12 14:42:43 --> Output Class Initialized
INFO - 2016-08-12 14:42:43 --> Security Class Initialized
DEBUG - 2016-08-12 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:42:43 --> Input Class Initialized
INFO - 2016-08-12 14:42:43 --> Language Class Initialized
ERROR - 2016-08-12 14:42:43 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 14:44:33 --> Config Class Initialized
INFO - 2016-08-12 14:44:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:44:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:44:33 --> Utf8 Class Initialized
INFO - 2016-08-12 14:44:33 --> URI Class Initialized
INFO - 2016-08-12 14:44:33 --> Router Class Initialized
INFO - 2016-08-12 14:44:33 --> Output Class Initialized
INFO - 2016-08-12 14:44:33 --> Security Class Initialized
DEBUG - 2016-08-12 14:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:44:34 --> Input Class Initialized
INFO - 2016-08-12 14:44:34 --> Language Class Initialized
INFO - 2016-08-12 14:44:34 --> Loader Class Initialized
INFO - 2016-08-12 14:44:34 --> Helper loaded: url_helper
INFO - 2016-08-12 14:44:34 --> Helper loaded: date_helper
INFO - 2016-08-12 14:44:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:44:34 --> Database Driver Class Initialized
INFO - 2016-08-12 14:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:44:34 --> Email Class Initialized
INFO - 2016-08-12 14:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:44:34 --> Pagination Class Initialized
INFO - 2016-08-12 14:44:34 --> Model Class Initialized
INFO - 2016-08-12 14:44:34 --> Controller Class Initialized
DEBUG - 2016-08-12 14:44:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:44:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:44:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:44:34 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:44:34 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:44:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:44:34 --> Model Class Initialized
INFO - 2016-08-12 14:44:34 --> Helper loaded: form_helper
INFO - 2016-08-12 14:44:34 --> Form Validation Class Initialized
INFO - 2016-08-12 14:44:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 14:44:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 14:44:35 --> Config Class Initialized
INFO - 2016-08-12 14:44:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:44:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:44:35 --> Utf8 Class Initialized
INFO - 2016-08-12 14:44:35 --> URI Class Initialized
INFO - 2016-08-12 14:44:35 --> Router Class Initialized
INFO - 2016-08-12 14:44:35 --> Output Class Initialized
INFO - 2016-08-12 14:44:35 --> Security Class Initialized
DEBUG - 2016-08-12 14:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:44:35 --> Input Class Initialized
INFO - 2016-08-12 14:44:35 --> Language Class Initialized
INFO - 2016-08-12 14:44:35 --> Loader Class Initialized
INFO - 2016-08-12 14:44:35 --> Helper loaded: url_helper
INFO - 2016-08-12 14:44:35 --> Helper loaded: date_helper
INFO - 2016-08-12 14:44:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:44:35 --> Database Driver Class Initialized
INFO - 2016-08-12 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:44:35 --> Email Class Initialized
INFO - 2016-08-12 14:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:44:35 --> Pagination Class Initialized
INFO - 2016-08-12 14:44:35 --> Model Class Initialized
INFO - 2016-08-12 14:44:35 --> Controller Class Initialized
DEBUG - 2016-08-12 14:44:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:44:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:44:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:44:35 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:44:35 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:44:35 --> Model Class Initialized
INFO - 2016-08-12 14:44:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:44:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:44:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:44:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 14:44:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:44:35 --> Final output sent to browser
DEBUG - 2016-08-12 14:44:35 --> Total execution time: 0.7341
INFO - 2016-08-12 14:45:01 --> Config Class Initialized
INFO - 2016-08-12 14:45:02 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:02 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:02 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:02 --> URI Class Initialized
INFO - 2016-08-12 14:45:02 --> Router Class Initialized
INFO - 2016-08-12 14:45:02 --> Output Class Initialized
INFO - 2016-08-12 14:45:02 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:02 --> Input Class Initialized
INFO - 2016-08-12 14:45:02 --> Language Class Initialized
INFO - 2016-08-12 14:45:02 --> Loader Class Initialized
INFO - 2016-08-12 14:45:02 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:02 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:02 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:02 --> Email Class Initialized
INFO - 2016-08-12 14:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:02 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:02 --> Model Class Initialized
INFO - 2016-08-12 14:45:02 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:02 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:02 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:02 --> Model Class Initialized
INFO - 2016-08-12 14:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:02 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:02 --> Total execution time: 0.7627
INFO - 2016-08-12 14:45:05 --> Config Class Initialized
INFO - 2016-08-12 14:45:05 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:05 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:05 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:05 --> URI Class Initialized
INFO - 2016-08-12 14:45:05 --> Router Class Initialized
INFO - 2016-08-12 14:45:05 --> Output Class Initialized
INFO - 2016-08-12 14:45:05 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:05 --> Input Class Initialized
INFO - 2016-08-12 14:45:05 --> Language Class Initialized
INFO - 2016-08-12 14:45:05 --> Loader Class Initialized
INFO - 2016-08-12 14:45:05 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:05 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:06 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:06 --> Email Class Initialized
INFO - 2016-08-12 14:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:06 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:06 --> Model Class Initialized
INFO - 2016-08-12 14:45:06 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:06 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:06 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:06 --> Model Class Initialized
INFO - 2016-08-12 14:45:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-12 14:45:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:06 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:06 --> Total execution time: 0.7160
INFO - 2016-08-12 14:45:10 --> Config Class Initialized
INFO - 2016-08-12 14:45:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:10 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:10 --> URI Class Initialized
INFO - 2016-08-12 14:45:10 --> Router Class Initialized
INFO - 2016-08-12 14:45:10 --> Output Class Initialized
INFO - 2016-08-12 14:45:10 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:10 --> Input Class Initialized
INFO - 2016-08-12 14:45:10 --> Language Class Initialized
INFO - 2016-08-12 14:45:10 --> Loader Class Initialized
INFO - 2016-08-12 14:45:10 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:10 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:10 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:10 --> Email Class Initialized
INFO - 2016-08-12 14:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:10 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:10 --> Model Class Initialized
INFO - 2016-08-12 14:45:10 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:10 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:10 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:10 --> Model Class Initialized
INFO - 2016-08-12 14:45:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:45:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:10 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:10 --> Total execution time: 0.6831
INFO - 2016-08-12 14:45:13 --> Config Class Initialized
INFO - 2016-08-12 14:45:13 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:13 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:13 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:13 --> URI Class Initialized
INFO - 2016-08-12 14:45:13 --> Router Class Initialized
INFO - 2016-08-12 14:45:13 --> Output Class Initialized
INFO - 2016-08-12 14:45:13 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:13 --> Input Class Initialized
INFO - 2016-08-12 14:45:13 --> Language Class Initialized
INFO - 2016-08-12 14:45:13 --> Loader Class Initialized
INFO - 2016-08-12 14:45:13 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:14 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:14 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:14 --> Email Class Initialized
INFO - 2016-08-12 14:45:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:14 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:14 --> Model Class Initialized
INFO - 2016-08-12 14:45:14 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:14 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:14 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:14 --> Model Class Initialized
INFO - 2016-08-12 14:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-12 14:45:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:14 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:14 --> Total execution time: 0.6912
INFO - 2016-08-12 14:45:24 --> Config Class Initialized
INFO - 2016-08-12 14:45:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:24 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:24 --> URI Class Initialized
INFO - 2016-08-12 14:45:24 --> Router Class Initialized
INFO - 2016-08-12 14:45:24 --> Output Class Initialized
INFO - 2016-08-12 14:45:24 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:24 --> Input Class Initialized
INFO - 2016-08-12 14:45:24 --> Language Class Initialized
INFO - 2016-08-12 14:45:24 --> Loader Class Initialized
INFO - 2016-08-12 14:45:24 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:24 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:24 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:24 --> Email Class Initialized
INFO - 2016-08-12 14:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:24 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:24 --> Model Class Initialized
INFO - 2016-08-12 14:45:24 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:25 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:25 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:25 --> Model Class Initialized
INFO - 2016-08-12 14:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:25 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:25 --> Total execution time: 0.7087
INFO - 2016-08-12 14:45:28 --> Config Class Initialized
INFO - 2016-08-12 14:45:28 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:28 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:28 --> URI Class Initialized
INFO - 2016-08-12 14:45:28 --> Router Class Initialized
INFO - 2016-08-12 14:45:28 --> Output Class Initialized
INFO - 2016-08-12 14:45:28 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:28 --> Input Class Initialized
INFO - 2016-08-12 14:45:28 --> Language Class Initialized
INFO - 2016-08-12 14:45:28 --> Loader Class Initialized
INFO - 2016-08-12 14:45:28 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:28 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:28 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:29 --> Email Class Initialized
INFO - 2016-08-12 14:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:29 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:29 --> Model Class Initialized
INFO - 2016-08-12 14:45:29 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:29 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:29 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:29 --> Model Class Initialized
INFO - 2016-08-12 14:45:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-12 14:45:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:29 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:29 --> Total execution time: 0.7444
INFO - 2016-08-12 14:45:39 --> Config Class Initialized
INFO - 2016-08-12 14:45:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:39 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:39 --> URI Class Initialized
INFO - 2016-08-12 14:45:39 --> Router Class Initialized
INFO - 2016-08-12 14:45:39 --> Output Class Initialized
INFO - 2016-08-12 14:45:39 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:39 --> Input Class Initialized
INFO - 2016-08-12 14:45:39 --> Language Class Initialized
INFO - 2016-08-12 14:45:40 --> Loader Class Initialized
INFO - 2016-08-12 14:45:40 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:40 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:40 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:40 --> Email Class Initialized
INFO - 2016-08-12 14:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:40 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:40 --> Model Class Initialized
INFO - 2016-08-12 14:45:40 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:40 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:40 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:40 --> Model Class Initialized
INFO - 2016-08-12 14:45:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:45:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:40 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:40 --> Total execution time: 0.7424
INFO - 2016-08-12 14:45:43 --> Config Class Initialized
INFO - 2016-08-12 14:45:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:43 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:43 --> URI Class Initialized
INFO - 2016-08-12 14:45:43 --> Router Class Initialized
INFO - 2016-08-12 14:45:43 --> Output Class Initialized
INFO - 2016-08-12 14:45:43 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:43 --> Input Class Initialized
INFO - 2016-08-12 14:45:43 --> Language Class Initialized
INFO - 2016-08-12 14:45:43 --> Loader Class Initialized
INFO - 2016-08-12 14:45:43 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:43 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:43 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:43 --> Email Class Initialized
INFO - 2016-08-12 14:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:43 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:43 --> Model Class Initialized
INFO - 2016-08-12 14:45:43 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:43 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:43 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:43 --> Model Class Initialized
INFO - 2016-08-12 14:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-12 14:45:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:43 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:43 --> Total execution time: 0.6906
INFO - 2016-08-12 14:45:50 --> Config Class Initialized
INFO - 2016-08-12 14:45:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:50 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:50 --> URI Class Initialized
INFO - 2016-08-12 14:45:50 --> Router Class Initialized
INFO - 2016-08-12 14:45:50 --> Output Class Initialized
INFO - 2016-08-12 14:45:50 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:50 --> Input Class Initialized
INFO - 2016-08-12 14:45:50 --> Language Class Initialized
INFO - 2016-08-12 14:45:50 --> Loader Class Initialized
INFO - 2016-08-12 14:45:50 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:50 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:50 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:50 --> Email Class Initialized
INFO - 2016-08-12 14:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:50 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:50 --> Model Class Initialized
INFO - 2016-08-12 14:45:50 --> Controller Class Initialized
DEBUG - 2016-08-12 14:45:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:45:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:45:50 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:45:50 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:45:50 --> Model Class Initialized
INFO - 2016-08-12 14:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:45:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:45:51 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:51 --> Total execution time: 0.7329
INFO - 2016-08-12 14:45:53 --> Config Class Initialized
INFO - 2016-08-12 14:45:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:53 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:53 --> URI Class Initialized
INFO - 2016-08-12 14:45:53 --> Router Class Initialized
INFO - 2016-08-12 14:45:53 --> Output Class Initialized
INFO - 2016-08-12 14:45:53 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:53 --> Input Class Initialized
INFO - 2016-08-12 14:45:53 --> Language Class Initialized
INFO - 2016-08-12 14:45:53 --> Loader Class Initialized
INFO - 2016-08-12 14:45:53 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:53 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:54 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:54 --> Email Class Initialized
INFO - 2016-08-12 14:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:54 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:54 --> Model Class Initialized
INFO - 2016-08-12 14:45:54 --> Controller Class Initialized
INFO - 2016-08-12 14:45:54 --> Model Class Initialized
INFO - 2016-08-12 14:45:54 --> Helper loaded: text_helper
INFO - 2016-08-12 14:45:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:45:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:45:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:45:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:45:54 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:54 --> Total execution time: 0.6120
INFO - 2016-08-12 14:45:58 --> Config Class Initialized
INFO - 2016-08-12 14:45:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:45:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:45:58 --> Utf8 Class Initialized
INFO - 2016-08-12 14:45:58 --> URI Class Initialized
INFO - 2016-08-12 14:45:58 --> Router Class Initialized
INFO - 2016-08-12 14:45:58 --> Output Class Initialized
INFO - 2016-08-12 14:45:59 --> Security Class Initialized
DEBUG - 2016-08-12 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:45:59 --> Input Class Initialized
INFO - 2016-08-12 14:45:59 --> Language Class Initialized
INFO - 2016-08-12 14:45:59 --> Loader Class Initialized
INFO - 2016-08-12 14:45:59 --> Helper loaded: url_helper
INFO - 2016-08-12 14:45:59 --> Helper loaded: date_helper
INFO - 2016-08-12 14:45:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:45:59 --> Database Driver Class Initialized
INFO - 2016-08-12 14:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:45:59 --> Email Class Initialized
INFO - 2016-08-12 14:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:45:59 --> Pagination Class Initialized
INFO - 2016-08-12 14:45:59 --> Model Class Initialized
INFO - 2016-08-12 14:45:59 --> Controller Class Initialized
INFO - 2016-08-12 14:45:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:45:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:45:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 14:45:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:45:59 --> Final output sent to browser
DEBUG - 2016-08-12 14:45:59 --> Total execution time: 0.7299
INFO - 2016-08-12 14:46:19 --> Config Class Initialized
INFO - 2016-08-12 14:46:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:46:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:46:19 --> Utf8 Class Initialized
INFO - 2016-08-12 14:46:19 --> URI Class Initialized
INFO - 2016-08-12 14:46:19 --> Router Class Initialized
INFO - 2016-08-12 14:46:19 --> Output Class Initialized
INFO - 2016-08-12 14:46:19 --> Security Class Initialized
DEBUG - 2016-08-12 14:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:46:19 --> Input Class Initialized
INFO - 2016-08-12 14:46:19 --> Language Class Initialized
INFO - 2016-08-12 14:46:19 --> Loader Class Initialized
INFO - 2016-08-12 14:46:19 --> Helper loaded: url_helper
INFO - 2016-08-12 14:46:19 --> Helper loaded: date_helper
INFO - 2016-08-12 14:46:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:46:19 --> Database Driver Class Initialized
INFO - 2016-08-12 14:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:46:19 --> Email Class Initialized
INFO - 2016-08-12 14:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:46:19 --> Pagination Class Initialized
INFO - 2016-08-12 14:46:19 --> Model Class Initialized
INFO - 2016-08-12 14:46:19 --> Controller Class Initialized
DEBUG - 2016-08-12 14:46:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:46:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:46:19 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:46:19 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:19 --> Model Class Initialized
INFO - 2016-08-12 14:46:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:46:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:46:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:46:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-12 14:46:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:46:19 --> Final output sent to browser
DEBUG - 2016-08-12 14:46:19 --> Total execution time: 0.7795
INFO - 2016-08-12 14:46:39 --> Config Class Initialized
INFO - 2016-08-12 14:46:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:46:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:46:39 --> Utf8 Class Initialized
INFO - 2016-08-12 14:46:39 --> URI Class Initialized
INFO - 2016-08-12 14:46:39 --> Router Class Initialized
INFO - 2016-08-12 14:46:39 --> Output Class Initialized
INFO - 2016-08-12 14:46:39 --> Security Class Initialized
DEBUG - 2016-08-12 14:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:46:39 --> Input Class Initialized
INFO - 2016-08-12 14:46:39 --> Language Class Initialized
INFO - 2016-08-12 14:46:39 --> Loader Class Initialized
INFO - 2016-08-12 14:46:39 --> Helper loaded: url_helper
INFO - 2016-08-12 14:46:39 --> Helper loaded: date_helper
INFO - 2016-08-12 14:46:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:46:40 --> Database Driver Class Initialized
INFO - 2016-08-12 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:46:40 --> Email Class Initialized
INFO - 2016-08-12 14:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:46:40 --> Pagination Class Initialized
INFO - 2016-08-12 14:46:40 --> Model Class Initialized
INFO - 2016-08-12 14:46:40 --> Controller Class Initialized
DEBUG - 2016-08-12 14:46:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:46:40 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:46:40 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:40 --> Model Class Initialized
INFO - 2016-08-12 14:46:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:46:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:46:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:46:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 14:46:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:46:40 --> Final output sent to browser
DEBUG - 2016-08-12 14:46:40 --> Total execution time: 0.7593
INFO - 2016-08-12 14:46:51 --> Config Class Initialized
INFO - 2016-08-12 14:46:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:46:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:46:51 --> Utf8 Class Initialized
INFO - 2016-08-12 14:46:51 --> URI Class Initialized
INFO - 2016-08-12 14:46:51 --> Router Class Initialized
INFO - 2016-08-12 14:46:51 --> Output Class Initialized
INFO - 2016-08-12 14:46:51 --> Security Class Initialized
DEBUG - 2016-08-12 14:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:46:51 --> Input Class Initialized
INFO - 2016-08-12 14:46:51 --> Language Class Initialized
INFO - 2016-08-12 14:46:51 --> Loader Class Initialized
INFO - 2016-08-12 14:46:51 --> Helper loaded: url_helper
INFO - 2016-08-12 14:46:51 --> Helper loaded: date_helper
INFO - 2016-08-12 14:46:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:46:51 --> Database Driver Class Initialized
INFO - 2016-08-12 14:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:46:51 --> Email Class Initialized
INFO - 2016-08-12 14:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:46:51 --> Pagination Class Initialized
INFO - 2016-08-12 14:46:51 --> Model Class Initialized
INFO - 2016-08-12 14:46:51 --> Controller Class Initialized
DEBUG - 2016-08-12 14:46:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:46:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:46:51 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:46:51 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:46:51 --> Model Class Initialized
INFO - 2016-08-12 14:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:46:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-12 14:46:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:46:52 --> Final output sent to browser
DEBUG - 2016-08-12 14:46:52 --> Total execution time: 0.7168
INFO - 2016-08-12 14:47:10 --> Config Class Initialized
INFO - 2016-08-12 14:47:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:47:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:47:10 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:10 --> URI Class Initialized
INFO - 2016-08-12 14:47:10 --> Router Class Initialized
INFO - 2016-08-12 14:47:10 --> Output Class Initialized
INFO - 2016-08-12 14:47:10 --> Security Class Initialized
DEBUG - 2016-08-12 14:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:47:10 --> Input Class Initialized
INFO - 2016-08-12 14:47:10 --> Language Class Initialized
INFO - 2016-08-12 14:47:10 --> Loader Class Initialized
INFO - 2016-08-12 14:47:10 --> Helper loaded: url_helper
INFO - 2016-08-12 14:47:10 --> Helper loaded: date_helper
INFO - 2016-08-12 14:47:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:47:10 --> Database Driver Class Initialized
INFO - 2016-08-12 14:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:47:11 --> Email Class Initialized
INFO - 2016-08-12 14:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:47:11 --> Pagination Class Initialized
INFO - 2016-08-12 14:47:11 --> Model Class Initialized
INFO - 2016-08-12 14:47:11 --> Controller Class Initialized
INFO - 2016-08-12 14:47:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:47:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:47:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-12 14:47:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:47:11 --> Final output sent to browser
DEBUG - 2016-08-12 14:47:11 --> Total execution time: 0.5910
INFO - 2016-08-12 14:47:14 --> Config Class Initialized
INFO - 2016-08-12 14:47:14 --> Config Class Initialized
INFO - 2016-08-12 14:47:14 --> Config Class Initialized
INFO - 2016-08-12 14:47:14 --> Config Class Initialized
INFO - 2016-08-12 14:47:14 --> Hooks Class Initialized
INFO - 2016-08-12 14:47:14 --> Hooks Class Initialized
INFO - 2016-08-12 14:47:14 --> Hooks Class Initialized
INFO - 2016-08-12 14:47:14 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-12 14:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-12 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:47:14 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:14 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:14 --> Utf8 Class Initialized
DEBUG - 2016-08-12 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:47:14 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:14 --> URI Class Initialized
INFO - 2016-08-12 14:47:14 --> URI Class Initialized
INFO - 2016-08-12 14:47:14 --> URI Class Initialized
INFO - 2016-08-12 14:47:14 --> URI Class Initialized
INFO - 2016-08-12 14:47:14 --> Router Class Initialized
INFO - 2016-08-12 14:47:14 --> Output Class Initialized
INFO - 2016-08-12 14:47:14 --> Router Class Initialized
INFO - 2016-08-12 14:47:14 --> Router Class Initialized
INFO - 2016-08-12 14:47:14 --> Router Class Initialized
INFO - 2016-08-12 14:47:14 --> Security Class Initialized
INFO - 2016-08-12 14:47:14 --> Output Class Initialized
INFO - 2016-08-12 14:47:14 --> Output Class Initialized
INFO - 2016-08-12 14:47:14 --> Output Class Initialized
DEBUG - 2016-08-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:47:14 --> Security Class Initialized
INFO - 2016-08-12 14:47:14 --> Security Class Initialized
INFO - 2016-08-12 14:47:14 --> Security Class Initialized
INFO - 2016-08-12 14:47:14 --> Input Class Initialized
DEBUG - 2016-08-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:47:14 --> Input Class Initialized
INFO - 2016-08-12 14:47:14 --> Input Class Initialized
INFO - 2016-08-12 14:47:14 --> Input Class Initialized
INFO - 2016-08-12 14:47:14 --> Language Class Initialized
INFO - 2016-08-12 14:47:14 --> Language Class Initialized
ERROR - 2016-08-12 14:47:14 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 14:47:14 --> Language Class Initialized
INFO - 2016-08-12 14:47:14 --> Config Class Initialized
INFO - 2016-08-12 14:47:14 --> Hooks Class Initialized
INFO - 2016-08-12 14:47:14 --> Language Class Initialized
ERROR - 2016-08-12 14:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-12 14:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-12 14:47:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-08-12 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:47:14 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:14 --> URI Class Initialized
INFO - 2016-08-12 14:47:14 --> Router Class Initialized
INFO - 2016-08-12 14:47:14 --> Output Class Initialized
INFO - 2016-08-12 14:47:14 --> Security Class Initialized
DEBUG - 2016-08-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:47:14 --> Input Class Initialized
INFO - 2016-08-12 14:47:14 --> Language Class Initialized
INFO - 2016-08-12 14:47:14 --> Loader Class Initialized
INFO - 2016-08-12 14:47:14 --> Helper loaded: url_helper
INFO - 2016-08-12 14:47:14 --> Helper loaded: date_helper
INFO - 2016-08-12 14:47:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:47:14 --> Database Driver Class Initialized
INFO - 2016-08-12 14:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:47:14 --> Email Class Initialized
INFO - 2016-08-12 14:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:47:14 --> Pagination Class Initialized
INFO - 2016-08-12 14:47:14 --> Model Class Initialized
INFO - 2016-08-12 14:47:14 --> Controller Class Initialized
INFO - 2016-08-12 14:47:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-12 14:47:15 --> Final output sent to browser
DEBUG - 2016-08-12 14:47:15 --> Total execution time: 0.5628
INFO - 2016-08-12 14:47:41 --> Config Class Initialized
INFO - 2016-08-12 14:47:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:47:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:47:41 --> Utf8 Class Initialized
INFO - 2016-08-12 14:47:41 --> URI Class Initialized
INFO - 2016-08-12 14:47:41 --> Router Class Initialized
INFO - 2016-08-12 14:47:42 --> Output Class Initialized
INFO - 2016-08-12 14:47:42 --> Security Class Initialized
DEBUG - 2016-08-12 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:47:42 --> Input Class Initialized
INFO - 2016-08-12 14:47:42 --> Language Class Initialized
INFO - 2016-08-12 14:47:42 --> Loader Class Initialized
INFO - 2016-08-12 14:47:42 --> Helper loaded: url_helper
INFO - 2016-08-12 14:47:42 --> Helper loaded: date_helper
INFO - 2016-08-12 14:47:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:47:42 --> Database Driver Class Initialized
INFO - 2016-08-12 14:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:47:42 --> Email Class Initialized
INFO - 2016-08-12 14:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:47:42 --> Pagination Class Initialized
INFO - 2016-08-12 14:47:42 --> Model Class Initialized
INFO - 2016-08-12 14:47:42 --> Controller Class Initialized
DEBUG - 2016-08-12 14:47:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:47:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:47:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:47:42 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:47:42 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:47:42 --> Model Class Initialized
INFO - 2016-08-12 14:47:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:47:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:47:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:47:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 14:47:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:47:42 --> Final output sent to browser
DEBUG - 2016-08-12 14:47:42 --> Total execution time: 0.8707
INFO - 2016-08-12 14:52:16 --> Config Class Initialized
INFO - 2016-08-12 14:52:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:16 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:16 --> URI Class Initialized
INFO - 2016-08-12 14:52:16 --> Router Class Initialized
INFO - 2016-08-12 14:52:16 --> Output Class Initialized
INFO - 2016-08-12 14:52:16 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:16 --> Input Class Initialized
INFO - 2016-08-12 14:52:16 --> Language Class Initialized
INFO - 2016-08-12 14:52:16 --> Loader Class Initialized
INFO - 2016-08-12 14:52:16 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:16 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:16 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:16 --> Email Class Initialized
INFO - 2016-08-12 14:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:16 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:17 --> Model Class Initialized
INFO - 2016-08-12 14:52:17 --> Controller Class Initialized
INFO - 2016-08-12 14:52:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:52:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:52:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-12 14:52:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:52:17 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:17 --> Total execution time: 0.6914
INFO - 2016-08-12 14:52:18 --> Config Class Initialized
INFO - 2016-08-12 14:52:18 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:18 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:18 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:18 --> URI Class Initialized
INFO - 2016-08-12 14:52:18 --> Router Class Initialized
INFO - 2016-08-12 14:52:18 --> Output Class Initialized
INFO - 2016-08-12 14:52:18 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:18 --> Input Class Initialized
INFO - 2016-08-12 14:52:18 --> Language Class Initialized
ERROR - 2016-08-12 14:52:18 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 14:52:25 --> Config Class Initialized
INFO - 2016-08-12 14:52:25 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:25 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:25 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:25 --> URI Class Initialized
INFO - 2016-08-12 14:52:25 --> Router Class Initialized
INFO - 2016-08-12 14:52:25 --> Output Class Initialized
INFO - 2016-08-12 14:52:25 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:25 --> Input Class Initialized
INFO - 2016-08-12 14:52:25 --> Language Class Initialized
INFO - 2016-08-12 14:52:25 --> Loader Class Initialized
INFO - 2016-08-12 14:52:25 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:25 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:25 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:25 --> Email Class Initialized
INFO - 2016-08-12 14:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:25 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:25 --> Model Class Initialized
INFO - 2016-08-12 14:52:25 --> Controller Class Initialized
INFO - 2016-08-12 14:52:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:52:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:52:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 14:52:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:52:26 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:26 --> Total execution time: 0.5497
INFO - 2016-08-12 14:52:27 --> Config Class Initialized
INFO - 2016-08-12 14:52:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:27 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:28 --> URI Class Initialized
INFO - 2016-08-12 14:52:28 --> Router Class Initialized
INFO - 2016-08-12 14:52:28 --> Output Class Initialized
INFO - 2016-08-12 14:52:28 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:28 --> Input Class Initialized
INFO - 2016-08-12 14:52:28 --> Language Class Initialized
INFO - 2016-08-12 14:52:28 --> Loader Class Initialized
INFO - 2016-08-12 14:52:28 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:28 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:28 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:28 --> Email Class Initialized
INFO - 2016-08-12 14:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:28 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:28 --> Model Class Initialized
INFO - 2016-08-12 14:52:28 --> Controller Class Initialized
INFO - 2016-08-12 14:52:28 --> Model Class Initialized
INFO - 2016-08-12 14:52:28 --> Helper loaded: text_helper
INFO - 2016-08-12 14:52:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:52:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:52:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:52:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:52:28 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:28 --> Total execution time: 0.6208
INFO - 2016-08-12 14:52:36 --> Config Class Initialized
INFO - 2016-08-12 14:52:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:36 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:36 --> URI Class Initialized
INFO - 2016-08-12 14:52:36 --> Router Class Initialized
INFO - 2016-08-12 14:52:36 --> Output Class Initialized
INFO - 2016-08-12 14:52:36 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:36 --> Input Class Initialized
INFO - 2016-08-12 14:52:36 --> Language Class Initialized
INFO - 2016-08-12 14:52:36 --> Loader Class Initialized
INFO - 2016-08-12 14:52:36 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:36 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:36 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:36 --> Email Class Initialized
INFO - 2016-08-12 14:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:36 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:36 --> Model Class Initialized
INFO - 2016-08-12 14:52:36 --> Controller Class Initialized
DEBUG - 2016-08-12 14:52:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:52:37 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:52:37 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:37 --> Model Class Initialized
INFO - 2016-08-12 14:52:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:52:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:52:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:52:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 14:52:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:52:37 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:37 --> Total execution time: 1.5181
INFO - 2016-08-12 14:52:46 --> Config Class Initialized
INFO - 2016-08-12 14:52:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:46 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:46 --> URI Class Initialized
INFO - 2016-08-12 14:52:46 --> Router Class Initialized
INFO - 2016-08-12 14:52:46 --> Output Class Initialized
INFO - 2016-08-12 14:52:46 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:46 --> Input Class Initialized
INFO - 2016-08-12 14:52:46 --> Language Class Initialized
INFO - 2016-08-12 14:52:46 --> Loader Class Initialized
INFO - 2016-08-12 14:52:46 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:46 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:46 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:47 --> Email Class Initialized
INFO - 2016-08-12 14:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:47 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:47 --> Model Class Initialized
INFO - 2016-08-12 14:52:47 --> Controller Class Initialized
DEBUG - 2016-08-12 14:52:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:52:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:52:47 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:52:47 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:47 --> Model Class Initialized
INFO - 2016-08-12 14:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/update_pengguna.php
INFO - 2016-08-12 14:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:52:47 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:47 --> Total execution time: 1.2140
INFO - 2016-08-12 14:52:57 --> Config Class Initialized
INFO - 2016-08-12 14:52:57 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:57 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:57 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:57 --> URI Class Initialized
INFO - 2016-08-12 14:52:57 --> Router Class Initialized
INFO - 2016-08-12 14:52:57 --> Output Class Initialized
INFO - 2016-08-12 14:52:57 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:58 --> Input Class Initialized
INFO - 2016-08-12 14:52:58 --> Language Class Initialized
INFO - 2016-08-12 14:52:58 --> Loader Class Initialized
INFO - 2016-08-12 14:52:58 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:58 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:58 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:58 --> Email Class Initialized
INFO - 2016-08-12 14:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:58 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:58 --> Model Class Initialized
INFO - 2016-08-12 14:52:58 --> Controller Class Initialized
DEBUG - 2016-08-12 14:52:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:52:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:52:58 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:52:58 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:58 --> Model Class Initialized
INFO - 2016-08-12 14:52:58 --> Config Class Initialized
INFO - 2016-08-12 14:52:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:52:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:52:59 --> Utf8 Class Initialized
INFO - 2016-08-12 14:52:59 --> URI Class Initialized
INFO - 2016-08-12 14:52:59 --> Router Class Initialized
INFO - 2016-08-12 14:52:59 --> Output Class Initialized
INFO - 2016-08-12 14:52:59 --> Security Class Initialized
DEBUG - 2016-08-12 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:52:59 --> Input Class Initialized
INFO - 2016-08-12 14:52:59 --> Language Class Initialized
INFO - 2016-08-12 14:52:59 --> Loader Class Initialized
INFO - 2016-08-12 14:52:59 --> Helper loaded: url_helper
INFO - 2016-08-12 14:52:59 --> Helper loaded: date_helper
INFO - 2016-08-12 14:52:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:52:59 --> Database Driver Class Initialized
INFO - 2016-08-12 14:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:52:59 --> Email Class Initialized
INFO - 2016-08-12 14:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:52:59 --> Pagination Class Initialized
INFO - 2016-08-12 14:52:59 --> Model Class Initialized
INFO - 2016-08-12 14:52:59 --> Controller Class Initialized
DEBUG - 2016-08-12 14:52:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:52:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:52:59 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:52:59 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:52:59 --> Model Class Initialized
INFO - 2016-08-12 14:52:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:52:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:52:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:52:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 14:52:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:52:59 --> Final output sent to browser
DEBUG - 2016-08-12 14:52:59 --> Total execution time: 0.8853
INFO - 2016-08-12 14:53:08 --> Config Class Initialized
INFO - 2016-08-12 14:53:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:53:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:53:08 --> Utf8 Class Initialized
INFO - 2016-08-12 14:53:08 --> URI Class Initialized
INFO - 2016-08-12 14:53:08 --> Router Class Initialized
INFO - 2016-08-12 14:53:08 --> Output Class Initialized
INFO - 2016-08-12 14:53:08 --> Security Class Initialized
DEBUG - 2016-08-12 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:53:08 --> Input Class Initialized
INFO - 2016-08-12 14:53:08 --> Language Class Initialized
INFO - 2016-08-12 14:53:08 --> Loader Class Initialized
INFO - 2016-08-12 14:53:08 --> Helper loaded: url_helper
INFO - 2016-08-12 14:53:08 --> Helper loaded: date_helper
INFO - 2016-08-12 14:53:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:53:08 --> Database Driver Class Initialized
INFO - 2016-08-12 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:53:09 --> Email Class Initialized
INFO - 2016-08-12 14:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:53:09 --> Pagination Class Initialized
INFO - 2016-08-12 14:53:09 --> Model Class Initialized
INFO - 2016-08-12 14:53:09 --> Controller Class Initialized
DEBUG - 2016-08-12 14:53:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:53:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:53:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:53:09 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:53:09 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:53:09 --> Model Class Initialized
INFO - 2016-08-12 14:53:09 --> Final output sent to browser
DEBUG - 2016-08-12 14:53:09 --> Total execution time: 0.7850
INFO - 2016-08-12 14:53:09 --> Config Class Initialized
INFO - 2016-08-12 14:53:09 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:53:09 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:53:09 --> Utf8 Class Initialized
INFO - 2016-08-12 14:53:09 --> URI Class Initialized
INFO - 2016-08-12 14:53:09 --> Router Class Initialized
INFO - 2016-08-12 14:53:09 --> Output Class Initialized
INFO - 2016-08-12 14:53:09 --> Security Class Initialized
DEBUG - 2016-08-12 14:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:53:09 --> Input Class Initialized
INFO - 2016-08-12 14:53:09 --> Language Class Initialized
INFO - 2016-08-12 14:53:09 --> Loader Class Initialized
INFO - 2016-08-12 14:53:09 --> Helper loaded: url_helper
INFO - 2016-08-12 14:53:09 --> Helper loaded: date_helper
INFO - 2016-08-12 14:53:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:53:09 --> Database Driver Class Initialized
INFO - 2016-08-12 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:53:09 --> Email Class Initialized
INFO - 2016-08-12 14:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:53:09 --> Pagination Class Initialized
INFO - 2016-08-12 14:53:09 --> Model Class Initialized
INFO - 2016-08-12 14:53:09 --> Controller Class Initialized
DEBUG - 2016-08-12 14:53:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 14:53:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:53:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 14:53:10 --> Helper loaded: cookie_helper
INFO - 2016-08-12 14:53:10 --> Helper loaded: language_helper
DEBUG - 2016-08-12 14:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 14:53:10 --> Model Class Initialized
INFO - 2016-08-12 14:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 14:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 14:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 14:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 14:53:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 14:53:10 --> Final output sent to browser
DEBUG - 2016-08-12 14:53:10 --> Total execution time: 0.7784
INFO - 2016-08-12 14:53:19 --> Config Class Initialized
INFO - 2016-08-12 14:53:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 14:53:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 14:53:19 --> Utf8 Class Initialized
INFO - 2016-08-12 14:53:19 --> URI Class Initialized
INFO - 2016-08-12 14:53:19 --> Router Class Initialized
INFO - 2016-08-12 14:53:19 --> Output Class Initialized
INFO - 2016-08-12 14:53:19 --> Security Class Initialized
DEBUG - 2016-08-12 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 14:53:19 --> Input Class Initialized
INFO - 2016-08-12 14:53:19 --> Language Class Initialized
INFO - 2016-08-12 14:53:19 --> Loader Class Initialized
INFO - 2016-08-12 14:53:19 --> Helper loaded: url_helper
INFO - 2016-08-12 14:53:19 --> Helper loaded: date_helper
INFO - 2016-08-12 14:53:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 14:53:19 --> Database Driver Class Initialized
INFO - 2016-08-12 14:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 14:53:19 --> Email Class Initialized
INFO - 2016-08-12 14:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 14:53:19 --> Pagination Class Initialized
INFO - 2016-08-12 14:53:19 --> Model Class Initialized
INFO - 2016-08-12 14:53:19 --> Controller Class Initialized
INFO - 2016-08-12 14:53:19 --> Model Class Initialized
INFO - 2016-08-12 14:53:19 --> Helper loaded: text_helper
INFO - 2016-08-12 14:53:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 14:53:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 14:53:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 14:53:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 14:53:19 --> Final output sent to browser
DEBUG - 2016-08-12 14:53:19 --> Total execution time: 0.6816
INFO - 2016-08-12 15:50:17 --> Config Class Initialized
INFO - 2016-08-12 15:50:18 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:18 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:18 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:18 --> URI Class Initialized
INFO - 2016-08-12 15:50:18 --> Router Class Initialized
INFO - 2016-08-12 15:50:18 --> Output Class Initialized
INFO - 2016-08-12 15:50:18 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:19 --> Input Class Initialized
INFO - 2016-08-12 15:50:19 --> Language Class Initialized
INFO - 2016-08-12 15:50:19 --> Loader Class Initialized
INFO - 2016-08-12 15:50:19 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:19 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:19 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:19 --> Email Class Initialized
INFO - 2016-08-12 15:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:20 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:20 --> Model Class Initialized
INFO - 2016-08-12 15:50:20 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:20 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:20 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:20 --> Model Class Initialized
INFO - 2016-08-12 15:50:20 --> Config Class Initialized
INFO - 2016-08-12 15:50:20 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:20 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:20 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:20 --> URI Class Initialized
INFO - 2016-08-12 15:50:20 --> Router Class Initialized
INFO - 2016-08-12 15:50:20 --> Output Class Initialized
INFO - 2016-08-12 15:50:20 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:20 --> Input Class Initialized
INFO - 2016-08-12 15:50:20 --> Language Class Initialized
INFO - 2016-08-12 15:50:20 --> Loader Class Initialized
INFO - 2016-08-12 15:50:20 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:20 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:21 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:21 --> Email Class Initialized
INFO - 2016-08-12 15:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:21 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:21 --> Model Class Initialized
INFO - 2016-08-12 15:50:21 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:21 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:21 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:21 --> Model Class Initialized
INFO - 2016-08-12 15:50:21 --> Helper loaded: form_helper
INFO - 2016-08-12 15:50:21 --> Form Validation Class Initialized
INFO - 2016-08-12 15:50:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 15:50:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-12 15:50:21 --> Final output sent to browser
DEBUG - 2016-08-12 15:50:21 --> Total execution time: 0.8946
INFO - 2016-08-12 15:50:30 --> Config Class Initialized
INFO - 2016-08-12 15:50:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:30 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:30 --> URI Class Initialized
INFO - 2016-08-12 15:50:30 --> Router Class Initialized
INFO - 2016-08-12 15:50:30 --> Output Class Initialized
INFO - 2016-08-12 15:50:30 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:30 --> Input Class Initialized
INFO - 2016-08-12 15:50:30 --> Language Class Initialized
INFO - 2016-08-12 15:50:30 --> Loader Class Initialized
INFO - 2016-08-12 15:50:30 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:30 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:30 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:30 --> Email Class Initialized
INFO - 2016-08-12 15:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:30 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:30 --> Model Class Initialized
INFO - 2016-08-12 15:50:30 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:30 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:30 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:30 --> Model Class Initialized
INFO - 2016-08-12 15:50:30 --> Helper loaded: form_helper
INFO - 2016-08-12 15:50:30 --> Form Validation Class Initialized
INFO - 2016-08-12 15:50:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-12 15:50:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 15:50:31 --> Config Class Initialized
INFO - 2016-08-12 15:50:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:31 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:31 --> URI Class Initialized
INFO - 2016-08-12 15:50:31 --> Router Class Initialized
INFO - 2016-08-12 15:50:31 --> Output Class Initialized
INFO - 2016-08-12 15:50:31 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:31 --> Input Class Initialized
INFO - 2016-08-12 15:50:31 --> Language Class Initialized
INFO - 2016-08-12 15:50:31 --> Loader Class Initialized
INFO - 2016-08-12 15:50:31 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:31 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:31 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:31 --> Email Class Initialized
INFO - 2016-08-12 15:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:31 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:31 --> Model Class Initialized
INFO - 2016-08-12 15:50:31 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:31 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:31 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:31 --> Model Class Initialized
INFO - 2016-08-12 15:50:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:50:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:50:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:50:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-12 15:50:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:50:32 --> Final output sent to browser
DEBUG - 2016-08-12 15:50:32 --> Total execution time: 0.9557
INFO - 2016-08-12 15:50:51 --> Config Class Initialized
INFO - 2016-08-12 15:50:51 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:51 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:51 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:51 --> URI Class Initialized
INFO - 2016-08-12 15:50:51 --> Router Class Initialized
INFO - 2016-08-12 15:50:51 --> Output Class Initialized
INFO - 2016-08-12 15:50:51 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:52 --> Input Class Initialized
INFO - 2016-08-12 15:50:52 --> Language Class Initialized
INFO - 2016-08-12 15:50:52 --> Loader Class Initialized
INFO - 2016-08-12 15:50:52 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:52 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:52 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:52 --> Email Class Initialized
INFO - 2016-08-12 15:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:52 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:52 --> Model Class Initialized
INFO - 2016-08-12 15:50:52 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:52 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:52 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:52 --> Model Class Initialized
INFO - 2016-08-12 15:50:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:50:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:50:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:50:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 15:50:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:50:52 --> Final output sent to browser
DEBUG - 2016-08-12 15:50:52 --> Total execution time: 0.8792
INFO - 2016-08-12 15:50:56 --> Config Class Initialized
INFO - 2016-08-12 15:50:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:50:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:50:56 --> Utf8 Class Initialized
INFO - 2016-08-12 15:50:56 --> URI Class Initialized
INFO - 2016-08-12 15:50:56 --> Router Class Initialized
INFO - 2016-08-12 15:50:56 --> Output Class Initialized
INFO - 2016-08-12 15:50:56 --> Security Class Initialized
DEBUG - 2016-08-12 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:50:56 --> Input Class Initialized
INFO - 2016-08-12 15:50:56 --> Language Class Initialized
INFO - 2016-08-12 15:50:56 --> Loader Class Initialized
INFO - 2016-08-12 15:50:56 --> Helper loaded: url_helper
INFO - 2016-08-12 15:50:56 --> Helper loaded: date_helper
INFO - 2016-08-12 15:50:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:50:56 --> Database Driver Class Initialized
INFO - 2016-08-12 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:50:56 --> Email Class Initialized
INFO - 2016-08-12 15:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:50:56 --> Pagination Class Initialized
INFO - 2016-08-12 15:50:56 --> Model Class Initialized
INFO - 2016-08-12 15:50:56 --> Controller Class Initialized
DEBUG - 2016-08-12 15:50:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:50:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:50:56 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:50:56 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:50:56 --> Model Class Initialized
INFO - 2016-08-12 15:50:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:50:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:50:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:50:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-12 15:50:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:50:57 --> Final output sent to browser
DEBUG - 2016-08-12 15:50:57 --> Total execution time: 0.8351
INFO - 2016-08-12 15:51:03 --> Config Class Initialized
INFO - 2016-08-12 15:51:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:51:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:51:03 --> Utf8 Class Initialized
INFO - 2016-08-12 15:51:03 --> URI Class Initialized
INFO - 2016-08-12 15:51:03 --> Router Class Initialized
INFO - 2016-08-12 15:51:03 --> Output Class Initialized
INFO - 2016-08-12 15:51:03 --> Security Class Initialized
DEBUG - 2016-08-12 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:51:04 --> Input Class Initialized
INFO - 2016-08-12 15:51:04 --> Language Class Initialized
INFO - 2016-08-12 15:51:04 --> Loader Class Initialized
INFO - 2016-08-12 15:51:04 --> Helper loaded: url_helper
INFO - 2016-08-12 15:51:04 --> Helper loaded: date_helper
INFO - 2016-08-12 15:51:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:51:04 --> Database Driver Class Initialized
INFO - 2016-08-12 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:51:04 --> Email Class Initialized
INFO - 2016-08-12 15:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:51:04 --> Pagination Class Initialized
INFO - 2016-08-12 15:51:04 --> Model Class Initialized
INFO - 2016-08-12 15:51:04 --> Controller Class Initialized
DEBUG - 2016-08-12 15:51:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:51:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:51:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:51:04 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:51:04 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:51:04 --> Model Class Initialized
INFO - 2016-08-12 15:51:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:51:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:51:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:51:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/linksocial/view_linksocial.php
INFO - 2016-08-12 15:51:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:51:04 --> Final output sent to browser
DEBUG - 2016-08-12 15:51:04 --> Total execution time: 0.8828
INFO - 2016-08-12 15:51:12 --> Config Class Initialized
INFO - 2016-08-12 15:51:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:51:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:51:12 --> Utf8 Class Initialized
INFO - 2016-08-12 15:51:12 --> URI Class Initialized
DEBUG - 2016-08-12 15:51:13 --> No URI present. Default controller set.
INFO - 2016-08-12 15:51:13 --> Router Class Initialized
INFO - 2016-08-12 15:51:13 --> Output Class Initialized
INFO - 2016-08-12 15:51:13 --> Security Class Initialized
DEBUG - 2016-08-12 15:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:51:13 --> Input Class Initialized
INFO - 2016-08-12 15:51:13 --> Language Class Initialized
INFO - 2016-08-12 15:51:13 --> Loader Class Initialized
INFO - 2016-08-12 15:51:13 --> Helper loaded: url_helper
INFO - 2016-08-12 15:51:13 --> Helper loaded: date_helper
INFO - 2016-08-12 15:51:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:51:13 --> Database Driver Class Initialized
INFO - 2016-08-12 15:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:51:13 --> Email Class Initialized
INFO - 2016-08-12 15:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:51:13 --> Pagination Class Initialized
INFO - 2016-08-12 15:51:13 --> Model Class Initialized
INFO - 2016-08-12 15:51:13 --> Controller Class Initialized
INFO - 2016-08-12 15:51:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:51:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:51:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 15:51:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:51:13 --> Final output sent to browser
DEBUG - 2016-08-12 15:51:13 --> Total execution time: 0.7846
INFO - 2016-08-12 15:51:27 --> Config Class Initialized
INFO - 2016-08-12 15:51:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:51:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:51:27 --> Utf8 Class Initialized
INFO - 2016-08-12 15:51:27 --> URI Class Initialized
INFO - 2016-08-12 15:51:27 --> Router Class Initialized
INFO - 2016-08-12 15:51:28 --> Output Class Initialized
INFO - 2016-08-12 15:51:28 --> Security Class Initialized
DEBUG - 2016-08-12 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:51:28 --> Input Class Initialized
INFO - 2016-08-12 15:51:28 --> Language Class Initialized
INFO - 2016-08-12 15:51:28 --> Loader Class Initialized
INFO - 2016-08-12 15:51:28 --> Helper loaded: url_helper
INFO - 2016-08-12 15:51:28 --> Helper loaded: date_helper
INFO - 2016-08-12 15:51:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:51:28 --> Database Driver Class Initialized
INFO - 2016-08-12 15:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:51:28 --> Email Class Initialized
INFO - 2016-08-12 15:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:51:28 --> Pagination Class Initialized
INFO - 2016-08-12 15:51:28 --> Model Class Initialized
INFO - 2016-08-12 15:51:28 --> Controller Class Initialized
INFO - 2016-08-12 15:51:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:51:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:51:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 15:51:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:51:28 --> Final output sent to browser
DEBUG - 2016-08-12 15:51:28 --> Total execution time: 0.6669
INFO - 2016-08-12 15:51:28 --> Config Class Initialized
INFO - 2016-08-12 15:51:28 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:51:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:51:29 --> Utf8 Class Initialized
INFO - 2016-08-12 15:51:29 --> URI Class Initialized
INFO - 2016-08-12 15:51:29 --> Router Class Initialized
INFO - 2016-08-12 15:51:29 --> Output Class Initialized
INFO - 2016-08-12 15:51:29 --> Security Class Initialized
DEBUG - 2016-08-12 15:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:51:29 --> Input Class Initialized
INFO - 2016-08-12 15:51:29 --> Language Class Initialized
ERROR - 2016-08-12 15:51:29 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 15:51:42 --> Config Class Initialized
INFO - 2016-08-12 15:51:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:51:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:51:42 --> Utf8 Class Initialized
INFO - 2016-08-12 15:51:42 --> URI Class Initialized
INFO - 2016-08-12 15:51:42 --> Router Class Initialized
INFO - 2016-08-12 15:51:42 --> Output Class Initialized
INFO - 2016-08-12 15:51:42 --> Security Class Initialized
DEBUG - 2016-08-12 15:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:51:42 --> Input Class Initialized
INFO - 2016-08-12 15:51:42 --> Language Class Initialized
INFO - 2016-08-12 15:51:42 --> Loader Class Initialized
INFO - 2016-08-12 15:51:42 --> Helper loaded: url_helper
INFO - 2016-08-12 15:51:42 --> Helper loaded: date_helper
INFO - 2016-08-12 15:51:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:51:42 --> Database Driver Class Initialized
INFO - 2016-08-12 15:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:51:42 --> Email Class Initialized
INFO - 2016-08-12 15:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:51:42 --> Pagination Class Initialized
INFO - 2016-08-12 15:51:42 --> Model Class Initialized
INFO - 2016-08-12 15:51:42 --> Controller Class Initialized
DEBUG - 2016-08-12 15:51:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:51:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:51:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:51:43 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:51:43 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:51:43 --> Model Class Initialized
INFO - 2016-08-12 15:51:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:51:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:51:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:51:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-12 15:51:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:51:43 --> Final output sent to browser
DEBUG - 2016-08-12 15:51:43 --> Total execution time: 0.9287
INFO - 2016-08-12 15:52:41 --> Config Class Initialized
INFO - 2016-08-12 15:52:41 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:52:41 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:52:41 --> Utf8 Class Initialized
INFO - 2016-08-12 15:52:41 --> URI Class Initialized
INFO - 2016-08-12 15:52:41 --> Router Class Initialized
INFO - 2016-08-12 15:52:41 --> Output Class Initialized
INFO - 2016-08-12 15:52:41 --> Security Class Initialized
DEBUG - 2016-08-12 15:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:52:42 --> Input Class Initialized
INFO - 2016-08-12 15:52:42 --> Language Class Initialized
INFO - 2016-08-12 15:52:42 --> Loader Class Initialized
INFO - 2016-08-12 15:52:42 --> Helper loaded: url_helper
INFO - 2016-08-12 15:52:42 --> Helper loaded: date_helper
INFO - 2016-08-12 15:52:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:52:42 --> Database Driver Class Initialized
INFO - 2016-08-12 15:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:52:42 --> Email Class Initialized
INFO - 2016-08-12 15:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:52:42 --> Pagination Class Initialized
INFO - 2016-08-12 15:52:42 --> Model Class Initialized
INFO - 2016-08-12 15:52:42 --> Controller Class Initialized
INFO - 2016-08-12 15:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 15:52:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:52:42 --> Final output sent to browser
DEBUG - 2016-08-12 15:52:42 --> Total execution time: 0.7146
INFO - 2016-08-12 15:52:42 --> Config Class Initialized
INFO - 2016-08-12 15:52:43 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:52:43 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:52:43 --> Utf8 Class Initialized
INFO - 2016-08-12 15:52:43 --> URI Class Initialized
INFO - 2016-08-12 15:52:43 --> Router Class Initialized
INFO - 2016-08-12 15:52:43 --> Output Class Initialized
INFO - 2016-08-12 15:52:43 --> Security Class Initialized
DEBUG - 2016-08-12 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:52:43 --> Input Class Initialized
INFO - 2016-08-12 15:52:43 --> Language Class Initialized
ERROR - 2016-08-12 15:52:43 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 15:53:06 --> Config Class Initialized
INFO - 2016-08-12 15:53:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:53:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:53:06 --> Utf8 Class Initialized
INFO - 2016-08-12 15:53:06 --> URI Class Initialized
INFO - 2016-08-12 15:53:06 --> Router Class Initialized
INFO - 2016-08-12 15:53:06 --> Output Class Initialized
INFO - 2016-08-12 15:53:06 --> Security Class Initialized
DEBUG - 2016-08-12 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:53:06 --> Input Class Initialized
INFO - 2016-08-12 15:53:06 --> Language Class Initialized
INFO - 2016-08-12 15:53:06 --> Loader Class Initialized
INFO - 2016-08-12 15:53:06 --> Helper loaded: url_helper
INFO - 2016-08-12 15:53:06 --> Helper loaded: date_helper
INFO - 2016-08-12 15:53:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:53:06 --> Database Driver Class Initialized
INFO - 2016-08-12 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:53:06 --> Email Class Initialized
INFO - 2016-08-12 15:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:53:06 --> Pagination Class Initialized
INFO - 2016-08-12 15:53:06 --> Model Class Initialized
INFO - 2016-08-12 15:53:06 --> Controller Class Initialized
INFO - 2016-08-12 15:53:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:53:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:53:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-12 15:53:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:53:06 --> Final output sent to browser
DEBUG - 2016-08-12 15:53:07 --> Total execution time: 0.7477
INFO - 2016-08-12 15:54:15 --> Config Class Initialized
INFO - 2016-08-12 15:54:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:54:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:54:15 --> Utf8 Class Initialized
INFO - 2016-08-12 15:54:15 --> URI Class Initialized
INFO - 2016-08-12 15:54:15 --> Router Class Initialized
INFO - 2016-08-12 15:54:15 --> Output Class Initialized
INFO - 2016-08-12 15:54:15 --> Security Class Initialized
DEBUG - 2016-08-12 15:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:54:16 --> Input Class Initialized
INFO - 2016-08-12 15:54:16 --> Language Class Initialized
INFO - 2016-08-12 15:54:16 --> Loader Class Initialized
INFO - 2016-08-12 15:54:16 --> Helper loaded: url_helper
INFO - 2016-08-12 15:54:16 --> Helper loaded: date_helper
INFO - 2016-08-12 15:54:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:54:16 --> Database Driver Class Initialized
INFO - 2016-08-12 15:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:54:16 --> Email Class Initialized
INFO - 2016-08-12 15:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:54:16 --> Pagination Class Initialized
INFO - 2016-08-12 15:54:16 --> Model Class Initialized
INFO - 2016-08-12 15:54:16 --> Controller Class Initialized
DEBUG - 2016-08-12 15:54:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:54:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:54:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:54:16 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:54:16 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:54:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:54:16 --> Model Class Initialized
INFO - 2016-08-12 15:54:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:54:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:54:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:54:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-12 15:54:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:54:16 --> Final output sent to browser
DEBUG - 2016-08-12 15:54:16 --> Total execution time: 0.8531
INFO - 2016-08-12 15:54:21 --> Config Class Initialized
INFO - 2016-08-12 15:54:21 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:54:21 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:54:21 --> Utf8 Class Initialized
INFO - 2016-08-12 15:54:21 --> URI Class Initialized
INFO - 2016-08-12 15:54:21 --> Router Class Initialized
INFO - 2016-08-12 15:54:21 --> Output Class Initialized
INFO - 2016-08-12 15:54:21 --> Security Class Initialized
DEBUG - 2016-08-12 15:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:54:21 --> Input Class Initialized
INFO - 2016-08-12 15:54:21 --> Language Class Initialized
INFO - 2016-08-12 15:54:21 --> Loader Class Initialized
INFO - 2016-08-12 15:54:21 --> Helper loaded: url_helper
INFO - 2016-08-12 15:54:21 --> Helper loaded: date_helper
INFO - 2016-08-12 15:54:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:54:21 --> Database Driver Class Initialized
INFO - 2016-08-12 15:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:54:21 --> Email Class Initialized
INFO - 2016-08-12 15:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:54:22 --> Pagination Class Initialized
INFO - 2016-08-12 15:54:22 --> Model Class Initialized
INFO - 2016-08-12 15:54:22 --> Controller Class Initialized
INFO - 2016-08-12 15:54:22 --> Model Class Initialized
INFO - 2016-08-12 15:54:22 --> Helper loaded: text_helper
INFO - 2016-08-12 15:54:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:54:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:54:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 15:54:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:54:22 --> Final output sent to browser
DEBUG - 2016-08-12 15:54:22 --> Total execution time: 0.7593
INFO - 2016-08-12 15:54:29 --> Config Class Initialized
INFO - 2016-08-12 15:54:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:54:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:54:29 --> Utf8 Class Initialized
INFO - 2016-08-12 15:54:29 --> URI Class Initialized
INFO - 2016-08-12 15:54:29 --> Router Class Initialized
INFO - 2016-08-12 15:54:29 --> Output Class Initialized
INFO - 2016-08-12 15:54:29 --> Security Class Initialized
DEBUG - 2016-08-12 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:54:29 --> Input Class Initialized
INFO - 2016-08-12 15:54:29 --> Language Class Initialized
INFO - 2016-08-12 15:54:29 --> Loader Class Initialized
INFO - 2016-08-12 15:54:29 --> Helper loaded: url_helper
INFO - 2016-08-12 15:54:29 --> Helper loaded: date_helper
INFO - 2016-08-12 15:54:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:54:29 --> Database Driver Class Initialized
INFO - 2016-08-12 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:54:30 --> Email Class Initialized
INFO - 2016-08-12 15:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:54:30 --> Pagination Class Initialized
INFO - 2016-08-12 15:54:30 --> Model Class Initialized
INFO - 2016-08-12 15:54:30 --> Controller Class Initialized
DEBUG - 2016-08-12 15:54:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 15:54:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:54:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 15:54:30 --> Helper loaded: cookie_helper
INFO - 2016-08-12 15:54:30 --> Helper loaded: language_helper
DEBUG - 2016-08-12 15:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 15:54:30 --> Model Class Initialized
INFO - 2016-08-12 15:54:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 15:54:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 15:54:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 15:54:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-12 15:54:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 15:54:30 --> Final output sent to browser
DEBUG - 2016-08-12 15:54:30 --> Total execution time: 0.7465
INFO - 2016-08-12 15:55:06 --> Config Class Initialized
INFO - 2016-08-12 15:55:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:06 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:06 --> URI Class Initialized
INFO - 2016-08-12 15:55:06 --> Router Class Initialized
INFO - 2016-08-12 15:55:06 --> Output Class Initialized
INFO - 2016-08-12 15:55:06 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:06 --> Input Class Initialized
INFO - 2016-08-12 15:55:06 --> Language Class Initialized
INFO - 2016-08-12 15:55:06 --> Loader Class Initialized
INFO - 2016-08-12 15:55:06 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:06 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:06 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:55:06 --> Email Class Initialized
INFO - 2016-08-12 15:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:55:06 --> Pagination Class Initialized
INFO - 2016-08-12 15:55:06 --> Model Class Initialized
INFO - 2016-08-12 15:55:06 --> Controller Class Initialized
INFO - 2016-08-12 15:55:06 --> Model Class Initialized
INFO - 2016-08-12 15:55:06 --> Helper loaded: text_helper
INFO - 2016-08-12 15:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 15:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:55:07 --> Final output sent to browser
DEBUG - 2016-08-12 15:55:07 --> Total execution time: 0.7395
INFO - 2016-08-12 15:55:19 --> Config Class Initialized
INFO - 2016-08-12 15:55:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:19 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:19 --> URI Class Initialized
INFO - 2016-08-12 15:55:19 --> Router Class Initialized
INFO - 2016-08-12 15:55:19 --> Output Class Initialized
INFO - 2016-08-12 15:55:19 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:19 --> Input Class Initialized
INFO - 2016-08-12 15:55:19 --> Language Class Initialized
INFO - 2016-08-12 15:55:19 --> Loader Class Initialized
INFO - 2016-08-12 15:55:19 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:19 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:19 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:55:19 --> Email Class Initialized
INFO - 2016-08-12 15:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:55:19 --> Pagination Class Initialized
INFO - 2016-08-12 15:55:19 --> Model Class Initialized
INFO - 2016-08-12 15:55:19 --> Controller Class Initialized
INFO - 2016-08-12 15:55:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:55:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:55:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 15:55:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:55:19 --> Final output sent to browser
DEBUG - 2016-08-12 15:55:19 --> Total execution time: 0.5704
INFO - 2016-08-12 15:55:21 --> Config Class Initialized
INFO - 2016-08-12 15:55:21 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:22 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:22 --> URI Class Initialized
INFO - 2016-08-12 15:55:22 --> Router Class Initialized
INFO - 2016-08-12 15:55:22 --> Output Class Initialized
INFO - 2016-08-12 15:55:22 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:22 --> Input Class Initialized
INFO - 2016-08-12 15:55:22 --> Language Class Initialized
INFO - 2016-08-12 15:55:22 --> Loader Class Initialized
INFO - 2016-08-12 15:55:22 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:22 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:22 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:55:22 --> Email Class Initialized
INFO - 2016-08-12 15:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:55:22 --> Pagination Class Initialized
INFO - 2016-08-12 15:55:22 --> Model Class Initialized
INFO - 2016-08-12 15:55:22 --> Controller Class Initialized
INFO - 2016-08-12 15:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-12 15:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:55:22 --> Final output sent to browser
DEBUG - 2016-08-12 15:55:22 --> Total execution time: 0.6698
INFO - 2016-08-12 15:55:24 --> Config Class Initialized
INFO - 2016-08-12 15:55:24 --> Config Class Initialized
INFO - 2016-08-12 15:55:24 --> Config Class Initialized
INFO - 2016-08-12 15:55:24 --> Config Class Initialized
INFO - 2016-08-12 15:55:24 --> Hooks Class Initialized
INFO - 2016-08-12 15:55:24 --> Hooks Class Initialized
INFO - 2016-08-12 15:55:24 --> Hooks Class Initialized
INFO - 2016-08-12 15:55:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-12 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-12 15:55:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:24 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:24 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:24 --> Utf8 Class Initialized
DEBUG - 2016-08-12 15:55:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:24 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:24 --> URI Class Initialized
INFO - 2016-08-12 15:55:24 --> URI Class Initialized
INFO - 2016-08-12 15:55:24 --> URI Class Initialized
INFO - 2016-08-12 15:55:24 --> URI Class Initialized
INFO - 2016-08-12 15:55:24 --> Router Class Initialized
INFO - 2016-08-12 15:55:24 --> Router Class Initialized
INFO - 2016-08-12 15:55:24 --> Router Class Initialized
INFO - 2016-08-12 15:55:24 --> Router Class Initialized
INFO - 2016-08-12 15:55:24 --> Output Class Initialized
INFO - 2016-08-12 15:55:24 --> Output Class Initialized
INFO - 2016-08-12 15:55:24 --> Output Class Initialized
INFO - 2016-08-12 15:55:24 --> Security Class Initialized
INFO - 2016-08-12 15:55:24 --> Security Class Initialized
INFO - 2016-08-12 15:55:24 --> Output Class Initialized
INFO - 2016-08-12 15:55:24 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-12 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:24 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:24 --> Input Class Initialized
INFO - 2016-08-12 15:55:24 --> Input Class Initialized
INFO - 2016-08-12 15:55:24 --> Input Class Initialized
DEBUG - 2016-08-12 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:24 --> Input Class Initialized
INFO - 2016-08-12 15:55:24 --> Language Class Initialized
INFO - 2016-08-12 15:55:24 --> Config Class Initialized
INFO - 2016-08-12 15:55:24 --> Language Class Initialized
INFO - 2016-08-12 15:55:24 --> Language Class Initialized
INFO - 2016-08-12 15:55:24 --> Hooks Class Initialized
INFO - 2016-08-12 15:55:24 --> Language Class Initialized
ERROR - 2016-08-12 15:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-12 15:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-12 15:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-12 15:55:24 --> 404 Page Not Found: Assets/css
DEBUG - 2016-08-12 15:55:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:24 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:24 --> URI Class Initialized
INFO - 2016-08-12 15:55:24 --> Router Class Initialized
INFO - 2016-08-12 15:55:24 --> Output Class Initialized
INFO - 2016-08-12 15:55:24 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:24 --> Input Class Initialized
INFO - 2016-08-12 15:55:24 --> Language Class Initialized
INFO - 2016-08-12 15:55:24 --> Loader Class Initialized
INFO - 2016-08-12 15:55:25 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:25 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:25 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:55:25 --> Email Class Initialized
INFO - 2016-08-12 15:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:55:25 --> Pagination Class Initialized
INFO - 2016-08-12 15:55:25 --> Model Class Initialized
INFO - 2016-08-12 15:55:25 --> Controller Class Initialized
INFO - 2016-08-12 15:55:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-12 15:55:25 --> Final output sent to browser
DEBUG - 2016-08-12 15:55:25 --> Total execution time: 0.5662
INFO - 2016-08-12 15:55:54 --> Config Class Initialized
INFO - 2016-08-12 15:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:54 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:54 --> URI Class Initialized
INFO - 2016-08-12 15:55:54 --> Router Class Initialized
INFO - 2016-08-12 15:55:54 --> Output Class Initialized
INFO - 2016-08-12 15:55:54 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:54 --> Input Class Initialized
INFO - 2016-08-12 15:55:54 --> Language Class Initialized
INFO - 2016-08-12 15:55:54 --> Loader Class Initialized
INFO - 2016-08-12 15:55:54 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:54 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:55 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:55:55 --> Email Class Initialized
INFO - 2016-08-12 15:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:55:55 --> Pagination Class Initialized
INFO - 2016-08-12 15:55:55 --> Model Class Initialized
INFO - 2016-08-12 15:55:55 --> Controller Class Initialized
INFO - 2016-08-12 15:55:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-12 15:55:55 --> Final output sent to browser
DEBUG - 2016-08-12 15:55:55 --> Total execution time: 0.5253
INFO - 2016-08-12 15:55:59 --> Config Class Initialized
INFO - 2016-08-12 15:55:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 15:55:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 15:55:59 --> Utf8 Class Initialized
INFO - 2016-08-12 15:55:59 --> URI Class Initialized
INFO - 2016-08-12 15:55:59 --> Router Class Initialized
INFO - 2016-08-12 15:55:59 --> Output Class Initialized
INFO - 2016-08-12 15:55:59 --> Security Class Initialized
DEBUG - 2016-08-12 15:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 15:55:59 --> Input Class Initialized
INFO - 2016-08-12 15:55:59 --> Language Class Initialized
INFO - 2016-08-12 15:55:59 --> Loader Class Initialized
INFO - 2016-08-12 15:55:59 --> Helper loaded: url_helper
INFO - 2016-08-12 15:55:59 --> Helper loaded: date_helper
INFO - 2016-08-12 15:55:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 15:55:59 --> Database Driver Class Initialized
INFO - 2016-08-12 15:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 15:56:00 --> Email Class Initialized
INFO - 2016-08-12 15:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 15:56:00 --> Pagination Class Initialized
INFO - 2016-08-12 15:56:00 --> Model Class Initialized
INFO - 2016-08-12 15:56:00 --> Controller Class Initialized
INFO - 2016-08-12 15:56:00 --> Model Class Initialized
INFO - 2016-08-12 15:56:00 --> Helper loaded: text_helper
INFO - 2016-08-12 15:56:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 15:56:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 15:56:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 15:56:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 15:56:00 --> Final output sent to browser
DEBUG - 2016-08-12 15:56:00 --> Total execution time: 0.6589
INFO - 2016-08-12 16:01:40 --> Config Class Initialized
INFO - 2016-08-12 16:01:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:01:40 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:01:40 --> Utf8 Class Initialized
INFO - 2016-08-12 16:01:40 --> URI Class Initialized
INFO - 2016-08-12 16:01:40 --> Router Class Initialized
INFO - 2016-08-12 16:01:40 --> Output Class Initialized
INFO - 2016-08-12 16:01:40 --> Security Class Initialized
DEBUG - 2016-08-12 16:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:01:40 --> Input Class Initialized
INFO - 2016-08-12 16:01:40 --> Language Class Initialized
INFO - 2016-08-12 16:01:40 --> Loader Class Initialized
INFO - 2016-08-12 16:01:40 --> Helper loaded: url_helper
INFO - 2016-08-12 16:01:40 --> Helper loaded: date_helper
INFO - 2016-08-12 16:01:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:01:40 --> Database Driver Class Initialized
INFO - 2016-08-12 16:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:01:40 --> Email Class Initialized
INFO - 2016-08-12 16:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:01:40 --> Pagination Class Initialized
INFO - 2016-08-12 16:01:40 --> Model Class Initialized
INFO - 2016-08-12 16:01:40 --> Controller Class Initialized
INFO - 2016-08-12 16:01:40 --> Model Class Initialized
INFO - 2016-08-12 16:01:41 --> Helper loaded: text_helper
INFO - 2016-08-12 16:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 16:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 16:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-12 16:01:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 16:01:41 --> Final output sent to browser
DEBUG - 2016-08-12 16:01:41 --> Total execution time: 0.7105
INFO - 2016-08-12 16:03:53 --> Config Class Initialized
INFO - 2016-08-12 16:03:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:03:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:03:53 --> Utf8 Class Initialized
INFO - 2016-08-12 16:03:53 --> URI Class Initialized
DEBUG - 2016-08-12 16:03:53 --> No URI present. Default controller set.
INFO - 2016-08-12 16:03:53 --> Router Class Initialized
INFO - 2016-08-12 16:03:53 --> Output Class Initialized
INFO - 2016-08-12 16:03:53 --> Security Class Initialized
DEBUG - 2016-08-12 16:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:03:53 --> Input Class Initialized
INFO - 2016-08-12 16:03:53 --> Language Class Initialized
INFO - 2016-08-12 16:03:53 --> Loader Class Initialized
INFO - 2016-08-12 16:03:53 --> Helper loaded: url_helper
INFO - 2016-08-12 16:03:53 --> Helper loaded: date_helper
INFO - 2016-08-12 16:03:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:03:53 --> Database Driver Class Initialized
INFO - 2016-08-12 16:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:03:53 --> Email Class Initialized
INFO - 2016-08-12 16:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:03:54 --> Pagination Class Initialized
INFO - 2016-08-12 16:03:54 --> Model Class Initialized
INFO - 2016-08-12 16:03:54 --> Controller Class Initialized
INFO - 2016-08-12 16:03:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 16:03:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 16:03:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 16:03:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 16:03:54 --> Final output sent to browser
DEBUG - 2016-08-12 16:03:54 --> Total execution time: 0.8837
INFO - 2016-08-12 16:04:06 --> Config Class Initialized
INFO - 2016-08-12 16:04:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:04:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:04:06 --> Utf8 Class Initialized
INFO - 2016-08-12 16:04:06 --> URI Class Initialized
INFO - 2016-08-12 16:04:06 --> Router Class Initialized
INFO - 2016-08-12 16:04:06 --> Output Class Initialized
INFO - 2016-08-12 16:04:06 --> Security Class Initialized
DEBUG - 2016-08-12 16:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:04:06 --> Input Class Initialized
INFO - 2016-08-12 16:04:06 --> Language Class Initialized
INFO - 2016-08-12 16:04:06 --> Loader Class Initialized
INFO - 2016-08-12 16:04:06 --> Helper loaded: url_helper
INFO - 2016-08-12 16:04:06 --> Helper loaded: date_helper
INFO - 2016-08-12 16:04:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:04:07 --> Database Driver Class Initialized
INFO - 2016-08-12 16:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:04:07 --> Email Class Initialized
INFO - 2016-08-12 16:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:04:07 --> Pagination Class Initialized
INFO - 2016-08-12 16:04:07 --> Model Class Initialized
INFO - 2016-08-12 16:04:07 --> Controller Class Initialized
INFO - 2016-08-12 16:04:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 16:04:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 16:04:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-12 16:04:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 16:04:07 --> Final output sent to browser
DEBUG - 2016-08-12 16:04:07 --> Total execution time: 0.6322
INFO - 2016-08-12 16:04:22 --> Config Class Initialized
INFO - 2016-08-12 16:04:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:04:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:04:22 --> Utf8 Class Initialized
INFO - 2016-08-12 16:04:22 --> URI Class Initialized
INFO - 2016-08-12 16:04:22 --> Router Class Initialized
INFO - 2016-08-12 16:04:22 --> Output Class Initialized
INFO - 2016-08-12 16:04:22 --> Security Class Initialized
DEBUG - 2016-08-12 16:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:04:22 --> Input Class Initialized
INFO - 2016-08-12 16:04:22 --> Language Class Initialized
INFO - 2016-08-12 16:04:22 --> Loader Class Initialized
INFO - 2016-08-12 16:04:22 --> Helper loaded: url_helper
INFO - 2016-08-12 16:04:22 --> Helper loaded: date_helper
INFO - 2016-08-12 16:04:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:04:22 --> Database Driver Class Initialized
INFO - 2016-08-12 16:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:04:22 --> Email Class Initialized
INFO - 2016-08-12 16:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:04:22 --> Pagination Class Initialized
INFO - 2016-08-12 16:04:22 --> Model Class Initialized
INFO - 2016-08-12 16:04:22 --> Controller Class Initialized
DEBUG - 2016-08-12 16:04:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:04:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:04:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:04:22 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:04:22 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:04:23 --> Model Class Initialized
INFO - 2016-08-12 16:04:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:04:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:04:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-12 16:04:23 --> Severity: Notice --> Undefined variable: kategori D:\xampp\htdocs\aqiqahsehati\application\views\admin\order\view_order.php 40
ERROR - 2016-08-12 16:04:23 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\order\view_order.php 40
INFO - 2016-08-12 16:04:25 --> Config Class Initialized
INFO - 2016-08-12 16:04:25 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:04:25 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:04:25 --> Utf8 Class Initialized
INFO - 2016-08-12 16:04:25 --> URI Class Initialized
INFO - 2016-08-12 16:04:25 --> Router Class Initialized
INFO - 2016-08-12 16:04:25 --> Output Class Initialized
INFO - 2016-08-12 16:04:25 --> Security Class Initialized
DEBUG - 2016-08-12 16:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:04:25 --> Input Class Initialized
INFO - 2016-08-12 16:04:25 --> Language Class Initialized
INFO - 2016-08-12 16:04:25 --> Loader Class Initialized
INFO - 2016-08-12 16:04:25 --> Helper loaded: url_helper
INFO - 2016-08-12 16:04:25 --> Helper loaded: date_helper
INFO - 2016-08-12 16:04:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:04:26 --> Database Driver Class Initialized
INFO - 2016-08-12 16:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:04:26 --> Email Class Initialized
INFO - 2016-08-12 16:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:04:26 --> Pagination Class Initialized
INFO - 2016-08-12 16:04:26 --> Model Class Initialized
INFO - 2016-08-12 16:04:26 --> Controller Class Initialized
DEBUG - 2016-08-12 16:04:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:04:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:04:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:04:26 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:04:26 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:04:26 --> Model Class Initialized
INFO - 2016-08-12 16:04:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:04:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:04:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:04:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-12 16:04:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:04:26 --> Final output sent to browser
DEBUG - 2016-08-12 16:04:26 --> Total execution time: 0.8477
INFO - 2016-08-12 16:07:58 --> Config Class Initialized
INFO - 2016-08-12 16:07:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:07:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:07:58 --> Utf8 Class Initialized
INFO - 2016-08-12 16:07:58 --> URI Class Initialized
INFO - 2016-08-12 16:07:58 --> Router Class Initialized
INFO - 2016-08-12 16:07:58 --> Output Class Initialized
INFO - 2016-08-12 16:07:58 --> Security Class Initialized
DEBUG - 2016-08-12 16:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:07:58 --> Input Class Initialized
INFO - 2016-08-12 16:07:58 --> Language Class Initialized
INFO - 2016-08-12 16:07:58 --> Loader Class Initialized
INFO - 2016-08-12 16:07:58 --> Helper loaded: url_helper
INFO - 2016-08-12 16:07:58 --> Helper loaded: date_helper
INFO - 2016-08-12 16:07:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:07:58 --> Database Driver Class Initialized
INFO - 2016-08-12 16:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:07:58 --> Email Class Initialized
INFO - 2016-08-12 16:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:07:58 --> Pagination Class Initialized
INFO - 2016-08-12 16:07:58 --> Model Class Initialized
INFO - 2016-08-12 16:07:58 --> Controller Class Initialized
INFO - 2016-08-12 16:07:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 16:07:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 16:07:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 16:07:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 16:07:58 --> Final output sent to browser
DEBUG - 2016-08-12 16:07:58 --> Total execution time: 0.6330
INFO - 2016-08-12 16:07:59 --> Config Class Initialized
INFO - 2016-08-12 16:07:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:07:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:07:59 --> Utf8 Class Initialized
INFO - 2016-08-12 16:07:59 --> URI Class Initialized
INFO - 2016-08-12 16:07:59 --> Router Class Initialized
INFO - 2016-08-12 16:07:59 --> Output Class Initialized
INFO - 2016-08-12 16:07:59 --> Security Class Initialized
DEBUG - 2016-08-12 16:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:07:59 --> Input Class Initialized
INFO - 2016-08-12 16:07:59 --> Language Class Initialized
ERROR - 2016-08-12 16:07:59 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 16:09:30 --> Config Class Initialized
INFO - 2016-08-12 16:09:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:09:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:09:30 --> Utf8 Class Initialized
INFO - 2016-08-12 16:09:30 --> URI Class Initialized
INFO - 2016-08-12 16:09:30 --> Router Class Initialized
INFO - 2016-08-12 16:09:30 --> Output Class Initialized
INFO - 2016-08-12 16:09:30 --> Security Class Initialized
DEBUG - 2016-08-12 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:09:30 --> Input Class Initialized
INFO - 2016-08-12 16:09:30 --> Language Class Initialized
INFO - 2016-08-12 16:09:30 --> Loader Class Initialized
INFO - 2016-08-12 16:09:30 --> Helper loaded: url_helper
INFO - 2016-08-12 16:09:30 --> Helper loaded: date_helper
INFO - 2016-08-12 16:09:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:09:30 --> Database Driver Class Initialized
INFO - 2016-08-12 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:09:30 --> Email Class Initialized
INFO - 2016-08-12 16:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:09:30 --> Pagination Class Initialized
INFO - 2016-08-12 16:09:30 --> Model Class Initialized
INFO - 2016-08-12 16:09:30 --> Controller Class Initialized
DEBUG - 2016-08-12 16:09:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:09:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:09:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:09:31 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:09:31 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:09:31 --> Model Class Initialized
INFO - 2016-08-12 16:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/identitas/view_identitas.php
INFO - 2016-08-12 16:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:09:31 --> Final output sent to browser
DEBUG - 2016-08-12 16:09:31 --> Total execution time: 0.8205
INFO - 2016-08-12 16:09:34 --> Config Class Initialized
INFO - 2016-08-12 16:09:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:09:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:09:34 --> Utf8 Class Initialized
INFO - 2016-08-12 16:09:35 --> URI Class Initialized
INFO - 2016-08-12 16:09:35 --> Router Class Initialized
INFO - 2016-08-12 16:09:35 --> Output Class Initialized
INFO - 2016-08-12 16:09:35 --> Security Class Initialized
DEBUG - 2016-08-12 16:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:09:35 --> Input Class Initialized
INFO - 2016-08-12 16:09:35 --> Language Class Initialized
INFO - 2016-08-12 16:09:35 --> Loader Class Initialized
INFO - 2016-08-12 16:09:35 --> Helper loaded: url_helper
INFO - 2016-08-12 16:09:35 --> Helper loaded: date_helper
INFO - 2016-08-12 16:09:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:09:35 --> Database Driver Class Initialized
INFO - 2016-08-12 16:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:09:35 --> Email Class Initialized
INFO - 2016-08-12 16:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:09:35 --> Pagination Class Initialized
INFO - 2016-08-12 16:09:35 --> Model Class Initialized
INFO - 2016-08-12 16:09:35 --> Controller Class Initialized
DEBUG - 2016-08-12 16:09:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:09:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:09:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:09:35 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:09:35 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:09:35 --> Model Class Initialized
INFO - 2016-08-12 16:09:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:09:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:09:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:09:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 16:09:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:09:35 --> Final output sent to browser
DEBUG - 2016-08-12 16:09:35 --> Total execution time: 0.8197
INFO - 2016-08-12 16:09:59 --> Config Class Initialized
INFO - 2016-08-12 16:09:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:09:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:09:59 --> Utf8 Class Initialized
INFO - 2016-08-12 16:09:59 --> URI Class Initialized
INFO - 2016-08-12 16:09:59 --> Router Class Initialized
INFO - 2016-08-12 16:09:59 --> Output Class Initialized
INFO - 2016-08-12 16:09:59 --> Security Class Initialized
DEBUG - 2016-08-12 16:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:10:00 --> Input Class Initialized
INFO - 2016-08-12 16:10:00 --> Language Class Initialized
INFO - 2016-08-12 16:10:00 --> Loader Class Initialized
INFO - 2016-08-12 16:10:00 --> Helper loaded: url_helper
INFO - 2016-08-12 16:10:00 --> Helper loaded: date_helper
INFO - 2016-08-12 16:10:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:10:00 --> Database Driver Class Initialized
INFO - 2016-08-12 16:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:10:00 --> Email Class Initialized
INFO - 2016-08-12 16:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:10:00 --> Pagination Class Initialized
INFO - 2016-08-12 16:10:00 --> Model Class Initialized
INFO - 2016-08-12 16:10:00 --> Controller Class Initialized
DEBUG - 2016-08-12 16:10:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:10:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:10:00 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:10:00 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:00 --> Model Class Initialized
INFO - 2016-08-12 16:10:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:10:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:10:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:10:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/update_pengguna.php
INFO - 2016-08-12 16:10:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:10:00 --> Final output sent to browser
DEBUG - 2016-08-12 16:10:00 --> Total execution time: 0.9146
INFO - 2016-08-12 16:10:06 --> Config Class Initialized
INFO - 2016-08-12 16:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:10:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:10:06 --> Utf8 Class Initialized
INFO - 2016-08-12 16:10:06 --> URI Class Initialized
INFO - 2016-08-12 16:10:06 --> Router Class Initialized
INFO - 2016-08-12 16:10:06 --> Output Class Initialized
INFO - 2016-08-12 16:10:06 --> Security Class Initialized
DEBUG - 2016-08-12 16:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:10:06 --> Input Class Initialized
INFO - 2016-08-12 16:10:06 --> Language Class Initialized
INFO - 2016-08-12 16:10:06 --> Loader Class Initialized
INFO - 2016-08-12 16:10:06 --> Helper loaded: url_helper
INFO - 2016-08-12 16:10:06 --> Helper loaded: date_helper
INFO - 2016-08-12 16:10:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:10:06 --> Database Driver Class Initialized
INFO - 2016-08-12 16:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:10:06 --> Email Class Initialized
INFO - 2016-08-12 16:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:10:06 --> Pagination Class Initialized
INFO - 2016-08-12 16:10:06 --> Model Class Initialized
INFO - 2016-08-12 16:10:06 --> Controller Class Initialized
DEBUG - 2016-08-12 16:10:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:10:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:10:07 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:10:07 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:07 --> Model Class Initialized
INFO - 2016-08-12 16:10:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:10:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:10:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:10:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 16:10:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:10:07 --> Final output sent to browser
DEBUG - 2016-08-12 16:10:07 --> Total execution time: 0.8273
INFO - 2016-08-12 16:10:21 --> Config Class Initialized
INFO - 2016-08-12 16:10:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:10:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:10:22 --> Utf8 Class Initialized
INFO - 2016-08-12 16:10:22 --> URI Class Initialized
INFO - 2016-08-12 16:10:22 --> Router Class Initialized
INFO - 2016-08-12 16:10:22 --> Output Class Initialized
INFO - 2016-08-12 16:10:22 --> Security Class Initialized
DEBUG - 2016-08-12 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:10:22 --> Input Class Initialized
INFO - 2016-08-12 16:10:22 --> Language Class Initialized
ERROR - 2016-08-12 16:10:22 --> 404 Page Not Found: Index2html/index
INFO - 2016-08-12 16:10:23 --> Config Class Initialized
INFO - 2016-08-12 16:10:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:10:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:10:24 --> Utf8 Class Initialized
INFO - 2016-08-12 16:10:24 --> URI Class Initialized
INFO - 2016-08-12 16:10:24 --> Router Class Initialized
INFO - 2016-08-12 16:10:24 --> Output Class Initialized
INFO - 2016-08-12 16:10:24 --> Security Class Initialized
DEBUG - 2016-08-12 16:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:10:24 --> Input Class Initialized
INFO - 2016-08-12 16:10:24 --> Language Class Initialized
INFO - 2016-08-12 16:10:24 --> Loader Class Initialized
INFO - 2016-08-12 16:10:24 --> Helper loaded: url_helper
INFO - 2016-08-12 16:10:24 --> Helper loaded: date_helper
INFO - 2016-08-12 16:10:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:10:24 --> Database Driver Class Initialized
INFO - 2016-08-12 16:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:10:24 --> Email Class Initialized
INFO - 2016-08-12 16:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:10:24 --> Pagination Class Initialized
INFO - 2016-08-12 16:10:24 --> Model Class Initialized
INFO - 2016-08-12 16:10:24 --> Controller Class Initialized
DEBUG - 2016-08-12 16:10:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-12 16:10:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-12 16:10:24 --> Helper loaded: cookie_helper
INFO - 2016-08-12 16:10:24 --> Helper loaded: language_helper
DEBUG - 2016-08-12 16:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-12 16:10:24 --> Model Class Initialized
INFO - 2016-08-12 16:10:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-12 16:10:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-12 16:10:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-12 16:10:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/pengguna/view_pengguna.php
INFO - 2016-08-12 16:10:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-12 16:10:24 --> Final output sent to browser
DEBUG - 2016-08-12 16:10:24 --> Total execution time: 0.8390
INFO - 2016-08-12 16:11:10 --> Config Class Initialized
INFO - 2016-08-12 16:11:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 16:11:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 16:11:10 --> Utf8 Class Initialized
INFO - 2016-08-12 16:11:10 --> URI Class Initialized
DEBUG - 2016-08-12 16:11:11 --> No URI present. Default controller set.
INFO - 2016-08-12 16:11:11 --> Router Class Initialized
INFO - 2016-08-12 16:11:11 --> Output Class Initialized
INFO - 2016-08-12 16:11:11 --> Security Class Initialized
DEBUG - 2016-08-12 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 16:11:11 --> Input Class Initialized
INFO - 2016-08-12 16:11:11 --> Language Class Initialized
INFO - 2016-08-12 16:11:11 --> Loader Class Initialized
INFO - 2016-08-12 16:11:11 --> Helper loaded: url_helper
INFO - 2016-08-12 16:11:11 --> Helper loaded: date_helper
INFO - 2016-08-12 16:11:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 16:11:11 --> Database Driver Class Initialized
INFO - 2016-08-12 16:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 16:11:11 --> Email Class Initialized
INFO - 2016-08-12 16:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 16:11:11 --> Pagination Class Initialized
INFO - 2016-08-12 16:11:11 --> Model Class Initialized
INFO - 2016-08-12 16:11:11 --> Controller Class Initialized
INFO - 2016-08-12 16:11:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 16:11:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 16:11:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 16:11:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 16:11:11 --> Final output sent to browser
DEBUG - 2016-08-12 16:11:11 --> Total execution time: 0.6651
INFO - 2016-08-12 22:05:53 --> Config Class Initialized
INFO - 2016-08-12 22:05:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:05:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:05:53 --> Utf8 Class Initialized
INFO - 2016-08-12 22:05:53 --> URI Class Initialized
DEBUG - 2016-08-12 22:05:53 --> No URI present. Default controller set.
INFO - 2016-08-12 22:05:53 --> Router Class Initialized
INFO - 2016-08-12 22:05:54 --> Output Class Initialized
INFO - 2016-08-12 22:05:54 --> Security Class Initialized
DEBUG - 2016-08-12 22:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:05:54 --> Input Class Initialized
INFO - 2016-08-12 22:05:54 --> Language Class Initialized
INFO - 2016-08-12 22:05:54 --> Loader Class Initialized
INFO - 2016-08-12 22:05:54 --> Helper loaded: url_helper
INFO - 2016-08-12 22:05:54 --> Helper loaded: date_helper
INFO - 2016-08-12 22:05:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:05:54 --> Database Driver Class Initialized
INFO - 2016-08-12 22:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:05:54 --> Email Class Initialized
INFO - 2016-08-12 22:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:05:54 --> Pagination Class Initialized
INFO - 2016-08-12 22:05:54 --> Model Class Initialized
INFO - 2016-08-12 22:05:54 --> Controller Class Initialized
INFO - 2016-08-12 22:05:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:05:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:05:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 22:05:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:05:55 --> Final output sent to browser
DEBUG - 2016-08-12 22:05:55 --> Total execution time: 1.9506
INFO - 2016-08-12 22:06:07 --> Config Class Initialized
INFO - 2016-08-12 22:06:07 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:06:07 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:06:07 --> Utf8 Class Initialized
INFO - 2016-08-12 22:06:07 --> URI Class Initialized
DEBUG - 2016-08-12 22:06:07 --> No URI present. Default controller set.
INFO - 2016-08-12 22:06:07 --> Router Class Initialized
INFO - 2016-08-12 22:06:07 --> Output Class Initialized
INFO - 2016-08-12 22:06:07 --> Security Class Initialized
DEBUG - 2016-08-12 22:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:06:08 --> Input Class Initialized
INFO - 2016-08-12 22:06:08 --> Language Class Initialized
INFO - 2016-08-12 22:06:08 --> Loader Class Initialized
INFO - 2016-08-12 22:06:08 --> Helper loaded: url_helper
INFO - 2016-08-12 22:06:08 --> Helper loaded: date_helper
INFO - 2016-08-12 22:06:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:06:08 --> Database Driver Class Initialized
INFO - 2016-08-12 22:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:06:08 --> Email Class Initialized
INFO - 2016-08-12 22:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:06:08 --> Pagination Class Initialized
INFO - 2016-08-12 22:06:08 --> Model Class Initialized
INFO - 2016-08-12 22:06:08 --> Controller Class Initialized
INFO - 2016-08-12 22:06:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:06:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:06:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-12 22:06:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:06:08 --> Final output sent to browser
DEBUG - 2016-08-12 22:06:08 --> Total execution time: 0.6591
INFO - 2016-08-12 22:12:15 --> Config Class Initialized
INFO - 2016-08-12 22:12:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:12:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:12:15 --> Utf8 Class Initialized
INFO - 2016-08-12 22:12:15 --> URI Class Initialized
INFO - 2016-08-12 22:12:15 --> Router Class Initialized
INFO - 2016-08-12 22:12:15 --> Output Class Initialized
INFO - 2016-08-12 22:12:15 --> Security Class Initialized
DEBUG - 2016-08-12 22:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:12:15 --> Input Class Initialized
INFO - 2016-08-12 22:12:15 --> Language Class Initialized
INFO - 2016-08-12 22:12:15 --> Loader Class Initialized
INFO - 2016-08-12 22:12:16 --> Helper loaded: url_helper
INFO - 2016-08-12 22:12:16 --> Helper loaded: date_helper
INFO - 2016-08-12 22:12:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:12:16 --> Database Driver Class Initialized
INFO - 2016-08-12 22:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:12:16 --> Email Class Initialized
INFO - 2016-08-12 22:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:12:16 --> Pagination Class Initialized
INFO - 2016-08-12 22:12:16 --> Model Class Initialized
INFO - 2016-08-12 22:12:16 --> Controller Class Initialized
INFO - 2016-08-12 22:12:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:12:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:12:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:12:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:12:16 --> Final output sent to browser
DEBUG - 2016-08-12 22:12:16 --> Total execution time: 1.0500
INFO - 2016-08-12 22:12:17 --> Config Class Initialized
INFO - 2016-08-12 22:12:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:12:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:12:17 --> Utf8 Class Initialized
INFO - 2016-08-12 22:12:17 --> URI Class Initialized
INFO - 2016-08-12 22:12:17 --> Router Class Initialized
INFO - 2016-08-12 22:12:17 --> Output Class Initialized
INFO - 2016-08-12 22:12:17 --> Security Class Initialized
DEBUG - 2016-08-12 22:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:12:17 --> Input Class Initialized
INFO - 2016-08-12 22:12:17 --> Language Class Initialized
ERROR - 2016-08-12 22:12:17 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 22:17:04 --> Config Class Initialized
INFO - 2016-08-12 22:17:04 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:17:04 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:17:04 --> Utf8 Class Initialized
INFO - 2016-08-12 22:17:04 --> URI Class Initialized
INFO - 2016-08-12 22:17:05 --> Router Class Initialized
INFO - 2016-08-12 22:17:05 --> Output Class Initialized
INFO - 2016-08-12 22:17:05 --> Security Class Initialized
DEBUG - 2016-08-12 22:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:17:05 --> Input Class Initialized
INFO - 2016-08-12 22:17:05 --> Language Class Initialized
INFO - 2016-08-12 22:17:05 --> Loader Class Initialized
INFO - 2016-08-12 22:17:05 --> Helper loaded: url_helper
INFO - 2016-08-12 22:17:05 --> Helper loaded: date_helper
INFO - 2016-08-12 22:17:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:17:05 --> Database Driver Class Initialized
INFO - 2016-08-12 22:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:17:05 --> Email Class Initialized
INFO - 2016-08-12 22:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:17:05 --> Pagination Class Initialized
INFO - 2016-08-12 22:17:05 --> Model Class Initialized
INFO - 2016-08-12 22:17:05 --> Controller Class Initialized
INFO - 2016-08-12 22:17:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:17:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:17:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:17:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:17:05 --> Final output sent to browser
DEBUG - 2016-08-12 22:17:05 --> Total execution time: 0.7259
INFO - 2016-08-12 22:17:06 --> Config Class Initialized
INFO - 2016-08-12 22:17:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:17:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:17:06 --> Utf8 Class Initialized
INFO - 2016-08-12 22:17:06 --> URI Class Initialized
INFO - 2016-08-12 22:17:06 --> Router Class Initialized
INFO - 2016-08-12 22:17:06 --> Output Class Initialized
INFO - 2016-08-12 22:17:06 --> Security Class Initialized
DEBUG - 2016-08-12 22:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:17:06 --> Input Class Initialized
INFO - 2016-08-12 22:17:06 --> Language Class Initialized
ERROR - 2016-08-12 22:17:06 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 22:18:18 --> Config Class Initialized
INFO - 2016-08-12 22:18:18 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:18:18 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:18:18 --> Utf8 Class Initialized
INFO - 2016-08-12 22:18:18 --> URI Class Initialized
INFO - 2016-08-12 22:18:18 --> Router Class Initialized
INFO - 2016-08-12 22:18:19 --> Output Class Initialized
INFO - 2016-08-12 22:18:19 --> Security Class Initialized
DEBUG - 2016-08-12 22:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:18:19 --> Input Class Initialized
INFO - 2016-08-12 22:18:19 --> Language Class Initialized
INFO - 2016-08-12 22:18:19 --> Loader Class Initialized
INFO - 2016-08-12 22:18:19 --> Helper loaded: url_helper
INFO - 2016-08-12 22:18:19 --> Helper loaded: date_helper
INFO - 2016-08-12 22:18:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:18:19 --> Database Driver Class Initialized
INFO - 2016-08-12 22:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:18:19 --> Email Class Initialized
INFO - 2016-08-12 22:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:18:19 --> Pagination Class Initialized
INFO - 2016-08-12 22:18:19 --> Model Class Initialized
INFO - 2016-08-12 22:18:19 --> Controller Class Initialized
INFO - 2016-08-12 22:18:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:18:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:18:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:18:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:18:19 --> Final output sent to browser
DEBUG - 2016-08-12 22:18:19 --> Total execution time: 0.9057
INFO - 2016-08-12 22:19:37 --> Config Class Initialized
INFO - 2016-08-12 22:19:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:19:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:19:37 --> Utf8 Class Initialized
INFO - 2016-08-12 22:19:37 --> URI Class Initialized
INFO - 2016-08-12 22:19:37 --> Router Class Initialized
INFO - 2016-08-12 22:19:37 --> Output Class Initialized
INFO - 2016-08-12 22:19:37 --> Security Class Initialized
DEBUG - 2016-08-12 22:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:19:37 --> Input Class Initialized
INFO - 2016-08-12 22:19:37 --> Language Class Initialized
INFO - 2016-08-12 22:19:37 --> Loader Class Initialized
INFO - 2016-08-12 22:19:37 --> Helper loaded: url_helper
INFO - 2016-08-12 22:19:37 --> Helper loaded: date_helper
INFO - 2016-08-12 22:19:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:19:37 --> Database Driver Class Initialized
INFO - 2016-08-12 22:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:19:37 --> Email Class Initialized
INFO - 2016-08-12 22:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:19:37 --> Pagination Class Initialized
INFO - 2016-08-12 22:19:37 --> Model Class Initialized
INFO - 2016-08-12 22:19:37 --> Controller Class Initialized
INFO - 2016-08-12 22:19:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:19:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:19:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:19:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:19:37 --> Final output sent to browser
DEBUG - 2016-08-12 22:19:37 --> Total execution time: 0.6270
INFO - 2016-08-12 22:19:38 --> Config Class Initialized
INFO - 2016-08-12 22:19:38 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:19:38 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:19:38 --> Utf8 Class Initialized
INFO - 2016-08-12 22:19:38 --> URI Class Initialized
INFO - 2016-08-12 22:19:38 --> Router Class Initialized
INFO - 2016-08-12 22:19:38 --> Output Class Initialized
INFO - 2016-08-12 22:19:38 --> Security Class Initialized
DEBUG - 2016-08-12 22:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:19:38 --> Input Class Initialized
INFO - 2016-08-12 22:19:38 --> Language Class Initialized
ERROR - 2016-08-12 22:19:38 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 22:20:24 --> Config Class Initialized
INFO - 2016-08-12 22:20:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:20:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:20:24 --> Utf8 Class Initialized
INFO - 2016-08-12 22:20:24 --> URI Class Initialized
INFO - 2016-08-12 22:20:25 --> Router Class Initialized
INFO - 2016-08-12 22:20:25 --> Output Class Initialized
INFO - 2016-08-12 22:20:25 --> Security Class Initialized
DEBUG - 2016-08-12 22:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:20:25 --> Input Class Initialized
INFO - 2016-08-12 22:20:25 --> Language Class Initialized
INFO - 2016-08-12 22:20:25 --> Loader Class Initialized
INFO - 2016-08-12 22:20:25 --> Helper loaded: url_helper
INFO - 2016-08-12 22:20:25 --> Helper loaded: date_helper
INFO - 2016-08-12 22:20:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:20:25 --> Database Driver Class Initialized
INFO - 2016-08-12 22:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:20:25 --> Email Class Initialized
INFO - 2016-08-12 22:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:20:25 --> Pagination Class Initialized
INFO - 2016-08-12 22:20:25 --> Model Class Initialized
INFO - 2016-08-12 22:20:25 --> Controller Class Initialized
INFO - 2016-08-12 22:20:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:20:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:20:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:20:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:20:25 --> Final output sent to browser
DEBUG - 2016-08-12 22:20:25 --> Total execution time: 0.6324
INFO - 2016-08-12 22:20:34 --> Config Class Initialized
INFO - 2016-08-12 22:20:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:20:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:20:34 --> Utf8 Class Initialized
INFO - 2016-08-12 22:20:34 --> URI Class Initialized
INFO - 2016-08-12 22:20:34 --> Router Class Initialized
INFO - 2016-08-12 22:20:34 --> Output Class Initialized
INFO - 2016-08-12 22:20:34 --> Security Class Initialized
DEBUG - 2016-08-12 22:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:20:34 --> Input Class Initialized
INFO - 2016-08-12 22:20:34 --> Language Class Initialized
INFO - 2016-08-12 22:20:34 --> Loader Class Initialized
INFO - 2016-08-12 22:20:34 --> Helper loaded: url_helper
INFO - 2016-08-12 22:20:34 --> Helper loaded: date_helper
INFO - 2016-08-12 22:20:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:20:34 --> Database Driver Class Initialized
INFO - 2016-08-12 22:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:20:34 --> Email Class Initialized
INFO - 2016-08-12 22:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:20:34 --> Pagination Class Initialized
INFO - 2016-08-12 22:20:34 --> Model Class Initialized
INFO - 2016-08-12 22:20:34 --> Controller Class Initialized
INFO - 2016-08-12 22:20:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:20:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:20:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:20:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:20:34 --> Final output sent to browser
DEBUG - 2016-08-12 22:20:34 --> Total execution time: 0.6560
INFO - 2016-08-12 22:21:11 --> Config Class Initialized
INFO - 2016-08-12 22:21:11 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:21:11 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:21:11 --> Utf8 Class Initialized
INFO - 2016-08-12 22:21:11 --> URI Class Initialized
INFO - 2016-08-12 22:21:11 --> Router Class Initialized
INFO - 2016-08-12 22:21:11 --> Output Class Initialized
INFO - 2016-08-12 22:21:11 --> Security Class Initialized
DEBUG - 2016-08-12 22:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:21:11 --> Input Class Initialized
INFO - 2016-08-12 22:21:11 --> Language Class Initialized
INFO - 2016-08-12 22:21:11 --> Loader Class Initialized
INFO - 2016-08-12 22:21:11 --> Helper loaded: url_helper
INFO - 2016-08-12 22:21:11 --> Helper loaded: date_helper
INFO - 2016-08-12 22:21:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:21:11 --> Database Driver Class Initialized
INFO - 2016-08-12 22:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:21:11 --> Email Class Initialized
INFO - 2016-08-12 22:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:21:11 --> Pagination Class Initialized
INFO - 2016-08-12 22:21:11 --> Model Class Initialized
INFO - 2016-08-12 22:21:11 --> Controller Class Initialized
INFO - 2016-08-12 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:21:11 --> Final output sent to browser
DEBUG - 2016-08-12 22:21:11 --> Total execution time: 0.6747
INFO - 2016-08-12 22:25:15 --> Config Class Initialized
INFO - 2016-08-12 22:25:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:25:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:25:15 --> Utf8 Class Initialized
INFO - 2016-08-12 22:25:15 --> URI Class Initialized
INFO - 2016-08-12 22:25:15 --> Router Class Initialized
INFO - 2016-08-12 22:25:15 --> Output Class Initialized
INFO - 2016-08-12 22:25:15 --> Security Class Initialized
DEBUG - 2016-08-12 22:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:25:15 --> Input Class Initialized
INFO - 2016-08-12 22:25:15 --> Language Class Initialized
INFO - 2016-08-12 22:25:15 --> Loader Class Initialized
INFO - 2016-08-12 22:25:15 --> Helper loaded: url_helper
INFO - 2016-08-12 22:25:15 --> Helper loaded: date_helper
INFO - 2016-08-12 22:25:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:25:15 --> Database Driver Class Initialized
INFO - 2016-08-12 22:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:25:15 --> Email Class Initialized
INFO - 2016-08-12 22:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:25:15 --> Pagination Class Initialized
INFO - 2016-08-12 22:25:15 --> Model Class Initialized
INFO - 2016-08-12 22:25:15 --> Controller Class Initialized
INFO - 2016-08-12 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:25:15 --> Final output sent to browser
DEBUG - 2016-08-12 22:25:15 --> Total execution time: 0.6400
INFO - 2016-08-12 22:25:16 --> Config Class Initialized
INFO - 2016-08-12 22:25:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:25:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:25:16 --> Utf8 Class Initialized
INFO - 2016-08-12 22:25:16 --> URI Class Initialized
INFO - 2016-08-12 22:25:16 --> Router Class Initialized
INFO - 2016-08-12 22:25:16 --> Output Class Initialized
INFO - 2016-08-12 22:25:16 --> Security Class Initialized
DEBUG - 2016-08-12 22:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:25:16 --> Input Class Initialized
INFO - 2016-08-12 22:25:16 --> Language Class Initialized
ERROR - 2016-08-12 22:25:16 --> 404 Page Not Found: Assets/css
INFO - 2016-08-12 22:25:33 --> Config Class Initialized
INFO - 2016-08-12 22:25:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:25:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:25:33 --> Utf8 Class Initialized
INFO - 2016-08-12 22:25:33 --> URI Class Initialized
INFO - 2016-08-12 22:25:33 --> Router Class Initialized
INFO - 2016-08-12 22:25:33 --> Output Class Initialized
INFO - 2016-08-12 22:25:33 --> Security Class Initialized
DEBUG - 2016-08-12 22:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:25:33 --> Input Class Initialized
INFO - 2016-08-12 22:25:33 --> Language Class Initialized
INFO - 2016-08-12 22:25:33 --> Loader Class Initialized
INFO - 2016-08-12 22:25:33 --> Helper loaded: url_helper
INFO - 2016-08-12 22:25:33 --> Helper loaded: date_helper
INFO - 2016-08-12 22:25:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:25:33 --> Database Driver Class Initialized
INFO - 2016-08-12 22:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:25:33 --> Email Class Initialized
INFO - 2016-08-12 22:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:25:34 --> Pagination Class Initialized
INFO - 2016-08-12 22:25:34 --> Model Class Initialized
INFO - 2016-08-12 22:25:34 --> Controller Class Initialized
INFO - 2016-08-12 22:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:25:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:25:34 --> Final output sent to browser
DEBUG - 2016-08-12 22:25:34 --> Total execution time: 0.7880
INFO - 2016-08-12 22:26:15 --> Config Class Initialized
INFO - 2016-08-12 22:26:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 22:26:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 22:26:15 --> Utf8 Class Initialized
INFO - 2016-08-12 22:26:15 --> URI Class Initialized
INFO - 2016-08-12 22:26:15 --> Router Class Initialized
INFO - 2016-08-12 22:26:15 --> Output Class Initialized
INFO - 2016-08-12 22:26:15 --> Security Class Initialized
DEBUG - 2016-08-12 22:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 22:26:16 --> Input Class Initialized
INFO - 2016-08-12 22:26:16 --> Language Class Initialized
INFO - 2016-08-12 22:26:16 --> Loader Class Initialized
INFO - 2016-08-12 22:26:16 --> Helper loaded: url_helper
INFO - 2016-08-12 22:26:16 --> Helper loaded: date_helper
INFO - 2016-08-12 22:26:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-12 22:26:16 --> Database Driver Class Initialized
INFO - 2016-08-12 22:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 22:26:16 --> Email Class Initialized
INFO - 2016-08-12 22:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-12 22:26:16 --> Pagination Class Initialized
INFO - 2016-08-12 22:26:16 --> Model Class Initialized
INFO - 2016-08-12 22:26:16 --> Controller Class Initialized
INFO - 2016-08-12 22:26:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-12 22:26:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-12 22:26:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\order.php
INFO - 2016-08-12 22:26:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-12 22:26:16 --> Final output sent to browser
DEBUG - 2016-08-12 22:26:16 --> Total execution time: 0.6810
