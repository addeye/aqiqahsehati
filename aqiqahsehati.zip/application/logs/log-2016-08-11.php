<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-11 00:00:06 --> Config Class Initialized
INFO - 2016-08-11 00:00:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:00:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:00:06 --> Utf8 Class Initialized
INFO - 2016-08-11 00:00:06 --> URI Class Initialized
INFO - 2016-08-11 00:00:06 --> Router Class Initialized
INFO - 2016-08-11 00:00:06 --> Output Class Initialized
INFO - 2016-08-11 00:00:06 --> Security Class Initialized
DEBUG - 2016-08-11 00:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:00:06 --> Input Class Initialized
INFO - 2016-08-11 00:00:06 --> Language Class Initialized
INFO - 2016-08-11 00:00:06 --> Loader Class Initialized
INFO - 2016-08-11 00:00:06 --> Helper loaded: url_helper
INFO - 2016-08-11 00:00:06 --> Helper loaded: date_helper
INFO - 2016-08-11 00:00:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:00:06 --> Database Driver Class Initialized
INFO - 2016-08-11 00:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:00:06 --> Email Class Initialized
INFO - 2016-08-11 00:00:06 --> Model Class Initialized
INFO - 2016-08-11 00:00:06 --> Controller Class Initialized
DEBUG - 2016-08-11 00:00:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:00:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:00:06 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:00:06 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:00:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:06 --> Model Class Initialized
INFO - 2016-08-11 00:00:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:00:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:00:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:00:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-11 00:00:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:00:06 --> Final output sent to browser
DEBUG - 2016-08-11 00:00:06 --> Total execution time: 0.3226
INFO - 2016-08-11 00:00:17 --> Config Class Initialized
INFO - 2016-08-11 00:00:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:00:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:00:17 --> Utf8 Class Initialized
INFO - 2016-08-11 00:00:17 --> URI Class Initialized
INFO - 2016-08-11 00:00:17 --> Router Class Initialized
INFO - 2016-08-11 00:00:17 --> Output Class Initialized
INFO - 2016-08-11 00:00:17 --> Security Class Initialized
DEBUG - 2016-08-11 00:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:00:17 --> Input Class Initialized
INFO - 2016-08-11 00:00:17 --> Language Class Initialized
INFO - 2016-08-11 00:00:17 --> Loader Class Initialized
INFO - 2016-08-11 00:00:17 --> Helper loaded: url_helper
INFO - 2016-08-11 00:00:17 --> Helper loaded: date_helper
INFO - 2016-08-11 00:00:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:00:17 --> Database Driver Class Initialized
INFO - 2016-08-11 00:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:00:17 --> Email Class Initialized
INFO - 2016-08-11 00:00:17 --> Model Class Initialized
INFO - 2016-08-11 00:00:17 --> Controller Class Initialized
DEBUG - 2016-08-11 00:00:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:00:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:00:17 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:00:17 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:17 --> Model Class Initialized
INFO - 2016-08-11 00:00:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:00:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:00:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:00:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 00:00:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:00:17 --> Final output sent to browser
DEBUG - 2016-08-11 00:00:17 --> Total execution time: 0.3576
INFO - 2016-08-11 00:00:51 --> Config Class Initialized
INFO - 2016-08-11 00:00:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:00:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:00:51 --> Utf8 Class Initialized
INFO - 2016-08-11 00:00:51 --> URI Class Initialized
INFO - 2016-08-11 00:00:51 --> Router Class Initialized
INFO - 2016-08-11 00:00:51 --> Output Class Initialized
INFO - 2016-08-11 00:00:51 --> Security Class Initialized
DEBUG - 2016-08-11 00:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:00:51 --> Input Class Initialized
INFO - 2016-08-11 00:00:51 --> Language Class Initialized
INFO - 2016-08-11 00:00:51 --> Loader Class Initialized
INFO - 2016-08-11 00:00:51 --> Helper loaded: url_helper
INFO - 2016-08-11 00:00:51 --> Helper loaded: date_helper
INFO - 2016-08-11 00:00:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:00:51 --> Database Driver Class Initialized
INFO - 2016-08-11 00:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:00:51 --> Email Class Initialized
INFO - 2016-08-11 00:00:51 --> Model Class Initialized
INFO - 2016-08-11 00:00:51 --> Controller Class Initialized
DEBUG - 2016-08-11 00:00:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:00:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:00:51 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:00:51 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:00:51 --> Model Class Initialized
INFO - 2016-08-11 00:00:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:00:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:00:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:00:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 00:00:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:00:51 --> Final output sent to browser
DEBUG - 2016-08-11 00:00:51 --> Total execution time: 0.3141
INFO - 2016-08-11 00:06:50 --> Config Class Initialized
INFO - 2016-08-11 00:06:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:06:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:06:50 --> Utf8 Class Initialized
INFO - 2016-08-11 00:06:50 --> URI Class Initialized
INFO - 2016-08-11 00:06:50 --> Router Class Initialized
INFO - 2016-08-11 00:06:50 --> Output Class Initialized
INFO - 2016-08-11 00:06:50 --> Security Class Initialized
DEBUG - 2016-08-11 00:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:06:50 --> Input Class Initialized
INFO - 2016-08-11 00:06:50 --> Language Class Initialized
INFO - 2016-08-11 00:06:50 --> Loader Class Initialized
INFO - 2016-08-11 00:06:50 --> Helper loaded: url_helper
INFO - 2016-08-11 00:06:50 --> Helper loaded: date_helper
INFO - 2016-08-11 00:06:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:06:50 --> Database Driver Class Initialized
INFO - 2016-08-11 00:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:06:50 --> Email Class Initialized
INFO - 2016-08-11 00:06:50 --> Model Class Initialized
INFO - 2016-08-11 00:06:50 --> Controller Class Initialized
DEBUG - 2016-08-11 00:06:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:06:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:06:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:06:50 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:06:50 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:06:50 --> Model Class Initialized
INFO - 2016-08-11 00:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-11 00:06:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:06:50 --> Final output sent to browser
DEBUG - 2016-08-11 00:06:50 --> Total execution time: 0.3238
INFO - 2016-08-11 00:07:02 --> Config Class Initialized
INFO - 2016-08-11 00:07:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:07:02 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:07:02 --> Utf8 Class Initialized
INFO - 2016-08-11 00:07:02 --> URI Class Initialized
INFO - 2016-08-11 00:07:02 --> Router Class Initialized
INFO - 2016-08-11 00:07:02 --> Output Class Initialized
INFO - 2016-08-11 00:07:02 --> Security Class Initialized
DEBUG - 2016-08-11 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:07:02 --> Input Class Initialized
INFO - 2016-08-11 00:07:02 --> Language Class Initialized
INFO - 2016-08-11 00:07:02 --> Loader Class Initialized
INFO - 2016-08-11 00:07:02 --> Helper loaded: url_helper
INFO - 2016-08-11 00:07:02 --> Helper loaded: date_helper
INFO - 2016-08-11 00:07:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:07:02 --> Database Driver Class Initialized
INFO - 2016-08-11 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:07:02 --> Email Class Initialized
INFO - 2016-08-11 00:07:02 --> Model Class Initialized
INFO - 2016-08-11 00:07:02 --> Controller Class Initialized
DEBUG - 2016-08-11 00:07:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:07:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:07:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:07:02 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:07:02 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:07:02 --> Model Class Initialized
INFO - 2016-08-11 00:07:02 --> Config Class Initialized
INFO - 2016-08-11 00:07:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:07:02 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:07:02 --> Utf8 Class Initialized
INFO - 2016-08-11 00:07:02 --> URI Class Initialized
INFO - 2016-08-11 00:07:02 --> Router Class Initialized
INFO - 2016-08-11 00:07:02 --> Output Class Initialized
INFO - 2016-08-11 00:07:02 --> Security Class Initialized
DEBUG - 2016-08-11 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:07:02 --> Input Class Initialized
INFO - 2016-08-11 00:07:02 --> Language Class Initialized
INFO - 2016-08-11 00:07:02 --> Loader Class Initialized
INFO - 2016-08-11 00:07:02 --> Helper loaded: url_helper
INFO - 2016-08-11 00:07:02 --> Helper loaded: date_helper
INFO - 2016-08-11 00:07:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:07:02 --> Database Driver Class Initialized
INFO - 2016-08-11 00:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:07:03 --> Email Class Initialized
INFO - 2016-08-11 00:07:03 --> Model Class Initialized
INFO - 2016-08-11 00:07:03 --> Controller Class Initialized
DEBUG - 2016-08-11 00:07:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:07:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:07:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:07:03 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:07:03 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:07:03 --> Model Class Initialized
INFO - 2016-08-11 00:07:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:07:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:07:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:07:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 00:07:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:07:03 --> Final output sent to browser
DEBUG - 2016-08-11 00:07:03 --> Total execution time: 0.3410
INFO - 2016-08-11 00:43:57 --> Config Class Initialized
INFO - 2016-08-11 00:43:57 --> Hooks Class Initialized
DEBUG - 2016-08-11 00:43:57 --> UTF-8 Support Enabled
INFO - 2016-08-11 00:43:57 --> Utf8 Class Initialized
INFO - 2016-08-11 00:43:57 --> URI Class Initialized
INFO - 2016-08-11 00:43:57 --> Router Class Initialized
INFO - 2016-08-11 00:43:57 --> Output Class Initialized
INFO - 2016-08-11 00:43:57 --> Security Class Initialized
DEBUG - 2016-08-11 00:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 00:43:57 --> Input Class Initialized
INFO - 2016-08-11 00:43:57 --> Language Class Initialized
INFO - 2016-08-11 00:43:57 --> Loader Class Initialized
INFO - 2016-08-11 00:43:57 --> Helper loaded: url_helper
INFO - 2016-08-11 00:43:58 --> Helper loaded: date_helper
INFO - 2016-08-11 00:43:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 00:43:58 --> Database Driver Class Initialized
INFO - 2016-08-11 00:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 00:43:58 --> Email Class Initialized
INFO - 2016-08-11 00:43:58 --> Model Class Initialized
INFO - 2016-08-11 00:43:58 --> Controller Class Initialized
DEBUG - 2016-08-11 00:43:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 00:43:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:43:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 00:43:58 --> Helper loaded: cookie_helper
INFO - 2016-08-11 00:43:58 --> Helper loaded: language_helper
DEBUG - 2016-08-11 00:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 00:43:58 --> Model Class Initialized
INFO - 2016-08-11 00:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 00:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 00:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 00:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 00:43:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 00:43:58 --> Final output sent to browser
DEBUG - 2016-08-11 00:43:58 --> Total execution time: 0.3708
INFO - 2016-08-11 07:40:11 --> Config Class Initialized
INFO - 2016-08-11 07:40:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 07:40:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 07:40:11 --> Utf8 Class Initialized
INFO - 2016-08-11 07:40:11 --> URI Class Initialized
INFO - 2016-08-11 07:40:11 --> Router Class Initialized
INFO - 2016-08-11 07:40:11 --> Output Class Initialized
INFO - 2016-08-11 07:40:11 --> Security Class Initialized
DEBUG - 2016-08-11 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 07:40:11 --> Input Class Initialized
INFO - 2016-08-11 07:40:11 --> Language Class Initialized
INFO - 2016-08-11 07:40:12 --> Loader Class Initialized
INFO - 2016-08-11 07:40:12 --> Helper loaded: url_helper
INFO - 2016-08-11 07:40:12 --> Helper loaded: date_helper
INFO - 2016-08-11 07:40:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 07:40:15 --> Database Driver Class Initialized
INFO - 2016-08-11 07:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 07:40:16 --> Email Class Initialized
INFO - 2016-08-11 07:40:16 --> Model Class Initialized
INFO - 2016-08-11 07:40:16 --> Controller Class Initialized
DEBUG - 2016-08-11 07:40:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 07:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 07:40:16 --> Helper loaded: cookie_helper
INFO - 2016-08-11 07:40:16 --> Helper loaded: language_helper
DEBUG - 2016-08-11 07:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:16 --> Model Class Initialized
INFO - 2016-08-11 07:40:17 --> Config Class Initialized
INFO - 2016-08-11 07:40:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 07:40:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 07:40:17 --> Utf8 Class Initialized
INFO - 2016-08-11 07:40:17 --> URI Class Initialized
INFO - 2016-08-11 07:40:17 --> Router Class Initialized
INFO - 2016-08-11 07:40:17 --> Output Class Initialized
INFO - 2016-08-11 07:40:17 --> Security Class Initialized
DEBUG - 2016-08-11 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 07:40:17 --> Input Class Initialized
INFO - 2016-08-11 07:40:17 --> Language Class Initialized
INFO - 2016-08-11 07:40:17 --> Loader Class Initialized
INFO - 2016-08-11 07:40:17 --> Helper loaded: url_helper
INFO - 2016-08-11 07:40:17 --> Helper loaded: date_helper
INFO - 2016-08-11 07:40:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 07:40:17 --> Database Driver Class Initialized
INFO - 2016-08-11 07:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 07:40:17 --> Email Class Initialized
INFO - 2016-08-11 07:40:17 --> Model Class Initialized
INFO - 2016-08-11 07:40:17 --> Controller Class Initialized
DEBUG - 2016-08-11 07:40:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 07:40:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 07:40:17 --> Helper loaded: cookie_helper
INFO - 2016-08-11 07:40:17 --> Helper loaded: language_helper
DEBUG - 2016-08-11 07:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:17 --> Model Class Initialized
INFO - 2016-08-11 07:40:17 --> Helper loaded: form_helper
INFO - 2016-08-11 07:40:17 --> Form Validation Class Initialized
INFO - 2016-08-11 07:40:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 07:40:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 07:40:17 --> Final output sent to browser
DEBUG - 2016-08-11 07:40:17 --> Total execution time: 0.8575
INFO - 2016-08-11 07:40:24 --> Config Class Initialized
INFO - 2016-08-11 07:40:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 07:40:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 07:40:24 --> Utf8 Class Initialized
INFO - 2016-08-11 07:40:24 --> URI Class Initialized
INFO - 2016-08-11 07:40:24 --> Router Class Initialized
INFO - 2016-08-11 07:40:24 --> Output Class Initialized
INFO - 2016-08-11 07:40:24 --> Security Class Initialized
DEBUG - 2016-08-11 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 07:40:24 --> Input Class Initialized
INFO - 2016-08-11 07:40:24 --> Language Class Initialized
INFO - 2016-08-11 07:40:24 --> Loader Class Initialized
INFO - 2016-08-11 07:40:24 --> Helper loaded: url_helper
INFO - 2016-08-11 07:40:24 --> Helper loaded: date_helper
INFO - 2016-08-11 07:40:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 07:40:24 --> Database Driver Class Initialized
INFO - 2016-08-11 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 07:40:24 --> Email Class Initialized
INFO - 2016-08-11 07:40:24 --> Model Class Initialized
INFO - 2016-08-11 07:40:24 --> Controller Class Initialized
DEBUG - 2016-08-11 07:40:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 07:40:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 07:40:24 --> Helper loaded: cookie_helper
INFO - 2016-08-11 07:40:24 --> Helper loaded: language_helper
DEBUG - 2016-08-11 07:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:24 --> Model Class Initialized
INFO - 2016-08-11 07:40:24 --> Helper loaded: form_helper
INFO - 2016-08-11 07:40:24 --> Form Validation Class Initialized
INFO - 2016-08-11 07:40:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 07:40:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 07:40:25 --> Config Class Initialized
INFO - 2016-08-11 07:40:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 07:40:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 07:40:25 --> Utf8 Class Initialized
INFO - 2016-08-11 07:40:25 --> URI Class Initialized
INFO - 2016-08-11 07:40:25 --> Router Class Initialized
INFO - 2016-08-11 07:40:25 --> Output Class Initialized
INFO - 2016-08-11 07:40:25 --> Security Class Initialized
DEBUG - 2016-08-11 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 07:40:25 --> Input Class Initialized
INFO - 2016-08-11 07:40:25 --> Language Class Initialized
INFO - 2016-08-11 07:40:25 --> Loader Class Initialized
INFO - 2016-08-11 07:40:25 --> Helper loaded: url_helper
INFO - 2016-08-11 07:40:25 --> Helper loaded: date_helper
INFO - 2016-08-11 07:40:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 07:40:25 --> Database Driver Class Initialized
INFO - 2016-08-11 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 07:40:25 --> Email Class Initialized
INFO - 2016-08-11 07:40:25 --> Model Class Initialized
INFO - 2016-08-11 07:40:25 --> Controller Class Initialized
DEBUG - 2016-08-11 07:40:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 07:40:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 07:40:25 --> Helper loaded: cookie_helper
INFO - 2016-08-11 07:40:25 --> Helper loaded: language_helper
DEBUG - 2016-08-11 07:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 07:40:25 --> Model Class Initialized
INFO - 2016-08-11 07:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 07:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 07:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 07:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 07:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 07:40:25 --> Final output sent to browser
DEBUG - 2016-08-11 07:40:25 --> Total execution time: 0.5877
INFO - 2016-08-11 08:45:19 --> Config Class Initialized
INFO - 2016-08-11 08:45:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:45:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:45:19 --> Utf8 Class Initialized
INFO - 2016-08-11 08:45:20 --> URI Class Initialized
INFO - 2016-08-11 08:45:20 --> Router Class Initialized
INFO - 2016-08-11 08:45:20 --> Output Class Initialized
INFO - 2016-08-11 08:45:20 --> Security Class Initialized
DEBUG - 2016-08-11 08:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:45:20 --> Input Class Initialized
INFO - 2016-08-11 08:45:20 --> Language Class Initialized
INFO - 2016-08-11 08:45:20 --> Loader Class Initialized
INFO - 2016-08-11 08:45:20 --> Helper loaded: url_helper
INFO - 2016-08-11 08:45:20 --> Helper loaded: date_helper
INFO - 2016-08-11 08:45:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 08:45:20 --> Database Driver Class Initialized
INFO - 2016-08-11 08:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:45:20 --> Email Class Initialized
INFO - 2016-08-11 08:45:20 --> Model Class Initialized
INFO - 2016-08-11 08:45:20 --> Controller Class Initialized
DEBUG - 2016-08-11 08:45:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 08:45:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 08:45:20 --> Helper loaded: cookie_helper
INFO - 2016-08-11 08:45:20 --> Helper loaded: language_helper
DEBUG - 2016-08-11 08:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:21 --> Model Class Initialized
INFO - 2016-08-11 08:45:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 08:45:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 08:45:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 08:45:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 08:45:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 08:45:21 --> Final output sent to browser
DEBUG - 2016-08-11 08:45:21 --> Total execution time: 1.4502
INFO - 2016-08-11 08:45:24 --> Config Class Initialized
INFO - 2016-08-11 08:45:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:45:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:45:24 --> Utf8 Class Initialized
INFO - 2016-08-11 08:45:24 --> URI Class Initialized
INFO - 2016-08-11 08:45:24 --> Router Class Initialized
INFO - 2016-08-11 08:45:24 --> Output Class Initialized
INFO - 2016-08-11 08:45:24 --> Security Class Initialized
DEBUG - 2016-08-11 08:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:45:24 --> Input Class Initialized
INFO - 2016-08-11 08:45:24 --> Language Class Initialized
INFO - 2016-08-11 08:45:24 --> Loader Class Initialized
INFO - 2016-08-11 08:45:24 --> Helper loaded: url_helper
INFO - 2016-08-11 08:45:24 --> Helper loaded: date_helper
INFO - 2016-08-11 08:45:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 08:45:24 --> Database Driver Class Initialized
INFO - 2016-08-11 08:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:45:25 --> Email Class Initialized
INFO - 2016-08-11 08:45:25 --> Model Class Initialized
INFO - 2016-08-11 08:45:25 --> Controller Class Initialized
DEBUG - 2016-08-11 08:45:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 08:45:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 08:45:25 --> Helper loaded: cookie_helper
INFO - 2016-08-11 08:45:25 --> Helper loaded: language_helper
DEBUG - 2016-08-11 08:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:25 --> Model Class Initialized
INFO - 2016-08-11 08:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 08:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 08:45:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Undefined variable: pengguna D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 26
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 30
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 36
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 42
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 48
ERROR - 2016-08-11 08:45:25 --> Severity: Notice --> Undefined variable: groups D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 63
ERROR - 2016-08-11 08:45:25 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\admin\kategori\update_kategori.php 63
INFO - 2016-08-11 08:45:27 --> Config Class Initialized
INFO - 2016-08-11 08:45:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 08:45:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 08:45:27 --> Utf8 Class Initialized
INFO - 2016-08-11 08:45:27 --> URI Class Initialized
INFO - 2016-08-11 08:45:27 --> Router Class Initialized
INFO - 2016-08-11 08:45:27 --> Output Class Initialized
INFO - 2016-08-11 08:45:27 --> Security Class Initialized
DEBUG - 2016-08-11 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 08:45:27 --> Input Class Initialized
INFO - 2016-08-11 08:45:27 --> Language Class Initialized
INFO - 2016-08-11 08:45:27 --> Loader Class Initialized
INFO - 2016-08-11 08:45:27 --> Helper loaded: url_helper
INFO - 2016-08-11 08:45:27 --> Helper loaded: date_helper
INFO - 2016-08-11 08:45:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 08:45:27 --> Database Driver Class Initialized
INFO - 2016-08-11 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 08:45:27 --> Email Class Initialized
INFO - 2016-08-11 08:45:27 --> Model Class Initialized
INFO - 2016-08-11 08:45:27 --> Controller Class Initialized
DEBUG - 2016-08-11 08:45:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 08:45:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 08:45:27 --> Helper loaded: cookie_helper
INFO - 2016-08-11 08:45:27 --> Helper loaded: language_helper
DEBUG - 2016-08-11 08:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 08:45:27 --> Model Class Initialized
INFO - 2016-08-11 08:45:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 08:45:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 08:45:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 08:45:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 08:45:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 08:45:28 --> Final output sent to browser
DEBUG - 2016-08-11 08:45:28 --> Total execution time: 0.3530
INFO - 2016-08-11 12:09:10 --> Config Class Initialized
INFO - 2016-08-11 12:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:10 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:10 --> URI Class Initialized
DEBUG - 2016-08-11 12:09:10 --> No URI present. Default controller set.
INFO - 2016-08-11 12:09:10 --> Router Class Initialized
INFO - 2016-08-11 12:09:10 --> Output Class Initialized
INFO - 2016-08-11 12:09:10 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:10 --> Input Class Initialized
INFO - 2016-08-11 12:09:10 --> Language Class Initialized
INFO - 2016-08-11 12:09:10 --> Loader Class Initialized
INFO - 2016-08-11 12:09:10 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:10 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:11 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:11 --> Email Class Initialized
INFO - 2016-08-11 12:09:11 --> Model Class Initialized
INFO - 2016-08-11 12:09:11 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:11 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:11 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:11 --> Model Class Initialized
INFO - 2016-08-11 12:09:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:09:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:09:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:09:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:09:11 --> Final output sent to browser
DEBUG - 2016-08-11 12:09:11 --> Total execution time: 1.6704
INFO - 2016-08-11 12:09:15 --> Config Class Initialized
INFO - 2016-08-11 12:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:15 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:15 --> URI Class Initialized
INFO - 2016-08-11 12:09:15 --> Router Class Initialized
INFO - 2016-08-11 12:09:15 --> Output Class Initialized
INFO - 2016-08-11 12:09:15 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:15 --> Input Class Initialized
INFO - 2016-08-11 12:09:15 --> Language Class Initialized
INFO - 2016-08-11 12:09:15 --> Loader Class Initialized
INFO - 2016-08-11 12:09:15 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:15 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:15 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:15 --> Email Class Initialized
INFO - 2016-08-11 12:09:15 --> Model Class Initialized
INFO - 2016-08-11 12:09:15 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:15 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:15 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:15 --> Model Class Initialized
INFO - 2016-08-11 12:09:15 --> Config Class Initialized
INFO - 2016-08-11 12:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:15 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:15 --> URI Class Initialized
INFO - 2016-08-11 12:09:15 --> Router Class Initialized
INFO - 2016-08-11 12:09:15 --> Output Class Initialized
INFO - 2016-08-11 12:09:15 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:15 --> Input Class Initialized
INFO - 2016-08-11 12:09:15 --> Language Class Initialized
INFO - 2016-08-11 12:09:16 --> Loader Class Initialized
INFO - 2016-08-11 12:09:16 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:16 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:16 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:16 --> Email Class Initialized
INFO - 2016-08-11 12:09:16 --> Model Class Initialized
INFO - 2016-08-11 12:09:16 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:16 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:16 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:16 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:16 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:16 --> Model Class Initialized
INFO - 2016-08-11 12:09:16 --> Helper loaded: form_helper
INFO - 2016-08-11 12:09:16 --> Form Validation Class Initialized
INFO - 2016-08-11 12:09:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 12:09:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 12:09:16 --> Final output sent to browser
DEBUG - 2016-08-11 12:09:16 --> Total execution time: 0.5462
INFO - 2016-08-11 12:09:21 --> Config Class Initialized
INFO - 2016-08-11 12:09:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:21 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:21 --> URI Class Initialized
INFO - 2016-08-11 12:09:21 --> Router Class Initialized
INFO - 2016-08-11 12:09:21 --> Output Class Initialized
INFO - 2016-08-11 12:09:21 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:21 --> Input Class Initialized
INFO - 2016-08-11 12:09:21 --> Language Class Initialized
INFO - 2016-08-11 12:09:21 --> Loader Class Initialized
INFO - 2016-08-11 12:09:21 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:21 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:21 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:21 --> Email Class Initialized
INFO - 2016-08-11 12:09:21 --> Model Class Initialized
INFO - 2016-08-11 12:09:21 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:21 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:21 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:21 --> Model Class Initialized
INFO - 2016-08-11 12:09:21 --> Helper loaded: form_helper
INFO - 2016-08-11 12:09:21 --> Form Validation Class Initialized
INFO - 2016-08-11 12:09:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 12:09:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 12:09:22 --> Config Class Initialized
INFO - 2016-08-11 12:09:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:22 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:22 --> URI Class Initialized
INFO - 2016-08-11 12:09:22 --> Router Class Initialized
INFO - 2016-08-11 12:09:22 --> Output Class Initialized
INFO - 2016-08-11 12:09:22 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:22 --> Input Class Initialized
INFO - 2016-08-11 12:09:22 --> Language Class Initialized
INFO - 2016-08-11 12:09:22 --> Loader Class Initialized
INFO - 2016-08-11 12:09:22 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:22 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:22 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:22 --> Email Class Initialized
INFO - 2016-08-11 12:09:22 --> Model Class Initialized
INFO - 2016-08-11 12:09:22 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:22 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:22 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:22 --> Model Class Initialized
INFO - 2016-08-11 12:09:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 12:09:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 12:09:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 12:09:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 12:09:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 12:09:22 --> Final output sent to browser
DEBUG - 2016-08-11 12:09:23 --> Total execution time: 0.4378
INFO - 2016-08-11 12:09:53 --> Config Class Initialized
INFO - 2016-08-11 12:09:53 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:09:53 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:09:53 --> Utf8 Class Initialized
INFO - 2016-08-11 12:09:53 --> URI Class Initialized
INFO - 2016-08-11 12:09:53 --> Router Class Initialized
INFO - 2016-08-11 12:09:53 --> Output Class Initialized
INFO - 2016-08-11 12:09:53 --> Security Class Initialized
DEBUG - 2016-08-11 12:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:09:53 --> Input Class Initialized
INFO - 2016-08-11 12:09:53 --> Language Class Initialized
INFO - 2016-08-11 12:09:54 --> Loader Class Initialized
INFO - 2016-08-11 12:09:54 --> Helper loaded: url_helper
INFO - 2016-08-11 12:09:54 --> Helper loaded: date_helper
INFO - 2016-08-11 12:09:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:09:54 --> Database Driver Class Initialized
INFO - 2016-08-11 12:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:09:54 --> Email Class Initialized
INFO - 2016-08-11 12:09:54 --> Model Class Initialized
INFO - 2016-08-11 12:09:54 --> Controller Class Initialized
DEBUG - 2016-08-11 12:09:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:09:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:09:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:09:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:09:54 --> Model Class Initialized
INFO - 2016-08-11 12:09:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-11 12:09:54 --> Final output sent to browser
DEBUG - 2016-08-11 12:09:54 --> Total execution time: 0.4224
INFO - 2016-08-11 12:10:09 --> Config Class Initialized
INFO - 2016-08-11 12:10:09 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:10:09 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:10:09 --> Utf8 Class Initialized
INFO - 2016-08-11 12:10:09 --> URI Class Initialized
INFO - 2016-08-11 12:10:09 --> Router Class Initialized
INFO - 2016-08-11 12:10:09 --> Output Class Initialized
INFO - 2016-08-11 12:10:09 --> Security Class Initialized
DEBUG - 2016-08-11 12:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:10:09 --> Input Class Initialized
INFO - 2016-08-11 12:10:09 --> Language Class Initialized
INFO - 2016-08-11 12:10:09 --> Loader Class Initialized
INFO - 2016-08-11 12:10:09 --> Helper loaded: url_helper
INFO - 2016-08-11 12:10:09 --> Helper loaded: date_helper
INFO - 2016-08-11 12:10:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:10:09 --> Database Driver Class Initialized
INFO - 2016-08-11 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:10:10 --> Email Class Initialized
INFO - 2016-08-11 12:10:10 --> Model Class Initialized
INFO - 2016-08-11 12:10:10 --> Controller Class Initialized
DEBUG - 2016-08-11 12:10:10 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:10:10 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:10:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:10:10 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:10:10 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:10:10 --> Model Class Initialized
INFO - 2016-08-11 12:10:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-11 12:10:10 --> Final output sent to browser
DEBUG - 2016-08-11 12:10:10 --> Total execution time: 0.3792
INFO - 2016-08-11 12:27:59 --> Config Class Initialized
INFO - 2016-08-11 12:27:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:27:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:27:59 --> Utf8 Class Initialized
INFO - 2016-08-11 12:27:59 --> URI Class Initialized
DEBUG - 2016-08-11 12:27:59 --> No URI present. Default controller set.
INFO - 2016-08-11 12:27:59 --> Router Class Initialized
INFO - 2016-08-11 12:27:59 --> Output Class Initialized
INFO - 2016-08-11 12:27:59 --> Security Class Initialized
DEBUG - 2016-08-11 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:27:59 --> Input Class Initialized
INFO - 2016-08-11 12:27:59 --> Language Class Initialized
INFO - 2016-08-11 12:27:59 --> Loader Class Initialized
INFO - 2016-08-11 12:27:59 --> Helper loaded: url_helper
INFO - 2016-08-11 12:27:59 --> Helper loaded: date_helper
INFO - 2016-08-11 12:27:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:28:00 --> Database Driver Class Initialized
INFO - 2016-08-11 12:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:28:00 --> Email Class Initialized
INFO - 2016-08-11 12:28:00 --> Model Class Initialized
INFO - 2016-08-11 12:28:00 --> Controller Class Initialized
DEBUG - 2016-08-11 12:28:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:28:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:28:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:28:00 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:28:00 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:28:00 --> Model Class Initialized
INFO - 2016-08-11 12:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:28:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:28:00 --> Final output sent to browser
DEBUG - 2016-08-11 12:28:00 --> Total execution time: 0.3732
INFO - 2016-08-11 12:28:03 --> Config Class Initialized
INFO - 2016-08-11 12:28:03 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:28:03 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:28:03 --> Utf8 Class Initialized
INFO - 2016-08-11 12:28:03 --> URI Class Initialized
DEBUG - 2016-08-11 12:28:03 --> No URI present. Default controller set.
INFO - 2016-08-11 12:28:03 --> Router Class Initialized
INFO - 2016-08-11 12:28:03 --> Output Class Initialized
INFO - 2016-08-11 12:28:03 --> Security Class Initialized
DEBUG - 2016-08-11 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:28:03 --> Input Class Initialized
INFO - 2016-08-11 12:28:04 --> Language Class Initialized
INFO - 2016-08-11 12:28:04 --> Loader Class Initialized
INFO - 2016-08-11 12:28:04 --> Helper loaded: url_helper
INFO - 2016-08-11 12:28:04 --> Helper loaded: date_helper
INFO - 2016-08-11 12:28:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:28:04 --> Database Driver Class Initialized
INFO - 2016-08-11 12:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:28:04 --> Email Class Initialized
INFO - 2016-08-11 12:28:04 --> Model Class Initialized
INFO - 2016-08-11 12:28:04 --> Controller Class Initialized
DEBUG - 2016-08-11 12:28:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:28:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:28:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:28:04 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:28:04 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:28:04 --> Model Class Initialized
INFO - 2016-08-11 12:28:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:28:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:28:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:28:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:28:04 --> Final output sent to browser
DEBUG - 2016-08-11 12:28:04 --> Total execution time: 0.9399
INFO - 2016-08-11 12:31:38 --> Config Class Initialized
INFO - 2016-08-11 12:31:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:31:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:31:38 --> Utf8 Class Initialized
INFO - 2016-08-11 12:31:38 --> URI Class Initialized
DEBUG - 2016-08-11 12:31:38 --> No URI present. Default controller set.
INFO - 2016-08-11 12:31:38 --> Router Class Initialized
INFO - 2016-08-11 12:31:38 --> Output Class Initialized
INFO - 2016-08-11 12:31:38 --> Security Class Initialized
DEBUG - 2016-08-11 12:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:31:38 --> Input Class Initialized
INFO - 2016-08-11 12:31:38 --> Language Class Initialized
INFO - 2016-08-11 12:31:38 --> Loader Class Initialized
INFO - 2016-08-11 12:31:38 --> Helper loaded: url_helper
INFO - 2016-08-11 12:31:38 --> Helper loaded: date_helper
INFO - 2016-08-11 12:31:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:31:38 --> Database Driver Class Initialized
INFO - 2016-08-11 12:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:31:38 --> Email Class Initialized
INFO - 2016-08-11 12:31:38 --> Model Class Initialized
INFO - 2016-08-11 12:31:38 --> Controller Class Initialized
DEBUG - 2016-08-11 12:31:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:31:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:31:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:31:38 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:31:38 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:31:38 --> Model Class Initialized
INFO - 2016-08-11 12:31:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:31:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:31:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:31:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:31:38 --> Final output sent to browser
DEBUG - 2016-08-11 12:31:38 --> Total execution time: 0.8127
INFO - 2016-08-11 12:31:54 --> Config Class Initialized
INFO - 2016-08-11 12:31:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:31:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:31:54 --> Utf8 Class Initialized
INFO - 2016-08-11 12:31:54 --> URI Class Initialized
DEBUG - 2016-08-11 12:31:54 --> No URI present. Default controller set.
INFO - 2016-08-11 12:31:54 --> Router Class Initialized
INFO - 2016-08-11 12:31:54 --> Output Class Initialized
INFO - 2016-08-11 12:31:54 --> Security Class Initialized
DEBUG - 2016-08-11 12:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:31:54 --> Input Class Initialized
INFO - 2016-08-11 12:31:54 --> Language Class Initialized
INFO - 2016-08-11 12:31:54 --> Loader Class Initialized
INFO - 2016-08-11 12:31:54 --> Helper loaded: url_helper
INFO - 2016-08-11 12:31:54 --> Helper loaded: date_helper
INFO - 2016-08-11 12:31:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:31:54 --> Database Driver Class Initialized
INFO - 2016-08-11 12:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:31:54 --> Email Class Initialized
INFO - 2016-08-11 12:31:54 --> Model Class Initialized
INFO - 2016-08-11 12:31:54 --> Controller Class Initialized
DEBUG - 2016-08-11 12:31:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:31:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:31:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:31:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:31:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:31:54 --> Model Class Initialized
INFO - 2016-08-11 12:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:31:54 --> Final output sent to browser
DEBUG - 2016-08-11 12:31:54 --> Total execution time: 0.5941
INFO - 2016-08-11 12:32:05 --> Config Class Initialized
INFO - 2016-08-11 12:32:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:32:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:32:05 --> Utf8 Class Initialized
INFO - 2016-08-11 12:32:05 --> URI Class Initialized
DEBUG - 2016-08-11 12:32:05 --> No URI present. Default controller set.
INFO - 2016-08-11 12:32:05 --> Router Class Initialized
INFO - 2016-08-11 12:32:05 --> Output Class Initialized
INFO - 2016-08-11 12:32:05 --> Security Class Initialized
DEBUG - 2016-08-11 12:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:32:05 --> Input Class Initialized
INFO - 2016-08-11 12:32:05 --> Language Class Initialized
INFO - 2016-08-11 12:32:05 --> Loader Class Initialized
INFO - 2016-08-11 12:32:05 --> Helper loaded: url_helper
INFO - 2016-08-11 12:32:05 --> Helper loaded: date_helper
INFO - 2016-08-11 12:32:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:32:05 --> Database Driver Class Initialized
INFO - 2016-08-11 12:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:32:05 --> Email Class Initialized
INFO - 2016-08-11 12:32:05 --> Model Class Initialized
INFO - 2016-08-11 12:32:05 --> Controller Class Initialized
DEBUG - 2016-08-11 12:32:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:32:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:32:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:32:05 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:32:05 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:32:05 --> Model Class Initialized
INFO - 2016-08-11 12:32:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:32:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:32:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:32:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:32:06 --> Final output sent to browser
DEBUG - 2016-08-11 12:32:06 --> Total execution time: 0.6058
INFO - 2016-08-11 12:35:01 --> Config Class Initialized
INFO - 2016-08-11 12:35:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:35:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:35:01 --> Utf8 Class Initialized
INFO - 2016-08-11 12:35:01 --> URI Class Initialized
DEBUG - 2016-08-11 12:35:01 --> No URI present. Default controller set.
INFO - 2016-08-11 12:35:01 --> Router Class Initialized
INFO - 2016-08-11 12:35:01 --> Output Class Initialized
INFO - 2016-08-11 12:35:01 --> Security Class Initialized
DEBUG - 2016-08-11 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:35:01 --> Input Class Initialized
INFO - 2016-08-11 12:35:01 --> Language Class Initialized
INFO - 2016-08-11 12:35:01 --> Loader Class Initialized
INFO - 2016-08-11 12:35:01 --> Helper loaded: url_helper
INFO - 2016-08-11 12:35:02 --> Helper loaded: date_helper
INFO - 2016-08-11 12:35:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:35:02 --> Database Driver Class Initialized
INFO - 2016-08-11 12:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:35:02 --> Email Class Initialized
INFO - 2016-08-11 12:35:02 --> Model Class Initialized
INFO - 2016-08-11 12:35:02 --> Controller Class Initialized
DEBUG - 2016-08-11 12:35:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:35:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:35:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:35:02 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:35:02 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:35:02 --> Model Class Initialized
INFO - 2016-08-11 12:35:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:35:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:35:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:35:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:35:02 --> Final output sent to browser
DEBUG - 2016-08-11 12:35:02 --> Total execution time: 0.4277
INFO - 2016-08-11 12:38:40 --> Config Class Initialized
INFO - 2016-08-11 12:38:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:38:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:38:40 --> Utf8 Class Initialized
INFO - 2016-08-11 12:38:40 --> URI Class Initialized
DEBUG - 2016-08-11 12:38:40 --> No URI present. Default controller set.
INFO - 2016-08-11 12:38:40 --> Router Class Initialized
INFO - 2016-08-11 12:38:40 --> Output Class Initialized
INFO - 2016-08-11 12:38:40 --> Security Class Initialized
DEBUG - 2016-08-11 12:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:38:40 --> Input Class Initialized
INFO - 2016-08-11 12:38:40 --> Language Class Initialized
INFO - 2016-08-11 12:38:40 --> Loader Class Initialized
INFO - 2016-08-11 12:38:40 --> Helper loaded: url_helper
INFO - 2016-08-11 12:38:40 --> Helper loaded: date_helper
INFO - 2016-08-11 12:38:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:38:40 --> Database Driver Class Initialized
INFO - 2016-08-11 12:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:38:40 --> Email Class Initialized
INFO - 2016-08-11 12:38:40 --> Model Class Initialized
INFO - 2016-08-11 12:38:40 --> Controller Class Initialized
DEBUG - 2016-08-11 12:38:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:38:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:38:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:38:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:38:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:38:40 --> Model Class Initialized
INFO - 2016-08-11 12:38:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:38:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:38:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:38:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:38:40 --> Final output sent to browser
DEBUG - 2016-08-11 12:38:40 --> Total execution time: 0.6775
INFO - 2016-08-11 12:39:48 --> Config Class Initialized
INFO - 2016-08-11 12:39:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:39:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:39:48 --> Utf8 Class Initialized
INFO - 2016-08-11 12:39:48 --> URI Class Initialized
DEBUG - 2016-08-11 12:39:48 --> No URI present. Default controller set.
INFO - 2016-08-11 12:39:48 --> Router Class Initialized
INFO - 2016-08-11 12:39:48 --> Output Class Initialized
INFO - 2016-08-11 12:39:48 --> Security Class Initialized
DEBUG - 2016-08-11 12:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:39:48 --> Input Class Initialized
INFO - 2016-08-11 12:39:48 --> Language Class Initialized
INFO - 2016-08-11 12:39:48 --> Loader Class Initialized
INFO - 2016-08-11 12:39:48 --> Helper loaded: url_helper
INFO - 2016-08-11 12:39:48 --> Helper loaded: date_helper
INFO - 2016-08-11 12:39:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:39:49 --> Database Driver Class Initialized
INFO - 2016-08-11 12:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:39:49 --> Email Class Initialized
INFO - 2016-08-11 12:39:49 --> Model Class Initialized
INFO - 2016-08-11 12:39:49 --> Controller Class Initialized
DEBUG - 2016-08-11 12:39:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:39:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:39:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:39:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:39:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:39:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:39:49 --> Model Class Initialized
INFO - 2016-08-11 12:39:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:39:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:39:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:39:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:39:49 --> Final output sent to browser
DEBUG - 2016-08-11 12:39:49 --> Total execution time: 0.3942
INFO - 2016-08-11 12:39:55 --> Config Class Initialized
INFO - 2016-08-11 12:39:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 12:39:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 12:39:55 --> Utf8 Class Initialized
INFO - 2016-08-11 12:39:55 --> URI Class Initialized
DEBUG - 2016-08-11 12:39:55 --> No URI present. Default controller set.
INFO - 2016-08-11 12:39:55 --> Router Class Initialized
INFO - 2016-08-11 12:39:55 --> Output Class Initialized
INFO - 2016-08-11 12:39:55 --> Security Class Initialized
DEBUG - 2016-08-11 12:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 12:39:55 --> Input Class Initialized
INFO - 2016-08-11 12:39:55 --> Language Class Initialized
INFO - 2016-08-11 12:39:55 --> Loader Class Initialized
INFO - 2016-08-11 12:39:55 --> Helper loaded: url_helper
INFO - 2016-08-11 12:39:55 --> Helper loaded: date_helper
INFO - 2016-08-11 12:39:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 12:39:55 --> Database Driver Class Initialized
INFO - 2016-08-11 12:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 12:39:55 --> Email Class Initialized
INFO - 2016-08-11 12:39:56 --> Model Class Initialized
INFO - 2016-08-11 12:39:56 --> Controller Class Initialized
DEBUG - 2016-08-11 12:39:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 12:39:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:39:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 12:39:56 --> Helper loaded: cookie_helper
INFO - 2016-08-11 12:39:56 --> Helper loaded: language_helper
DEBUG - 2016-08-11 12:39:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 12:39:56 --> Model Class Initialized
INFO - 2016-08-11 12:39:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 12:39:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 12:39:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 12:39:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 12:39:56 --> Final output sent to browser
DEBUG - 2016-08-11 12:39:56 --> Total execution time: 0.3857
INFO - 2016-08-11 13:53:31 --> Config Class Initialized
INFO - 2016-08-11 13:53:31 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:53:32 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:53:32 --> Utf8 Class Initialized
INFO - 2016-08-11 13:53:32 --> URI Class Initialized
DEBUG - 2016-08-11 13:53:32 --> No URI present. Default controller set.
INFO - 2016-08-11 13:53:32 --> Router Class Initialized
INFO - 2016-08-11 13:53:32 --> Output Class Initialized
INFO - 2016-08-11 13:53:32 --> Security Class Initialized
DEBUG - 2016-08-11 13:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:53:32 --> Input Class Initialized
INFO - 2016-08-11 13:53:32 --> Language Class Initialized
INFO - 2016-08-11 13:53:32 --> Loader Class Initialized
INFO - 2016-08-11 13:53:32 --> Helper loaded: url_helper
INFO - 2016-08-11 13:53:32 --> Helper loaded: date_helper
INFO - 2016-08-11 13:53:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:53:32 --> Database Driver Class Initialized
INFO - 2016-08-11 13:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:53:33 --> Email Class Initialized
INFO - 2016-08-11 13:53:33 --> Model Class Initialized
INFO - 2016-08-11 13:53:33 --> Controller Class Initialized
DEBUG - 2016-08-11 13:53:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:53:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:53:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:53:33 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:53:33 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:53:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:53:33 --> Model Class Initialized
INFO - 2016-08-11 13:53:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 13:53:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 13:53:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 13:53:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 13:53:33 --> Final output sent to browser
DEBUG - 2016-08-11 13:53:33 --> Total execution time: 2.0196
INFO - 2016-08-11 13:55:10 --> Config Class Initialized
INFO - 2016-08-11 13:55:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:55:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:55:10 --> Utf8 Class Initialized
INFO - 2016-08-11 13:55:10 --> URI Class Initialized
INFO - 2016-08-11 13:55:10 --> Router Class Initialized
INFO - 2016-08-11 13:55:10 --> Output Class Initialized
INFO - 2016-08-11 13:55:10 --> Security Class Initialized
DEBUG - 2016-08-11 13:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:55:10 --> Input Class Initialized
INFO - 2016-08-11 13:55:10 --> Language Class Initialized
INFO - 2016-08-11 13:55:11 --> Loader Class Initialized
INFO - 2016-08-11 13:55:11 --> Helper loaded: url_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: date_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:55:11 --> Database Driver Class Initialized
INFO - 2016-08-11 13:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:55:11 --> Email Class Initialized
INFO - 2016-08-11 13:55:11 --> Model Class Initialized
INFO - 2016-08-11 13:55:11 --> Controller Class Initialized
DEBUG - 2016-08-11 13:55:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:55:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:55:11 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:11 --> Model Class Initialized
INFO - 2016-08-11 13:55:11 --> Config Class Initialized
INFO - 2016-08-11 13:55:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:55:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:55:11 --> Utf8 Class Initialized
INFO - 2016-08-11 13:55:11 --> URI Class Initialized
INFO - 2016-08-11 13:55:11 --> Router Class Initialized
INFO - 2016-08-11 13:55:11 --> Output Class Initialized
INFO - 2016-08-11 13:55:11 --> Security Class Initialized
DEBUG - 2016-08-11 13:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:55:11 --> Input Class Initialized
INFO - 2016-08-11 13:55:11 --> Language Class Initialized
INFO - 2016-08-11 13:55:11 --> Loader Class Initialized
INFO - 2016-08-11 13:55:11 --> Helper loaded: url_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: date_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:55:11 --> Database Driver Class Initialized
INFO - 2016-08-11 13:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:55:11 --> Email Class Initialized
INFO - 2016-08-11 13:55:11 --> Model Class Initialized
INFO - 2016-08-11 13:55:11 --> Controller Class Initialized
DEBUG - 2016-08-11 13:55:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:55:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:55:11 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:55:11 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:11 --> Model Class Initialized
INFO - 2016-08-11 13:55:11 --> Helper loaded: form_helper
INFO - 2016-08-11 13:55:11 --> Form Validation Class Initialized
INFO - 2016-08-11 13:55:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 13:55:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 13:55:11 --> Final output sent to browser
DEBUG - 2016-08-11 13:55:11 --> Total execution time: 0.5299
INFO - 2016-08-11 13:55:21 --> Config Class Initialized
INFO - 2016-08-11 13:55:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:55:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:55:21 --> Utf8 Class Initialized
INFO - 2016-08-11 13:55:21 --> URI Class Initialized
INFO - 2016-08-11 13:55:21 --> Router Class Initialized
INFO - 2016-08-11 13:55:21 --> Output Class Initialized
INFO - 2016-08-11 13:55:21 --> Security Class Initialized
DEBUG - 2016-08-11 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:55:21 --> Input Class Initialized
INFO - 2016-08-11 13:55:21 --> Language Class Initialized
INFO - 2016-08-11 13:55:21 --> Loader Class Initialized
INFO - 2016-08-11 13:55:21 --> Helper loaded: url_helper
INFO - 2016-08-11 13:55:21 --> Helper loaded: date_helper
INFO - 2016-08-11 13:55:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:55:21 --> Database Driver Class Initialized
INFO - 2016-08-11 13:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:55:21 --> Email Class Initialized
INFO - 2016-08-11 13:55:21 --> Model Class Initialized
INFO - 2016-08-11 13:55:21 --> Controller Class Initialized
DEBUG - 2016-08-11 13:55:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:55:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:55:21 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:55:21 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:21 --> Model Class Initialized
INFO - 2016-08-11 13:55:21 --> Helper loaded: form_helper
INFO - 2016-08-11 13:55:21 --> Form Validation Class Initialized
INFO - 2016-08-11 13:55:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 13:55:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 13:55:21 --> Config Class Initialized
INFO - 2016-08-11 13:55:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:55:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:55:21 --> Utf8 Class Initialized
INFO - 2016-08-11 13:55:21 --> URI Class Initialized
INFO - 2016-08-11 13:55:21 --> Router Class Initialized
INFO - 2016-08-11 13:55:21 --> Output Class Initialized
INFO - 2016-08-11 13:55:21 --> Security Class Initialized
DEBUG - 2016-08-11 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:55:21 --> Input Class Initialized
INFO - 2016-08-11 13:55:21 --> Language Class Initialized
INFO - 2016-08-11 13:55:21 --> Loader Class Initialized
INFO - 2016-08-11 13:55:21 --> Helper loaded: url_helper
INFO - 2016-08-11 13:55:21 --> Helper loaded: date_helper
INFO - 2016-08-11 13:55:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:55:22 --> Database Driver Class Initialized
INFO - 2016-08-11 13:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:55:22 --> Email Class Initialized
INFO - 2016-08-11 13:55:22 --> Model Class Initialized
INFO - 2016-08-11 13:55:22 --> Controller Class Initialized
DEBUG - 2016-08-11 13:55:22 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:55:22 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:55:22 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:55:22 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:22 --> Model Class Initialized
INFO - 2016-08-11 13:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 13:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 13:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 13:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 13:55:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 13:55:22 --> Final output sent to browser
DEBUG - 2016-08-11 13:55:22 --> Total execution time: 0.4801
INFO - 2016-08-11 13:55:28 --> Config Class Initialized
INFO - 2016-08-11 13:55:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 13:55:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 13:55:28 --> Utf8 Class Initialized
INFO - 2016-08-11 13:55:28 --> URI Class Initialized
INFO - 2016-08-11 13:55:28 --> Router Class Initialized
INFO - 2016-08-11 13:55:28 --> Output Class Initialized
INFO - 2016-08-11 13:55:28 --> Security Class Initialized
DEBUG - 2016-08-11 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 13:55:29 --> Input Class Initialized
INFO - 2016-08-11 13:55:29 --> Language Class Initialized
INFO - 2016-08-11 13:55:29 --> Loader Class Initialized
INFO - 2016-08-11 13:55:29 --> Helper loaded: url_helper
INFO - 2016-08-11 13:55:29 --> Helper loaded: date_helper
INFO - 2016-08-11 13:55:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 13:55:29 --> Database Driver Class Initialized
INFO - 2016-08-11 13:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 13:55:29 --> Email Class Initialized
INFO - 2016-08-11 13:55:29 --> Model Class Initialized
INFO - 2016-08-11 13:55:29 --> Controller Class Initialized
DEBUG - 2016-08-11 13:55:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 13:55:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 13:55:29 --> Helper loaded: cookie_helper
INFO - 2016-08-11 13:55:29 --> Helper loaded: language_helper
DEBUG - 2016-08-11 13:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 13:55:29 --> Model Class Initialized
INFO - 2016-08-11 13:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 13:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 13:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 13:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 13:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 13:55:29 --> Final output sent to browser
DEBUG - 2016-08-11 13:55:29 --> Total execution time: 0.5122
INFO - 2016-08-11 14:00:39 --> Config Class Initialized
INFO - 2016-08-11 14:00:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:00:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:00:39 --> Utf8 Class Initialized
INFO - 2016-08-11 14:00:39 --> URI Class Initialized
INFO - 2016-08-11 14:00:39 --> Router Class Initialized
INFO - 2016-08-11 14:00:39 --> Output Class Initialized
INFO - 2016-08-11 14:00:39 --> Security Class Initialized
DEBUG - 2016-08-11 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:00:39 --> Input Class Initialized
INFO - 2016-08-11 14:00:39 --> Language Class Initialized
INFO - 2016-08-11 14:00:39 --> Loader Class Initialized
INFO - 2016-08-11 14:00:39 --> Helper loaded: url_helper
INFO - 2016-08-11 14:00:39 --> Helper loaded: date_helper
INFO - 2016-08-11 14:00:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:00:39 --> Database Driver Class Initialized
INFO - 2016-08-11 14:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:00:40 --> Email Class Initialized
INFO - 2016-08-11 14:00:40 --> Model Class Initialized
INFO - 2016-08-11 14:00:40 --> Controller Class Initialized
DEBUG - 2016-08-11 14:00:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:00:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:00:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:00:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:00:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:00:40 --> Model Class Initialized
INFO - 2016-08-11 14:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/tambah_kategori.php
INFO - 2016-08-11 14:00:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:00:40 --> Final output sent to browser
DEBUG - 2016-08-11 14:00:40 --> Total execution time: 0.5293
INFO - 2016-08-11 14:00:42 --> Config Class Initialized
INFO - 2016-08-11 14:00:42 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:00:42 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:00:42 --> Utf8 Class Initialized
INFO - 2016-08-11 14:00:42 --> URI Class Initialized
INFO - 2016-08-11 14:00:42 --> Router Class Initialized
INFO - 2016-08-11 14:00:42 --> Output Class Initialized
INFO - 2016-08-11 14:00:42 --> Security Class Initialized
DEBUG - 2016-08-11 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:00:42 --> Input Class Initialized
INFO - 2016-08-11 14:00:42 --> Language Class Initialized
INFO - 2016-08-11 14:00:42 --> Loader Class Initialized
INFO - 2016-08-11 14:00:42 --> Helper loaded: url_helper
INFO - 2016-08-11 14:00:42 --> Helper loaded: date_helper
INFO - 2016-08-11 14:00:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:00:42 --> Database Driver Class Initialized
INFO - 2016-08-11 14:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:00:42 --> Email Class Initialized
INFO - 2016-08-11 14:00:42 --> Model Class Initialized
INFO - 2016-08-11 14:00:42 --> Controller Class Initialized
DEBUG - 2016-08-11 14:00:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:00:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:00:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:00:42 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:00:42 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:00:42 --> Model Class Initialized
INFO - 2016-08-11 14:00:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:00:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:00:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:00:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:00:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:00:42 --> Final output sent to browser
DEBUG - 2016-08-11 14:00:42 --> Total execution time: 0.4126
INFO - 2016-08-11 14:01:46 --> Config Class Initialized
INFO - 2016-08-11 14:01:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:01:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:01:46 --> Utf8 Class Initialized
INFO - 2016-08-11 14:01:46 --> URI Class Initialized
INFO - 2016-08-11 14:01:46 --> Router Class Initialized
INFO - 2016-08-11 14:01:46 --> Output Class Initialized
INFO - 2016-08-11 14:01:46 --> Security Class Initialized
DEBUG - 2016-08-11 14:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:01:46 --> Input Class Initialized
INFO - 2016-08-11 14:01:46 --> Language Class Initialized
INFO - 2016-08-11 14:01:46 --> Loader Class Initialized
INFO - 2016-08-11 14:01:46 --> Helper loaded: url_helper
INFO - 2016-08-11 14:01:47 --> Helper loaded: date_helper
INFO - 2016-08-11 14:01:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:01:47 --> Database Driver Class Initialized
INFO - 2016-08-11 14:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:01:47 --> Email Class Initialized
INFO - 2016-08-11 14:01:47 --> Model Class Initialized
INFO - 2016-08-11 14:01:47 --> Controller Class Initialized
DEBUG - 2016-08-11 14:01:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:01:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:01:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:01:47 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:01:47 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:01:47 --> Model Class Initialized
INFO - 2016-08-11 14:01:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:01:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:01:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:01:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/update_kategori.php
INFO - 2016-08-11 14:01:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:01:47 --> Final output sent to browser
DEBUG - 2016-08-11 14:01:47 --> Total execution time: 0.4469
INFO - 2016-08-11 14:01:49 --> Config Class Initialized
INFO - 2016-08-11 14:01:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:01:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:01:49 --> Utf8 Class Initialized
INFO - 2016-08-11 14:01:49 --> URI Class Initialized
INFO - 2016-08-11 14:01:49 --> Router Class Initialized
INFO - 2016-08-11 14:01:49 --> Output Class Initialized
INFO - 2016-08-11 14:01:49 --> Security Class Initialized
DEBUG - 2016-08-11 14:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:01:49 --> Input Class Initialized
INFO - 2016-08-11 14:01:49 --> Language Class Initialized
INFO - 2016-08-11 14:01:49 --> Loader Class Initialized
INFO - 2016-08-11 14:01:49 --> Helper loaded: url_helper
INFO - 2016-08-11 14:01:49 --> Helper loaded: date_helper
INFO - 2016-08-11 14:01:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:01:49 --> Database Driver Class Initialized
INFO - 2016-08-11 14:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:01:49 --> Email Class Initialized
INFO - 2016-08-11 14:01:49 --> Model Class Initialized
INFO - 2016-08-11 14:01:49 --> Controller Class Initialized
DEBUG - 2016-08-11 14:01:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:01:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:01:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:01:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:01:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:01:49 --> Model Class Initialized
INFO - 2016-08-11 14:01:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:01:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:01:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:01:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:01:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:01:49 --> Final output sent to browser
DEBUG - 2016-08-11 14:01:49 --> Total execution time: 0.4220
INFO - 2016-08-11 14:06:35 --> Config Class Initialized
INFO - 2016-08-11 14:06:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:06:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:06:35 --> Utf8 Class Initialized
INFO - 2016-08-11 14:06:35 --> URI Class Initialized
INFO - 2016-08-11 14:06:35 --> Router Class Initialized
INFO - 2016-08-11 14:06:35 --> Output Class Initialized
INFO - 2016-08-11 14:06:35 --> Security Class Initialized
DEBUG - 2016-08-11 14:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:06:35 --> Input Class Initialized
INFO - 2016-08-11 14:06:35 --> Language Class Initialized
INFO - 2016-08-11 14:06:36 --> Loader Class Initialized
INFO - 2016-08-11 14:06:36 --> Helper loaded: url_helper
INFO - 2016-08-11 14:06:36 --> Helper loaded: date_helper
INFO - 2016-08-11 14:06:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:06:36 --> Database Driver Class Initialized
INFO - 2016-08-11 14:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:06:36 --> Email Class Initialized
INFO - 2016-08-11 14:06:36 --> Model Class Initialized
INFO - 2016-08-11 14:06:36 --> Controller Class Initialized
DEBUG - 2016-08-11 14:06:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:06:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:06:36 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:06:36 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:36 --> Model Class Initialized
INFO - 2016-08-11 14:06:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:06:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:06:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:06:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:06:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:06:36 --> Final output sent to browser
DEBUG - 2016-08-11 14:06:36 --> Total execution time: 0.4335
INFO - 2016-08-11 14:06:40 --> Config Class Initialized
INFO - 2016-08-11 14:06:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:06:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:06:40 --> Utf8 Class Initialized
INFO - 2016-08-11 14:06:40 --> URI Class Initialized
INFO - 2016-08-11 14:06:40 --> Router Class Initialized
INFO - 2016-08-11 14:06:40 --> Output Class Initialized
INFO - 2016-08-11 14:06:40 --> Security Class Initialized
DEBUG - 2016-08-11 14:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:06:40 --> Input Class Initialized
INFO - 2016-08-11 14:06:40 --> Language Class Initialized
INFO - 2016-08-11 14:06:40 --> Loader Class Initialized
INFO - 2016-08-11 14:06:40 --> Helper loaded: url_helper
INFO - 2016-08-11 14:06:40 --> Helper loaded: date_helper
INFO - 2016-08-11 14:06:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:06:40 --> Database Driver Class Initialized
INFO - 2016-08-11 14:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:06:40 --> Email Class Initialized
INFO - 2016-08-11 14:06:40 --> Model Class Initialized
INFO - 2016-08-11 14:06:40 --> Controller Class Initialized
DEBUG - 2016-08-11 14:06:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:06:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:06:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:06:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:40 --> Model Class Initialized
INFO - 2016-08-11 14:06:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:06:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:06:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:06:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/update_kategori.php
INFO - 2016-08-11 14:06:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:06:41 --> Final output sent to browser
DEBUG - 2016-08-11 14:06:41 --> Total execution time: 0.5015
INFO - 2016-08-11 14:06:43 --> Config Class Initialized
INFO - 2016-08-11 14:06:43 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:06:43 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:06:43 --> Utf8 Class Initialized
INFO - 2016-08-11 14:06:43 --> URI Class Initialized
INFO - 2016-08-11 14:06:43 --> Router Class Initialized
INFO - 2016-08-11 14:06:43 --> Output Class Initialized
INFO - 2016-08-11 14:06:43 --> Security Class Initialized
DEBUG - 2016-08-11 14:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:06:43 --> Input Class Initialized
INFO - 2016-08-11 14:06:43 --> Language Class Initialized
INFO - 2016-08-11 14:06:43 --> Loader Class Initialized
INFO - 2016-08-11 14:06:43 --> Helper loaded: url_helper
INFO - 2016-08-11 14:06:43 --> Helper loaded: date_helper
INFO - 2016-08-11 14:06:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:06:43 --> Database Driver Class Initialized
INFO - 2016-08-11 14:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:06:43 --> Email Class Initialized
INFO - 2016-08-11 14:06:43 --> Model Class Initialized
INFO - 2016-08-11 14:06:43 --> Controller Class Initialized
DEBUG - 2016-08-11 14:06:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:06:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:06:43 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:06:43 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:06:43 --> Model Class Initialized
INFO - 2016-08-11 14:06:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:06:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:06:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:06:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:06:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:06:43 --> Final output sent to browser
DEBUG - 2016-08-11 14:06:43 --> Total execution time: 0.4224
INFO - 2016-08-11 14:08:29 --> Config Class Initialized
INFO - 2016-08-11 14:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:29 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:29 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:29 --> URI Class Initialized
INFO - 2016-08-11 14:08:29 --> Router Class Initialized
INFO - 2016-08-11 14:08:29 --> Output Class Initialized
INFO - 2016-08-11 14:08:29 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:29 --> Input Class Initialized
INFO - 2016-08-11 14:08:29 --> Language Class Initialized
INFO - 2016-08-11 14:08:29 --> Loader Class Initialized
INFO - 2016-08-11 14:08:29 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:29 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:29 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:30 --> Email Class Initialized
INFO - 2016-08-11 14:08:30 --> Model Class Initialized
INFO - 2016-08-11 14:08:30 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:30 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:30 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:30 --> Model Class Initialized
INFO - 2016-08-11 14:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/update_kategori.php
INFO - 2016-08-11 14:08:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:30 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:30 --> Total execution time: 0.4749
INFO - 2016-08-11 14:08:34 --> Config Class Initialized
INFO - 2016-08-11 14:08:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:34 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:34 --> URI Class Initialized
INFO - 2016-08-11 14:08:34 --> Router Class Initialized
INFO - 2016-08-11 14:08:34 --> Output Class Initialized
INFO - 2016-08-11 14:08:34 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:34 --> Input Class Initialized
INFO - 2016-08-11 14:08:34 --> Language Class Initialized
INFO - 2016-08-11 14:08:34 --> Loader Class Initialized
INFO - 2016-08-11 14:08:34 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:34 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:34 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:34 --> Email Class Initialized
INFO - 2016-08-11 14:08:34 --> Model Class Initialized
INFO - 2016-08-11 14:08:34 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:34 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:34 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:34 --> Model Class Initialized
INFO - 2016-08-11 14:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:08:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:34 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:34 --> Total execution time: 0.4817
INFO - 2016-08-11 14:08:36 --> Config Class Initialized
INFO - 2016-08-11 14:08:36 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:36 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:36 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:36 --> URI Class Initialized
INFO - 2016-08-11 14:08:36 --> Router Class Initialized
INFO - 2016-08-11 14:08:36 --> Output Class Initialized
INFO - 2016-08-11 14:08:36 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:36 --> Input Class Initialized
INFO - 2016-08-11 14:08:36 --> Language Class Initialized
INFO - 2016-08-11 14:08:36 --> Loader Class Initialized
INFO - 2016-08-11 14:08:36 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:36 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:36 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:36 --> Email Class Initialized
INFO - 2016-08-11 14:08:37 --> Model Class Initialized
INFO - 2016-08-11 14:08:37 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:37 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:37 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:37 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:37 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:37 --> Model Class Initialized
INFO - 2016-08-11 14:08:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/update_kategori.php
INFO - 2016-08-11 14:08:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:37 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:37 --> Total execution time: 0.4398
INFO - 2016-08-11 14:08:46 --> Config Class Initialized
INFO - 2016-08-11 14:08:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:46 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:46 --> URI Class Initialized
INFO - 2016-08-11 14:08:46 --> Router Class Initialized
INFO - 2016-08-11 14:08:46 --> Output Class Initialized
INFO - 2016-08-11 14:08:46 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:46 --> Input Class Initialized
INFO - 2016-08-11 14:08:46 --> Language Class Initialized
INFO - 2016-08-11 14:08:46 --> Loader Class Initialized
INFO - 2016-08-11 14:08:46 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:46 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:46 --> Email Class Initialized
INFO - 2016-08-11 14:08:46 --> Model Class Initialized
INFO - 2016-08-11 14:08:46 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:46 --> Model Class Initialized
INFO - 2016-08-11 14:08:46 --> Config Class Initialized
INFO - 2016-08-11 14:08:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:46 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:46 --> URI Class Initialized
INFO - 2016-08-11 14:08:46 --> Router Class Initialized
INFO - 2016-08-11 14:08:46 --> Output Class Initialized
INFO - 2016-08-11 14:08:46 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:46 --> Input Class Initialized
INFO - 2016-08-11 14:08:46 --> Language Class Initialized
INFO - 2016-08-11 14:08:46 --> Loader Class Initialized
INFO - 2016-08-11 14:08:46 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:46 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:46 --> Email Class Initialized
INFO - 2016-08-11 14:08:46 --> Model Class Initialized
INFO - 2016-08-11 14:08:46 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:46 --> Model Class Initialized
INFO - 2016-08-11 14:08:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:08:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:46 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:46 --> Total execution time: 0.4263
INFO - 2016-08-11 14:08:49 --> Config Class Initialized
INFO - 2016-08-11 14:08:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:49 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:49 --> URI Class Initialized
INFO - 2016-08-11 14:08:49 --> Router Class Initialized
INFO - 2016-08-11 14:08:49 --> Output Class Initialized
INFO - 2016-08-11 14:08:49 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:49 --> Input Class Initialized
INFO - 2016-08-11 14:08:49 --> Language Class Initialized
INFO - 2016-08-11 14:08:49 --> Loader Class Initialized
INFO - 2016-08-11 14:08:49 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:49 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:49 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:49 --> Email Class Initialized
INFO - 2016-08-11 14:08:49 --> Model Class Initialized
INFO - 2016-08-11 14:08:49 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:49 --> Model Class Initialized
INFO - 2016-08-11 14:08:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/update_kategori.php
INFO - 2016-08-11 14:08:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:49 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:49 --> Total execution time: 0.4412
INFO - 2016-08-11 14:08:53 --> Config Class Initialized
INFO - 2016-08-11 14:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:53 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:53 --> URI Class Initialized
INFO - 2016-08-11 14:08:53 --> Router Class Initialized
INFO - 2016-08-11 14:08:53 --> Output Class Initialized
INFO - 2016-08-11 14:08:53 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:53 --> Input Class Initialized
INFO - 2016-08-11 14:08:53 --> Language Class Initialized
INFO - 2016-08-11 14:08:53 --> Loader Class Initialized
INFO - 2016-08-11 14:08:53 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:53 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:53 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:54 --> Email Class Initialized
INFO - 2016-08-11 14:08:54 --> Model Class Initialized
INFO - 2016-08-11 14:08:54 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:54 --> Model Class Initialized
INFO - 2016-08-11 14:08:54 --> Config Class Initialized
INFO - 2016-08-11 14:08:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:08:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:08:54 --> Utf8 Class Initialized
INFO - 2016-08-11 14:08:54 --> URI Class Initialized
INFO - 2016-08-11 14:08:54 --> Router Class Initialized
INFO - 2016-08-11 14:08:54 --> Output Class Initialized
INFO - 2016-08-11 14:08:54 --> Security Class Initialized
DEBUG - 2016-08-11 14:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:08:54 --> Input Class Initialized
INFO - 2016-08-11 14:08:54 --> Language Class Initialized
INFO - 2016-08-11 14:08:54 --> Loader Class Initialized
INFO - 2016-08-11 14:08:54 --> Helper loaded: url_helper
INFO - 2016-08-11 14:08:54 --> Helper loaded: date_helper
INFO - 2016-08-11 14:08:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:08:54 --> Database Driver Class Initialized
INFO - 2016-08-11 14:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:08:54 --> Email Class Initialized
INFO - 2016-08-11 14:08:54 --> Model Class Initialized
INFO - 2016-08-11 14:08:54 --> Controller Class Initialized
DEBUG - 2016-08-11 14:08:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:08:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:08:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:08:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:08:54 --> Model Class Initialized
INFO - 2016-08-11 14:08:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:08:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:08:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:08:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:08:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:08:54 --> Final output sent to browser
DEBUG - 2016-08-11 14:08:54 --> Total execution time: 0.4283
INFO - 2016-08-11 14:12:20 --> Config Class Initialized
INFO - 2016-08-11 14:12:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:12:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:12:20 --> Utf8 Class Initialized
INFO - 2016-08-11 14:12:20 --> URI Class Initialized
INFO - 2016-08-11 14:12:20 --> Router Class Initialized
INFO - 2016-08-11 14:12:20 --> Output Class Initialized
INFO - 2016-08-11 14:12:20 --> Security Class Initialized
DEBUG - 2016-08-11 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:12:20 --> Input Class Initialized
INFO - 2016-08-11 14:12:20 --> Language Class Initialized
INFO - 2016-08-11 14:12:20 --> Loader Class Initialized
INFO - 2016-08-11 14:12:21 --> Helper loaded: url_helper
INFO - 2016-08-11 14:12:21 --> Helper loaded: date_helper
INFO - 2016-08-11 14:12:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:12:21 --> Database Driver Class Initialized
INFO - 2016-08-11 14:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:12:21 --> Email Class Initialized
INFO - 2016-08-11 14:12:21 --> Model Class Initialized
INFO - 2016-08-11 14:12:21 --> Controller Class Initialized
DEBUG - 2016-08-11 14:12:21 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:12:21 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:12:21 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:12:21 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:21 --> Model Class Initialized
INFO - 2016-08-11 14:12:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:12:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:12:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:12:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:12:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:12:21 --> Final output sent to browser
DEBUG - 2016-08-11 14:12:21 --> Total execution time: 0.4387
INFO - 2016-08-11 14:12:40 --> Config Class Initialized
INFO - 2016-08-11 14:12:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:12:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:12:40 --> Utf8 Class Initialized
INFO - 2016-08-11 14:12:40 --> URI Class Initialized
INFO - 2016-08-11 14:12:40 --> Router Class Initialized
INFO - 2016-08-11 14:12:40 --> Output Class Initialized
INFO - 2016-08-11 14:12:40 --> Security Class Initialized
DEBUG - 2016-08-11 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:12:40 --> Input Class Initialized
INFO - 2016-08-11 14:12:40 --> Language Class Initialized
INFO - 2016-08-11 14:12:40 --> Loader Class Initialized
INFO - 2016-08-11 14:12:40 --> Helper loaded: url_helper
INFO - 2016-08-11 14:12:40 --> Helper loaded: date_helper
INFO - 2016-08-11 14:12:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:12:40 --> Database Driver Class Initialized
INFO - 2016-08-11 14:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:12:40 --> Email Class Initialized
INFO - 2016-08-11 14:12:40 --> Model Class Initialized
INFO - 2016-08-11 14:12:40 --> Controller Class Initialized
DEBUG - 2016-08-11 14:12:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:12:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:12:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:12:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:40 --> Model Class Initialized
INFO - 2016-08-11 14:12:40 --> Final output sent to browser
DEBUG - 2016-08-11 14:12:40 --> Total execution time: 0.4912
INFO - 2016-08-11 14:12:40 --> Config Class Initialized
INFO - 2016-08-11 14:12:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:12:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:12:40 --> Utf8 Class Initialized
INFO - 2016-08-11 14:12:40 --> URI Class Initialized
INFO - 2016-08-11 14:12:40 --> Router Class Initialized
INFO - 2016-08-11 14:12:40 --> Output Class Initialized
INFO - 2016-08-11 14:12:40 --> Security Class Initialized
DEBUG - 2016-08-11 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:12:40 --> Input Class Initialized
INFO - 2016-08-11 14:12:40 --> Language Class Initialized
INFO - 2016-08-11 14:12:41 --> Loader Class Initialized
INFO - 2016-08-11 14:12:41 --> Helper loaded: url_helper
INFO - 2016-08-11 14:12:41 --> Helper loaded: date_helper
INFO - 2016-08-11 14:12:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:12:41 --> Database Driver Class Initialized
INFO - 2016-08-11 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:12:41 --> Email Class Initialized
INFO - 2016-08-11 14:12:41 --> Model Class Initialized
INFO - 2016-08-11 14:12:41 --> Controller Class Initialized
DEBUG - 2016-08-11 14:12:41 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:12:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:12:41 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:12:41 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:12:41 --> Model Class Initialized
INFO - 2016-08-11 14:12:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:12:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:12:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:12:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/kategori/view_kategori.php
INFO - 2016-08-11 14:12:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:12:41 --> Final output sent to browser
DEBUG - 2016-08-11 14:12:41 --> Total execution time: 0.4922
INFO - 2016-08-11 14:13:07 --> Config Class Initialized
INFO - 2016-08-11 14:13:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:13:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:13:07 --> Utf8 Class Initialized
INFO - 2016-08-11 14:13:07 --> URI Class Initialized
INFO - 2016-08-11 14:13:07 --> Router Class Initialized
INFO - 2016-08-11 14:13:07 --> Output Class Initialized
INFO - 2016-08-11 14:13:07 --> Security Class Initialized
DEBUG - 2016-08-11 14:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:13:07 --> Input Class Initialized
INFO - 2016-08-11 14:13:07 --> Language Class Initialized
INFO - 2016-08-11 14:13:07 --> Loader Class Initialized
INFO - 2016-08-11 14:13:07 --> Helper loaded: url_helper
INFO - 2016-08-11 14:13:07 --> Helper loaded: date_helper
INFO - 2016-08-11 14:13:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:13:07 --> Database Driver Class Initialized
INFO - 2016-08-11 14:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:13:08 --> Email Class Initialized
INFO - 2016-08-11 14:13:08 --> Model Class Initialized
INFO - 2016-08-11 14:13:08 --> Controller Class Initialized
DEBUG - 2016-08-11 14:13:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:13:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:13:08 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:13:08 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:08 --> Model Class Initialized
INFO - 2016-08-11 14:13:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:13:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:13:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:13:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 14:13:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:13:08 --> Final output sent to browser
DEBUG - 2016-08-11 14:13:08 --> Total execution time: 0.5144
INFO - 2016-08-11 14:13:27 --> Config Class Initialized
INFO - 2016-08-11 14:13:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:13:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:13:27 --> Utf8 Class Initialized
INFO - 2016-08-11 14:13:27 --> URI Class Initialized
INFO - 2016-08-11 14:13:27 --> Router Class Initialized
INFO - 2016-08-11 14:13:27 --> Output Class Initialized
INFO - 2016-08-11 14:13:27 --> Security Class Initialized
DEBUG - 2016-08-11 14:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:13:27 --> Input Class Initialized
INFO - 2016-08-11 14:13:27 --> Language Class Initialized
INFO - 2016-08-11 14:13:27 --> Loader Class Initialized
INFO - 2016-08-11 14:13:27 --> Helper loaded: url_helper
INFO - 2016-08-11 14:13:27 --> Helper loaded: date_helper
INFO - 2016-08-11 14:13:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:13:27 --> Database Driver Class Initialized
INFO - 2016-08-11 14:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:13:27 --> Email Class Initialized
INFO - 2016-08-11 14:13:27 --> Model Class Initialized
INFO - 2016-08-11 14:13:27 --> Controller Class Initialized
DEBUG - 2016-08-11 14:13:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:13:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:13:27 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:13:27 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:13:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:27 --> Model Class Initialized
INFO - 2016-08-11 14:13:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:13:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:13:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-11 14:13:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:13:27 --> Final output sent to browser
DEBUG - 2016-08-11 14:13:27 --> Total execution time: 0.4874
INFO - 2016-08-11 14:13:28 --> Config Class Initialized
INFO - 2016-08-11 14:13:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:13:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:13:28 --> Utf8 Class Initialized
INFO - 2016-08-11 14:13:28 --> URI Class Initialized
INFO - 2016-08-11 14:13:28 --> Router Class Initialized
INFO - 2016-08-11 14:13:28 --> Output Class Initialized
INFO - 2016-08-11 14:13:28 --> Security Class Initialized
DEBUG - 2016-08-11 14:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:13:28 --> Input Class Initialized
INFO - 2016-08-11 14:13:28 --> Language Class Initialized
ERROR - 2016-08-11 14:13:28 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 14:13:33 --> Config Class Initialized
INFO - 2016-08-11 14:13:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:13:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:13:33 --> Utf8 Class Initialized
INFO - 2016-08-11 14:13:33 --> URI Class Initialized
INFO - 2016-08-11 14:13:33 --> Router Class Initialized
INFO - 2016-08-11 14:13:33 --> Output Class Initialized
INFO - 2016-08-11 14:13:33 --> Security Class Initialized
DEBUG - 2016-08-11 14:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:13:33 --> Input Class Initialized
INFO - 2016-08-11 14:13:33 --> Language Class Initialized
INFO - 2016-08-11 14:13:33 --> Loader Class Initialized
INFO - 2016-08-11 14:13:33 --> Helper loaded: url_helper
INFO - 2016-08-11 14:13:33 --> Helper loaded: date_helper
INFO - 2016-08-11 14:13:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:13:33 --> Database Driver Class Initialized
INFO - 2016-08-11 14:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:13:33 --> Email Class Initialized
INFO - 2016-08-11 14:13:33 --> Model Class Initialized
INFO - 2016-08-11 14:13:33 --> Controller Class Initialized
DEBUG - 2016-08-11 14:13:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:13:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:13:33 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:13:33 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:13:33 --> Model Class Initialized
INFO - 2016-08-11 14:13:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:13:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 14:13:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:13:34 --> Final output sent to browser
DEBUG - 2016-08-11 14:13:34 --> Total execution time: 0.5806
INFO - 2016-08-11 14:14:05 --> Config Class Initialized
INFO - 2016-08-11 14:14:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:14:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:14:05 --> Utf8 Class Initialized
INFO - 2016-08-11 14:14:05 --> URI Class Initialized
INFO - 2016-08-11 14:14:05 --> Router Class Initialized
INFO - 2016-08-11 14:14:05 --> Output Class Initialized
INFO - 2016-08-11 14:14:05 --> Security Class Initialized
DEBUG - 2016-08-11 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:14:05 --> Input Class Initialized
INFO - 2016-08-11 14:14:05 --> Language Class Initialized
INFO - 2016-08-11 14:14:05 --> Loader Class Initialized
INFO - 2016-08-11 14:14:05 --> Helper loaded: url_helper
INFO - 2016-08-11 14:14:05 --> Helper loaded: date_helper
INFO - 2016-08-11 14:14:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:14:05 --> Database Driver Class Initialized
INFO - 2016-08-11 14:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:14:05 --> Email Class Initialized
INFO - 2016-08-11 14:14:05 --> Model Class Initialized
INFO - 2016-08-11 14:14:05 --> Controller Class Initialized
DEBUG - 2016-08-11 14:14:05 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:14:05 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:14:05 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:14:05 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:05 --> Model Class Initialized
INFO - 2016-08-11 14:14:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:14:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:14:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-11 14:14:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:14:05 --> Final output sent to browser
DEBUG - 2016-08-11 14:14:05 --> Total execution time: 0.5549
INFO - 2016-08-11 14:14:31 --> Config Class Initialized
INFO - 2016-08-11 14:14:31 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:14:31 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:14:31 --> Utf8 Class Initialized
INFO - 2016-08-11 14:14:31 --> URI Class Initialized
DEBUG - 2016-08-11 14:14:32 --> No URI present. Default controller set.
INFO - 2016-08-11 14:14:32 --> Router Class Initialized
INFO - 2016-08-11 14:14:32 --> Output Class Initialized
INFO - 2016-08-11 14:14:32 --> Security Class Initialized
DEBUG - 2016-08-11 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:14:32 --> Input Class Initialized
INFO - 2016-08-11 14:14:32 --> Language Class Initialized
INFO - 2016-08-11 14:14:32 --> Loader Class Initialized
INFO - 2016-08-11 14:14:32 --> Helper loaded: url_helper
INFO - 2016-08-11 14:14:32 --> Helper loaded: date_helper
INFO - 2016-08-11 14:14:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:14:32 --> Database Driver Class Initialized
INFO - 2016-08-11 14:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:14:32 --> Email Class Initialized
INFO - 2016-08-11 14:14:32 --> Model Class Initialized
INFO - 2016-08-11 14:14:32 --> Controller Class Initialized
DEBUG - 2016-08-11 14:14:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:14:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:14:32 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:14:32 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:32 --> Model Class Initialized
INFO - 2016-08-11 14:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 14:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:14:32 --> Final output sent to browser
DEBUG - 2016-08-11 14:14:32 --> Total execution time: 0.5046
INFO - 2016-08-11 14:14:55 --> Config Class Initialized
INFO - 2016-08-11 14:14:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:14:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:14:55 --> Utf8 Class Initialized
INFO - 2016-08-11 14:14:55 --> URI Class Initialized
INFO - 2016-08-11 14:14:55 --> Router Class Initialized
INFO - 2016-08-11 14:14:55 --> Output Class Initialized
INFO - 2016-08-11 14:14:55 --> Security Class Initialized
DEBUG - 2016-08-11 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:14:55 --> Input Class Initialized
INFO - 2016-08-11 14:14:55 --> Language Class Initialized
INFO - 2016-08-11 14:14:55 --> Loader Class Initialized
INFO - 2016-08-11 14:14:55 --> Helper loaded: url_helper
INFO - 2016-08-11 14:14:55 --> Helper loaded: date_helper
INFO - 2016-08-11 14:14:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:14:55 --> Database Driver Class Initialized
INFO - 2016-08-11 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:14:55 --> Email Class Initialized
INFO - 2016-08-11 14:14:55 --> Model Class Initialized
INFO - 2016-08-11 14:14:55 --> Controller Class Initialized
DEBUG - 2016-08-11 14:14:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:14:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:14:55 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:14:55 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:14:55 --> Model Class Initialized
INFO - 2016-08-11 14:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-11 14:14:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:14:55 --> Final output sent to browser
DEBUG - 2016-08-11 14:14:55 --> Total execution time: 0.4769
INFO - 2016-08-11 14:17:08 --> Config Class Initialized
INFO - 2016-08-11 14:17:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:17:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:17:08 --> Utf8 Class Initialized
INFO - 2016-08-11 14:17:08 --> URI Class Initialized
INFO - 2016-08-11 14:17:08 --> Router Class Initialized
INFO - 2016-08-11 14:17:08 --> Output Class Initialized
INFO - 2016-08-11 14:17:08 --> Security Class Initialized
DEBUG - 2016-08-11 14:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:17:08 --> Input Class Initialized
INFO - 2016-08-11 14:17:08 --> Language Class Initialized
INFO - 2016-08-11 14:17:08 --> Loader Class Initialized
INFO - 2016-08-11 14:17:08 --> Helper loaded: url_helper
INFO - 2016-08-11 14:17:08 --> Helper loaded: date_helper
INFO - 2016-08-11 14:17:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:17:08 --> Database Driver Class Initialized
INFO - 2016-08-11 14:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:17:08 --> Email Class Initialized
INFO - 2016-08-11 14:17:08 --> Model Class Initialized
INFO - 2016-08-11 14:17:08 --> Controller Class Initialized
DEBUG - 2016-08-11 14:17:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:17:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:17:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:17:08 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:17:08 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:17:08 --> Model Class Initialized
INFO - 2016-08-11 14:17:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 14:17:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 14:17:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-11 14:17:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 14:17:08 --> Final output sent to browser
DEBUG - 2016-08-11 14:17:08 --> Total execution time: 0.4877
INFO - 2016-08-11 14:31:54 --> Config Class Initialized
INFO - 2016-08-11 14:31:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:31:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:31:54 --> Utf8 Class Initialized
INFO - 2016-08-11 14:31:54 --> URI Class Initialized
INFO - 2016-08-11 14:31:54 --> Router Class Initialized
INFO - 2016-08-11 14:31:54 --> Output Class Initialized
INFO - 2016-08-11 14:31:54 --> Security Class Initialized
DEBUG - 2016-08-11 14:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:31:54 --> Input Class Initialized
INFO - 2016-08-11 14:31:54 --> Language Class Initialized
INFO - 2016-08-11 14:31:54 --> Loader Class Initialized
INFO - 2016-08-11 14:31:54 --> Helper loaded: url_helper
INFO - 2016-08-11 14:31:54 --> Helper loaded: date_helper
INFO - 2016-08-11 14:31:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:31:54 --> Database Driver Class Initialized
INFO - 2016-08-11 14:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:31:54 --> Email Class Initialized
INFO - 2016-08-11 14:31:54 --> Model Class Initialized
INFO - 2016-08-11 14:31:54 --> Controller Class Initialized
DEBUG - 2016-08-11 14:31:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:31:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:31:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:31:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:31:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:31:54 --> Model Class Initialized
INFO - 2016-08-11 14:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 14:31:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:31:54 --> Final output sent to browser
DEBUG - 2016-08-11 14:31:54 --> Total execution time: 0.4762
INFO - 2016-08-11 14:32:03 --> Config Class Initialized
INFO - 2016-08-11 14:32:03 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:32:03 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:32:03 --> Utf8 Class Initialized
INFO - 2016-08-11 14:32:03 --> URI Class Initialized
INFO - 2016-08-11 14:32:03 --> Router Class Initialized
INFO - 2016-08-11 14:32:03 --> Output Class Initialized
INFO - 2016-08-11 14:32:03 --> Security Class Initialized
DEBUG - 2016-08-11 14:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:32:03 --> Input Class Initialized
INFO - 2016-08-11 14:32:03 --> Language Class Initialized
INFO - 2016-08-11 14:32:03 --> Loader Class Initialized
INFO - 2016-08-11 14:32:03 --> Helper loaded: url_helper
INFO - 2016-08-11 14:32:03 --> Helper loaded: date_helper
INFO - 2016-08-11 14:32:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:32:03 --> Database Driver Class Initialized
INFO - 2016-08-11 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:32:03 --> Email Class Initialized
INFO - 2016-08-11 14:32:03 --> Model Class Initialized
INFO - 2016-08-11 14:32:03 --> Controller Class Initialized
INFO - 2016-08-11 14:32:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:32:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:32:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:32:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-11 14:32:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:32:03 --> Final output sent to browser
DEBUG - 2016-08-11 14:32:03 --> Total execution time: 0.3835
INFO - 2016-08-11 14:37:18 --> Config Class Initialized
INFO - 2016-08-11 14:37:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:37:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:37:18 --> Utf8 Class Initialized
INFO - 2016-08-11 14:37:18 --> URI Class Initialized
INFO - 2016-08-11 14:37:18 --> Router Class Initialized
INFO - 2016-08-11 14:37:18 --> Output Class Initialized
INFO - 2016-08-11 14:37:18 --> Security Class Initialized
DEBUG - 2016-08-11 14:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:37:18 --> Input Class Initialized
INFO - 2016-08-11 14:37:18 --> Language Class Initialized
INFO - 2016-08-11 14:37:18 --> Loader Class Initialized
INFO - 2016-08-11 14:37:18 --> Helper loaded: url_helper
INFO - 2016-08-11 14:37:18 --> Helper loaded: date_helper
INFO - 2016-08-11 14:37:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:37:18 --> Database Driver Class Initialized
INFO - 2016-08-11 14:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:37:18 --> Email Class Initialized
INFO - 2016-08-11 14:37:18 --> Model Class Initialized
INFO - 2016-08-11 14:37:18 --> Controller Class Initialized
INFO - 2016-08-11 14:37:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:37:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:37:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:37:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-11 14:37:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:37:18 --> Final output sent to browser
DEBUG - 2016-08-11 14:37:18 --> Total execution time: 0.3621
INFO - 2016-08-11 14:38:04 --> Config Class Initialized
INFO - 2016-08-11 14:38:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:38:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:38:04 --> Utf8 Class Initialized
INFO - 2016-08-11 14:38:04 --> URI Class Initialized
INFO - 2016-08-11 14:38:04 --> Router Class Initialized
INFO - 2016-08-11 14:38:04 --> Output Class Initialized
INFO - 2016-08-11 14:38:04 --> Security Class Initialized
DEBUG - 2016-08-11 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:38:04 --> Input Class Initialized
INFO - 2016-08-11 14:38:04 --> Language Class Initialized
INFO - 2016-08-11 14:38:04 --> Loader Class Initialized
INFO - 2016-08-11 14:38:04 --> Helper loaded: url_helper
INFO - 2016-08-11 14:38:04 --> Helper loaded: date_helper
INFO - 2016-08-11 14:38:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:38:04 --> Database Driver Class Initialized
INFO - 2016-08-11 14:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:38:04 --> Email Class Initialized
INFO - 2016-08-11 14:38:04 --> Model Class Initialized
INFO - 2016-08-11 14:38:04 --> Controller Class Initialized
INFO - 2016-08-11 14:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-11 14:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:38:04 --> Final output sent to browser
DEBUG - 2016-08-11 14:38:04 --> Total execution time: 0.3661
INFO - 2016-08-11 14:52:35 --> Config Class Initialized
INFO - 2016-08-11 14:52:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:52:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:52:35 --> Utf8 Class Initialized
INFO - 2016-08-11 14:52:35 --> URI Class Initialized
INFO - 2016-08-11 14:52:35 --> Router Class Initialized
INFO - 2016-08-11 14:52:35 --> Output Class Initialized
INFO - 2016-08-11 14:52:35 --> Security Class Initialized
DEBUG - 2016-08-11 14:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:52:35 --> Input Class Initialized
INFO - 2016-08-11 14:52:35 --> Language Class Initialized
INFO - 2016-08-11 14:52:35 --> Loader Class Initialized
INFO - 2016-08-11 14:52:35 --> Helper loaded: url_helper
INFO - 2016-08-11 14:52:35 --> Helper loaded: date_helper
INFO - 2016-08-11 14:52:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:52:35 --> Database Driver Class Initialized
INFO - 2016-08-11 14:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:52:35 --> Email Class Initialized
INFO - 2016-08-11 14:52:35 --> Model Class Initialized
INFO - 2016-08-11 14:52:35 --> Controller Class Initialized
INFO - 2016-08-11 14:52:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:52:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:52:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:52:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-11 14:52:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:52:35 --> Final output sent to browser
DEBUG - 2016-08-11 14:52:35 --> Total execution time: 0.4138
INFO - 2016-08-11 14:54:11 --> Config Class Initialized
INFO - 2016-08-11 14:54:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:54:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:54:11 --> Utf8 Class Initialized
INFO - 2016-08-11 14:54:11 --> URI Class Initialized
INFO - 2016-08-11 14:54:11 --> Router Class Initialized
INFO - 2016-08-11 14:54:11 --> Output Class Initialized
INFO - 2016-08-11 14:54:11 --> Security Class Initialized
DEBUG - 2016-08-11 14:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:54:11 --> Input Class Initialized
INFO - 2016-08-11 14:54:11 --> Language Class Initialized
INFO - 2016-08-11 14:54:11 --> Loader Class Initialized
INFO - 2016-08-11 14:54:11 --> Helper loaded: url_helper
INFO - 2016-08-11 14:54:11 --> Helper loaded: date_helper
INFO - 2016-08-11 14:54:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:54:11 --> Database Driver Class Initialized
INFO - 2016-08-11 14:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:54:11 --> Email Class Initialized
INFO - 2016-08-11 14:54:11 --> Model Class Initialized
INFO - 2016-08-11 14:54:11 --> Controller Class Initialized
INFO - 2016-08-11 14:54:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:54:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:54:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:54:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/buku_tamu/view_buku_tamu.php
INFO - 2016-08-11 14:54:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:54:11 --> Final output sent to browser
DEBUG - 2016-08-11 14:54:11 --> Total execution time: 0.3779
INFO - 2016-08-11 14:57:03 --> Config Class Initialized
INFO - 2016-08-11 14:57:03 --> Hooks Class Initialized
DEBUG - 2016-08-11 14:57:03 --> UTF-8 Support Enabled
INFO - 2016-08-11 14:57:03 --> Utf8 Class Initialized
INFO - 2016-08-11 14:57:03 --> URI Class Initialized
INFO - 2016-08-11 14:57:03 --> Router Class Initialized
INFO - 2016-08-11 14:57:04 --> Output Class Initialized
INFO - 2016-08-11 14:57:04 --> Security Class Initialized
DEBUG - 2016-08-11 14:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 14:57:04 --> Input Class Initialized
INFO - 2016-08-11 14:57:04 --> Language Class Initialized
INFO - 2016-08-11 14:57:04 --> Loader Class Initialized
INFO - 2016-08-11 14:57:04 --> Helper loaded: url_helper
INFO - 2016-08-11 14:57:04 --> Helper loaded: date_helper
INFO - 2016-08-11 14:57:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 14:57:04 --> Database Driver Class Initialized
INFO - 2016-08-11 14:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 14:57:04 --> Email Class Initialized
INFO - 2016-08-11 14:57:04 --> Model Class Initialized
INFO - 2016-08-11 14:57:04 --> Controller Class Initialized
DEBUG - 2016-08-11 14:57:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 14:57:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:57:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 14:57:04 --> Helper loaded: cookie_helper
INFO - 2016-08-11 14:57:04 --> Helper loaded: language_helper
DEBUG - 2016-08-11 14:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 14:57:04 --> Model Class Initialized
INFO - 2016-08-11 14:57:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 14:57:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 14:57:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 14:57:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 14:57:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 14:57:04 --> Final output sent to browser
DEBUG - 2016-08-11 14:57:04 --> Total execution time: 0.4893
INFO - 2016-08-11 15:29:12 --> Config Class Initialized
INFO - 2016-08-11 15:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:29:12 --> Utf8 Class Initialized
INFO - 2016-08-11 15:29:12 --> URI Class Initialized
INFO - 2016-08-11 15:29:12 --> Router Class Initialized
INFO - 2016-08-11 15:29:12 --> Output Class Initialized
INFO - 2016-08-11 15:29:12 --> Security Class Initialized
DEBUG - 2016-08-11 15:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:29:12 --> Input Class Initialized
INFO - 2016-08-11 15:29:12 --> Language Class Initialized
INFO - 2016-08-11 15:29:12 --> Loader Class Initialized
INFO - 2016-08-11 15:29:12 --> Helper loaded: url_helper
INFO - 2016-08-11 15:29:12 --> Helper loaded: date_helper
INFO - 2016-08-11 15:29:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:29:12 --> Database Driver Class Initialized
INFO - 2016-08-11 15:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:29:12 --> Email Class Initialized
INFO - 2016-08-11 15:29:12 --> Model Class Initialized
INFO - 2016-08-11 15:29:12 --> Controller Class Initialized
DEBUG - 2016-08-11 15:29:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:29:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:29:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:29:13 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:29:13 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:29:13 --> Model Class Initialized
INFO - 2016-08-11 15:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:29:13 --> Final output sent to browser
DEBUG - 2016-08-11 15:29:13 --> Total execution time: 0.5630
INFO - 2016-08-11 15:33:54 --> Config Class Initialized
INFO - 2016-08-11 15:33:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:33:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:33:54 --> Utf8 Class Initialized
INFO - 2016-08-11 15:33:54 --> URI Class Initialized
INFO - 2016-08-11 15:33:54 --> Router Class Initialized
INFO - 2016-08-11 15:33:54 --> Output Class Initialized
INFO - 2016-08-11 15:33:54 --> Security Class Initialized
DEBUG - 2016-08-11 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:33:54 --> Input Class Initialized
INFO - 2016-08-11 15:33:54 --> Language Class Initialized
INFO - 2016-08-11 15:33:54 --> Loader Class Initialized
INFO - 2016-08-11 15:33:54 --> Helper loaded: url_helper
INFO - 2016-08-11 15:33:54 --> Helper loaded: date_helper
INFO - 2016-08-11 15:33:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:33:54 --> Database Driver Class Initialized
INFO - 2016-08-11 15:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:33:54 --> Email Class Initialized
INFO - 2016-08-11 15:33:54 --> Model Class Initialized
INFO - 2016-08-11 15:33:54 --> Controller Class Initialized
DEBUG - 2016-08-11 15:33:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:33:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:33:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:33:54 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:33:54 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:33:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:33:54 --> Model Class Initialized
INFO - 2016-08-11 15:33:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:33:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:33:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\harga.php
INFO - 2016-08-11 15:33:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:33:54 --> Final output sent to browser
DEBUG - 2016-08-11 15:33:54 --> Total execution time: 0.4583
INFO - 2016-08-11 15:33:56 --> Config Class Initialized
INFO - 2016-08-11 15:33:56 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:33:56 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:33:56 --> Utf8 Class Initialized
INFO - 2016-08-11 15:33:56 --> URI Class Initialized
INFO - 2016-08-11 15:33:56 --> Router Class Initialized
INFO - 2016-08-11 15:33:56 --> Output Class Initialized
INFO - 2016-08-11 15:33:56 --> Security Class Initialized
DEBUG - 2016-08-11 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:33:56 --> Input Class Initialized
INFO - 2016-08-11 15:33:56 --> Language Class Initialized
INFO - 2016-08-11 15:33:56 --> Loader Class Initialized
INFO - 2016-08-11 15:33:56 --> Helper loaded: url_helper
INFO - 2016-08-11 15:33:56 --> Helper loaded: date_helper
INFO - 2016-08-11 15:33:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:33:56 --> Database Driver Class Initialized
INFO - 2016-08-11 15:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:33:56 --> Email Class Initialized
INFO - 2016-08-11 15:33:56 --> Model Class Initialized
INFO - 2016-08-11 15:33:56 --> Controller Class Initialized
DEBUG - 2016-08-11 15:33:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:33:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:33:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:33:56 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:33:57 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:33:57 --> Model Class Initialized
INFO - 2016-08-11 15:33:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:33:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:33:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:33:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:33:57 --> Final output sent to browser
DEBUG - 2016-08-11 15:33:57 --> Total execution time: 0.4732
INFO - 2016-08-11 15:35:38 --> Config Class Initialized
INFO - 2016-08-11 15:35:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:35:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:35:38 --> Utf8 Class Initialized
INFO - 2016-08-11 15:35:38 --> URI Class Initialized
INFO - 2016-08-11 15:35:38 --> Router Class Initialized
INFO - 2016-08-11 15:35:38 --> Output Class Initialized
INFO - 2016-08-11 15:35:38 --> Security Class Initialized
DEBUG - 2016-08-11 15:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:35:38 --> Input Class Initialized
INFO - 2016-08-11 15:35:38 --> Language Class Initialized
ERROR - 2016-08-11 15:35:38 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:35:44 --> Config Class Initialized
INFO - 2016-08-11 15:35:44 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:35:44 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:35:44 --> Utf8 Class Initialized
INFO - 2016-08-11 15:35:44 --> URI Class Initialized
INFO - 2016-08-11 15:35:44 --> Router Class Initialized
INFO - 2016-08-11 15:35:44 --> Output Class Initialized
INFO - 2016-08-11 15:35:44 --> Security Class Initialized
DEBUG - 2016-08-11 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:35:44 --> Input Class Initialized
INFO - 2016-08-11 15:35:44 --> Language Class Initialized
ERROR - 2016-08-11 15:35:44 --> 404 Page Not Found: Tentang-sehati/index
INFO - 2016-08-11 15:35:47 --> Config Class Initialized
INFO - 2016-08-11 15:35:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:35:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:35:47 --> Utf8 Class Initialized
INFO - 2016-08-11 15:35:47 --> URI Class Initialized
INFO - 2016-08-11 15:35:47 --> Router Class Initialized
INFO - 2016-08-11 15:35:47 --> Output Class Initialized
INFO - 2016-08-11 15:35:47 --> Security Class Initialized
DEBUG - 2016-08-11 15:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:35:47 --> Input Class Initialized
INFO - 2016-08-11 15:35:47 --> Language Class Initialized
INFO - 2016-08-11 15:35:47 --> Loader Class Initialized
INFO - 2016-08-11 15:35:47 --> Helper loaded: url_helper
INFO - 2016-08-11 15:35:47 --> Helper loaded: date_helper
INFO - 2016-08-11 15:35:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:35:47 --> Database Driver Class Initialized
INFO - 2016-08-11 15:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:35:47 --> Email Class Initialized
INFO - 2016-08-11 15:35:47 --> Model Class Initialized
INFO - 2016-08-11 15:35:47 --> Controller Class Initialized
DEBUG - 2016-08-11 15:35:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:35:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:35:47 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:35:47 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:47 --> Model Class Initialized
INFO - 2016-08-11 15:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:35:47 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:35:47 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:35:49 --> Config Class Initialized
INFO - 2016-08-11 15:35:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:35:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:35:50 --> Utf8 Class Initialized
INFO - 2016-08-11 15:35:50 --> URI Class Initialized
INFO - 2016-08-11 15:35:50 --> Router Class Initialized
INFO - 2016-08-11 15:35:50 --> Output Class Initialized
INFO - 2016-08-11 15:35:50 --> Security Class Initialized
DEBUG - 2016-08-11 15:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:35:50 --> Input Class Initialized
INFO - 2016-08-11 15:35:50 --> Language Class Initialized
INFO - 2016-08-11 15:35:50 --> Loader Class Initialized
INFO - 2016-08-11 15:35:50 --> Helper loaded: url_helper
INFO - 2016-08-11 15:35:50 --> Helper loaded: date_helper
INFO - 2016-08-11 15:35:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:35:50 --> Database Driver Class Initialized
INFO - 2016-08-11 15:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:35:50 --> Email Class Initialized
INFO - 2016-08-11 15:35:50 --> Model Class Initialized
INFO - 2016-08-11 15:35:50 --> Controller Class Initialized
DEBUG - 2016-08-11 15:35:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:35:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:35:50 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:35:50 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:50 --> Model Class Initialized
INFO - 2016-08-11 15:35:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:35:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:35:50 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:35:50 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:35:54 --> Config Class Initialized
INFO - 2016-08-11 15:35:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:35:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:35:54 --> Utf8 Class Initialized
INFO - 2016-08-11 15:35:54 --> URI Class Initialized
INFO - 2016-08-11 15:35:54 --> Router Class Initialized
INFO - 2016-08-11 15:35:54 --> Output Class Initialized
INFO - 2016-08-11 15:35:54 --> Security Class Initialized
DEBUG - 2016-08-11 15:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:35:54 --> Input Class Initialized
INFO - 2016-08-11 15:35:54 --> Language Class Initialized
INFO - 2016-08-11 15:35:54 --> Loader Class Initialized
INFO - 2016-08-11 15:35:54 --> Helper loaded: url_helper
INFO - 2016-08-11 15:35:54 --> Helper loaded: date_helper
INFO - 2016-08-11 15:35:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:35:54 --> Database Driver Class Initialized
INFO - 2016-08-11 15:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:35:54 --> Email Class Initialized
INFO - 2016-08-11 15:35:54 --> Model Class Initialized
INFO - 2016-08-11 15:35:54 --> Controller Class Initialized
DEBUG - 2016-08-11 15:35:54 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:35:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:35:55 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:35:55 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:35:55 --> Model Class Initialized
INFO - 2016-08-11 15:35:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:35:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:35:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 15:35:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:35:55 --> Final output sent to browser
DEBUG - 2016-08-11 15:35:55 --> Total execution time: 0.4721
INFO - 2016-08-11 15:36:01 --> Config Class Initialized
INFO - 2016-08-11 15:36:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:36:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:36:01 --> Utf8 Class Initialized
INFO - 2016-08-11 15:36:01 --> URI Class Initialized
INFO - 2016-08-11 15:36:01 --> Router Class Initialized
INFO - 2016-08-11 15:36:01 --> Output Class Initialized
INFO - 2016-08-11 15:36:01 --> Security Class Initialized
DEBUG - 2016-08-11 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:36:01 --> Input Class Initialized
INFO - 2016-08-11 15:36:01 --> Language Class Initialized
INFO - 2016-08-11 15:36:01 --> Loader Class Initialized
INFO - 2016-08-11 15:36:01 --> Helper loaded: url_helper
INFO - 2016-08-11 15:36:01 --> Helper loaded: date_helper
INFO - 2016-08-11 15:36:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:36:01 --> Database Driver Class Initialized
INFO - 2016-08-11 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:36:01 --> Email Class Initialized
INFO - 2016-08-11 15:36:01 --> Model Class Initialized
INFO - 2016-08-11 15:36:01 --> Controller Class Initialized
ERROR - 2016-08-11 15:36:01 --> Severity: Warning --> Missing argument 1 for Page::index() D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 16
ERROR - 2016-08-11 15:36:01 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 19
INFO - 2016-08-11 15:36:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:36:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:36:01 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:36:01 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:36:17 --> Config Class Initialized
INFO - 2016-08-11 15:36:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:36:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:36:17 --> Utf8 Class Initialized
INFO - 2016-08-11 15:36:17 --> URI Class Initialized
INFO - 2016-08-11 15:36:17 --> Router Class Initialized
INFO - 2016-08-11 15:36:17 --> Output Class Initialized
INFO - 2016-08-11 15:36:17 --> Security Class Initialized
DEBUG - 2016-08-11 15:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:36:17 --> Input Class Initialized
INFO - 2016-08-11 15:36:17 --> Language Class Initialized
INFO - 2016-08-11 15:36:17 --> Loader Class Initialized
INFO - 2016-08-11 15:36:17 --> Helper loaded: url_helper
INFO - 2016-08-11 15:36:17 --> Helper loaded: date_helper
INFO - 2016-08-11 15:36:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:36:18 --> Database Driver Class Initialized
INFO - 2016-08-11 15:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:36:18 --> Email Class Initialized
INFO - 2016-08-11 15:36:18 --> Model Class Initialized
INFO - 2016-08-11 15:36:18 --> Controller Class Initialized
ERROR - 2016-08-11 15:36:18 --> Severity: Warning --> Missing argument 1 for Page::index() D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 16
ERROR - 2016-08-11 15:36:18 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 19
INFO - 2016-08-11 15:36:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:36:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:36:18 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:36:18 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:36:21 --> Config Class Initialized
INFO - 2016-08-11 15:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:36:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:36:21 --> Utf8 Class Initialized
INFO - 2016-08-11 15:36:21 --> URI Class Initialized
INFO - 2016-08-11 15:36:21 --> Router Class Initialized
INFO - 2016-08-11 15:36:21 --> Output Class Initialized
INFO - 2016-08-11 15:36:21 --> Security Class Initialized
DEBUG - 2016-08-11 15:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:36:21 --> Input Class Initialized
INFO - 2016-08-11 15:36:21 --> Language Class Initialized
ERROR - 2016-08-11 15:36:21 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:36:24 --> Config Class Initialized
INFO - 2016-08-11 15:36:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:36:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:36:24 --> Utf8 Class Initialized
INFO - 2016-08-11 15:36:24 --> URI Class Initialized
INFO - 2016-08-11 15:36:24 --> Router Class Initialized
INFO - 2016-08-11 15:36:24 --> Output Class Initialized
INFO - 2016-08-11 15:36:24 --> Security Class Initialized
DEBUG - 2016-08-11 15:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:36:24 --> Input Class Initialized
INFO - 2016-08-11 15:36:24 --> Language Class Initialized
ERROR - 2016-08-11 15:36:24 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:37:28 --> Config Class Initialized
INFO - 2016-08-11 15:37:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:37:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:37:28 --> Utf8 Class Initialized
INFO - 2016-08-11 15:37:28 --> URI Class Initialized
INFO - 2016-08-11 15:37:28 --> Router Class Initialized
INFO - 2016-08-11 15:37:28 --> Output Class Initialized
INFO - 2016-08-11 15:37:28 --> Security Class Initialized
DEBUG - 2016-08-11 15:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:37:28 --> Input Class Initialized
INFO - 2016-08-11 15:37:28 --> Language Class Initialized
ERROR - 2016-08-11 15:37:28 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:37:43 --> Config Class Initialized
INFO - 2016-08-11 15:37:43 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:37:43 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:37:43 --> Utf8 Class Initialized
INFO - 2016-08-11 15:37:43 --> URI Class Initialized
INFO - 2016-08-11 15:37:43 --> Router Class Initialized
INFO - 2016-08-11 15:37:43 --> Output Class Initialized
INFO - 2016-08-11 15:37:43 --> Security Class Initialized
DEBUG - 2016-08-11 15:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:37:43 --> Input Class Initialized
INFO - 2016-08-11 15:37:43 --> Language Class Initialized
ERROR - 2016-08-11 15:37:43 --> Severity: Warning --> Missing argument 1 for Page::__construct(), called in D:\xampp\htdocs\aqiqahsehati\system\core\CodeIgniter.php on line 500 and defined D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 13
INFO - 2016-08-11 15:37:43 --> Loader Class Initialized
INFO - 2016-08-11 15:37:43 --> Helper loaded: url_helper
INFO - 2016-08-11 15:37:43 --> Helper loaded: date_helper
INFO - 2016-08-11 15:37:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:37:43 --> Database Driver Class Initialized
INFO - 2016-08-11 15:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:37:43 --> Email Class Initialized
INFO - 2016-08-11 15:37:43 --> Model Class Initialized
INFO - 2016-08-11 15:37:43 --> Controller Class Initialized
ERROR - 2016-08-11 15:37:43 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 16
INFO - 2016-08-11 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:37:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:37:43 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:37:43 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:39:53 --> Config Class Initialized
INFO - 2016-08-11 15:39:53 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:39:53 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:39:53 --> Utf8 Class Initialized
INFO - 2016-08-11 15:39:53 --> URI Class Initialized
INFO - 2016-08-11 15:39:53 --> Router Class Initialized
INFO - 2016-08-11 15:39:53 --> Output Class Initialized
INFO - 2016-08-11 15:39:53 --> Security Class Initialized
DEBUG - 2016-08-11 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:39:53 --> Input Class Initialized
INFO - 2016-08-11 15:39:53 --> Language Class Initialized
INFO - 2016-08-11 15:39:53 --> Loader Class Initialized
INFO - 2016-08-11 15:39:53 --> Helper loaded: url_helper
INFO - 2016-08-11 15:39:53 --> Helper loaded: date_helper
INFO - 2016-08-11 15:39:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:39:53 --> Database Driver Class Initialized
INFO - 2016-08-11 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:39:53 --> Email Class Initialized
INFO - 2016-08-11 15:39:53 --> Model Class Initialized
INFO - 2016-08-11 15:39:53 --> Controller Class Initialized
INFO - 2016-08-11 15:39:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:39:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:39:53 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:39:53 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:40:18 --> Config Class Initialized
INFO - 2016-08-11 15:40:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:40:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:40:18 --> Utf8 Class Initialized
INFO - 2016-08-11 15:40:18 --> URI Class Initialized
INFO - 2016-08-11 15:40:18 --> Router Class Initialized
INFO - 2016-08-11 15:40:18 --> Output Class Initialized
INFO - 2016-08-11 15:40:18 --> Security Class Initialized
DEBUG - 2016-08-11 15:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:40:18 --> Input Class Initialized
INFO - 2016-08-11 15:40:18 --> Language Class Initialized
ERROR - 2016-08-11 15:40:18 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:41:36 --> Config Class Initialized
INFO - 2016-08-11 15:41:36 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:41:36 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:41:36 --> Utf8 Class Initialized
INFO - 2016-08-11 15:41:36 --> URI Class Initialized
INFO - 2016-08-11 15:41:36 --> Router Class Initialized
INFO - 2016-08-11 15:41:36 --> Output Class Initialized
INFO - 2016-08-11 15:41:36 --> Security Class Initialized
DEBUG - 2016-08-11 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:41:36 --> Input Class Initialized
INFO - 2016-08-11 15:41:36 --> Language Class Initialized
INFO - 2016-08-11 15:41:36 --> Loader Class Initialized
INFO - 2016-08-11 15:41:37 --> Helper loaded: url_helper
INFO - 2016-08-11 15:41:37 --> Helper loaded: date_helper
INFO - 2016-08-11 15:41:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:41:37 --> Database Driver Class Initialized
INFO - 2016-08-11 15:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:41:37 --> Email Class Initialized
INFO - 2016-08-11 15:41:37 --> Model Class Initialized
INFO - 2016-08-11 15:41:37 --> Controller Class Initialized
INFO - 2016-08-11 15:41:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:41:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:41:37 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:41:37 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:41:48 --> Config Class Initialized
INFO - 2016-08-11 15:41:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:41:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:41:48 --> Utf8 Class Initialized
INFO - 2016-08-11 15:41:48 --> URI Class Initialized
INFO - 2016-08-11 15:41:48 --> Router Class Initialized
INFO - 2016-08-11 15:41:48 --> Output Class Initialized
INFO - 2016-08-11 15:41:48 --> Security Class Initialized
DEBUG - 2016-08-11 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:41:48 --> Input Class Initialized
INFO - 2016-08-11 15:41:48 --> Language Class Initialized
INFO - 2016-08-11 15:41:48 --> Loader Class Initialized
INFO - 2016-08-11 15:41:48 --> Helper loaded: url_helper
INFO - 2016-08-11 15:41:48 --> Helper loaded: date_helper
INFO - 2016-08-11 15:41:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:41:48 --> Database Driver Class Initialized
INFO - 2016-08-11 15:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:41:48 --> Email Class Initialized
INFO - 2016-08-11 15:41:48 --> Model Class Initialized
INFO - 2016-08-11 15:41:48 --> Controller Class Initialized
INFO - 2016-08-11 15:41:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:41:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:41:48 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 15:41:48 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 15:42:26 --> Config Class Initialized
INFO - 2016-08-11 15:42:26 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:42:26 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:26 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:26 --> URI Class Initialized
INFO - 2016-08-11 15:42:26 --> Router Class Initialized
INFO - 2016-08-11 15:42:26 --> Output Class Initialized
INFO - 2016-08-11 15:42:26 --> Security Class Initialized
DEBUG - 2016-08-11 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:27 --> Input Class Initialized
INFO - 2016-08-11 15:42:27 --> Language Class Initialized
ERROR - 2016-08-11 15:42:27 --> Severity: Warning --> Missing argument 1 for Page::__construct(), called in D:\xampp\htdocs\aqiqahsehati\system\core\CodeIgniter.php on line 500 and defined D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 13
INFO - 2016-08-11 15:42:27 --> Loader Class Initialized
INFO - 2016-08-11 15:42:27 --> Helper loaded: url_helper
INFO - 2016-08-11 15:42:27 --> Helper loaded: date_helper
INFO - 2016-08-11 15:42:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:42:27 --> Database Driver Class Initialized
INFO - 2016-08-11 15:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:42:27 --> Email Class Initialized
INFO - 2016-08-11 15:42:27 --> Model Class Initialized
INFO - 2016-08-11 15:42:27 --> Controller Class Initialized
ERROR - 2016-08-11 15:42:27 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 16
INFO - 2016-08-11 15:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:42:27 --> Final output sent to browser
DEBUG - 2016-08-11 15:42:27 --> Total execution time: 0.4024
INFO - 2016-08-11 15:42:27 --> Config Class Initialized
INFO - 2016-08-11 15:42:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:42:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:27 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:27 --> URI Class Initialized
INFO - 2016-08-11 15:42:27 --> Router Class Initialized
INFO - 2016-08-11 15:42:27 --> Output Class Initialized
INFO - 2016-08-11 15:42:27 --> Security Class Initialized
DEBUG - 2016-08-11 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:27 --> Input Class Initialized
INFO - 2016-08-11 15:42:27 --> Language Class Initialized
ERROR - 2016-08-11 15:42:27 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 15:42:34 --> Config Class Initialized
INFO - 2016-08-11 15:42:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:42:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:34 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:34 --> URI Class Initialized
INFO - 2016-08-11 15:42:34 --> Config Class Initialized
INFO - 2016-08-11 15:42:34 --> Hooks Class Initialized
INFO - 2016-08-11 15:42:34 --> Router Class Initialized
INFO - 2016-08-11 15:42:34 --> Output Class Initialized
DEBUG - 2016-08-11 15:42:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:34 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:34 --> Security Class Initialized
INFO - 2016-08-11 15:42:34 --> URI Class Initialized
DEBUG - 2016-08-11 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:34 --> Input Class Initialized
INFO - 2016-08-11 15:42:34 --> Router Class Initialized
INFO - 2016-08-11 15:42:34 --> Language Class Initialized
INFO - 2016-08-11 15:42:34 --> Output Class Initialized
INFO - 2016-08-11 15:42:34 --> Security Class Initialized
ERROR - 2016-08-11 15:42:34 --> 404 Page Not Found: Page/tentang-sehati
DEBUG - 2016-08-11 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:34 --> Input Class Initialized
INFO - 2016-08-11 15:42:34 --> Language Class Initialized
ERROR - 2016-08-11 15:42:34 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:42:36 --> Config Class Initialized
INFO - 2016-08-11 15:42:36 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:42:36 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:36 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:36 --> URI Class Initialized
INFO - 2016-08-11 15:42:36 --> Router Class Initialized
INFO - 2016-08-11 15:42:36 --> Output Class Initialized
INFO - 2016-08-11 15:42:36 --> Security Class Initialized
DEBUG - 2016-08-11 15:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:36 --> Input Class Initialized
INFO - 2016-08-11 15:42:36 --> Language Class Initialized
ERROR - 2016-08-11 15:42:36 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:42:43 --> Config Class Initialized
INFO - 2016-08-11 15:42:43 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:42:43 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:42:43 --> Utf8 Class Initialized
INFO - 2016-08-11 15:42:43 --> URI Class Initialized
INFO - 2016-08-11 15:42:43 --> Router Class Initialized
INFO - 2016-08-11 15:42:43 --> Output Class Initialized
INFO - 2016-08-11 15:42:43 --> Security Class Initialized
DEBUG - 2016-08-11 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:42:43 --> Input Class Initialized
INFO - 2016-08-11 15:42:43 --> Language Class Initialized
ERROR - 2016-08-11 15:42:43 --> Severity: Warning --> Missing argument 1 for Page::__construct(), called in D:\xampp\htdocs\aqiqahsehati\system\core\CodeIgniter.php on line 500 and defined D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 13
INFO - 2016-08-11 15:42:43 --> Loader Class Initialized
INFO - 2016-08-11 15:42:43 --> Helper loaded: url_helper
INFO - 2016-08-11 15:42:43 --> Helper loaded: date_helper
INFO - 2016-08-11 15:42:43 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:42:43 --> Database Driver Class Initialized
INFO - 2016-08-11 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:42:43 --> Email Class Initialized
INFO - 2016-08-11 15:42:43 --> Model Class Initialized
INFO - 2016-08-11 15:42:43 --> Controller Class Initialized
ERROR - 2016-08-11 15:42:43 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 16
INFO - 2016-08-11 15:42:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:42:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:42:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:42:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:42:43 --> Final output sent to browser
DEBUG - 2016-08-11 15:42:43 --> Total execution time: 0.4047
INFO - 2016-08-11 15:43:14 --> Config Class Initialized
INFO - 2016-08-11 15:43:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:43:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:43:14 --> Utf8 Class Initialized
INFO - 2016-08-11 15:43:14 --> URI Class Initialized
INFO - 2016-08-11 15:43:14 --> Router Class Initialized
INFO - 2016-08-11 15:43:14 --> Output Class Initialized
INFO - 2016-08-11 15:43:14 --> Security Class Initialized
DEBUG - 2016-08-11 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:43:14 --> Input Class Initialized
INFO - 2016-08-11 15:43:14 --> Language Class Initialized
INFO - 2016-08-11 15:43:14 --> Loader Class Initialized
INFO - 2016-08-11 15:43:14 --> Helper loaded: url_helper
INFO - 2016-08-11 15:43:14 --> Helper loaded: date_helper
INFO - 2016-08-11 15:43:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:43:14 --> Database Driver Class Initialized
INFO - 2016-08-11 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:43:14 --> Email Class Initialized
INFO - 2016-08-11 15:43:14 --> Model Class Initialized
INFO - 2016-08-11 15:43:14 --> Controller Class Initialized
ERROR - 2016-08-11 15:43:14 --> Severity: Warning --> Missing argument 1 for Page::index() D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 18
ERROR - 2016-08-11 15:43:14 --> Severity: Notice --> Undefined variable: slug D:\xampp\htdocs\aqiqahsehati\application\controllers\Page.php 21
INFO - 2016-08-11 15:43:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:43:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 15:43:14 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 10
INFO - 2016-08-11 15:43:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:43:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:43:14 --> Final output sent to browser
DEBUG - 2016-08-11 15:43:15 --> Total execution time: 0.7340
INFO - 2016-08-11 15:43:21 --> Config Class Initialized
INFO - 2016-08-11 15:43:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:43:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:43:21 --> Utf8 Class Initialized
INFO - 2016-08-11 15:43:21 --> URI Class Initialized
INFO - 2016-08-11 15:43:21 --> Router Class Initialized
INFO - 2016-08-11 15:43:21 --> Output Class Initialized
INFO - 2016-08-11 15:43:21 --> Security Class Initialized
INFO - 2016-08-11 15:43:21 --> Config Class Initialized
DEBUG - 2016-08-11 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:43:21 --> Hooks Class Initialized
INFO - 2016-08-11 15:43:21 --> Input Class Initialized
INFO - 2016-08-11 15:43:21 --> Language Class Initialized
DEBUG - 2016-08-11 15:43:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:43:21 --> Utf8 Class Initialized
ERROR - 2016-08-11 15:43:21 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:43:21 --> URI Class Initialized
INFO - 2016-08-11 15:43:21 --> Router Class Initialized
INFO - 2016-08-11 15:43:21 --> Output Class Initialized
INFO - 2016-08-11 15:43:21 --> Security Class Initialized
DEBUG - 2016-08-11 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:43:21 --> Input Class Initialized
INFO - 2016-08-11 15:43:21 --> Language Class Initialized
ERROR - 2016-08-11 15:43:21 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:44:17 --> Config Class Initialized
INFO - 2016-08-11 15:44:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:44:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:44:17 --> Utf8 Class Initialized
INFO - 2016-08-11 15:44:17 --> URI Class Initialized
INFO - 2016-08-11 15:44:17 --> Router Class Initialized
INFO - 2016-08-11 15:44:17 --> Output Class Initialized
INFO - 2016-08-11 15:44:17 --> Security Class Initialized
DEBUG - 2016-08-11 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:44:17 --> Input Class Initialized
INFO - 2016-08-11 15:44:17 --> Language Class Initialized
ERROR - 2016-08-11 15:44:17 --> 404 Page Not Found: Page/tentang-sehati
INFO - 2016-08-11 15:48:08 --> Config Class Initialized
INFO - 2016-08-11 15:48:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:48:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:48:08 --> Utf8 Class Initialized
INFO - 2016-08-11 15:48:08 --> URI Class Initialized
INFO - 2016-08-11 15:48:08 --> Router Class Initialized
INFO - 2016-08-11 15:48:08 --> Output Class Initialized
INFO - 2016-08-11 15:48:08 --> Security Class Initialized
DEBUG - 2016-08-11 15:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:48:08 --> Input Class Initialized
INFO - 2016-08-11 15:48:08 --> Language Class Initialized
ERROR - 2016-08-11 15:48:08 --> 404 Page Not Found: Slug/tentang-sehati
INFO - 2016-08-11 15:48:10 --> Config Class Initialized
INFO - 2016-08-11 15:48:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:48:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:48:10 --> Utf8 Class Initialized
INFO - 2016-08-11 15:48:10 --> URI Class Initialized
INFO - 2016-08-11 15:48:10 --> Router Class Initialized
INFO - 2016-08-11 15:48:10 --> Output Class Initialized
INFO - 2016-08-11 15:48:10 --> Security Class Initialized
DEBUG - 2016-08-11 15:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:48:10 --> Input Class Initialized
INFO - 2016-08-11 15:48:10 --> Language Class Initialized
ERROR - 2016-08-11 15:48:10 --> 404 Page Not Found: Slug/tentang-sehati
INFO - 2016-08-11 15:48:19 --> Config Class Initialized
INFO - 2016-08-11 15:48:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:48:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:48:19 --> Utf8 Class Initialized
INFO - 2016-08-11 15:48:19 --> URI Class Initialized
INFO - 2016-08-11 15:48:19 --> Router Class Initialized
INFO - 2016-08-11 15:48:19 --> Output Class Initialized
INFO - 2016-08-11 15:48:19 --> Security Class Initialized
DEBUG - 2016-08-11 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:48:19 --> Input Class Initialized
INFO - 2016-08-11 15:48:19 --> Language Class Initialized
INFO - 2016-08-11 15:48:19 --> Loader Class Initialized
INFO - 2016-08-11 15:48:19 --> Helper loaded: url_helper
INFO - 2016-08-11 15:48:19 --> Helper loaded: date_helper
INFO - 2016-08-11 15:48:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:48:19 --> Database Driver Class Initialized
INFO - 2016-08-11 15:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:48:19 --> Email Class Initialized
INFO - 2016-08-11 15:48:19 --> Model Class Initialized
INFO - 2016-08-11 15:48:19 --> Controller Class Initialized
INFO - 2016-08-11 15:48:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:48:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:48:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:48:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:48:19 --> Final output sent to browser
DEBUG - 2016-08-11 15:48:19 --> Total execution time: 0.3819
INFO - 2016-08-11 15:48:20 --> Config Class Initialized
INFO - 2016-08-11 15:48:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:48:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:48:20 --> Utf8 Class Initialized
INFO - 2016-08-11 15:48:20 --> URI Class Initialized
INFO - 2016-08-11 15:48:20 --> Router Class Initialized
INFO - 2016-08-11 15:48:20 --> Output Class Initialized
INFO - 2016-08-11 15:48:20 --> Security Class Initialized
DEBUG - 2016-08-11 15:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:48:20 --> Input Class Initialized
INFO - 2016-08-11 15:48:20 --> Language Class Initialized
ERROR - 2016-08-11 15:48:20 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 15:56:08 --> Config Class Initialized
INFO - 2016-08-11 15:56:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:56:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:56:08 --> Utf8 Class Initialized
INFO - 2016-08-11 15:56:08 --> URI Class Initialized
INFO - 2016-08-11 15:56:08 --> Router Class Initialized
INFO - 2016-08-11 15:56:08 --> Output Class Initialized
INFO - 2016-08-11 15:56:08 --> Security Class Initialized
DEBUG - 2016-08-11 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:56:08 --> Input Class Initialized
INFO - 2016-08-11 15:56:08 --> Language Class Initialized
INFO - 2016-08-11 15:56:08 --> Loader Class Initialized
INFO - 2016-08-11 15:56:08 --> Helper loaded: url_helper
INFO - 2016-08-11 15:56:08 --> Helper loaded: date_helper
INFO - 2016-08-11 15:56:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:56:08 --> Database Driver Class Initialized
INFO - 2016-08-11 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:56:08 --> Email Class Initialized
INFO - 2016-08-11 15:56:08 --> Model Class Initialized
INFO - 2016-08-11 15:56:08 --> Controller Class Initialized
DEBUG - 2016-08-11 15:56:08 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:56:08 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:56:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:56:08 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:56:08 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:56:08 --> Model Class Initialized
INFO - 2016-08-11 15:56:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 15:56:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 15:56:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 15:56:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 15:56:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 15:56:08 --> Final output sent to browser
DEBUG - 2016-08-11 15:56:08 --> Total execution time: 0.5070
INFO - 2016-08-11 15:56:13 --> Config Class Initialized
INFO - 2016-08-11 15:56:13 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:56:13 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:56:13 --> Utf8 Class Initialized
INFO - 2016-08-11 15:56:13 --> URI Class Initialized
INFO - 2016-08-11 15:56:13 --> Router Class Initialized
INFO - 2016-08-11 15:56:13 --> Output Class Initialized
INFO - 2016-08-11 15:56:13 --> Security Class Initialized
DEBUG - 2016-08-11 15:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:56:13 --> Input Class Initialized
INFO - 2016-08-11 15:56:13 --> Language Class Initialized
INFO - 2016-08-11 15:56:13 --> Loader Class Initialized
INFO - 2016-08-11 15:56:13 --> Helper loaded: url_helper
INFO - 2016-08-11 15:56:13 --> Helper loaded: date_helper
INFO - 2016-08-11 15:56:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:56:13 --> Database Driver Class Initialized
INFO - 2016-08-11 15:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:56:13 --> Email Class Initialized
INFO - 2016-08-11 15:56:13 --> Model Class Initialized
INFO - 2016-08-11 15:56:13 --> Controller Class Initialized
DEBUG - 2016-08-11 15:56:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 15:56:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:56:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 15:56:13 --> Helper loaded: cookie_helper
INFO - 2016-08-11 15:56:13 --> Helper loaded: language_helper
DEBUG - 2016-08-11 15:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 15:56:13 --> Model Class Initialized
INFO - 2016-08-11 15:56:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 15:56:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 15:56:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 15:56:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 15:56:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 15:56:13 --> Final output sent to browser
DEBUG - 2016-08-11 15:56:13 --> Total execution time: 0.5100
INFO - 2016-08-11 15:57:45 --> Config Class Initialized
INFO - 2016-08-11 15:57:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:57:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:57:45 --> Utf8 Class Initialized
INFO - 2016-08-11 15:57:45 --> URI Class Initialized
INFO - 2016-08-11 15:57:45 --> Router Class Initialized
INFO - 2016-08-11 15:57:45 --> Output Class Initialized
INFO - 2016-08-11 15:57:45 --> Security Class Initialized
DEBUG - 2016-08-11 15:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:57:45 --> Input Class Initialized
INFO - 2016-08-11 15:57:45 --> Language Class Initialized
INFO - 2016-08-11 15:57:45 --> Loader Class Initialized
INFO - 2016-08-11 15:57:45 --> Helper loaded: url_helper
INFO - 2016-08-11 15:57:45 --> Helper loaded: date_helper
INFO - 2016-08-11 15:57:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 15:57:45 --> Database Driver Class Initialized
INFO - 2016-08-11 15:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 15:57:45 --> Email Class Initialized
INFO - 2016-08-11 15:57:45 --> Model Class Initialized
INFO - 2016-08-11 15:57:45 --> Controller Class Initialized
INFO - 2016-08-11 15:57:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 15:57:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 15:57:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 15:57:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 15:57:45 --> Final output sent to browser
DEBUG - 2016-08-11 15:57:45 --> Total execution time: 0.3846
INFO - 2016-08-11 15:57:45 --> Config Class Initialized
INFO - 2016-08-11 15:57:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 15:57:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 15:57:45 --> Utf8 Class Initialized
INFO - 2016-08-11 15:57:46 --> URI Class Initialized
INFO - 2016-08-11 15:57:46 --> Router Class Initialized
INFO - 2016-08-11 15:57:46 --> Output Class Initialized
INFO - 2016-08-11 15:57:46 --> Security Class Initialized
DEBUG - 2016-08-11 15:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 15:57:46 --> Input Class Initialized
INFO - 2016-08-11 15:57:46 --> Language Class Initialized
ERROR - 2016-08-11 15:57:46 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 16:04:11 --> Config Class Initialized
INFO - 2016-08-11 16:04:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:04:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:04:11 --> Utf8 Class Initialized
INFO - 2016-08-11 16:04:11 --> URI Class Initialized
INFO - 2016-08-11 16:04:11 --> Router Class Initialized
INFO - 2016-08-11 16:04:11 --> Output Class Initialized
INFO - 2016-08-11 16:04:11 --> Security Class Initialized
DEBUG - 2016-08-11 16:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:04:11 --> Input Class Initialized
INFO - 2016-08-11 16:04:11 --> Language Class Initialized
INFO - 2016-08-11 16:04:11 --> Loader Class Initialized
INFO - 2016-08-11 16:04:11 --> Helper loaded: url_helper
INFO - 2016-08-11 16:04:11 --> Helper loaded: date_helper
INFO - 2016-08-11 16:04:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:04:11 --> Database Driver Class Initialized
INFO - 2016-08-11 16:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:04:12 --> Email Class Initialized
INFO - 2016-08-11 16:04:12 --> Model Class Initialized
INFO - 2016-08-11 16:04:12 --> Controller Class Initialized
INFO - 2016-08-11 16:04:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:04:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:04:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:04:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:04:12 --> Final output sent to browser
DEBUG - 2016-08-11 16:04:12 --> Total execution time: 0.5111
INFO - 2016-08-11 16:04:21 --> Config Class Initialized
INFO - 2016-08-11 16:04:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:04:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:04:21 --> Utf8 Class Initialized
INFO - 2016-08-11 16:04:21 --> URI Class Initialized
INFO - 2016-08-11 16:04:21 --> Router Class Initialized
INFO - 2016-08-11 16:04:21 --> Output Class Initialized
INFO - 2016-08-11 16:04:21 --> Security Class Initialized
DEBUG - 2016-08-11 16:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:04:21 --> Input Class Initialized
INFO - 2016-08-11 16:04:21 --> Language Class Initialized
INFO - 2016-08-11 16:04:21 --> Loader Class Initialized
INFO - 2016-08-11 16:04:21 --> Helper loaded: url_helper
INFO - 2016-08-11 16:04:21 --> Helper loaded: date_helper
INFO - 2016-08-11 16:04:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:04:21 --> Database Driver Class Initialized
INFO - 2016-08-11 16:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:04:21 --> Email Class Initialized
INFO - 2016-08-11 16:04:21 --> Model Class Initialized
INFO - 2016-08-11 16:04:21 --> Controller Class Initialized
INFO - 2016-08-11 16:04:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:04:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:04:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:04:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:04:21 --> Final output sent to browser
DEBUG - 2016-08-11 16:04:21 --> Total execution time: 0.3910
INFO - 2016-08-11 16:04:49 --> Config Class Initialized
INFO - 2016-08-11 16:04:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:04:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:04:49 --> Utf8 Class Initialized
INFO - 2016-08-11 16:04:50 --> URI Class Initialized
INFO - 2016-08-11 16:04:50 --> Router Class Initialized
INFO - 2016-08-11 16:04:50 --> Output Class Initialized
INFO - 2016-08-11 16:04:50 --> Security Class Initialized
DEBUG - 2016-08-11 16:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:04:50 --> Input Class Initialized
INFO - 2016-08-11 16:04:50 --> Language Class Initialized
INFO - 2016-08-11 16:04:50 --> Loader Class Initialized
INFO - 2016-08-11 16:04:50 --> Helper loaded: url_helper
INFO - 2016-08-11 16:04:50 --> Helper loaded: date_helper
INFO - 2016-08-11 16:04:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:04:50 --> Database Driver Class Initialized
INFO - 2016-08-11 16:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:04:50 --> Email Class Initialized
INFO - 2016-08-11 16:04:50 --> Model Class Initialized
INFO - 2016-08-11 16:04:50 --> Controller Class Initialized
DEBUG - 2016-08-11 16:04:50 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:04:50 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:04:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:04:50 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:04:50 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:04:50 --> Model Class Initialized
INFO - 2016-08-11 16:04:50 --> Upload Class Initialized
INFO - 2016-08-11 16:04:50 --> Config Class Initialized
INFO - 2016-08-11 16:04:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:04:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:04:50 --> Utf8 Class Initialized
INFO - 2016-08-11 16:04:50 --> URI Class Initialized
INFO - 2016-08-11 16:04:50 --> Router Class Initialized
INFO - 2016-08-11 16:04:50 --> Output Class Initialized
INFO - 2016-08-11 16:04:50 --> Security Class Initialized
DEBUG - 2016-08-11 16:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:04:50 --> Input Class Initialized
INFO - 2016-08-11 16:04:50 --> Language Class Initialized
INFO - 2016-08-11 16:04:50 --> Loader Class Initialized
INFO - 2016-08-11 16:04:50 --> Helper loaded: url_helper
INFO - 2016-08-11 16:04:50 --> Helper loaded: date_helper
INFO - 2016-08-11 16:04:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:04:51 --> Database Driver Class Initialized
INFO - 2016-08-11 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:04:51 --> Email Class Initialized
INFO - 2016-08-11 16:04:51 --> Model Class Initialized
INFO - 2016-08-11 16:04:51 --> Controller Class Initialized
DEBUG - 2016-08-11 16:04:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:04:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:04:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:04:51 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:04:51 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:04:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:04:51 --> Model Class Initialized
INFO - 2016-08-11 16:04:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:04:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:04:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:04:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:04:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:04:51 --> Final output sent to browser
DEBUG - 2016-08-11 16:04:51 --> Total execution time: 0.8465
INFO - 2016-08-11 16:04:54 --> Config Class Initialized
INFO - 2016-08-11 16:04:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:04:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:04:54 --> Utf8 Class Initialized
INFO - 2016-08-11 16:04:54 --> URI Class Initialized
INFO - 2016-08-11 16:04:54 --> Router Class Initialized
INFO - 2016-08-11 16:04:54 --> Output Class Initialized
INFO - 2016-08-11 16:04:54 --> Security Class Initialized
DEBUG - 2016-08-11 16:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:04:54 --> Input Class Initialized
INFO - 2016-08-11 16:04:54 --> Language Class Initialized
INFO - 2016-08-11 16:04:54 --> Loader Class Initialized
INFO - 2016-08-11 16:04:54 --> Helper loaded: url_helper
INFO - 2016-08-11 16:04:54 --> Helper loaded: date_helper
INFO - 2016-08-11 16:04:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:04:54 --> Database Driver Class Initialized
INFO - 2016-08-11 16:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:04:54 --> Email Class Initialized
INFO - 2016-08-11 16:04:54 --> Model Class Initialized
INFO - 2016-08-11 16:04:54 --> Controller Class Initialized
INFO - 2016-08-11 16:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:04:54 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:04:54 --> Final output sent to browser
DEBUG - 2016-08-11 16:04:54 --> Total execution time: 0.4037
INFO - 2016-08-11 16:05:06 --> Config Class Initialized
INFO - 2016-08-11 16:05:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:05:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:05:06 --> Utf8 Class Initialized
INFO - 2016-08-11 16:05:06 --> URI Class Initialized
INFO - 2016-08-11 16:05:06 --> Router Class Initialized
INFO - 2016-08-11 16:05:06 --> Output Class Initialized
INFO - 2016-08-11 16:05:06 --> Security Class Initialized
DEBUG - 2016-08-11 16:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:05:06 --> Input Class Initialized
INFO - 2016-08-11 16:05:06 --> Language Class Initialized
INFO - 2016-08-11 16:05:06 --> Loader Class Initialized
INFO - 2016-08-11 16:05:06 --> Helper loaded: url_helper
INFO - 2016-08-11 16:05:06 --> Helper loaded: date_helper
INFO - 2016-08-11 16:05:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:05:06 --> Database Driver Class Initialized
INFO - 2016-08-11 16:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:05:06 --> Email Class Initialized
INFO - 2016-08-11 16:05:06 --> Model Class Initialized
INFO - 2016-08-11 16:05:06 --> Controller Class Initialized
DEBUG - 2016-08-11 16:05:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:05:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:05:06 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:05:06 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:06 --> Model Class Initialized
INFO - 2016-08-11 16:05:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:05:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:05:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:05:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:05:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:05:06 --> Final output sent to browser
DEBUG - 2016-08-11 16:05:06 --> Total execution time: 0.5246
INFO - 2016-08-11 16:05:33 --> Config Class Initialized
INFO - 2016-08-11 16:05:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:05:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:05:33 --> Utf8 Class Initialized
INFO - 2016-08-11 16:05:33 --> URI Class Initialized
INFO - 2016-08-11 16:05:33 --> Router Class Initialized
INFO - 2016-08-11 16:05:33 --> Output Class Initialized
INFO - 2016-08-11 16:05:33 --> Security Class Initialized
DEBUG - 2016-08-11 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:05:33 --> Input Class Initialized
INFO - 2016-08-11 16:05:33 --> Language Class Initialized
INFO - 2016-08-11 16:05:33 --> Loader Class Initialized
INFO - 2016-08-11 16:05:33 --> Helper loaded: url_helper
INFO - 2016-08-11 16:05:33 --> Helper loaded: date_helper
INFO - 2016-08-11 16:05:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:05:33 --> Database Driver Class Initialized
INFO - 2016-08-11 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:05:33 --> Email Class Initialized
INFO - 2016-08-11 16:05:33 --> Model Class Initialized
INFO - 2016-08-11 16:05:33 --> Controller Class Initialized
DEBUG - 2016-08-11 16:05:33 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:05:33 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:05:33 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:05:33 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:34 --> Model Class Initialized
INFO - 2016-08-11 16:05:34 --> Upload Class Initialized
INFO - 2016-08-11 16:05:34 --> Config Class Initialized
INFO - 2016-08-11 16:05:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:05:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:05:34 --> Utf8 Class Initialized
INFO - 2016-08-11 16:05:34 --> URI Class Initialized
INFO - 2016-08-11 16:05:34 --> Router Class Initialized
INFO - 2016-08-11 16:05:34 --> Output Class Initialized
INFO - 2016-08-11 16:05:34 --> Security Class Initialized
DEBUG - 2016-08-11 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:05:34 --> Input Class Initialized
INFO - 2016-08-11 16:05:34 --> Language Class Initialized
INFO - 2016-08-11 16:05:34 --> Loader Class Initialized
INFO - 2016-08-11 16:05:34 --> Helper loaded: url_helper
INFO - 2016-08-11 16:05:34 --> Helper loaded: date_helper
INFO - 2016-08-11 16:05:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:05:34 --> Database Driver Class Initialized
INFO - 2016-08-11 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:05:34 --> Email Class Initialized
INFO - 2016-08-11 16:05:34 --> Model Class Initialized
INFO - 2016-08-11 16:05:34 --> Controller Class Initialized
DEBUG - 2016-08-11 16:05:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:05:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:05:34 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:05:34 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:05:34 --> Model Class Initialized
INFO - 2016-08-11 16:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:05:34 --> Final output sent to browser
DEBUG - 2016-08-11 16:05:34 --> Total execution time: 0.5405
INFO - 2016-08-11 16:05:38 --> Config Class Initialized
INFO - 2016-08-11 16:05:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:05:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:05:38 --> Utf8 Class Initialized
INFO - 2016-08-11 16:05:38 --> URI Class Initialized
INFO - 2016-08-11 16:05:38 --> Router Class Initialized
INFO - 2016-08-11 16:05:38 --> Output Class Initialized
INFO - 2016-08-11 16:05:38 --> Security Class Initialized
DEBUG - 2016-08-11 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:05:38 --> Input Class Initialized
INFO - 2016-08-11 16:05:38 --> Language Class Initialized
INFO - 2016-08-11 16:05:38 --> Loader Class Initialized
INFO - 2016-08-11 16:05:38 --> Helper loaded: url_helper
INFO - 2016-08-11 16:05:38 --> Helper loaded: date_helper
INFO - 2016-08-11 16:05:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:05:38 --> Database Driver Class Initialized
INFO - 2016-08-11 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:05:38 --> Email Class Initialized
INFO - 2016-08-11 16:05:38 --> Model Class Initialized
INFO - 2016-08-11 16:05:38 --> Controller Class Initialized
INFO - 2016-08-11 16:05:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:05:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:05:39 --> Final output sent to browser
DEBUG - 2016-08-11 16:05:39 --> Total execution time: 0.4263
INFO - 2016-08-11 16:06:18 --> Config Class Initialized
INFO - 2016-08-11 16:06:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:06:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:06:18 --> Utf8 Class Initialized
INFO - 2016-08-11 16:06:18 --> URI Class Initialized
INFO - 2016-08-11 16:06:18 --> Router Class Initialized
INFO - 2016-08-11 16:06:18 --> Output Class Initialized
INFO - 2016-08-11 16:06:18 --> Security Class Initialized
DEBUG - 2016-08-11 16:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:06:18 --> Input Class Initialized
INFO - 2016-08-11 16:06:18 --> Language Class Initialized
INFO - 2016-08-11 16:06:18 --> Loader Class Initialized
INFO - 2016-08-11 16:06:18 --> Helper loaded: url_helper
INFO - 2016-08-11 16:06:18 --> Helper loaded: date_helper
INFO - 2016-08-11 16:06:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:06:18 --> Database Driver Class Initialized
INFO - 2016-08-11 16:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:06:18 --> Email Class Initialized
INFO - 2016-08-11 16:06:18 --> Model Class Initialized
INFO - 2016-08-11 16:06:18 --> Controller Class Initialized
DEBUG - 2016-08-11 16:06:18 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:06:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:06:18 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:06:18 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:18 --> Model Class Initialized
INFO - 2016-08-11 16:06:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:06:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:06:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:06:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:06:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:06:18 --> Final output sent to browser
DEBUG - 2016-08-11 16:06:18 --> Total execution time: 0.5989
INFO - 2016-08-11 16:06:44 --> Config Class Initialized
INFO - 2016-08-11 16:06:44 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:06:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:06:45 --> Utf8 Class Initialized
INFO - 2016-08-11 16:06:45 --> URI Class Initialized
INFO - 2016-08-11 16:06:45 --> Router Class Initialized
INFO - 2016-08-11 16:06:45 --> Output Class Initialized
INFO - 2016-08-11 16:06:45 --> Security Class Initialized
DEBUG - 2016-08-11 16:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:06:45 --> Input Class Initialized
INFO - 2016-08-11 16:06:45 --> Language Class Initialized
INFO - 2016-08-11 16:06:45 --> Loader Class Initialized
INFO - 2016-08-11 16:06:45 --> Helper loaded: url_helper
INFO - 2016-08-11 16:06:45 --> Helper loaded: date_helper
INFO - 2016-08-11 16:06:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:06:45 --> Database Driver Class Initialized
INFO - 2016-08-11 16:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:06:45 --> Email Class Initialized
INFO - 2016-08-11 16:06:45 --> Model Class Initialized
INFO - 2016-08-11 16:06:45 --> Controller Class Initialized
DEBUG - 2016-08-11 16:06:45 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:06:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:06:45 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:06:45 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:45 --> Model Class Initialized
INFO - 2016-08-11 16:06:45 --> Upload Class Initialized
INFO - 2016-08-11 16:06:45 --> Config Class Initialized
INFO - 2016-08-11 16:06:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:06:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:06:45 --> Utf8 Class Initialized
INFO - 2016-08-11 16:06:45 --> URI Class Initialized
INFO - 2016-08-11 16:06:45 --> Router Class Initialized
INFO - 2016-08-11 16:06:45 --> Output Class Initialized
INFO - 2016-08-11 16:06:45 --> Security Class Initialized
DEBUG - 2016-08-11 16:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:06:45 --> Input Class Initialized
INFO - 2016-08-11 16:06:45 --> Language Class Initialized
INFO - 2016-08-11 16:06:45 --> Loader Class Initialized
INFO - 2016-08-11 16:06:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:06:46 --> Helper loaded: date_helper
INFO - 2016-08-11 16:06:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:06:46 --> Database Driver Class Initialized
INFO - 2016-08-11 16:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:06:46 --> Email Class Initialized
INFO - 2016-08-11 16:06:46 --> Model Class Initialized
INFO - 2016-08-11 16:06:46 --> Controller Class Initialized
DEBUG - 2016-08-11 16:06:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:06:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:06:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:06:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:46 --> Model Class Initialized
INFO - 2016-08-11 16:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:06:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:06:46 --> Final output sent to browser
DEBUG - 2016-08-11 16:06:46 --> Total execution time: 1.0032
INFO - 2016-08-11 16:06:49 --> Config Class Initialized
INFO - 2016-08-11 16:06:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:06:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:06:49 --> Utf8 Class Initialized
INFO - 2016-08-11 16:06:49 --> URI Class Initialized
INFO - 2016-08-11 16:06:49 --> Router Class Initialized
INFO - 2016-08-11 16:06:49 --> Output Class Initialized
INFO - 2016-08-11 16:06:49 --> Security Class Initialized
DEBUG - 2016-08-11 16:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:06:49 --> Input Class Initialized
INFO - 2016-08-11 16:06:49 --> Language Class Initialized
INFO - 2016-08-11 16:06:49 --> Loader Class Initialized
INFO - 2016-08-11 16:06:49 --> Helper loaded: url_helper
INFO - 2016-08-11 16:06:49 --> Helper loaded: date_helper
INFO - 2016-08-11 16:06:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:06:49 --> Database Driver Class Initialized
INFO - 2016-08-11 16:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:06:49 --> Email Class Initialized
INFO - 2016-08-11 16:06:49 --> Model Class Initialized
INFO - 2016-08-11 16:06:49 --> Controller Class Initialized
DEBUG - 2016-08-11 16:06:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:06:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:06:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:06:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:06:49 --> Model Class Initialized
INFO - 2016-08-11 16:06:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:06:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:06:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:06:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:06:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:06:49 --> Final output sent to browser
DEBUG - 2016-08-11 16:06:49 --> Total execution time: 0.5311
INFO - 2016-08-11 16:07:09 --> Config Class Initialized
INFO - 2016-08-11 16:07:09 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:07:09 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:07:09 --> Utf8 Class Initialized
INFO - 2016-08-11 16:07:09 --> URI Class Initialized
INFO - 2016-08-11 16:07:09 --> Router Class Initialized
INFO - 2016-08-11 16:07:09 --> Output Class Initialized
INFO - 2016-08-11 16:07:09 --> Security Class Initialized
DEBUG - 2016-08-11 16:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:07:09 --> Input Class Initialized
INFO - 2016-08-11 16:07:09 --> Language Class Initialized
INFO - 2016-08-11 16:07:09 --> Loader Class Initialized
INFO - 2016-08-11 16:07:09 --> Helper loaded: url_helper
INFO - 2016-08-11 16:07:09 --> Helper loaded: date_helper
INFO - 2016-08-11 16:07:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:07:09 --> Database Driver Class Initialized
INFO - 2016-08-11 16:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:07:09 --> Email Class Initialized
INFO - 2016-08-11 16:07:09 --> Model Class Initialized
INFO - 2016-08-11 16:07:09 --> Controller Class Initialized
DEBUG - 2016-08-11 16:07:09 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:07:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:07:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:07:09 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:07:09 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:07:09 --> Model Class Initialized
INFO - 2016-08-11 16:07:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:07:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:07:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:07:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:07:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:07:09 --> Final output sent to browser
DEBUG - 2016-08-11 16:07:09 --> Total execution time: 0.5436
INFO - 2016-08-11 16:07:11 --> Config Class Initialized
INFO - 2016-08-11 16:07:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:07:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:07:11 --> Utf8 Class Initialized
INFO - 2016-08-11 16:07:11 --> URI Class Initialized
INFO - 2016-08-11 16:07:11 --> Router Class Initialized
INFO - 2016-08-11 16:07:11 --> Output Class Initialized
INFO - 2016-08-11 16:07:11 --> Security Class Initialized
DEBUG - 2016-08-11 16:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:07:11 --> Input Class Initialized
INFO - 2016-08-11 16:07:11 --> Language Class Initialized
INFO - 2016-08-11 16:07:11 --> Loader Class Initialized
INFO - 2016-08-11 16:07:11 --> Helper loaded: url_helper
INFO - 2016-08-11 16:07:11 --> Helper loaded: date_helper
INFO - 2016-08-11 16:07:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:07:11 --> Database Driver Class Initialized
INFO - 2016-08-11 16:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:07:11 --> Email Class Initialized
INFO - 2016-08-11 16:07:11 --> Model Class Initialized
INFO - 2016-08-11 16:07:11 --> Controller Class Initialized
INFO - 2016-08-11 16:07:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:07:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:07:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:07:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:07:11 --> Final output sent to browser
DEBUG - 2016-08-11 16:07:12 --> Total execution time: 0.4280
INFO - 2016-08-11 16:09:12 --> Config Class Initialized
INFO - 2016-08-11 16:09:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:09:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:09:12 --> Utf8 Class Initialized
INFO - 2016-08-11 16:09:12 --> URI Class Initialized
INFO - 2016-08-11 16:09:12 --> Router Class Initialized
INFO - 2016-08-11 16:09:12 --> Output Class Initialized
INFO - 2016-08-11 16:09:12 --> Security Class Initialized
DEBUG - 2016-08-11 16:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:09:12 --> Input Class Initialized
INFO - 2016-08-11 16:09:12 --> Language Class Initialized
INFO - 2016-08-11 16:09:12 --> Loader Class Initialized
INFO - 2016-08-11 16:09:12 --> Helper loaded: url_helper
INFO - 2016-08-11 16:09:12 --> Helper loaded: date_helper
INFO - 2016-08-11 16:09:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:09:12 --> Database Driver Class Initialized
INFO - 2016-08-11 16:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:09:12 --> Email Class Initialized
INFO - 2016-08-11 16:09:13 --> Model Class Initialized
INFO - 2016-08-11 16:09:13 --> Controller Class Initialized
DEBUG - 2016-08-11 16:09:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:09:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:09:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:09:13 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:09:13 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:09:13 --> Model Class Initialized
INFO - 2016-08-11 16:09:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:09:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:09:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:09:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:09:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:09:13 --> Final output sent to browser
DEBUG - 2016-08-11 16:09:13 --> Total execution time: 0.5468
INFO - 2016-08-11 16:10:39 --> Config Class Initialized
INFO - 2016-08-11 16:10:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:10:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:10:39 --> Utf8 Class Initialized
INFO - 2016-08-11 16:10:39 --> URI Class Initialized
INFO - 2016-08-11 16:10:39 --> Router Class Initialized
INFO - 2016-08-11 16:10:39 --> Output Class Initialized
INFO - 2016-08-11 16:10:39 --> Security Class Initialized
DEBUG - 2016-08-11 16:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:10:39 --> Input Class Initialized
INFO - 2016-08-11 16:10:39 --> Language Class Initialized
INFO - 2016-08-11 16:10:39 --> Loader Class Initialized
INFO - 2016-08-11 16:10:39 --> Helper loaded: url_helper
INFO - 2016-08-11 16:10:39 --> Helper loaded: date_helper
INFO - 2016-08-11 16:10:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:10:39 --> Database Driver Class Initialized
INFO - 2016-08-11 16:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:10:39 --> Email Class Initialized
INFO - 2016-08-11 16:10:39 --> Model Class Initialized
INFO - 2016-08-11 16:10:39 --> Controller Class Initialized
DEBUG - 2016-08-11 16:10:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:10:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:10:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:10:39 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:10:39 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:10:39 --> Model Class Initialized
INFO - 2016-08-11 16:10:39 --> Upload Class Initialized
INFO - 2016-08-11 16:10:39 --> Config Class Initialized
INFO - 2016-08-11 16:10:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:10:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:10:39 --> Utf8 Class Initialized
INFO - 2016-08-11 16:10:39 --> URI Class Initialized
INFO - 2016-08-11 16:10:39 --> Router Class Initialized
INFO - 2016-08-11 16:10:39 --> Output Class Initialized
INFO - 2016-08-11 16:10:39 --> Security Class Initialized
DEBUG - 2016-08-11 16:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:10:39 --> Input Class Initialized
INFO - 2016-08-11 16:10:39 --> Language Class Initialized
INFO - 2016-08-11 16:10:39 --> Loader Class Initialized
INFO - 2016-08-11 16:10:39 --> Helper loaded: url_helper
INFO - 2016-08-11 16:10:39 --> Helper loaded: date_helper
INFO - 2016-08-11 16:10:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:10:40 --> Database Driver Class Initialized
INFO - 2016-08-11 16:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:10:40 --> Email Class Initialized
INFO - 2016-08-11 16:10:40 --> Model Class Initialized
INFO - 2016-08-11 16:10:40 --> Controller Class Initialized
DEBUG - 2016-08-11 16:10:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:10:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:10:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:10:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:10:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:10:40 --> Model Class Initialized
INFO - 2016-08-11 16:10:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:10:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:10:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:10:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:10:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:10:40 --> Final output sent to browser
DEBUG - 2016-08-11 16:10:40 --> Total execution time: 0.6521
INFO - 2016-08-11 16:10:42 --> Config Class Initialized
INFO - 2016-08-11 16:10:42 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:10:42 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:10:42 --> Utf8 Class Initialized
INFO - 2016-08-11 16:10:42 --> URI Class Initialized
INFO - 2016-08-11 16:10:42 --> Router Class Initialized
INFO - 2016-08-11 16:10:42 --> Output Class Initialized
INFO - 2016-08-11 16:10:42 --> Security Class Initialized
DEBUG - 2016-08-11 16:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:10:42 --> Input Class Initialized
INFO - 2016-08-11 16:10:42 --> Language Class Initialized
INFO - 2016-08-11 16:10:42 --> Loader Class Initialized
INFO - 2016-08-11 16:10:42 --> Helper loaded: url_helper
INFO - 2016-08-11 16:10:42 --> Helper loaded: date_helper
INFO - 2016-08-11 16:10:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:10:42 --> Database Driver Class Initialized
INFO - 2016-08-11 16:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:10:42 --> Email Class Initialized
INFO - 2016-08-11 16:10:42 --> Model Class Initialized
INFO - 2016-08-11 16:10:42 --> Controller Class Initialized
INFO - 2016-08-11 16:10:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:10:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:10:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:10:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:10:42 --> Final output sent to browser
DEBUG - 2016-08-11 16:10:42 --> Total execution time: 0.4245
INFO - 2016-08-11 16:11:06 --> Config Class Initialized
INFO - 2016-08-11 16:11:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:06 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:06 --> URI Class Initialized
INFO - 2016-08-11 16:11:06 --> Router Class Initialized
INFO - 2016-08-11 16:11:06 --> Output Class Initialized
INFO - 2016-08-11 16:11:06 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:06 --> Input Class Initialized
INFO - 2016-08-11 16:11:06 --> Language Class Initialized
INFO - 2016-08-11 16:11:06 --> Loader Class Initialized
INFO - 2016-08-11 16:11:06 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:06 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:06 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:06 --> Email Class Initialized
INFO - 2016-08-11 16:11:06 --> Model Class Initialized
INFO - 2016-08-11 16:11:06 --> Controller Class Initialized
DEBUG - 2016-08-11 16:11:06 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:11:06 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:11:06 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:11:06 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:06 --> Model Class Initialized
INFO - 2016-08-11 16:11:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:11:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:11:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:11:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:11:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:11:06 --> Final output sent to browser
DEBUG - 2016-08-11 16:11:06 --> Total execution time: 0.5458
INFO - 2016-08-11 16:11:33 --> Config Class Initialized
INFO - 2016-08-11 16:11:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:33 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:33 --> URI Class Initialized
INFO - 2016-08-11 16:11:33 --> Router Class Initialized
INFO - 2016-08-11 16:11:34 --> Output Class Initialized
INFO - 2016-08-11 16:11:34 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:34 --> Input Class Initialized
INFO - 2016-08-11 16:11:34 --> Language Class Initialized
INFO - 2016-08-11 16:11:34 --> Loader Class Initialized
INFO - 2016-08-11 16:11:34 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:34 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:34 --> Email Class Initialized
INFO - 2016-08-11 16:11:34 --> Model Class Initialized
INFO - 2016-08-11 16:11:34 --> Controller Class Initialized
DEBUG - 2016-08-11 16:11:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:11:34 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:34 --> Model Class Initialized
INFO - 2016-08-11 16:11:34 --> Upload Class Initialized
INFO - 2016-08-11 16:11:34 --> Config Class Initialized
INFO - 2016-08-11 16:11:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:34 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:34 --> URI Class Initialized
INFO - 2016-08-11 16:11:34 --> Router Class Initialized
INFO - 2016-08-11 16:11:34 --> Output Class Initialized
INFO - 2016-08-11 16:11:34 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:34 --> Input Class Initialized
INFO - 2016-08-11 16:11:34 --> Language Class Initialized
INFO - 2016-08-11 16:11:34 --> Loader Class Initialized
INFO - 2016-08-11 16:11:34 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:34 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:34 --> Email Class Initialized
INFO - 2016-08-11 16:11:34 --> Model Class Initialized
INFO - 2016-08-11 16:11:34 --> Controller Class Initialized
DEBUG - 2016-08-11 16:11:34 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:11:34 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:11:34 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:34 --> Model Class Initialized
INFO - 2016-08-11 16:11:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:11:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:11:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:11:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:11:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:11:35 --> Final output sent to browser
DEBUG - 2016-08-11 16:11:35 --> Total execution time: 0.5601
INFO - 2016-08-11 16:11:36 --> Config Class Initialized
INFO - 2016-08-11 16:11:36 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:36 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:36 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:36 --> URI Class Initialized
INFO - 2016-08-11 16:11:36 --> Router Class Initialized
INFO - 2016-08-11 16:11:36 --> Output Class Initialized
INFO - 2016-08-11 16:11:36 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:36 --> Input Class Initialized
INFO - 2016-08-11 16:11:36 --> Language Class Initialized
INFO - 2016-08-11 16:11:36 --> Loader Class Initialized
INFO - 2016-08-11 16:11:36 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:36 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:36 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:36 --> Email Class Initialized
INFO - 2016-08-11 16:11:36 --> Model Class Initialized
INFO - 2016-08-11 16:11:36 --> Controller Class Initialized
INFO - 2016-08-11 16:11:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:11:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:11:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:11:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:11:36 --> Final output sent to browser
DEBUG - 2016-08-11 16:11:37 --> Total execution time: 0.4187
INFO - 2016-08-11 16:11:45 --> Config Class Initialized
INFO - 2016-08-11 16:11:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:45 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:45 --> URI Class Initialized
INFO - 2016-08-11 16:11:45 --> Router Class Initialized
INFO - 2016-08-11 16:11:45 --> Output Class Initialized
INFO - 2016-08-11 16:11:45 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:45 --> Input Class Initialized
INFO - 2016-08-11 16:11:45 --> Language Class Initialized
INFO - 2016-08-11 16:11:45 --> Loader Class Initialized
INFO - 2016-08-11 16:11:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:46 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:46 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:46 --> Email Class Initialized
INFO - 2016-08-11 16:11:46 --> Model Class Initialized
INFO - 2016-08-11 16:11:46 --> Controller Class Initialized
DEBUG - 2016-08-11 16:11:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:11:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:11:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:11:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:11:46 --> Model Class Initialized
INFO - 2016-08-11 16:11:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:11:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 16:11:46 --> Severity: Notice --> Undefined variable: konten D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
ERROR - 2016-08-11 16:11:46 --> Severity: Error --> Call to a member function row() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\page.php 4
INFO - 2016-08-11 16:11:49 --> Config Class Initialized
INFO - 2016-08-11 16:11:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:11:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:11:49 --> Utf8 Class Initialized
INFO - 2016-08-11 16:11:49 --> URI Class Initialized
INFO - 2016-08-11 16:11:49 --> Router Class Initialized
INFO - 2016-08-11 16:11:49 --> Output Class Initialized
INFO - 2016-08-11 16:11:49 --> Security Class Initialized
DEBUG - 2016-08-11 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:11:49 --> Input Class Initialized
INFO - 2016-08-11 16:11:49 --> Language Class Initialized
INFO - 2016-08-11 16:11:49 --> Loader Class Initialized
INFO - 2016-08-11 16:11:49 --> Helper loaded: url_helper
INFO - 2016-08-11 16:11:49 --> Helper loaded: date_helper
INFO - 2016-08-11 16:11:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:11:49 --> Database Driver Class Initialized
INFO - 2016-08-11 16:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:11:49 --> Email Class Initialized
INFO - 2016-08-11 16:11:49 --> Model Class Initialized
INFO - 2016-08-11 16:11:49 --> Controller Class Initialized
INFO - 2016-08-11 16:11:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:11:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:11:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:11:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:11:49 --> Final output sent to browser
DEBUG - 2016-08-11 16:11:49 --> Total execution time: 0.4294
INFO - 2016-08-11 16:18:22 --> Config Class Initialized
INFO - 2016-08-11 16:18:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:18:22 --> Utf8 Class Initialized
INFO - 2016-08-11 16:18:22 --> URI Class Initialized
INFO - 2016-08-11 16:18:22 --> Router Class Initialized
INFO - 2016-08-11 16:18:22 --> Output Class Initialized
INFO - 2016-08-11 16:18:22 --> Security Class Initialized
DEBUG - 2016-08-11 16:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:18:22 --> Input Class Initialized
INFO - 2016-08-11 16:18:22 --> Language Class Initialized
INFO - 2016-08-11 16:18:22 --> Loader Class Initialized
INFO - 2016-08-11 16:18:22 --> Helper loaded: url_helper
INFO - 2016-08-11 16:18:22 --> Helper loaded: date_helper
INFO - 2016-08-11 16:18:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:18:22 --> Database Driver Class Initialized
INFO - 2016-08-11 16:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:18:22 --> Email Class Initialized
INFO - 2016-08-11 16:18:22 --> Config Class Initialized
INFO - 2016-08-11 16:18:22 --> Model Class Initialized
INFO - 2016-08-11 16:18:22 --> Hooks Class Initialized
INFO - 2016-08-11 16:18:22 --> Controller Class Initialized
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
DEBUG - 2016-08-11 16:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:18:22 --> Utf8 Class Initialized
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:18:22 --> URI Class Initialized
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:18:22 --> Router Class Initialized
INFO - 2016-08-11 16:18:22 --> Final output sent to browser
INFO - 2016-08-11 16:18:22 --> Output Class Initialized
DEBUG - 2016-08-11 16:18:22 --> Total execution time: 0.4770
INFO - 2016-08-11 16:18:22 --> Security Class Initialized
DEBUG - 2016-08-11 16:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:18:22 --> Input Class Initialized
INFO - 2016-08-11 16:18:22 --> Language Class Initialized
INFO - 2016-08-11 16:18:22 --> Loader Class Initialized
INFO - 2016-08-11 16:18:22 --> Helper loaded: url_helper
INFO - 2016-08-11 16:18:22 --> Helper loaded: date_helper
INFO - 2016-08-11 16:18:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:18:22 --> Database Driver Class Initialized
INFO - 2016-08-11 16:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:18:22 --> Email Class Initialized
INFO - 2016-08-11 16:18:22 --> Model Class Initialized
INFO - 2016-08-11 16:18:22 --> Controller Class Initialized
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:18:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:18:22 --> Final output sent to browser
DEBUG - 2016-08-11 16:18:22 --> Total execution time: 0.4224
INFO - 2016-08-11 16:19:55 --> Config Class Initialized
INFO - 2016-08-11 16:19:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:19:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:19:55 --> Utf8 Class Initialized
INFO - 2016-08-11 16:19:55 --> URI Class Initialized
INFO - 2016-08-11 16:19:55 --> Router Class Initialized
INFO - 2016-08-11 16:19:55 --> Output Class Initialized
INFO - 2016-08-11 16:19:55 --> Security Class Initialized
DEBUG - 2016-08-11 16:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:19:55 --> Input Class Initialized
INFO - 2016-08-11 16:19:55 --> Language Class Initialized
INFO - 2016-08-11 16:19:55 --> Loader Class Initialized
INFO - 2016-08-11 16:19:55 --> Helper loaded: url_helper
INFO - 2016-08-11 16:19:55 --> Helper loaded: date_helper
INFO - 2016-08-11 16:19:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:19:55 --> Database Driver Class Initialized
INFO - 2016-08-11 16:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:19:55 --> Email Class Initialized
INFO - 2016-08-11 16:19:55 --> Model Class Initialized
INFO - 2016-08-11 16:19:55 --> Controller Class Initialized
DEBUG - 2016-08-11 16:19:55 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:19:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:19:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:19:55 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:19:55 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:19:55 --> Model Class Initialized
INFO - 2016-08-11 16:19:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:19:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:19:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:19:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:19:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:19:55 --> Final output sent to browser
DEBUG - 2016-08-11 16:19:55 --> Total execution time: 0.5545
INFO - 2016-08-11 16:21:20 --> Config Class Initialized
INFO - 2016-08-11 16:21:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:21:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:21:20 --> Utf8 Class Initialized
INFO - 2016-08-11 16:21:20 --> URI Class Initialized
INFO - 2016-08-11 16:21:21 --> Router Class Initialized
INFO - 2016-08-11 16:21:21 --> Output Class Initialized
INFO - 2016-08-11 16:21:21 --> Security Class Initialized
DEBUG - 2016-08-11 16:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:21:21 --> Input Class Initialized
INFO - 2016-08-11 16:21:21 --> Language Class Initialized
INFO - 2016-08-11 16:21:21 --> Loader Class Initialized
INFO - 2016-08-11 16:21:21 --> Helper loaded: url_helper
INFO - 2016-08-11 16:21:21 --> Helper loaded: date_helper
INFO - 2016-08-11 16:21:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:21:21 --> Database Driver Class Initialized
INFO - 2016-08-11 16:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:21:21 --> Email Class Initialized
INFO - 2016-08-11 16:21:21 --> Model Class Initialized
INFO - 2016-08-11 16:21:21 --> Controller Class Initialized
INFO - 2016-08-11 16:21:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:21:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:21:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:21:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:21:21 --> Final output sent to browser
DEBUG - 2016-08-11 16:21:21 --> Total execution time: 0.4749
INFO - 2016-08-11 16:21:56 --> Config Class Initialized
INFO - 2016-08-11 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:21:56 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:21:56 --> Utf8 Class Initialized
INFO - 2016-08-11 16:21:56 --> URI Class Initialized
INFO - 2016-08-11 16:21:56 --> Router Class Initialized
INFO - 2016-08-11 16:21:56 --> Output Class Initialized
INFO - 2016-08-11 16:21:56 --> Security Class Initialized
DEBUG - 2016-08-11 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:21:56 --> Input Class Initialized
INFO - 2016-08-11 16:21:56 --> Language Class Initialized
INFO - 2016-08-11 16:21:56 --> Loader Class Initialized
INFO - 2016-08-11 16:21:56 --> Helper loaded: url_helper
INFO - 2016-08-11 16:21:56 --> Helper loaded: date_helper
INFO - 2016-08-11 16:21:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:21:56 --> Database Driver Class Initialized
INFO - 2016-08-11 16:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:21:56 --> Email Class Initialized
INFO - 2016-08-11 16:21:56 --> Model Class Initialized
INFO - 2016-08-11 16:21:56 --> Controller Class Initialized
DEBUG - 2016-08-11 16:21:56 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:21:56 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:21:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:21:56 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:21:56 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:21:56 --> Model Class Initialized
INFO - 2016-08-11 16:21:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:21:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:21:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:21:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:21:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:21:57 --> Final output sent to browser
DEBUG - 2016-08-11 16:21:57 --> Total execution time: 0.5604
INFO - 2016-08-11 16:21:59 --> Config Class Initialized
INFO - 2016-08-11 16:21:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:21:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:21:59 --> Utf8 Class Initialized
INFO - 2016-08-11 16:21:59 --> URI Class Initialized
INFO - 2016-08-11 16:21:59 --> Router Class Initialized
INFO - 2016-08-11 16:21:59 --> Output Class Initialized
INFO - 2016-08-11 16:21:59 --> Security Class Initialized
DEBUG - 2016-08-11 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:21:59 --> Input Class Initialized
INFO - 2016-08-11 16:21:59 --> Language Class Initialized
INFO - 2016-08-11 16:21:59 --> Loader Class Initialized
INFO - 2016-08-11 16:22:00 --> Helper loaded: url_helper
INFO - 2016-08-11 16:22:00 --> Helper loaded: date_helper
INFO - 2016-08-11 16:22:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:22:00 --> Database Driver Class Initialized
INFO - 2016-08-11 16:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:22:00 --> Email Class Initialized
INFO - 2016-08-11 16:22:00 --> Model Class Initialized
INFO - 2016-08-11 16:22:00 --> Controller Class Initialized
DEBUG - 2016-08-11 16:22:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:22:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:22:00 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:22:00 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:00 --> Model Class Initialized
INFO - 2016-08-11 16:22:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:22:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:22:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:22:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/update_page.php
INFO - 2016-08-11 16:22:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:22:00 --> Final output sent to browser
DEBUG - 2016-08-11 16:22:00 --> Total execution time: 0.5794
INFO - 2016-08-11 16:22:11 --> Config Class Initialized
INFO - 2016-08-11 16:22:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:22:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:22:11 --> Utf8 Class Initialized
INFO - 2016-08-11 16:22:11 --> URI Class Initialized
INFO - 2016-08-11 16:22:11 --> Router Class Initialized
INFO - 2016-08-11 16:22:11 --> Output Class Initialized
INFO - 2016-08-11 16:22:11 --> Security Class Initialized
DEBUG - 2016-08-11 16:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:22:11 --> Input Class Initialized
INFO - 2016-08-11 16:22:11 --> Language Class Initialized
INFO - 2016-08-11 16:22:11 --> Loader Class Initialized
INFO - 2016-08-11 16:22:11 --> Helper loaded: url_helper
INFO - 2016-08-11 16:22:11 --> Helper loaded: date_helper
INFO - 2016-08-11 16:22:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:22:11 --> Database Driver Class Initialized
INFO - 2016-08-11 16:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:22:11 --> Email Class Initialized
INFO - 2016-08-11 16:22:11 --> Model Class Initialized
INFO - 2016-08-11 16:22:11 --> Controller Class Initialized
DEBUG - 2016-08-11 16:22:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:22:11 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:22:11 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:11 --> Model Class Initialized
INFO - 2016-08-11 16:22:11 --> Upload Class Initialized
INFO - 2016-08-11 16:22:12 --> Config Class Initialized
INFO - 2016-08-11 16:22:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:22:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:22:12 --> Utf8 Class Initialized
INFO - 2016-08-11 16:22:12 --> URI Class Initialized
INFO - 2016-08-11 16:22:12 --> Router Class Initialized
INFO - 2016-08-11 16:22:12 --> Output Class Initialized
INFO - 2016-08-11 16:22:12 --> Security Class Initialized
DEBUG - 2016-08-11 16:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:22:12 --> Input Class Initialized
INFO - 2016-08-11 16:22:12 --> Language Class Initialized
INFO - 2016-08-11 16:22:12 --> Loader Class Initialized
INFO - 2016-08-11 16:22:12 --> Helper loaded: url_helper
INFO - 2016-08-11 16:22:12 --> Helper loaded: date_helper
INFO - 2016-08-11 16:22:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:22:12 --> Database Driver Class Initialized
INFO - 2016-08-11 16:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:22:12 --> Email Class Initialized
INFO - 2016-08-11 16:22:12 --> Model Class Initialized
INFO - 2016-08-11 16:22:12 --> Controller Class Initialized
DEBUG - 2016-08-11 16:22:12 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:22:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:22:12 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:22:12 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:12 --> Model Class Initialized
INFO - 2016-08-11 16:22:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:22:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:22:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:22:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:22:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:22:12 --> Final output sent to browser
DEBUG - 2016-08-11 16:22:12 --> Total execution time: 0.6195
INFO - 2016-08-11 16:22:19 --> Config Class Initialized
INFO - 2016-08-11 16:22:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:22:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:22:19 --> Utf8 Class Initialized
INFO - 2016-08-11 16:22:19 --> URI Class Initialized
DEBUG - 2016-08-11 16:22:19 --> No URI present. Default controller set.
INFO - 2016-08-11 16:22:19 --> Router Class Initialized
INFO - 2016-08-11 16:22:19 --> Output Class Initialized
INFO - 2016-08-11 16:22:19 --> Security Class Initialized
DEBUG - 2016-08-11 16:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:22:19 --> Input Class Initialized
INFO - 2016-08-11 16:22:19 --> Language Class Initialized
INFO - 2016-08-11 16:22:19 --> Loader Class Initialized
INFO - 2016-08-11 16:22:19 --> Helper loaded: url_helper
INFO - 2016-08-11 16:22:19 --> Helper loaded: date_helper
INFO - 2016-08-11 16:22:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:22:19 --> Database Driver Class Initialized
INFO - 2016-08-11 16:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:22:19 --> Email Class Initialized
INFO - 2016-08-11 16:22:19 --> Model Class Initialized
INFO - 2016-08-11 16:22:19 --> Controller Class Initialized
DEBUG - 2016-08-11 16:22:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:22:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:22:19 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:22:19 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:22:19 --> Model Class Initialized
INFO - 2016-08-11 16:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:22:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:22:19 --> Final output sent to browser
DEBUG - 2016-08-11 16:22:19 --> Total execution time: 0.5561
INFO - 2016-08-11 16:26:46 --> Config Class Initialized
INFO - 2016-08-11 16:26:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:26:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:26:46 --> Utf8 Class Initialized
INFO - 2016-08-11 16:26:46 --> URI Class Initialized
DEBUG - 2016-08-11 16:26:46 --> No URI present. Default controller set.
INFO - 2016-08-11 16:26:46 --> Router Class Initialized
INFO - 2016-08-11 16:26:46 --> Output Class Initialized
INFO - 2016-08-11 16:26:46 --> Security Class Initialized
DEBUG - 2016-08-11 16:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:26:46 --> Input Class Initialized
INFO - 2016-08-11 16:26:46 --> Language Class Initialized
INFO - 2016-08-11 16:26:46 --> Loader Class Initialized
INFO - 2016-08-11 16:26:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:26:46 --> Helper loaded: date_helper
INFO - 2016-08-11 16:26:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:26:46 --> Database Driver Class Initialized
INFO - 2016-08-11 16:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:26:46 --> Email Class Initialized
INFO - 2016-08-11 16:26:46 --> Model Class Initialized
INFO - 2016-08-11 16:26:46 --> Controller Class Initialized
DEBUG - 2016-08-11 16:26:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:26:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:26:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:26:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:26:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:26:46 --> Model Class Initialized
INFO - 2016-08-11 16:26:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:26:46 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:26:46 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:28:28 --> Config Class Initialized
INFO - 2016-08-11 16:28:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:28:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:28:28 --> Utf8 Class Initialized
INFO - 2016-08-11 16:28:28 --> URI Class Initialized
DEBUG - 2016-08-11 16:28:29 --> No URI present. Default controller set.
INFO - 2016-08-11 16:28:29 --> Router Class Initialized
INFO - 2016-08-11 16:28:29 --> Output Class Initialized
INFO - 2016-08-11 16:28:29 --> Security Class Initialized
DEBUG - 2016-08-11 16:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:28:29 --> Input Class Initialized
INFO - 2016-08-11 16:28:29 --> Language Class Initialized
INFO - 2016-08-11 16:28:29 --> Loader Class Initialized
INFO - 2016-08-11 16:28:29 --> Helper loaded: url_helper
INFO - 2016-08-11 16:28:29 --> Helper loaded: date_helper
INFO - 2016-08-11 16:28:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:28:29 --> Database Driver Class Initialized
INFO - 2016-08-11 16:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:28:29 --> Email Class Initialized
INFO - 2016-08-11 16:28:29 --> Model Class Initialized
INFO - 2016-08-11 16:28:29 --> Controller Class Initialized
DEBUG - 2016-08-11 16:28:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:28:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:28:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:28:29 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:28:29 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:28:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:28:29 --> Model Class Initialized
ERROR - 2016-08-11 16:28:29 --> Severity: Notice --> Undefined variable: da D:\xampp\htdocs\aqiqahsehati\application\controllers\Home.php 26
INFO - 2016-08-11 16:28:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:28:29 --> Severity: Notice --> Undefined property: CI_Loader::$menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:28:29 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:28:58 --> Config Class Initialized
INFO - 2016-08-11 16:28:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:28:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:28:58 --> Utf8 Class Initialized
INFO - 2016-08-11 16:28:58 --> URI Class Initialized
DEBUG - 2016-08-11 16:28:59 --> No URI present. Default controller set.
INFO - 2016-08-11 16:28:59 --> Router Class Initialized
INFO - 2016-08-11 16:28:59 --> Output Class Initialized
INFO - 2016-08-11 16:28:59 --> Security Class Initialized
DEBUG - 2016-08-11 16:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:28:59 --> Input Class Initialized
INFO - 2016-08-11 16:28:59 --> Language Class Initialized
INFO - 2016-08-11 16:28:59 --> Loader Class Initialized
INFO - 2016-08-11 16:28:59 --> Helper loaded: url_helper
INFO - 2016-08-11 16:28:59 --> Helper loaded: date_helper
INFO - 2016-08-11 16:28:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:28:59 --> Database Driver Class Initialized
INFO - 2016-08-11 16:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:28:59 --> Email Class Initialized
INFO - 2016-08-11 16:28:59 --> Model Class Initialized
INFO - 2016-08-11 16:28:59 --> Controller Class Initialized
DEBUG - 2016-08-11 16:28:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:28:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:28:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:28:59 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:28:59 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:28:59 --> Model Class Initialized
INFO - 2016-08-11 16:28:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:28:59 --> Severity: Notice --> Undefined property: CI_Loader::$menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:28:59 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:29:12 --> Config Class Initialized
INFO - 2016-08-11 16:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:29:12 --> Utf8 Class Initialized
INFO - 2016-08-11 16:29:12 --> URI Class Initialized
DEBUG - 2016-08-11 16:29:12 --> No URI present. Default controller set.
INFO - 2016-08-11 16:29:12 --> Router Class Initialized
INFO - 2016-08-11 16:29:12 --> Output Class Initialized
INFO - 2016-08-11 16:29:13 --> Security Class Initialized
DEBUG - 2016-08-11 16:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:29:13 --> Input Class Initialized
INFO - 2016-08-11 16:29:13 --> Language Class Initialized
INFO - 2016-08-11 16:29:13 --> Loader Class Initialized
INFO - 2016-08-11 16:29:13 --> Helper loaded: url_helper
INFO - 2016-08-11 16:29:13 --> Helper loaded: date_helper
INFO - 2016-08-11 16:29:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:29:13 --> Database Driver Class Initialized
INFO - 2016-08-11 16:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:29:13 --> Email Class Initialized
INFO - 2016-08-11 16:29:13 --> Model Class Initialized
INFO - 2016-08-11 16:29:13 --> Controller Class Initialized
DEBUG - 2016-08-11 16:29:13 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:29:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:29:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:29:13 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:29:13 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:29:13 --> Model Class Initialized
INFO - 2016-08-11 16:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:29:13 --> Severity: Notice --> Undefined property: CI_Loader::$menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:29:13 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:29:23 --> Config Class Initialized
INFO - 2016-08-11 16:29:23 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:29:23 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:29:23 --> Utf8 Class Initialized
INFO - 2016-08-11 16:29:23 --> URI Class Initialized
DEBUG - 2016-08-11 16:29:23 --> No URI present. Default controller set.
INFO - 2016-08-11 16:29:23 --> Router Class Initialized
INFO - 2016-08-11 16:29:23 --> Output Class Initialized
INFO - 2016-08-11 16:29:23 --> Security Class Initialized
DEBUG - 2016-08-11 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:29:23 --> Input Class Initialized
INFO - 2016-08-11 16:29:23 --> Language Class Initialized
INFO - 2016-08-11 16:29:23 --> Loader Class Initialized
INFO - 2016-08-11 16:29:23 --> Helper loaded: url_helper
INFO - 2016-08-11 16:29:23 --> Helper loaded: date_helper
INFO - 2016-08-11 16:29:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:29:23 --> Database Driver Class Initialized
INFO - 2016-08-11 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:29:23 --> Email Class Initialized
INFO - 2016-08-11 16:29:23 --> Model Class Initialized
INFO - 2016-08-11 16:29:23 --> Controller Class Initialized
DEBUG - 2016-08-11 16:29:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:29:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:29:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:29:23 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:29:23 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:29:23 --> Model Class Initialized
INFO - 2016-08-11 16:29:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:29:23 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:29:23 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:30:26 --> Config Class Initialized
INFO - 2016-08-11 16:30:26 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:30:26 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:30:26 --> Utf8 Class Initialized
INFO - 2016-08-11 16:30:26 --> URI Class Initialized
INFO - 2016-08-11 16:30:26 --> Router Class Initialized
INFO - 2016-08-11 16:30:26 --> Output Class Initialized
INFO - 2016-08-11 16:30:26 --> Security Class Initialized
DEBUG - 2016-08-11 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:30:26 --> Input Class Initialized
INFO - 2016-08-11 16:30:26 --> Language Class Initialized
INFO - 2016-08-11 16:30:26 --> Loader Class Initialized
INFO - 2016-08-11 16:30:26 --> Helper loaded: url_helper
INFO - 2016-08-11 16:30:26 --> Helper loaded: date_helper
INFO - 2016-08-11 16:30:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:30:27 --> Database Driver Class Initialized
INFO - 2016-08-11 16:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:30:27 --> Email Class Initialized
INFO - 2016-08-11 16:30:27 --> Model Class Initialized
INFO - 2016-08-11 16:30:27 --> Controller Class Initialized
DEBUG - 2016-08-11 16:30:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:30:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:30:27 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:30:27 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:27 --> Model Class Initialized
INFO - 2016-08-11 16:30:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:30:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:30:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:30:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:30:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:30:27 --> Final output sent to browser
DEBUG - 2016-08-11 16:30:27 --> Total execution time: 0.6102
INFO - 2016-08-11 16:30:29 --> Config Class Initialized
INFO - 2016-08-11 16:30:29 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:30:29 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:30:29 --> Utf8 Class Initialized
INFO - 2016-08-11 16:30:29 --> URI Class Initialized
DEBUG - 2016-08-11 16:30:29 --> No URI present. Default controller set.
INFO - 2016-08-11 16:30:29 --> Router Class Initialized
INFO - 2016-08-11 16:30:29 --> Output Class Initialized
INFO - 2016-08-11 16:30:29 --> Security Class Initialized
DEBUG - 2016-08-11 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:30:29 --> Input Class Initialized
INFO - 2016-08-11 16:30:29 --> Language Class Initialized
INFO - 2016-08-11 16:30:29 --> Loader Class Initialized
INFO - 2016-08-11 16:30:29 --> Helper loaded: url_helper
INFO - 2016-08-11 16:30:29 --> Helper loaded: date_helper
INFO - 2016-08-11 16:30:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:30:29 --> Database Driver Class Initialized
INFO - 2016-08-11 16:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:30:29 --> Email Class Initialized
INFO - 2016-08-11 16:30:29 --> Model Class Initialized
INFO - 2016-08-11 16:30:29 --> Controller Class Initialized
DEBUG - 2016-08-11 16:30:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:30:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:30:29 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:30:29 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:29 --> Model Class Initialized
INFO - 2016-08-11 16:30:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:30:29 --> Severity: Notice --> Use of undefined constant judul - assumed 'judul' D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 42
ERROR - 2016-08-11 16:30:29 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 42
INFO - 2016-08-11 16:30:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:30:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:30:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:30:29 --> Final output sent to browser
DEBUG - 2016-08-11 16:30:29 --> Total execution time: 0.6395
INFO - 2016-08-11 16:30:48 --> Config Class Initialized
INFO - 2016-08-11 16:30:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:30:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:30:48 --> Utf8 Class Initialized
INFO - 2016-08-11 16:30:48 --> URI Class Initialized
DEBUG - 2016-08-11 16:30:48 --> No URI present. Default controller set.
INFO - 2016-08-11 16:30:48 --> Router Class Initialized
INFO - 2016-08-11 16:30:48 --> Output Class Initialized
INFO - 2016-08-11 16:30:48 --> Security Class Initialized
DEBUG - 2016-08-11 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:30:48 --> Input Class Initialized
INFO - 2016-08-11 16:30:48 --> Language Class Initialized
INFO - 2016-08-11 16:30:48 --> Loader Class Initialized
INFO - 2016-08-11 16:30:48 --> Helper loaded: url_helper
INFO - 2016-08-11 16:30:48 --> Helper loaded: date_helper
INFO - 2016-08-11 16:30:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:30:48 --> Database Driver Class Initialized
INFO - 2016-08-11 16:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:30:48 --> Email Class Initialized
INFO - 2016-08-11 16:30:48 --> Model Class Initialized
INFO - 2016-08-11 16:30:48 --> Controller Class Initialized
DEBUG - 2016-08-11 16:30:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:30:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:30:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:30:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:30:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:30:49 --> Model Class Initialized
INFO - 2016-08-11 16:30:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:30:49 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$judul D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 42
INFO - 2016-08-11 16:30:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:30:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:30:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:30:49 --> Final output sent to browser
DEBUG - 2016-08-11 16:30:49 --> Total execution time: 0.7013
INFO - 2016-08-11 16:31:19 --> Config Class Initialized
INFO - 2016-08-11 16:31:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:31:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:31:19 --> Utf8 Class Initialized
INFO - 2016-08-11 16:31:20 --> URI Class Initialized
DEBUG - 2016-08-11 16:31:20 --> No URI present. Default controller set.
INFO - 2016-08-11 16:31:20 --> Router Class Initialized
INFO - 2016-08-11 16:31:20 --> Output Class Initialized
INFO - 2016-08-11 16:31:20 --> Security Class Initialized
DEBUG - 2016-08-11 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:31:20 --> Input Class Initialized
INFO - 2016-08-11 16:31:20 --> Language Class Initialized
INFO - 2016-08-11 16:31:20 --> Loader Class Initialized
INFO - 2016-08-11 16:31:20 --> Helper loaded: url_helper
INFO - 2016-08-11 16:31:20 --> Helper loaded: date_helper
INFO - 2016-08-11 16:31:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:31:20 --> Database Driver Class Initialized
INFO - 2016-08-11 16:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:31:20 --> Email Class Initialized
INFO - 2016-08-11 16:31:20 --> Model Class Initialized
INFO - 2016-08-11 16:31:20 --> Controller Class Initialized
DEBUG - 2016-08-11 16:31:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:31:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:31:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:31:20 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:31:20 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:31:20 --> Model Class Initialized
INFO - 2016-08-11 16:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:31:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:31:20 --> Final output sent to browser
DEBUG - 2016-08-11 16:31:20 --> Total execution time: 0.6000
INFO - 2016-08-11 16:31:52 --> Config Class Initialized
INFO - 2016-08-11 16:31:53 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:31:53 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:31:53 --> Utf8 Class Initialized
INFO - 2016-08-11 16:31:53 --> URI Class Initialized
DEBUG - 2016-08-11 16:31:53 --> No URI present. Default controller set.
INFO - 2016-08-11 16:31:53 --> Router Class Initialized
INFO - 2016-08-11 16:31:53 --> Output Class Initialized
INFO - 2016-08-11 16:31:53 --> Security Class Initialized
DEBUG - 2016-08-11 16:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:31:53 --> Input Class Initialized
INFO - 2016-08-11 16:31:53 --> Language Class Initialized
INFO - 2016-08-11 16:31:53 --> Loader Class Initialized
INFO - 2016-08-11 16:31:53 --> Helper loaded: url_helper
INFO - 2016-08-11 16:31:53 --> Helper loaded: date_helper
INFO - 2016-08-11 16:31:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:31:53 --> Database Driver Class Initialized
INFO - 2016-08-11 16:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:31:53 --> Email Class Initialized
INFO - 2016-08-11 16:31:53 --> Model Class Initialized
INFO - 2016-08-11 16:31:53 --> Controller Class Initialized
DEBUG - 2016-08-11 16:31:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:31:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:31:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:31:53 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:31:53 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:31:53 --> Model Class Initialized
INFO - 2016-08-11 16:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:31:53 --> Final output sent to browser
DEBUG - 2016-08-11 16:31:53 --> Total execution time: 0.6341
INFO - 2016-08-11 16:31:57 --> Config Class Initialized
INFO - 2016-08-11 16:31:57 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:31:57 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:31:57 --> Utf8 Class Initialized
INFO - 2016-08-11 16:31:57 --> URI Class Initialized
INFO - 2016-08-11 16:31:57 --> Router Class Initialized
INFO - 2016-08-11 16:31:57 --> Output Class Initialized
INFO - 2016-08-11 16:31:57 --> Security Class Initialized
DEBUG - 2016-08-11 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:31:57 --> Input Class Initialized
INFO - 2016-08-11 16:31:57 --> Language Class Initialized
INFO - 2016-08-11 16:31:57 --> Loader Class Initialized
INFO - 2016-08-11 16:31:57 --> Helper loaded: url_helper
INFO - 2016-08-11 16:31:57 --> Helper loaded: date_helper
INFO - 2016-08-11 16:31:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:31:57 --> Database Driver Class Initialized
INFO - 2016-08-11 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:31:57 --> Email Class Initialized
INFO - 2016-08-11 16:31:57 --> Model Class Initialized
INFO - 2016-08-11 16:31:57 --> Controller Class Initialized
INFO - 2016-08-11 16:31:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:31:57 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:31:57 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:35:07 --> Config Class Initialized
INFO - 2016-08-11 16:35:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:35:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:35:07 --> Utf8 Class Initialized
INFO - 2016-08-11 16:35:07 --> URI Class Initialized
INFO - 2016-08-11 16:35:07 --> Router Class Initialized
INFO - 2016-08-11 16:35:07 --> Output Class Initialized
INFO - 2016-08-11 16:35:07 --> Security Class Initialized
DEBUG - 2016-08-11 16:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:35:07 --> Input Class Initialized
INFO - 2016-08-11 16:35:08 --> Language Class Initialized
INFO - 2016-08-11 16:35:08 --> Loader Class Initialized
INFO - 2016-08-11 16:35:08 --> Helper loaded: url_helper
INFO - 2016-08-11 16:35:08 --> Helper loaded: date_helper
INFO - 2016-08-11 16:35:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:35:08 --> Database Driver Class Initialized
INFO - 2016-08-11 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:35:08 --> Email Class Initialized
INFO - 2016-08-11 16:35:08 --> Model Class Initialized
INFO - 2016-08-11 16:35:08 --> Controller Class Initialized
INFO - 2016-08-11 16:35:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:35:08 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:35:08 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:35:37 --> Config Class Initialized
INFO - 2016-08-11 16:35:37 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:35:37 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:35:37 --> Utf8 Class Initialized
INFO - 2016-08-11 16:35:37 --> URI Class Initialized
INFO - 2016-08-11 16:35:37 --> Router Class Initialized
INFO - 2016-08-11 16:35:37 --> Output Class Initialized
INFO - 2016-08-11 16:35:37 --> Security Class Initialized
DEBUG - 2016-08-11 16:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:35:37 --> Input Class Initialized
INFO - 2016-08-11 16:35:37 --> Language Class Initialized
INFO - 2016-08-11 16:35:37 --> Loader Class Initialized
INFO - 2016-08-11 16:35:37 --> Helper loaded: url_helper
INFO - 2016-08-11 16:35:37 --> Helper loaded: date_helper
INFO - 2016-08-11 16:35:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:35:37 --> Database Driver Class Initialized
INFO - 2016-08-11 16:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:35:37 --> Email Class Initialized
INFO - 2016-08-11 16:35:37 --> Model Class Initialized
INFO - 2016-08-11 16:35:37 --> Controller Class Initialized
INFO - 2016-08-11 16:35:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:35:37 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:35:37 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:36:01 --> Config Class Initialized
INFO - 2016-08-11 16:36:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:36:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:36:01 --> Utf8 Class Initialized
INFO - 2016-08-11 16:36:01 --> URI Class Initialized
DEBUG - 2016-08-11 16:36:01 --> No URI present. Default controller set.
INFO - 2016-08-11 16:36:01 --> Router Class Initialized
INFO - 2016-08-11 16:36:01 --> Output Class Initialized
INFO - 2016-08-11 16:36:01 --> Security Class Initialized
DEBUG - 2016-08-11 16:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:36:01 --> Input Class Initialized
INFO - 2016-08-11 16:36:02 --> Language Class Initialized
INFO - 2016-08-11 16:36:02 --> Loader Class Initialized
INFO - 2016-08-11 16:36:02 --> Helper loaded: url_helper
INFO - 2016-08-11 16:36:02 --> Helper loaded: date_helper
INFO - 2016-08-11 16:36:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:36:02 --> Database Driver Class Initialized
INFO - 2016-08-11 16:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:36:02 --> Email Class Initialized
INFO - 2016-08-11 16:36:02 --> Model Class Initialized
INFO - 2016-08-11 16:36:02 --> Controller Class Initialized
DEBUG - 2016-08-11 16:36:02 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:36:02 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:36:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:36:02 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:36:02 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:36:02 --> Model Class Initialized
INFO - 2016-08-11 16:36:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:36:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:36:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:36:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:36:02 --> Final output sent to browser
DEBUG - 2016-08-11 16:36:02 --> Total execution time: 0.7747
INFO - 2016-08-11 16:36:46 --> Config Class Initialized
INFO - 2016-08-11 16:36:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:36:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:36:46 --> Utf8 Class Initialized
INFO - 2016-08-11 16:36:46 --> URI Class Initialized
DEBUG - 2016-08-11 16:36:46 --> No URI present. Default controller set.
INFO - 2016-08-11 16:36:46 --> Router Class Initialized
INFO - 2016-08-11 16:36:46 --> Output Class Initialized
INFO - 2016-08-11 16:36:46 --> Security Class Initialized
DEBUG - 2016-08-11 16:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:36:46 --> Input Class Initialized
INFO - 2016-08-11 16:36:46 --> Language Class Initialized
INFO - 2016-08-11 16:36:46 --> Loader Class Initialized
INFO - 2016-08-11 16:36:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:36:46 --> Helper loaded: date_helper
INFO - 2016-08-11 16:36:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:36:46 --> Database Driver Class Initialized
INFO - 2016-08-11 16:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:36:46 --> Email Class Initialized
INFO - 2016-08-11 16:36:46 --> Model Class Initialized
INFO - 2016-08-11 16:36:46 --> Controller Class Initialized
DEBUG - 2016-08-11 16:36:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:36:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:36:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:36:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:36:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:36:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:36:46 --> Model Class Initialized
INFO - 2016-08-11 16:36:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:36:46 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:36:46 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:37:02 --> Config Class Initialized
INFO - 2016-08-11 16:37:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:37:02 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:37:02 --> Utf8 Class Initialized
INFO - 2016-08-11 16:37:02 --> URI Class Initialized
DEBUG - 2016-08-11 16:37:02 --> No URI present. Default controller set.
INFO - 2016-08-11 16:37:02 --> Router Class Initialized
INFO - 2016-08-11 16:37:02 --> Output Class Initialized
INFO - 2016-08-11 16:37:02 --> Security Class Initialized
DEBUG - 2016-08-11 16:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:37:03 --> Input Class Initialized
INFO - 2016-08-11 16:37:03 --> Language Class Initialized
INFO - 2016-08-11 16:37:03 --> Loader Class Initialized
INFO - 2016-08-11 16:37:03 --> Helper loaded: url_helper
INFO - 2016-08-11 16:37:03 --> Helper loaded: date_helper
INFO - 2016-08-11 16:37:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:37:03 --> Database Driver Class Initialized
INFO - 2016-08-11 16:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:37:03 --> Email Class Initialized
INFO - 2016-08-11 16:37:03 --> Model Class Initialized
INFO - 2016-08-11 16:37:03 --> Controller Class Initialized
DEBUG - 2016-08-11 16:37:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:37:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:37:03 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:37:03 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:37:03 --> Model Class Initialized
INFO - 2016-08-11 16:37:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:37:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:37:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:37:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:37:03 --> Final output sent to browser
DEBUG - 2016-08-11 16:37:03 --> Total execution time: 0.9858
INFO - 2016-08-11 16:37:51 --> Config Class Initialized
INFO - 2016-08-11 16:37:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:37:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:37:51 --> Utf8 Class Initialized
INFO - 2016-08-11 16:37:51 --> URI Class Initialized
INFO - 2016-08-11 16:37:51 --> Router Class Initialized
INFO - 2016-08-11 16:37:51 --> Output Class Initialized
INFO - 2016-08-11 16:37:51 --> Security Class Initialized
DEBUG - 2016-08-11 16:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:37:51 --> Input Class Initialized
INFO - 2016-08-11 16:37:51 --> Language Class Initialized
INFO - 2016-08-11 16:37:51 --> Loader Class Initialized
INFO - 2016-08-11 16:37:52 --> Helper loaded: url_helper
INFO - 2016-08-11 16:37:52 --> Helper loaded: date_helper
INFO - 2016-08-11 16:37:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:37:52 --> Database Driver Class Initialized
INFO - 2016-08-11 16:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:37:52 --> Email Class Initialized
INFO - 2016-08-11 16:37:52 --> Model Class Initialized
INFO - 2016-08-11 16:37:52 --> Controller Class Initialized
INFO - 2016-08-11 16:37:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:37:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:37:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:37:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:37:52 --> Final output sent to browser
DEBUG - 2016-08-11 16:37:52 --> Total execution time: 0.5357
INFO - 2016-08-11 16:37:52 --> Config Class Initialized
INFO - 2016-08-11 16:37:52 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:37:52 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:37:52 --> Utf8 Class Initialized
INFO - 2016-08-11 16:37:52 --> URI Class Initialized
INFO - 2016-08-11 16:37:53 --> Router Class Initialized
INFO - 2016-08-11 16:37:53 --> Output Class Initialized
INFO - 2016-08-11 16:37:53 --> Security Class Initialized
DEBUG - 2016-08-11 16:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:37:53 --> Input Class Initialized
INFO - 2016-08-11 16:37:53 --> Language Class Initialized
ERROR - 2016-08-11 16:37:53 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 16:38:04 --> Config Class Initialized
INFO - 2016-08-11 16:38:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:38:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:38:04 --> Utf8 Class Initialized
INFO - 2016-08-11 16:38:04 --> URI Class Initialized
INFO - 2016-08-11 16:38:04 --> Router Class Initialized
INFO - 2016-08-11 16:38:04 --> Output Class Initialized
INFO - 2016-08-11 16:38:04 --> Security Class Initialized
DEBUG - 2016-08-11 16:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:38:04 --> Input Class Initialized
INFO - 2016-08-11 16:38:04 --> Language Class Initialized
INFO - 2016-08-11 16:38:04 --> Loader Class Initialized
INFO - 2016-08-11 16:38:04 --> Helper loaded: url_helper
INFO - 2016-08-11 16:38:04 --> Helper loaded: date_helper
INFO - 2016-08-11 16:38:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:38:04 --> Database Driver Class Initialized
INFO - 2016-08-11 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:38:04 --> Email Class Initialized
INFO - 2016-08-11 16:38:04 --> Model Class Initialized
INFO - 2016-08-11 16:38:04 --> Controller Class Initialized
DEBUG - 2016-08-11 16:38:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:38:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:38:04 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:38:04 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:04 --> Model Class Initialized
INFO - 2016-08-11 16:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:38:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:38:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:38:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/tambah_page.php
INFO - 2016-08-11 16:38:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:38:05 --> Final output sent to browser
DEBUG - 2016-08-11 16:38:05 --> Total execution time: 0.7070
INFO - 2016-08-11 16:38:58 --> Config Class Initialized
INFO - 2016-08-11 16:38:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:38:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:38:58 --> Utf8 Class Initialized
INFO - 2016-08-11 16:38:58 --> URI Class Initialized
INFO - 2016-08-11 16:38:58 --> Router Class Initialized
INFO - 2016-08-11 16:38:58 --> Output Class Initialized
INFO - 2016-08-11 16:38:58 --> Security Class Initialized
DEBUG - 2016-08-11 16:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:38:58 --> Input Class Initialized
INFO - 2016-08-11 16:38:58 --> Language Class Initialized
INFO - 2016-08-11 16:38:58 --> Loader Class Initialized
INFO - 2016-08-11 16:38:58 --> Helper loaded: url_helper
INFO - 2016-08-11 16:38:58 --> Helper loaded: date_helper
INFO - 2016-08-11 16:38:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:38:58 --> Database Driver Class Initialized
INFO - 2016-08-11 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:38:58 --> Email Class Initialized
INFO - 2016-08-11 16:38:58 --> Model Class Initialized
INFO - 2016-08-11 16:38:58 --> Controller Class Initialized
DEBUG - 2016-08-11 16:38:58 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:38:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:38:58 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:38:58 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:58 --> Model Class Initialized
INFO - 2016-08-11 16:38:58 --> Upload Class Initialized
INFO - 2016-08-11 16:38:58 --> Config Class Initialized
INFO - 2016-08-11 16:38:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:38:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:38:58 --> Utf8 Class Initialized
INFO - 2016-08-11 16:38:58 --> URI Class Initialized
INFO - 2016-08-11 16:38:58 --> Router Class Initialized
INFO - 2016-08-11 16:38:58 --> Output Class Initialized
INFO - 2016-08-11 16:38:58 --> Security Class Initialized
DEBUG - 2016-08-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:38:59 --> Input Class Initialized
INFO - 2016-08-11 16:38:59 --> Language Class Initialized
INFO - 2016-08-11 16:38:59 --> Loader Class Initialized
INFO - 2016-08-11 16:38:59 --> Helper loaded: url_helper
INFO - 2016-08-11 16:38:59 --> Helper loaded: date_helper
INFO - 2016-08-11 16:38:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:38:59 --> Database Driver Class Initialized
INFO - 2016-08-11 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:38:59 --> Email Class Initialized
INFO - 2016-08-11 16:38:59 --> Model Class Initialized
INFO - 2016-08-11 16:38:59 --> Controller Class Initialized
DEBUG - 2016-08-11 16:38:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:38:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:38:59 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:38:59 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:38:59 --> Model Class Initialized
INFO - 2016-08-11 16:38:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:38:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:38:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:38:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/page/view_page.php
INFO - 2016-08-11 16:38:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:38:59 --> Final output sent to browser
DEBUG - 2016-08-11 16:38:59 --> Total execution time: 0.6527
INFO - 2016-08-11 16:39:03 --> Config Class Initialized
INFO - 2016-08-11 16:39:03 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:39:03 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:39:03 --> Utf8 Class Initialized
INFO - 2016-08-11 16:39:03 --> URI Class Initialized
INFO - 2016-08-11 16:39:03 --> Router Class Initialized
INFO - 2016-08-11 16:39:03 --> Output Class Initialized
INFO - 2016-08-11 16:39:03 --> Security Class Initialized
DEBUG - 2016-08-11 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:39:03 --> Input Class Initialized
INFO - 2016-08-11 16:39:03 --> Language Class Initialized
INFO - 2016-08-11 16:39:03 --> Loader Class Initialized
INFO - 2016-08-11 16:39:03 --> Helper loaded: url_helper
INFO - 2016-08-11 16:39:03 --> Helper loaded: date_helper
INFO - 2016-08-11 16:39:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:39:03 --> Database Driver Class Initialized
INFO - 2016-08-11 16:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:39:03 --> Email Class Initialized
INFO - 2016-08-11 16:39:03 --> Model Class Initialized
INFO - 2016-08-11 16:39:03 --> Controller Class Initialized
INFO - 2016-08-11 16:39:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:39:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:39:04 --> Final output sent to browser
DEBUG - 2016-08-11 16:39:04 --> Total execution time: 0.5848
INFO - 2016-08-11 16:39:04 --> Config Class Initialized
INFO - 2016-08-11 16:39:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:39:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:39:04 --> Utf8 Class Initialized
INFO - 2016-08-11 16:39:04 --> URI Class Initialized
INFO - 2016-08-11 16:39:05 --> Router Class Initialized
INFO - 2016-08-11 16:39:05 --> Output Class Initialized
INFO - 2016-08-11 16:39:05 --> Security Class Initialized
DEBUG - 2016-08-11 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:39:05 --> Input Class Initialized
INFO - 2016-08-11 16:39:05 --> Language Class Initialized
ERROR - 2016-08-11 16:39:05 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 16:39:07 --> Config Class Initialized
INFO - 2016-08-11 16:39:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:39:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:39:07 --> Utf8 Class Initialized
INFO - 2016-08-11 16:39:07 --> URI Class Initialized
INFO - 2016-08-11 16:39:07 --> Router Class Initialized
INFO - 2016-08-11 16:39:07 --> Output Class Initialized
INFO - 2016-08-11 16:39:07 --> Security Class Initialized
DEBUG - 2016-08-11 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:39:07 --> Input Class Initialized
INFO - 2016-08-11 16:39:07 --> Language Class Initialized
INFO - 2016-08-11 16:39:07 --> Loader Class Initialized
INFO - 2016-08-11 16:39:07 --> Helper loaded: url_helper
INFO - 2016-08-11 16:39:07 --> Helper loaded: date_helper
INFO - 2016-08-11 16:39:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:39:07 --> Database Driver Class Initialized
INFO - 2016-08-11 16:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:39:07 --> Email Class Initialized
INFO - 2016-08-11 16:39:07 --> Model Class Initialized
INFO - 2016-08-11 16:39:07 --> Controller Class Initialized
INFO - 2016-08-11 16:39:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:39:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:39:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:39:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:39:08 --> Final output sent to browser
DEBUG - 2016-08-11 16:39:08 --> Total execution time: 0.4658
INFO - 2016-08-11 16:39:25 --> Config Class Initialized
INFO - 2016-08-11 16:39:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:39:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:39:25 --> Utf8 Class Initialized
INFO - 2016-08-11 16:39:25 --> URI Class Initialized
INFO - 2016-08-11 16:39:25 --> Router Class Initialized
INFO - 2016-08-11 16:39:25 --> Output Class Initialized
INFO - 2016-08-11 16:39:25 --> Security Class Initialized
DEBUG - 2016-08-11 16:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:39:25 --> Input Class Initialized
INFO - 2016-08-11 16:39:25 --> Language Class Initialized
INFO - 2016-08-11 16:39:25 --> Loader Class Initialized
INFO - 2016-08-11 16:39:25 --> Helper loaded: url_helper
INFO - 2016-08-11 16:39:25 --> Helper loaded: date_helper
INFO - 2016-08-11 16:39:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:39:25 --> Database Driver Class Initialized
INFO - 2016-08-11 16:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:39:25 --> Email Class Initialized
INFO - 2016-08-11 16:39:25 --> Model Class Initialized
INFO - 2016-08-11 16:39:25 --> Controller Class Initialized
INFO - 2016-08-11 16:39:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:39:25 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:39:25 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:49:09 --> Config Class Initialized
INFO - 2016-08-11 16:49:09 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:49:09 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:49:09 --> Utf8 Class Initialized
INFO - 2016-08-11 16:49:09 --> URI Class Initialized
INFO - 2016-08-11 16:49:10 --> Router Class Initialized
INFO - 2016-08-11 16:49:10 --> Output Class Initialized
INFO - 2016-08-11 16:49:10 --> Security Class Initialized
DEBUG - 2016-08-11 16:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:49:10 --> Input Class Initialized
INFO - 2016-08-11 16:49:10 --> Language Class Initialized
INFO - 2016-08-11 16:49:10 --> Loader Class Initialized
INFO - 2016-08-11 16:49:10 --> Helper loaded: url_helper
INFO - 2016-08-11 16:49:10 --> Helper loaded: date_helper
INFO - 2016-08-11 16:49:10 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:49:10 --> Database Driver Class Initialized
INFO - 2016-08-11 16:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:49:10 --> Email Class Initialized
INFO - 2016-08-11 16:49:10 --> Model Class Initialized
INFO - 2016-08-11 16:49:10 --> Controller Class Initialized
INFO - 2016-08-11 16:49:10 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:49:10 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:49:10 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:49:12 --> Config Class Initialized
INFO - 2016-08-11 16:49:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:49:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:49:12 --> Utf8 Class Initialized
INFO - 2016-08-11 16:49:12 --> URI Class Initialized
INFO - 2016-08-11 16:49:12 --> Router Class Initialized
INFO - 2016-08-11 16:49:12 --> Output Class Initialized
INFO - 2016-08-11 16:49:12 --> Security Class Initialized
DEBUG - 2016-08-11 16:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:49:12 --> Input Class Initialized
INFO - 2016-08-11 16:49:12 --> Language Class Initialized
INFO - 2016-08-11 16:49:12 --> Loader Class Initialized
INFO - 2016-08-11 16:49:12 --> Helper loaded: url_helper
INFO - 2016-08-11 16:49:12 --> Helper loaded: date_helper
INFO - 2016-08-11 16:49:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:49:12 --> Database Driver Class Initialized
INFO - 2016-08-11 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:49:12 --> Email Class Initialized
INFO - 2016-08-11 16:49:12 --> Model Class Initialized
INFO - 2016-08-11 16:49:12 --> Controller Class Initialized
INFO - 2016-08-11 16:49:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:49:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:49:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:49:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:49:12 --> Final output sent to browser
DEBUG - 2016-08-11 16:49:12 --> Total execution time: 0.4765
INFO - 2016-08-11 16:49:15 --> Config Class Initialized
INFO - 2016-08-11 16:49:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:49:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:49:15 --> Utf8 Class Initialized
INFO - 2016-08-11 16:49:15 --> URI Class Initialized
DEBUG - 2016-08-11 16:49:15 --> No URI present. Default controller set.
INFO - 2016-08-11 16:49:15 --> Router Class Initialized
INFO - 2016-08-11 16:49:15 --> Output Class Initialized
INFO - 2016-08-11 16:49:16 --> Security Class Initialized
DEBUG - 2016-08-11 16:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:49:16 --> Input Class Initialized
INFO - 2016-08-11 16:49:16 --> Language Class Initialized
INFO - 2016-08-11 16:49:16 --> Loader Class Initialized
INFO - 2016-08-11 16:49:16 --> Helper loaded: url_helper
INFO - 2016-08-11 16:49:16 --> Helper loaded: date_helper
INFO - 2016-08-11 16:49:16 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:49:16 --> Database Driver Class Initialized
INFO - 2016-08-11 16:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:49:16 --> Email Class Initialized
INFO - 2016-08-11 16:49:16 --> Model Class Initialized
INFO - 2016-08-11 16:49:16 --> Controller Class Initialized
INFO - 2016-08-11 16:49:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:49:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:49:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 16:49:16 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:49:16 --> Final output sent to browser
DEBUG - 2016-08-11 16:49:16 --> Total execution time: 0.5745
INFO - 2016-08-11 16:49:33 --> Config Class Initialized
INFO - 2016-08-11 16:49:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:49:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:49:33 --> Utf8 Class Initialized
INFO - 2016-08-11 16:49:33 --> URI Class Initialized
INFO - 2016-08-11 16:49:33 --> Router Class Initialized
INFO - 2016-08-11 16:49:33 --> Output Class Initialized
INFO - 2016-08-11 16:49:33 --> Security Class Initialized
DEBUG - 2016-08-11 16:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:49:33 --> Input Class Initialized
INFO - 2016-08-11 16:49:33 --> Language Class Initialized
INFO - 2016-08-11 16:49:33 --> Loader Class Initialized
INFO - 2016-08-11 16:49:33 --> Helper loaded: url_helper
INFO - 2016-08-11 16:49:33 --> Helper loaded: date_helper
INFO - 2016-08-11 16:49:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:49:33 --> Database Driver Class Initialized
INFO - 2016-08-11 16:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:49:33 --> Email Class Initialized
INFO - 2016-08-11 16:49:33 --> Model Class Initialized
INFO - 2016-08-11 16:49:33 --> Controller Class Initialized
INFO - 2016-08-11 16:49:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 16:49:33 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 16:49:33 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 16:52:46 --> Config Class Initialized
INFO - 2016-08-11 16:52:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:52:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:52:46 --> Utf8 Class Initialized
INFO - 2016-08-11 16:52:46 --> URI Class Initialized
INFO - 2016-08-11 16:52:46 --> Router Class Initialized
INFO - 2016-08-11 16:52:46 --> Output Class Initialized
INFO - 2016-08-11 16:52:46 --> Security Class Initialized
DEBUG - 2016-08-11 16:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:52:46 --> Input Class Initialized
INFO - 2016-08-11 16:52:46 --> Language Class Initialized
INFO - 2016-08-11 16:52:46 --> Loader Class Initialized
INFO - 2016-08-11 16:52:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:52:46 --> Helper loaded: date_helper
INFO - 2016-08-11 16:52:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:52:46 --> Database Driver Class Initialized
INFO - 2016-08-11 16:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:52:46 --> Email Class Initialized
INFO - 2016-08-11 16:52:46 --> Model Class Initialized
INFO - 2016-08-11 16:52:46 --> Controller Class Initialized
DEBUG - 2016-08-11 16:52:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:52:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:52:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:52:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:46 --> Model Class Initialized
INFO - 2016-08-11 16:52:46 --> Config Class Initialized
INFO - 2016-08-11 16:52:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:52:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:52:46 --> Utf8 Class Initialized
INFO - 2016-08-11 16:52:46 --> URI Class Initialized
INFO - 2016-08-11 16:52:46 --> Router Class Initialized
INFO - 2016-08-11 16:52:46 --> Output Class Initialized
INFO - 2016-08-11 16:52:46 --> Security Class Initialized
DEBUG - 2016-08-11 16:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:52:46 --> Input Class Initialized
INFO - 2016-08-11 16:52:46 --> Language Class Initialized
INFO - 2016-08-11 16:52:46 --> Loader Class Initialized
INFO - 2016-08-11 16:52:46 --> Helper loaded: url_helper
INFO - 2016-08-11 16:52:47 --> Helper loaded: date_helper
INFO - 2016-08-11 16:52:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:52:47 --> Database Driver Class Initialized
INFO - 2016-08-11 16:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:52:47 --> Email Class Initialized
INFO - 2016-08-11 16:52:47 --> Model Class Initialized
INFO - 2016-08-11 16:52:47 --> Controller Class Initialized
DEBUG - 2016-08-11 16:52:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:52:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:52:47 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:52:47 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:47 --> Model Class Initialized
INFO - 2016-08-11 16:52:47 --> Helper loaded: form_helper
INFO - 2016-08-11 16:52:47 --> Form Validation Class Initialized
INFO - 2016-08-11 16:52:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 16:52:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 16:52:47 --> Final output sent to browser
DEBUG - 2016-08-11 16:52:47 --> Total execution time: 0.7324
INFO - 2016-08-11 16:52:51 --> Config Class Initialized
INFO - 2016-08-11 16:52:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:52:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:52:51 --> Utf8 Class Initialized
INFO - 2016-08-11 16:52:51 --> URI Class Initialized
INFO - 2016-08-11 16:52:51 --> Router Class Initialized
INFO - 2016-08-11 16:52:51 --> Output Class Initialized
INFO - 2016-08-11 16:52:51 --> Security Class Initialized
DEBUG - 2016-08-11 16:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:52:51 --> Input Class Initialized
INFO - 2016-08-11 16:52:51 --> Language Class Initialized
INFO - 2016-08-11 16:52:51 --> Loader Class Initialized
INFO - 2016-08-11 16:52:51 --> Helper loaded: url_helper
INFO - 2016-08-11 16:52:51 --> Helper loaded: date_helper
INFO - 2016-08-11 16:52:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:52:51 --> Database Driver Class Initialized
INFO - 2016-08-11 16:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:52:51 --> Email Class Initialized
INFO - 2016-08-11 16:52:51 --> Model Class Initialized
INFO - 2016-08-11 16:52:51 --> Controller Class Initialized
DEBUG - 2016-08-11 16:52:51 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:52:51 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:52:51 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:52:51 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:51 --> Model Class Initialized
INFO - 2016-08-11 16:52:51 --> Helper loaded: form_helper
INFO - 2016-08-11 16:52:51 --> Form Validation Class Initialized
INFO - 2016-08-11 16:52:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 16:52:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 16:52:51 --> Config Class Initialized
INFO - 2016-08-11 16:52:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:52:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:52:51 --> Utf8 Class Initialized
INFO - 2016-08-11 16:52:51 --> URI Class Initialized
INFO - 2016-08-11 16:52:51 --> Router Class Initialized
INFO - 2016-08-11 16:52:52 --> Output Class Initialized
INFO - 2016-08-11 16:52:52 --> Security Class Initialized
DEBUG - 2016-08-11 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:52:52 --> Input Class Initialized
INFO - 2016-08-11 16:52:52 --> Language Class Initialized
INFO - 2016-08-11 16:52:52 --> Loader Class Initialized
INFO - 2016-08-11 16:52:52 --> Helper loaded: url_helper
INFO - 2016-08-11 16:52:52 --> Helper loaded: date_helper
INFO - 2016-08-11 16:52:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:52:52 --> Database Driver Class Initialized
INFO - 2016-08-11 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:52:52 --> Email Class Initialized
INFO - 2016-08-11 16:52:52 --> Model Class Initialized
INFO - 2016-08-11 16:52:52 --> Controller Class Initialized
DEBUG - 2016-08-11 16:52:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:52:52 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:52:52 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:52 --> Model Class Initialized
INFO - 2016-08-11 16:52:52 --> Helper loaded: form_helper
INFO - 2016-08-11 16:52:52 --> Form Validation Class Initialized
INFO - 2016-08-11 16:52:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 16:52:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 16:52:52 --> Final output sent to browser
DEBUG - 2016-08-11 16:52:52 --> Total execution time: 0.6711
INFO - 2016-08-11 16:52:59 --> Config Class Initialized
INFO - 2016-08-11 16:52:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:52:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:52:59 --> Utf8 Class Initialized
INFO - 2016-08-11 16:52:59 --> URI Class Initialized
INFO - 2016-08-11 16:52:59 --> Router Class Initialized
INFO - 2016-08-11 16:52:59 --> Output Class Initialized
INFO - 2016-08-11 16:52:59 --> Security Class Initialized
DEBUG - 2016-08-11 16:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:52:59 --> Input Class Initialized
INFO - 2016-08-11 16:52:59 --> Language Class Initialized
INFO - 2016-08-11 16:52:59 --> Loader Class Initialized
INFO - 2016-08-11 16:52:59 --> Helper loaded: url_helper
INFO - 2016-08-11 16:52:59 --> Helper loaded: date_helper
INFO - 2016-08-11 16:52:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:52:59 --> Database Driver Class Initialized
INFO - 2016-08-11 16:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:52:59 --> Email Class Initialized
INFO - 2016-08-11 16:52:59 --> Model Class Initialized
INFO - 2016-08-11 16:52:59 --> Controller Class Initialized
DEBUG - 2016-08-11 16:52:59 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:52:59 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:52:59 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:52:59 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:52:59 --> Model Class Initialized
INFO - 2016-08-11 16:52:59 --> Helper loaded: form_helper
INFO - 2016-08-11 16:52:59 --> Form Validation Class Initialized
INFO - 2016-08-11 16:52:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 16:52:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 16:53:00 --> Config Class Initialized
INFO - 2016-08-11 16:53:00 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:53:00 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:53:00 --> Utf8 Class Initialized
INFO - 2016-08-11 16:53:00 --> URI Class Initialized
INFO - 2016-08-11 16:53:00 --> Router Class Initialized
INFO - 2016-08-11 16:53:00 --> Output Class Initialized
INFO - 2016-08-11 16:53:00 --> Security Class Initialized
DEBUG - 2016-08-11 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:53:00 --> Input Class Initialized
INFO - 2016-08-11 16:53:00 --> Language Class Initialized
INFO - 2016-08-11 16:53:00 --> Loader Class Initialized
INFO - 2016-08-11 16:53:00 --> Helper loaded: url_helper
INFO - 2016-08-11 16:53:00 --> Helper loaded: date_helper
INFO - 2016-08-11 16:53:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:53:00 --> Database Driver Class Initialized
INFO - 2016-08-11 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:53:00 --> Email Class Initialized
INFO - 2016-08-11 16:53:00 --> Model Class Initialized
INFO - 2016-08-11 16:53:00 --> Controller Class Initialized
DEBUG - 2016-08-11 16:53:00 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:53:00 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:53:00 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:53:00 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:00 --> Model Class Initialized
INFO - 2016-08-11 16:53:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:53:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:53:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:53:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 16:53:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:53:00 --> Final output sent to browser
DEBUG - 2016-08-11 16:53:00 --> Total execution time: 0.6918
INFO - 2016-08-11 16:53:04 --> Config Class Initialized
INFO - 2016-08-11 16:53:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:53:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:53:04 --> Utf8 Class Initialized
INFO - 2016-08-11 16:53:04 --> URI Class Initialized
INFO - 2016-08-11 16:53:04 --> Router Class Initialized
INFO - 2016-08-11 16:53:04 --> Output Class Initialized
INFO - 2016-08-11 16:53:04 --> Security Class Initialized
DEBUG - 2016-08-11 16:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:53:04 --> Input Class Initialized
INFO - 2016-08-11 16:53:04 --> Language Class Initialized
INFO - 2016-08-11 16:53:04 --> Loader Class Initialized
INFO - 2016-08-11 16:53:04 --> Helper loaded: url_helper
INFO - 2016-08-11 16:53:04 --> Helper loaded: date_helper
INFO - 2016-08-11 16:53:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:53:04 --> Database Driver Class Initialized
INFO - 2016-08-11 16:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:53:04 --> Email Class Initialized
INFO - 2016-08-11 16:53:04 --> Model Class Initialized
INFO - 2016-08-11 16:53:04 --> Controller Class Initialized
DEBUG - 2016-08-11 16:53:04 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:53:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:53:04 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:53:05 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:05 --> Model Class Initialized
INFO - 2016-08-11 16:53:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:53:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:53:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:53:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 16:53:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:53:05 --> Final output sent to browser
DEBUG - 2016-08-11 16:53:05 --> Total execution time: 0.6454
INFO - 2016-08-11 16:53:28 --> Config Class Initialized
INFO - 2016-08-11 16:53:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:53:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:53:28 --> Utf8 Class Initialized
INFO - 2016-08-11 16:53:28 --> URI Class Initialized
INFO - 2016-08-11 16:53:28 --> Router Class Initialized
INFO - 2016-08-11 16:53:28 --> Output Class Initialized
INFO - 2016-08-11 16:53:28 --> Security Class Initialized
DEBUG - 2016-08-11 16:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:53:29 --> Input Class Initialized
INFO - 2016-08-11 16:53:29 --> Language Class Initialized
INFO - 2016-08-11 16:53:29 --> Loader Class Initialized
INFO - 2016-08-11 16:53:29 --> Helper loaded: url_helper
INFO - 2016-08-11 16:53:29 --> Helper loaded: date_helper
INFO - 2016-08-11 16:53:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:53:29 --> Database Driver Class Initialized
INFO - 2016-08-11 16:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:53:29 --> Email Class Initialized
INFO - 2016-08-11 16:53:29 --> Model Class Initialized
INFO - 2016-08-11 16:53:29 --> Controller Class Initialized
INFO - 2016-08-11 16:53:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:53:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:53:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 16:53:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:53:29 --> Final output sent to browser
DEBUG - 2016-08-11 16:53:29 --> Total execution time: 0.8601
INFO - 2016-08-11 16:53:30 --> Config Class Initialized
INFO - 2016-08-11 16:53:30 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:53:30 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:53:30 --> Utf8 Class Initialized
INFO - 2016-08-11 16:53:30 --> URI Class Initialized
INFO - 2016-08-11 16:53:30 --> Router Class Initialized
INFO - 2016-08-11 16:53:30 --> Output Class Initialized
INFO - 2016-08-11 16:53:30 --> Security Class Initialized
DEBUG - 2016-08-11 16:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:53:30 --> Input Class Initialized
INFO - 2016-08-11 16:53:30 --> Language Class Initialized
ERROR - 2016-08-11 16:53:30 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 16:53:42 --> Config Class Initialized
INFO - 2016-08-11 16:53:42 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:53:42 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:53:42 --> Utf8 Class Initialized
INFO - 2016-08-11 16:53:42 --> URI Class Initialized
INFO - 2016-08-11 16:53:42 --> Router Class Initialized
INFO - 2016-08-11 16:53:42 --> Output Class Initialized
INFO - 2016-08-11 16:53:42 --> Security Class Initialized
DEBUG - 2016-08-11 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:53:42 --> Input Class Initialized
INFO - 2016-08-11 16:53:42 --> Language Class Initialized
INFO - 2016-08-11 16:53:42 --> Loader Class Initialized
INFO - 2016-08-11 16:53:42 --> Helper loaded: url_helper
INFO - 2016-08-11 16:53:42 --> Helper loaded: date_helper
INFO - 2016-08-11 16:53:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:53:42 --> Database Driver Class Initialized
INFO - 2016-08-11 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:53:42 --> Email Class Initialized
INFO - 2016-08-11 16:53:42 --> Model Class Initialized
INFO - 2016-08-11 16:53:42 --> Controller Class Initialized
DEBUG - 2016-08-11 16:53:42 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:53:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:53:43 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:53:43 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:53:43 --> Model Class Initialized
INFO - 2016-08-11 16:53:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:53:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:53:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:53:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 16:53:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:53:43 --> Final output sent to browser
DEBUG - 2016-08-11 16:53:43 --> Total execution time: 0.8512
INFO - 2016-08-11 16:54:38 --> Config Class Initialized
INFO - 2016-08-11 16:54:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:54:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:54:38 --> Utf8 Class Initialized
INFO - 2016-08-11 16:54:39 --> URI Class Initialized
INFO - 2016-08-11 16:54:39 --> Router Class Initialized
INFO - 2016-08-11 16:54:39 --> Output Class Initialized
INFO - 2016-08-11 16:54:39 --> Security Class Initialized
DEBUG - 2016-08-11 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:54:39 --> Input Class Initialized
INFO - 2016-08-11 16:54:39 --> Language Class Initialized
INFO - 2016-08-11 16:54:39 --> Loader Class Initialized
INFO - 2016-08-11 16:54:39 --> Helper loaded: url_helper
INFO - 2016-08-11 16:54:39 --> Helper loaded: date_helper
INFO - 2016-08-11 16:54:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:54:39 --> Database Driver Class Initialized
INFO - 2016-08-11 16:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:54:39 --> Email Class Initialized
INFO - 2016-08-11 16:54:39 --> Model Class Initialized
INFO - 2016-08-11 16:54:39 --> Controller Class Initialized
DEBUG - 2016-08-11 16:54:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:54:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:54:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:54:39 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:54:39 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:54:39 --> Model Class Initialized
INFO - 2016-08-11 16:54:39 --> Upload Class Initialized
INFO - 2016-08-11 16:54:39 --> Config Class Initialized
INFO - 2016-08-11 16:54:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:54:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:54:40 --> Utf8 Class Initialized
INFO - 2016-08-11 16:54:40 --> URI Class Initialized
INFO - 2016-08-11 16:54:40 --> Router Class Initialized
INFO - 2016-08-11 16:54:40 --> Output Class Initialized
INFO - 2016-08-11 16:54:40 --> Security Class Initialized
DEBUG - 2016-08-11 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:54:40 --> Input Class Initialized
INFO - 2016-08-11 16:54:40 --> Language Class Initialized
INFO - 2016-08-11 16:54:40 --> Loader Class Initialized
INFO - 2016-08-11 16:54:40 --> Helper loaded: url_helper
INFO - 2016-08-11 16:54:40 --> Helper loaded: date_helper
INFO - 2016-08-11 16:54:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:54:40 --> Database Driver Class Initialized
INFO - 2016-08-11 16:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:54:40 --> Email Class Initialized
INFO - 2016-08-11 16:54:40 --> Model Class Initialized
INFO - 2016-08-11 16:54:40 --> Controller Class Initialized
DEBUG - 2016-08-11 16:54:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 16:54:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:54:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 16:54:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 16:54:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 16:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 16:54:40 --> Model Class Initialized
INFO - 2016-08-11 16:54:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 16:54:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 16:54:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 16:54:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 16:54:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 16:54:40 --> Final output sent to browser
DEBUG - 2016-08-11 16:54:40 --> Total execution time: 0.9345
INFO - 2016-08-11 16:55:04 --> Config Class Initialized
INFO - 2016-08-11 16:55:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:55:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:55:04 --> Utf8 Class Initialized
INFO - 2016-08-11 16:55:04 --> URI Class Initialized
INFO - 2016-08-11 16:55:04 --> Router Class Initialized
INFO - 2016-08-11 16:55:04 --> Output Class Initialized
INFO - 2016-08-11 16:55:04 --> Security Class Initialized
DEBUG - 2016-08-11 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:55:04 --> Input Class Initialized
INFO - 2016-08-11 16:55:04 --> Language Class Initialized
INFO - 2016-08-11 16:55:04 --> Loader Class Initialized
INFO - 2016-08-11 16:55:04 --> Helper loaded: url_helper
INFO - 2016-08-11 16:55:04 --> Helper loaded: date_helper
INFO - 2016-08-11 16:55:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:55:04 --> Database Driver Class Initialized
INFO - 2016-08-11 16:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:55:04 --> Email Class Initialized
INFO - 2016-08-11 16:55:04 --> Model Class Initialized
INFO - 2016-08-11 16:55:04 --> Controller Class Initialized
INFO - 2016-08-11 16:55:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:55:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:55:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:55:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:55:05 --> Final output sent to browser
DEBUG - 2016-08-11 16:55:05 --> Total execution time: 0.5289
INFO - 2016-08-11 16:55:06 --> Config Class Initialized
INFO - 2016-08-11 16:55:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:55:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:55:06 --> Utf8 Class Initialized
INFO - 2016-08-11 16:55:06 --> URI Class Initialized
INFO - 2016-08-11 16:55:06 --> Router Class Initialized
INFO - 2016-08-11 16:55:06 --> Output Class Initialized
INFO - 2016-08-11 16:55:06 --> Security Class Initialized
DEBUG - 2016-08-11 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:55:07 --> Input Class Initialized
INFO - 2016-08-11 16:55:07 --> Language Class Initialized
INFO - 2016-08-11 16:55:07 --> Loader Class Initialized
INFO - 2016-08-11 16:55:07 --> Helper loaded: url_helper
INFO - 2016-08-11 16:55:07 --> Helper loaded: date_helper
INFO - 2016-08-11 16:55:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:55:07 --> Database Driver Class Initialized
INFO - 2016-08-11 16:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:55:07 --> Email Class Initialized
INFO - 2016-08-11 16:55:07 --> Model Class Initialized
INFO - 2016-08-11 16:55:07 --> Controller Class Initialized
INFO - 2016-08-11 16:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 16:55:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:55:07 --> Final output sent to browser
DEBUG - 2016-08-11 16:55:07 --> Total execution time: 0.4892
INFO - 2016-08-11 16:55:21 --> Config Class Initialized
INFO - 2016-08-11 16:55:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:55:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:55:21 --> Utf8 Class Initialized
INFO - 2016-08-11 16:55:21 --> URI Class Initialized
INFO - 2016-08-11 16:55:21 --> Router Class Initialized
INFO - 2016-08-11 16:55:21 --> Output Class Initialized
INFO - 2016-08-11 16:55:21 --> Security Class Initialized
DEBUG - 2016-08-11 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:55:21 --> Input Class Initialized
INFO - 2016-08-11 16:55:21 --> Language Class Initialized
INFO - 2016-08-11 16:55:21 --> Loader Class Initialized
INFO - 2016-08-11 16:55:21 --> Helper loaded: url_helper
INFO - 2016-08-11 16:55:21 --> Helper loaded: date_helper
INFO - 2016-08-11 16:55:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:55:21 --> Database Driver Class Initialized
INFO - 2016-08-11 16:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:55:21 --> Email Class Initialized
INFO - 2016-08-11 16:55:21 --> Model Class Initialized
INFO - 2016-08-11 16:55:21 --> Controller Class Initialized
INFO - 2016-08-11 16:55:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:55:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:55:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:55:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:55:21 --> Final output sent to browser
DEBUG - 2016-08-11 16:55:21 --> Total execution time: 0.4679
INFO - 2016-08-11 16:55:24 --> Config Class Initialized
INFO - 2016-08-11 16:55:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:55:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:55:24 --> Utf8 Class Initialized
INFO - 2016-08-11 16:55:24 --> URI Class Initialized
INFO - 2016-08-11 16:55:24 --> Router Class Initialized
INFO - 2016-08-11 16:55:24 --> Output Class Initialized
INFO - 2016-08-11 16:55:24 --> Security Class Initialized
DEBUG - 2016-08-11 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:55:24 --> Input Class Initialized
INFO - 2016-08-11 16:55:24 --> Language Class Initialized
INFO - 2016-08-11 16:55:24 --> Loader Class Initialized
INFO - 2016-08-11 16:55:24 --> Helper loaded: url_helper
INFO - 2016-08-11 16:55:24 --> Helper loaded: date_helper
INFO - 2016-08-11 16:55:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:55:24 --> Database Driver Class Initialized
INFO - 2016-08-11 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:55:24 --> Email Class Initialized
INFO - 2016-08-11 16:55:24 --> Model Class Initialized
INFO - 2016-08-11 16:55:24 --> Controller Class Initialized
INFO - 2016-08-11 16:55:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:55:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:55:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-11 16:55:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:55:24 --> Final output sent to browser
DEBUG - 2016-08-11 16:55:24 --> Total execution time: 0.4680
INFO - 2016-08-11 16:55:29 --> Config Class Initialized
INFO - 2016-08-11 16:55:29 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:55:29 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:55:29 --> Utf8 Class Initialized
INFO - 2016-08-11 16:55:29 --> URI Class Initialized
INFO - 2016-08-11 16:55:29 --> Router Class Initialized
INFO - 2016-08-11 16:55:29 --> Output Class Initialized
INFO - 2016-08-11 16:55:29 --> Security Class Initialized
DEBUG - 2016-08-11 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:55:29 --> Input Class Initialized
INFO - 2016-08-11 16:55:29 --> Language Class Initialized
INFO - 2016-08-11 16:55:29 --> Loader Class Initialized
INFO - 2016-08-11 16:55:29 --> Helper loaded: url_helper
INFO - 2016-08-11 16:55:29 --> Helper loaded: date_helper
INFO - 2016-08-11 16:55:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:55:29 --> Database Driver Class Initialized
INFO - 2016-08-11 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:55:29 --> Email Class Initialized
INFO - 2016-08-11 16:55:29 --> Model Class Initialized
INFO - 2016-08-11 16:55:29 --> Controller Class Initialized
INFO - 2016-08-11 16:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 16:55:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:55:29 --> Final output sent to browser
DEBUG - 2016-08-11 16:55:29 --> Total execution time: 0.4705
INFO - 2016-08-11 16:57:27 --> Config Class Initialized
INFO - 2016-08-11 16:57:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 16:57:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 16:57:27 --> Utf8 Class Initialized
INFO - 2016-08-11 16:57:27 --> URI Class Initialized
INFO - 2016-08-11 16:57:27 --> Router Class Initialized
INFO - 2016-08-11 16:57:27 --> Output Class Initialized
INFO - 2016-08-11 16:57:27 --> Security Class Initialized
DEBUG - 2016-08-11 16:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 16:57:27 --> Input Class Initialized
INFO - 2016-08-11 16:57:28 --> Language Class Initialized
INFO - 2016-08-11 16:57:28 --> Loader Class Initialized
INFO - 2016-08-11 16:57:28 --> Helper loaded: url_helper
INFO - 2016-08-11 16:57:28 --> Helper loaded: date_helper
INFO - 2016-08-11 16:57:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 16:57:28 --> Database Driver Class Initialized
INFO - 2016-08-11 16:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 16:57:28 --> Email Class Initialized
INFO - 2016-08-11 16:57:28 --> Model Class Initialized
INFO - 2016-08-11 16:57:28 --> Controller Class Initialized
INFO - 2016-08-11 16:57:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 16:57:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 16:57:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 16:57:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 16:57:28 --> Final output sent to browser
DEBUG - 2016-08-11 16:57:28 --> Total execution time: 0.4922
INFO - 2016-08-11 17:01:46 --> Config Class Initialized
INFO - 2016-08-11 17:01:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 17:01:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 17:01:46 --> Utf8 Class Initialized
INFO - 2016-08-11 17:01:46 --> URI Class Initialized
INFO - 2016-08-11 17:01:46 --> Router Class Initialized
INFO - 2016-08-11 17:01:46 --> Output Class Initialized
INFO - 2016-08-11 17:01:46 --> Security Class Initialized
DEBUG - 2016-08-11 17:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 17:01:46 --> Input Class Initialized
INFO - 2016-08-11 17:01:46 --> Language Class Initialized
INFO - 2016-08-11 17:01:46 --> Loader Class Initialized
INFO - 2016-08-11 17:01:46 --> Helper loaded: url_helper
INFO - 2016-08-11 17:01:46 --> Helper loaded: date_helper
INFO - 2016-08-11 17:01:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 17:01:46 --> Database Driver Class Initialized
INFO - 2016-08-11 17:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 17:01:46 --> Email Class Initialized
INFO - 2016-08-11 17:01:46 --> Model Class Initialized
INFO - 2016-08-11 17:01:46 --> Controller Class Initialized
INFO - 2016-08-11 17:01:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 17:01:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 17:01:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 17:01:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 17:01:46 --> Final output sent to browser
DEBUG - 2016-08-11 17:01:47 --> Total execution time: 0.4785
INFO - 2016-08-11 18:04:41 --> Config Class Initialized
INFO - 2016-08-11 18:04:41 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:04:41 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:04:41 --> Utf8 Class Initialized
INFO - 2016-08-11 18:04:41 --> URI Class Initialized
INFO - 2016-08-11 18:04:41 --> Router Class Initialized
INFO - 2016-08-11 18:04:41 --> Output Class Initialized
INFO - 2016-08-11 18:04:41 --> Security Class Initialized
DEBUG - 2016-08-11 18:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:04:41 --> Input Class Initialized
INFO - 2016-08-11 18:04:41 --> Language Class Initialized
INFO - 2016-08-11 18:04:41 --> Loader Class Initialized
INFO - 2016-08-11 18:04:41 --> Helper loaded: url_helper
INFO - 2016-08-11 18:04:41 --> Helper loaded: date_helper
INFO - 2016-08-11 18:04:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:04:41 --> Database Driver Class Initialized
INFO - 2016-08-11 18:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:04:41 --> Email Class Initialized
INFO - 2016-08-11 18:04:41 --> Model Class Initialized
INFO - 2016-08-11 18:04:41 --> Controller Class Initialized
INFO - 2016-08-11 18:04:41 --> Model Class Initialized
ERROR - 2016-08-11 18:04:41 --> Severity: Notice --> Undefined property: News::$pagination D:\xampp\htdocs\aqiqahsehati\application\controllers\News.php 38
ERROR - 2016-08-11 18:04:41 --> Severity: Error --> Call to a member function initialize() on a non-object D:\xampp\htdocs\aqiqahsehati\application\controllers\News.php 38
INFO - 2016-08-11 18:05:34 --> Config Class Initialized
INFO - 2016-08-11 18:05:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:05:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:05:34 --> Utf8 Class Initialized
INFO - 2016-08-11 18:05:34 --> URI Class Initialized
INFO - 2016-08-11 18:05:35 --> Router Class Initialized
INFO - 2016-08-11 18:05:35 --> Output Class Initialized
INFO - 2016-08-11 18:05:35 --> Security Class Initialized
DEBUG - 2016-08-11 18:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:05:35 --> Input Class Initialized
INFO - 2016-08-11 18:05:35 --> Language Class Initialized
INFO - 2016-08-11 18:05:35 --> Loader Class Initialized
INFO - 2016-08-11 18:05:35 --> Helper loaded: url_helper
INFO - 2016-08-11 18:05:35 --> Helper loaded: date_helper
INFO - 2016-08-11 18:05:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:05:35 --> Database Driver Class Initialized
INFO - 2016-08-11 18:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:05:35 --> Email Class Initialized
INFO - 2016-08-11 18:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:05:35 --> Pagination Class Initialized
INFO - 2016-08-11 18:05:35 --> Model Class Initialized
INFO - 2016-08-11 18:05:35 --> Controller Class Initialized
INFO - 2016-08-11 18:05:35 --> Model Class Initialized
INFO - 2016-08-11 18:05:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:05:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 18:05:35 --> Severity: Notice --> Undefined variable: news D:\xampp\htdocs\aqiqahsehati\application\views\news.php 92
ERROR - 2016-08-11 18:05:35 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\news.php 92
INFO - 2016-08-11 18:06:51 --> Config Class Initialized
INFO - 2016-08-11 18:06:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:06:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:06:51 --> Utf8 Class Initialized
INFO - 2016-08-11 18:06:51 --> URI Class Initialized
INFO - 2016-08-11 18:06:51 --> Router Class Initialized
INFO - 2016-08-11 18:06:51 --> Output Class Initialized
INFO - 2016-08-11 18:06:51 --> Security Class Initialized
DEBUG - 2016-08-11 18:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:06:51 --> Input Class Initialized
INFO - 2016-08-11 18:06:51 --> Language Class Initialized
INFO - 2016-08-11 18:06:51 --> Loader Class Initialized
INFO - 2016-08-11 18:06:51 --> Helper loaded: url_helper
INFO - 2016-08-11 18:06:51 --> Helper loaded: date_helper
INFO - 2016-08-11 18:06:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:06:51 --> Database Driver Class Initialized
INFO - 2016-08-11 18:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:06:51 --> Email Class Initialized
INFO - 2016-08-11 18:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:06:51 --> Pagination Class Initialized
INFO - 2016-08-11 18:06:51 --> Model Class Initialized
INFO - 2016-08-11 18:06:51 --> Controller Class Initialized
INFO - 2016-08-11 18:06:51 --> Model Class Initialized
INFO - 2016-08-11 18:06:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:06:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:06:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:06:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:06:51 --> Final output sent to browser
DEBUG - 2016-08-11 18:06:51 --> Total execution time: 0.5341
INFO - 2016-08-11 18:06:52 --> Config Class Initialized
INFO - 2016-08-11 18:06:52 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:06:52 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:06:52 --> Utf8 Class Initialized
INFO - 2016-08-11 18:06:52 --> URI Class Initialized
INFO - 2016-08-11 18:06:52 --> Router Class Initialized
INFO - 2016-08-11 18:06:52 --> Output Class Initialized
INFO - 2016-08-11 18:06:52 --> Security Class Initialized
DEBUG - 2016-08-11 18:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:06:52 --> Input Class Initialized
INFO - 2016-08-11 18:06:52 --> Language Class Initialized
ERROR - 2016-08-11 18:06:52 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 18:07:48 --> Config Class Initialized
INFO - 2016-08-11 18:07:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:07:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:07:48 --> Utf8 Class Initialized
INFO - 2016-08-11 18:07:48 --> URI Class Initialized
INFO - 2016-08-11 18:07:48 --> Router Class Initialized
INFO - 2016-08-11 18:07:48 --> Output Class Initialized
INFO - 2016-08-11 18:07:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:07:48 --> Input Class Initialized
INFO - 2016-08-11 18:07:48 --> Language Class Initialized
INFO - 2016-08-11 18:07:48 --> Loader Class Initialized
INFO - 2016-08-11 18:07:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:07:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:07:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:07:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:07:48 --> Email Class Initialized
INFO - 2016-08-11 18:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:07:48 --> Pagination Class Initialized
INFO - 2016-08-11 18:07:48 --> Model Class Initialized
INFO - 2016-08-11 18:07:48 --> Controller Class Initialized
INFO - 2016-08-11 18:07:48 --> Model Class Initialized
INFO - 2016-08-11 18:07:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:07:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:07:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:07:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:07:49 --> Final output sent to browser
DEBUG - 2016-08-11 18:07:49 --> Total execution time: 0.5804
INFO - 2016-08-11 18:10:15 --> Config Class Initialized
INFO - 2016-08-11 18:10:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:10:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:10:15 --> Utf8 Class Initialized
INFO - 2016-08-11 18:10:15 --> URI Class Initialized
INFO - 2016-08-11 18:10:15 --> Router Class Initialized
INFO - 2016-08-11 18:10:15 --> Output Class Initialized
INFO - 2016-08-11 18:10:15 --> Security Class Initialized
DEBUG - 2016-08-11 18:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:10:15 --> Input Class Initialized
INFO - 2016-08-11 18:10:15 --> Language Class Initialized
INFO - 2016-08-11 18:10:15 --> Loader Class Initialized
INFO - 2016-08-11 18:10:15 --> Helper loaded: url_helper
INFO - 2016-08-11 18:10:15 --> Helper loaded: date_helper
INFO - 2016-08-11 18:10:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:10:15 --> Database Driver Class Initialized
INFO - 2016-08-11 18:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:10:15 --> Email Class Initialized
INFO - 2016-08-11 18:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:10:15 --> Pagination Class Initialized
INFO - 2016-08-11 18:10:15 --> Model Class Initialized
INFO - 2016-08-11 18:10:15 --> Controller Class Initialized
INFO - 2016-08-11 18:10:15 --> Model Class Initialized
INFO - 2016-08-11 18:10:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:10:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:10:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:10:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:10:15 --> Final output sent to browser
DEBUG - 2016-08-11 18:10:15 --> Total execution time: 0.5761
INFO - 2016-08-11 18:10:38 --> Config Class Initialized
INFO - 2016-08-11 18:10:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:10:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:10:38 --> Utf8 Class Initialized
INFO - 2016-08-11 18:10:38 --> URI Class Initialized
INFO - 2016-08-11 18:10:38 --> Router Class Initialized
INFO - 2016-08-11 18:10:38 --> Output Class Initialized
INFO - 2016-08-11 18:10:38 --> Security Class Initialized
DEBUG - 2016-08-11 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:10:38 --> Input Class Initialized
INFO - 2016-08-11 18:10:38 --> Language Class Initialized
INFO - 2016-08-11 18:10:38 --> Loader Class Initialized
INFO - 2016-08-11 18:10:38 --> Helper loaded: url_helper
INFO - 2016-08-11 18:10:38 --> Helper loaded: date_helper
INFO - 2016-08-11 18:10:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:10:38 --> Database Driver Class Initialized
INFO - 2016-08-11 18:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:10:38 --> Email Class Initialized
INFO - 2016-08-11 18:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:10:39 --> Pagination Class Initialized
INFO - 2016-08-11 18:10:39 --> Model Class Initialized
INFO - 2016-08-11 18:10:39 --> Controller Class Initialized
INFO - 2016-08-11 18:10:39 --> Model Class Initialized
INFO - 2016-08-11 18:10:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:10:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:10:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:10:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:10:39 --> Final output sent to browser
DEBUG - 2016-08-11 18:10:39 --> Total execution time: 0.6644
INFO - 2016-08-11 18:15:23 --> Config Class Initialized
INFO - 2016-08-11 18:15:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:15:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:15:24 --> Utf8 Class Initialized
INFO - 2016-08-11 18:15:24 --> URI Class Initialized
INFO - 2016-08-11 18:15:24 --> Router Class Initialized
INFO - 2016-08-11 18:15:24 --> Output Class Initialized
INFO - 2016-08-11 18:15:24 --> Security Class Initialized
DEBUG - 2016-08-11 18:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:15:24 --> Input Class Initialized
INFO - 2016-08-11 18:15:24 --> Language Class Initialized
INFO - 2016-08-11 18:15:24 --> Loader Class Initialized
INFO - 2016-08-11 18:15:24 --> Helper loaded: url_helper
INFO - 2016-08-11 18:15:24 --> Helper loaded: date_helper
INFO - 2016-08-11 18:15:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:15:24 --> Database Driver Class Initialized
INFO - 2016-08-11 18:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:15:24 --> Email Class Initialized
INFO - 2016-08-11 18:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:15:24 --> Pagination Class Initialized
INFO - 2016-08-11 18:15:24 --> Model Class Initialized
INFO - 2016-08-11 18:15:24 --> Controller Class Initialized
INFO - 2016-08-11 18:15:24 --> Model Class Initialized
INFO - 2016-08-11 18:15:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:15:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:15:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:15:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:15:24 --> Final output sent to browser
DEBUG - 2016-08-11 18:15:24 --> Total execution time: 0.6329
INFO - 2016-08-11 18:16:40 --> Config Class Initialized
INFO - 2016-08-11 18:16:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:16:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:16:40 --> Utf8 Class Initialized
INFO - 2016-08-11 18:16:40 --> URI Class Initialized
INFO - 2016-08-11 18:16:40 --> Router Class Initialized
INFO - 2016-08-11 18:16:40 --> Output Class Initialized
INFO - 2016-08-11 18:16:40 --> Security Class Initialized
DEBUG - 2016-08-11 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:16:40 --> Input Class Initialized
INFO - 2016-08-11 18:16:40 --> Language Class Initialized
INFO - 2016-08-11 18:16:40 --> Loader Class Initialized
INFO - 2016-08-11 18:16:40 --> Helper loaded: url_helper
INFO - 2016-08-11 18:16:40 --> Helper loaded: date_helper
INFO - 2016-08-11 18:16:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:16:40 --> Database Driver Class Initialized
INFO - 2016-08-11 18:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:16:40 --> Email Class Initialized
INFO - 2016-08-11 18:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:16:40 --> Pagination Class Initialized
INFO - 2016-08-11 18:16:40 --> Model Class Initialized
INFO - 2016-08-11 18:16:40 --> Controller Class Initialized
INFO - 2016-08-11 18:16:40 --> Model Class Initialized
INFO - 2016-08-11 18:16:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:16:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:16:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:16:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:16:40 --> Final output sent to browser
DEBUG - 2016-08-11 18:16:41 --> Total execution time: 0.5463
INFO - 2016-08-11 18:17:01 --> Config Class Initialized
INFO - 2016-08-11 18:17:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:01 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:01 --> URI Class Initialized
INFO - 2016-08-11 18:17:01 --> Router Class Initialized
INFO - 2016-08-11 18:17:01 --> Output Class Initialized
INFO - 2016-08-11 18:17:01 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:01 --> Input Class Initialized
INFO - 2016-08-11 18:17:01 --> Language Class Initialized
INFO - 2016-08-11 18:17:01 --> Loader Class Initialized
INFO - 2016-08-11 18:17:01 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:01 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:01 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:01 --> Email Class Initialized
INFO - 2016-08-11 18:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:01 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:01 --> Model Class Initialized
INFO - 2016-08-11 18:17:01 --> Controller Class Initialized
INFO - 2016-08-11 18:17:01 --> Model Class Initialized
INFO - 2016-08-11 18:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:17:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:17:01 --> Final output sent to browser
DEBUG - 2016-08-11 18:17:02 --> Total execution time: 0.5431
INFO - 2016-08-11 18:17:19 --> Config Class Initialized
INFO - 2016-08-11 18:17:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:19 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:19 --> URI Class Initialized
INFO - 2016-08-11 18:17:19 --> Router Class Initialized
INFO - 2016-08-11 18:17:19 --> Output Class Initialized
INFO - 2016-08-11 18:17:19 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:19 --> Input Class Initialized
INFO - 2016-08-11 18:17:19 --> Language Class Initialized
INFO - 2016-08-11 18:17:19 --> Loader Class Initialized
INFO - 2016-08-11 18:17:19 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:19 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:20 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:20 --> Email Class Initialized
INFO - 2016-08-11 18:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:20 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:20 --> Model Class Initialized
INFO - 2016-08-11 18:17:20 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:20 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:20 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:20 --> Model Class Initialized
INFO - 2016-08-11 18:17:20 --> Config Class Initialized
INFO - 2016-08-11 18:17:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:20 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:20 --> URI Class Initialized
INFO - 2016-08-11 18:17:20 --> Router Class Initialized
INFO - 2016-08-11 18:17:20 --> Output Class Initialized
INFO - 2016-08-11 18:17:20 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:20 --> Input Class Initialized
INFO - 2016-08-11 18:17:20 --> Language Class Initialized
INFO - 2016-08-11 18:17:20 --> Loader Class Initialized
INFO - 2016-08-11 18:17:20 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:20 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:20 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:20 --> Email Class Initialized
INFO - 2016-08-11 18:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:20 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:20 --> Model Class Initialized
INFO - 2016-08-11 18:17:20 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:20 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:20 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:20 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:20 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:20 --> Model Class Initialized
INFO - 2016-08-11 18:17:20 --> Helper loaded: form_helper
INFO - 2016-08-11 18:17:20 --> Form Validation Class Initialized
INFO - 2016-08-11 18:17:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 18:17:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 18:17:21 --> Final output sent to browser
DEBUG - 2016-08-11 18:17:21 --> Total execution time: 0.6825
INFO - 2016-08-11 18:17:26 --> Config Class Initialized
INFO - 2016-08-11 18:17:26 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:26 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:26 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:26 --> URI Class Initialized
INFO - 2016-08-11 18:17:26 --> Router Class Initialized
INFO - 2016-08-11 18:17:26 --> Output Class Initialized
INFO - 2016-08-11 18:17:26 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:26 --> Input Class Initialized
INFO - 2016-08-11 18:17:26 --> Language Class Initialized
INFO - 2016-08-11 18:17:26 --> Loader Class Initialized
INFO - 2016-08-11 18:17:26 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:26 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:27 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:27 --> Email Class Initialized
INFO - 2016-08-11 18:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:27 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:27 --> Model Class Initialized
INFO - 2016-08-11 18:17:27 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:27 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:27 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:27 --> Model Class Initialized
INFO - 2016-08-11 18:17:27 --> Helper loaded: form_helper
INFO - 2016-08-11 18:17:27 --> Form Validation Class Initialized
INFO - 2016-08-11 18:17:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 18:17:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 18:17:27 --> Config Class Initialized
INFO - 2016-08-11 18:17:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:27 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:27 --> URI Class Initialized
INFO - 2016-08-11 18:17:27 --> Router Class Initialized
INFO - 2016-08-11 18:17:27 --> Output Class Initialized
INFO - 2016-08-11 18:17:27 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:27 --> Input Class Initialized
INFO - 2016-08-11 18:17:27 --> Language Class Initialized
INFO - 2016-08-11 18:17:27 --> Loader Class Initialized
INFO - 2016-08-11 18:17:27 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:27 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:27 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:27 --> Email Class Initialized
INFO - 2016-08-11 18:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:27 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:28 --> Model Class Initialized
INFO - 2016-08-11 18:17:28 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:28 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:28 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:28 --> Model Class Initialized
INFO - 2016-08-11 18:17:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:17:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:17:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:17:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 18:17:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:17:28 --> Final output sent to browser
DEBUG - 2016-08-11 18:17:28 --> Total execution time: 0.7122
INFO - 2016-08-11 18:17:36 --> Config Class Initialized
INFO - 2016-08-11 18:17:36 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:36 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:36 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:36 --> URI Class Initialized
INFO - 2016-08-11 18:17:36 --> Router Class Initialized
INFO - 2016-08-11 18:17:36 --> Output Class Initialized
INFO - 2016-08-11 18:17:36 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:36 --> Input Class Initialized
INFO - 2016-08-11 18:17:36 --> Language Class Initialized
INFO - 2016-08-11 18:17:36 --> Loader Class Initialized
INFO - 2016-08-11 18:17:36 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:36 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:36 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:36 --> Email Class Initialized
INFO - 2016-08-11 18:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:36 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:36 --> Model Class Initialized
INFO - 2016-08-11 18:17:36 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:36 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:36 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:36 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:36 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:37 --> Model Class Initialized
INFO - 2016-08-11 18:17:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:17:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:17:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:17:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 18:17:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:17:37 --> Final output sent to browser
DEBUG - 2016-08-11 18:17:37 --> Total execution time: 0.6953
INFO - 2016-08-11 18:17:47 --> Config Class Initialized
INFO - 2016-08-11 18:17:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:17:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:17:47 --> Utf8 Class Initialized
INFO - 2016-08-11 18:17:47 --> URI Class Initialized
INFO - 2016-08-11 18:17:47 --> Router Class Initialized
INFO - 2016-08-11 18:17:48 --> Output Class Initialized
INFO - 2016-08-11 18:17:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:17:48 --> Input Class Initialized
INFO - 2016-08-11 18:17:48 --> Language Class Initialized
INFO - 2016-08-11 18:17:48 --> Loader Class Initialized
INFO - 2016-08-11 18:17:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:17:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:17:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:17:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:17:48 --> Email Class Initialized
INFO - 2016-08-11 18:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:17:48 --> Pagination Class Initialized
INFO - 2016-08-11 18:17:48 --> Model Class Initialized
INFO - 2016-08-11 18:17:48 --> Controller Class Initialized
DEBUG - 2016-08-11 18:17:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:17:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:17:48 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:17:48 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:17:48 --> Model Class Initialized
INFO - 2016-08-11 18:17:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:17:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:17:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:17:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 18:17:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:17:48 --> Final output sent to browser
DEBUG - 2016-08-11 18:17:48 --> Total execution time: 0.6983
INFO - 2016-08-11 18:18:25 --> Config Class Initialized
INFO - 2016-08-11 18:18:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:25 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:25 --> URI Class Initialized
INFO - 2016-08-11 18:18:25 --> Router Class Initialized
INFO - 2016-08-11 18:18:25 --> Output Class Initialized
INFO - 2016-08-11 18:18:25 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:25 --> Input Class Initialized
INFO - 2016-08-11 18:18:25 --> Language Class Initialized
INFO - 2016-08-11 18:18:25 --> Loader Class Initialized
INFO - 2016-08-11 18:18:25 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:25 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:25 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:25 --> Email Class Initialized
INFO - 2016-08-11 18:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:25 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:25 --> Model Class Initialized
INFO - 2016-08-11 18:18:25 --> Controller Class Initialized
DEBUG - 2016-08-11 18:18:25 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:18:25 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:18:25 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:18:25 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:25 --> Model Class Initialized
INFO - 2016-08-11 18:18:25 --> Upload Class Initialized
INFO - 2016-08-11 18:18:25 --> Config Class Initialized
INFO - 2016-08-11 18:18:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:25 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:25 --> URI Class Initialized
INFO - 2016-08-11 18:18:25 --> Router Class Initialized
INFO - 2016-08-11 18:18:25 --> Output Class Initialized
INFO - 2016-08-11 18:18:25 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:25 --> Input Class Initialized
INFO - 2016-08-11 18:18:26 --> Language Class Initialized
INFO - 2016-08-11 18:18:26 --> Loader Class Initialized
INFO - 2016-08-11 18:18:26 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:26 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:26 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:26 --> Email Class Initialized
INFO - 2016-08-11 18:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:26 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:26 --> Model Class Initialized
INFO - 2016-08-11 18:18:26 --> Controller Class Initialized
DEBUG - 2016-08-11 18:18:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:18:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:18:26 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:18:26 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:26 --> Model Class Initialized
INFO - 2016-08-11 18:18:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:18:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:18:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:18:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 18:18:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:18:26 --> Final output sent to browser
DEBUG - 2016-08-11 18:18:26 --> Total execution time: 0.7000
INFO - 2016-08-11 18:18:28 --> Config Class Initialized
INFO - 2016-08-11 18:18:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:28 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:28 --> URI Class Initialized
INFO - 2016-08-11 18:18:28 --> Router Class Initialized
INFO - 2016-08-11 18:18:28 --> Output Class Initialized
INFO - 2016-08-11 18:18:28 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:28 --> Input Class Initialized
INFO - 2016-08-11 18:18:28 --> Language Class Initialized
INFO - 2016-08-11 18:18:28 --> Loader Class Initialized
INFO - 2016-08-11 18:18:28 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:28 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:28 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:28 --> Email Class Initialized
INFO - 2016-08-11 18:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:28 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:28 --> Model Class Initialized
INFO - 2016-08-11 18:18:28 --> Controller Class Initialized
DEBUG - 2016-08-11 18:18:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:18:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:18:28 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:18:28 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:28 --> Model Class Initialized
INFO - 2016-08-11 18:18:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:18:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:18:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:18:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-11 18:18:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:18:29 --> Final output sent to browser
DEBUG - 2016-08-11 18:18:29 --> Total execution time: 0.7201
INFO - 2016-08-11 18:18:34 --> Config Class Initialized
INFO - 2016-08-11 18:18:34 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:34 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:34 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:34 --> URI Class Initialized
INFO - 2016-08-11 18:18:34 --> Router Class Initialized
INFO - 2016-08-11 18:18:34 --> Output Class Initialized
INFO - 2016-08-11 18:18:34 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:34 --> Input Class Initialized
INFO - 2016-08-11 18:18:34 --> Language Class Initialized
INFO - 2016-08-11 18:18:34 --> Loader Class Initialized
INFO - 2016-08-11 18:18:34 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:34 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:34 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:34 --> Email Class Initialized
INFO - 2016-08-11 18:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:35 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:35 --> Model Class Initialized
INFO - 2016-08-11 18:18:35 --> Controller Class Initialized
DEBUG - 2016-08-11 18:18:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:18:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:18:35 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:18:35 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:35 --> Model Class Initialized
INFO - 2016-08-11 18:18:35 --> Upload Class Initialized
INFO - 2016-08-11 18:18:35 --> Config Class Initialized
INFO - 2016-08-11 18:18:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:35 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:35 --> URI Class Initialized
INFO - 2016-08-11 18:18:35 --> Router Class Initialized
INFO - 2016-08-11 18:18:35 --> Output Class Initialized
INFO - 2016-08-11 18:18:35 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:35 --> Input Class Initialized
INFO - 2016-08-11 18:18:35 --> Language Class Initialized
INFO - 2016-08-11 18:18:35 --> Loader Class Initialized
INFO - 2016-08-11 18:18:35 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:35 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:35 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:35 --> Email Class Initialized
INFO - 2016-08-11 18:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:35 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:35 --> Model Class Initialized
INFO - 2016-08-11 18:18:35 --> Controller Class Initialized
DEBUG - 2016-08-11 18:18:35 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:18:35 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:18:35 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:18:35 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:18:35 --> Model Class Initialized
INFO - 2016-08-11 18:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:18:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 18:18:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:18:36 --> Final output sent to browser
DEBUG - 2016-08-11 18:18:36 --> Total execution time: 0.6905
INFO - 2016-08-11 18:18:44 --> Config Class Initialized
INFO - 2016-08-11 18:18:44 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:18:44 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:18:44 --> Utf8 Class Initialized
INFO - 2016-08-11 18:18:44 --> URI Class Initialized
INFO - 2016-08-11 18:18:44 --> Router Class Initialized
INFO - 2016-08-11 18:18:44 --> Output Class Initialized
INFO - 2016-08-11 18:18:44 --> Security Class Initialized
DEBUG - 2016-08-11 18:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:18:44 --> Input Class Initialized
INFO - 2016-08-11 18:18:44 --> Language Class Initialized
INFO - 2016-08-11 18:18:44 --> Loader Class Initialized
INFO - 2016-08-11 18:18:44 --> Helper loaded: url_helper
INFO - 2016-08-11 18:18:44 --> Helper loaded: date_helper
INFO - 2016-08-11 18:18:44 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:18:44 --> Database Driver Class Initialized
INFO - 2016-08-11 18:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:18:44 --> Email Class Initialized
INFO - 2016-08-11 18:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:18:44 --> Pagination Class Initialized
INFO - 2016-08-11 18:18:44 --> Model Class Initialized
INFO - 2016-08-11 18:18:44 --> Controller Class Initialized
INFO - 2016-08-11 18:18:44 --> Model Class Initialized
INFO - 2016-08-11 18:18:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:18:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:18:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:18:44 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:18:44 --> Final output sent to browser
DEBUG - 2016-08-11 18:18:44 --> Total execution time: 0.5753
INFO - 2016-08-11 18:22:08 --> Config Class Initialized
INFO - 2016-08-11 18:22:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:22:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:22:08 --> Utf8 Class Initialized
INFO - 2016-08-11 18:22:08 --> URI Class Initialized
INFO - 2016-08-11 18:22:08 --> Router Class Initialized
INFO - 2016-08-11 18:22:08 --> Output Class Initialized
INFO - 2016-08-11 18:22:08 --> Security Class Initialized
DEBUG - 2016-08-11 18:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:22:08 --> Input Class Initialized
INFO - 2016-08-11 18:22:08 --> Language Class Initialized
INFO - 2016-08-11 18:22:08 --> Loader Class Initialized
INFO - 2016-08-11 18:22:08 --> Helper loaded: url_helper
INFO - 2016-08-11 18:22:08 --> Helper loaded: date_helper
INFO - 2016-08-11 18:22:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:22:08 --> Database Driver Class Initialized
INFO - 2016-08-11 18:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:22:08 --> Email Class Initialized
INFO - 2016-08-11 18:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:22:08 --> Pagination Class Initialized
INFO - 2016-08-11 18:22:08 --> Model Class Initialized
INFO - 2016-08-11 18:22:08 --> Controller Class Initialized
INFO - 2016-08-11 18:22:08 --> Model Class Initialized
INFO - 2016-08-11 18:22:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:22:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:22:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:22:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:22:09 --> Final output sent to browser
DEBUG - 2016-08-11 18:22:09 --> Total execution time: 0.5605
INFO - 2016-08-11 18:24:18 --> Config Class Initialized
INFO - 2016-08-11 18:24:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:24:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:24:18 --> Utf8 Class Initialized
INFO - 2016-08-11 18:24:18 --> URI Class Initialized
INFO - 2016-08-11 18:24:18 --> Router Class Initialized
INFO - 2016-08-11 18:24:18 --> Output Class Initialized
INFO - 2016-08-11 18:24:18 --> Security Class Initialized
DEBUG - 2016-08-11 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:24:18 --> Input Class Initialized
INFO - 2016-08-11 18:24:18 --> Language Class Initialized
INFO - 2016-08-11 18:24:18 --> Loader Class Initialized
INFO - 2016-08-11 18:24:18 --> Helper loaded: url_helper
INFO - 2016-08-11 18:24:18 --> Helper loaded: date_helper
INFO - 2016-08-11 18:24:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:24:18 --> Database Driver Class Initialized
INFO - 2016-08-11 18:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:24:18 --> Email Class Initialized
INFO - 2016-08-11 18:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:24:18 --> Pagination Class Initialized
INFO - 2016-08-11 18:24:18 --> Model Class Initialized
INFO - 2016-08-11 18:24:18 --> Controller Class Initialized
DEBUG - 2016-08-11 18:24:18 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:24:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:24:18 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:24:19 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:19 --> Model Class Initialized
INFO - 2016-08-11 18:24:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:24:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:24:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:24:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 18:24:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:24:19 --> Final output sent to browser
DEBUG - 2016-08-11 18:24:19 --> Total execution time: 0.7131
INFO - 2016-08-11 18:24:47 --> Config Class Initialized
INFO - 2016-08-11 18:24:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:24:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:24:47 --> Utf8 Class Initialized
INFO - 2016-08-11 18:24:48 --> URI Class Initialized
INFO - 2016-08-11 18:24:48 --> Router Class Initialized
INFO - 2016-08-11 18:24:48 --> Output Class Initialized
INFO - 2016-08-11 18:24:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:24:48 --> Input Class Initialized
INFO - 2016-08-11 18:24:48 --> Language Class Initialized
INFO - 2016-08-11 18:24:48 --> Loader Class Initialized
INFO - 2016-08-11 18:24:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:24:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:24:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:24:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:24:48 --> Email Class Initialized
INFO - 2016-08-11 18:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:24:48 --> Pagination Class Initialized
INFO - 2016-08-11 18:24:48 --> Model Class Initialized
INFO - 2016-08-11 18:24:48 --> Controller Class Initialized
DEBUG - 2016-08-11 18:24:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:24:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:24:48 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:24:48 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:48 --> Model Class Initialized
INFO - 2016-08-11 18:24:48 --> Upload Class Initialized
INFO - 2016-08-11 18:24:48 --> Config Class Initialized
INFO - 2016-08-11 18:24:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:24:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:24:48 --> Utf8 Class Initialized
INFO - 2016-08-11 18:24:48 --> URI Class Initialized
INFO - 2016-08-11 18:24:48 --> Router Class Initialized
INFO - 2016-08-11 18:24:48 --> Output Class Initialized
INFO - 2016-08-11 18:24:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:24:48 --> Input Class Initialized
INFO - 2016-08-11 18:24:48 --> Language Class Initialized
INFO - 2016-08-11 18:24:48 --> Loader Class Initialized
INFO - 2016-08-11 18:24:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:24:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:24:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:24:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:24:49 --> Email Class Initialized
INFO - 2016-08-11 18:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:24:49 --> Pagination Class Initialized
INFO - 2016-08-11 18:24:49 --> Model Class Initialized
INFO - 2016-08-11 18:24:49 --> Controller Class Initialized
DEBUG - 2016-08-11 18:24:49 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:24:49 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:49 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:24:49 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:24:49 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:49 --> Model Class Initialized
INFO - 2016-08-11 18:24:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:24:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:24:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:24:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 18:24:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:24:49 --> Final output sent to browser
DEBUG - 2016-08-11 18:24:49 --> Total execution time: 0.7211
INFO - 2016-08-11 18:24:51 --> Config Class Initialized
INFO - 2016-08-11 18:24:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:24:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:24:51 --> Utf8 Class Initialized
INFO - 2016-08-11 18:24:51 --> URI Class Initialized
INFO - 2016-08-11 18:24:51 --> Router Class Initialized
INFO - 2016-08-11 18:24:51 --> Output Class Initialized
INFO - 2016-08-11 18:24:52 --> Security Class Initialized
DEBUG - 2016-08-11 18:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:24:52 --> Input Class Initialized
INFO - 2016-08-11 18:24:52 --> Language Class Initialized
INFO - 2016-08-11 18:24:52 --> Loader Class Initialized
INFO - 2016-08-11 18:24:52 --> Helper loaded: url_helper
INFO - 2016-08-11 18:24:52 --> Helper loaded: date_helper
INFO - 2016-08-11 18:24:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:24:52 --> Database Driver Class Initialized
INFO - 2016-08-11 18:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:24:52 --> Email Class Initialized
INFO - 2016-08-11 18:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:24:52 --> Pagination Class Initialized
INFO - 2016-08-11 18:24:52 --> Model Class Initialized
INFO - 2016-08-11 18:24:52 --> Controller Class Initialized
DEBUG - 2016-08-11 18:24:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:24:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:24:52 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:24:52 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:24:52 --> Model Class Initialized
INFO - 2016-08-11 18:24:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:24:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:24:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:24:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 18:24:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:24:52 --> Final output sent to browser
DEBUG - 2016-08-11 18:24:52 --> Total execution time: 0.7180
INFO - 2016-08-11 18:25:23 --> Config Class Initialized
INFO - 2016-08-11 18:25:23 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:23 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:23 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:23 --> URI Class Initialized
INFO - 2016-08-11 18:25:23 --> Router Class Initialized
INFO - 2016-08-11 18:25:23 --> Output Class Initialized
INFO - 2016-08-11 18:25:23 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:23 --> Input Class Initialized
INFO - 2016-08-11 18:25:23 --> Language Class Initialized
INFO - 2016-08-11 18:25:23 --> Loader Class Initialized
INFO - 2016-08-11 18:25:23 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:23 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:23 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:23 --> Email Class Initialized
INFO - 2016-08-11 18:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:23 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:23 --> Model Class Initialized
INFO - 2016-08-11 18:25:23 --> Controller Class Initialized
DEBUG - 2016-08-11 18:25:23 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:25:23 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:25:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:25:23 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:25:23 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:25:23 --> Model Class Initialized
INFO - 2016-08-11 18:25:23 --> Upload Class Initialized
INFO - 2016-08-11 18:25:24 --> Config Class Initialized
INFO - 2016-08-11 18:25:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:24 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:24 --> URI Class Initialized
INFO - 2016-08-11 18:25:24 --> Router Class Initialized
INFO - 2016-08-11 18:25:24 --> Output Class Initialized
INFO - 2016-08-11 18:25:24 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:24 --> Input Class Initialized
INFO - 2016-08-11 18:25:24 --> Language Class Initialized
INFO - 2016-08-11 18:25:24 --> Loader Class Initialized
INFO - 2016-08-11 18:25:24 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:24 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:24 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:24 --> Email Class Initialized
INFO - 2016-08-11 18:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:24 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:24 --> Model Class Initialized
INFO - 2016-08-11 18:25:24 --> Controller Class Initialized
DEBUG - 2016-08-11 18:25:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 18:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:25:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 18:25:24 --> Helper loaded: cookie_helper
INFO - 2016-08-11 18:25:24 --> Helper loaded: language_helper
DEBUG - 2016-08-11 18:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 18:25:24 --> Model Class Initialized
INFO - 2016-08-11 18:25:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 18:25:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 18:25:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 18:25:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 18:25:24 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 18:25:24 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:24 --> Total execution time: 0.7759
INFO - 2016-08-11 18:25:37 --> Config Class Initialized
INFO - 2016-08-11 18:25:37 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:37 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:37 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:37 --> URI Class Initialized
INFO - 2016-08-11 18:25:37 --> Router Class Initialized
INFO - 2016-08-11 18:25:37 --> Output Class Initialized
INFO - 2016-08-11 18:25:37 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:37 --> Input Class Initialized
INFO - 2016-08-11 18:25:37 --> Language Class Initialized
INFO - 2016-08-11 18:25:37 --> Loader Class Initialized
INFO - 2016-08-11 18:25:37 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:37 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:37 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:37 --> Email Class Initialized
INFO - 2016-08-11 18:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:37 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:37 --> Model Class Initialized
INFO - 2016-08-11 18:25:37 --> Controller Class Initialized
INFO - 2016-08-11 18:25:37 --> Model Class Initialized
INFO - 2016-08-11 18:25:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:25:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:25:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:25:37 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:25:37 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:37 --> Total execution time: 0.6304
INFO - 2016-08-11 18:25:45 --> Config Class Initialized
INFO - 2016-08-11 18:25:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:45 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:45 --> URI Class Initialized
INFO - 2016-08-11 18:25:45 --> Router Class Initialized
INFO - 2016-08-11 18:25:45 --> Output Class Initialized
INFO - 2016-08-11 18:25:45 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:45 --> Input Class Initialized
INFO - 2016-08-11 18:25:45 --> Language Class Initialized
INFO - 2016-08-11 18:25:45 --> Loader Class Initialized
INFO - 2016-08-11 18:25:45 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:45 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:45 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:45 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:45 --> Email Class Initialized
INFO - 2016-08-11 18:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:45 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:45 --> Model Class Initialized
INFO - 2016-08-11 18:25:45 --> Controller Class Initialized
INFO - 2016-08-11 18:25:45 --> Model Class Initialized
INFO - 2016-08-11 18:25:45 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:45 --> Total execution time: 0.5190
INFO - 2016-08-11 18:25:47 --> Config Class Initialized
INFO - 2016-08-11 18:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:47 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:47 --> URI Class Initialized
INFO - 2016-08-11 18:25:47 --> Router Class Initialized
INFO - 2016-08-11 18:25:47 --> Output Class Initialized
INFO - 2016-08-11 18:25:47 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:47 --> Input Class Initialized
INFO - 2016-08-11 18:25:47 --> Language Class Initialized
INFO - 2016-08-11 18:25:47 --> Loader Class Initialized
INFO - 2016-08-11 18:25:47 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:47 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:47 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:47 --> Email Class Initialized
INFO - 2016-08-11 18:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:47 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:47 --> Model Class Initialized
INFO - 2016-08-11 18:25:47 --> Controller Class Initialized
INFO - 2016-08-11 18:25:47 --> Model Class Initialized
INFO - 2016-08-11 18:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:25:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:25:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:25:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:25:48 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:48 --> Total execution time: 0.5751
INFO - 2016-08-11 18:25:50 --> Config Class Initialized
INFO - 2016-08-11 18:25:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:50 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:50 --> URI Class Initialized
INFO - 2016-08-11 18:25:50 --> Router Class Initialized
INFO - 2016-08-11 18:25:50 --> Output Class Initialized
INFO - 2016-08-11 18:25:50 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:50 --> Input Class Initialized
INFO - 2016-08-11 18:25:50 --> Language Class Initialized
INFO - 2016-08-11 18:25:50 --> Loader Class Initialized
INFO - 2016-08-11 18:25:50 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:50 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:50 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:50 --> Email Class Initialized
INFO - 2016-08-11 18:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:50 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:50 --> Model Class Initialized
INFO - 2016-08-11 18:25:50 --> Controller Class Initialized
INFO - 2016-08-11 18:25:50 --> Model Class Initialized
INFO - 2016-08-11 18:25:50 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:50 --> Total execution time: 0.4902
INFO - 2016-08-11 18:25:52 --> Config Class Initialized
INFO - 2016-08-11 18:25:52 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:25:52 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:25:52 --> Utf8 Class Initialized
INFO - 2016-08-11 18:25:52 --> URI Class Initialized
INFO - 2016-08-11 18:25:52 --> Router Class Initialized
INFO - 2016-08-11 18:25:52 --> Output Class Initialized
INFO - 2016-08-11 18:25:52 --> Security Class Initialized
DEBUG - 2016-08-11 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:25:52 --> Input Class Initialized
INFO - 2016-08-11 18:25:52 --> Language Class Initialized
INFO - 2016-08-11 18:25:52 --> Loader Class Initialized
INFO - 2016-08-11 18:25:52 --> Helper loaded: url_helper
INFO - 2016-08-11 18:25:52 --> Helper loaded: date_helper
INFO - 2016-08-11 18:25:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:25:52 --> Database Driver Class Initialized
INFO - 2016-08-11 18:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:25:52 --> Email Class Initialized
INFO - 2016-08-11 18:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:25:52 --> Pagination Class Initialized
INFO - 2016-08-11 18:25:52 --> Model Class Initialized
INFO - 2016-08-11 18:25:52 --> Controller Class Initialized
INFO - 2016-08-11 18:25:52 --> Model Class Initialized
INFO - 2016-08-11 18:25:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:25:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:25:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:25:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:25:52 --> Final output sent to browser
DEBUG - 2016-08-11 18:25:52 --> Total execution time: 0.5815
INFO - 2016-08-11 18:26:18 --> Config Class Initialized
INFO - 2016-08-11 18:26:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:26:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:26:18 --> Utf8 Class Initialized
INFO - 2016-08-11 18:26:18 --> URI Class Initialized
INFO - 2016-08-11 18:26:18 --> Router Class Initialized
INFO - 2016-08-11 18:26:18 --> Output Class Initialized
INFO - 2016-08-11 18:26:18 --> Security Class Initialized
DEBUG - 2016-08-11 18:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:26:18 --> Input Class Initialized
INFO - 2016-08-11 18:26:18 --> Language Class Initialized
INFO - 2016-08-11 18:26:18 --> Loader Class Initialized
INFO - 2016-08-11 18:26:18 --> Helper loaded: url_helper
INFO - 2016-08-11 18:26:18 --> Helper loaded: date_helper
INFO - 2016-08-11 18:26:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:26:18 --> Database Driver Class Initialized
INFO - 2016-08-11 18:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:26:18 --> Email Class Initialized
INFO - 2016-08-11 18:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:26:18 --> Pagination Class Initialized
INFO - 2016-08-11 18:26:18 --> Model Class Initialized
INFO - 2016-08-11 18:26:18 --> Controller Class Initialized
INFO - 2016-08-11 18:26:18 --> Model Class Initialized
INFO - 2016-08-11 18:26:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:26:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:26:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:26:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:26:18 --> Final output sent to browser
DEBUG - 2016-08-11 18:26:18 --> Total execution time: 0.5926
INFO - 2016-08-11 18:26:20 --> Config Class Initialized
INFO - 2016-08-11 18:26:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:26:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:26:20 --> Utf8 Class Initialized
INFO - 2016-08-11 18:26:20 --> URI Class Initialized
INFO - 2016-08-11 18:26:20 --> Router Class Initialized
INFO - 2016-08-11 18:26:20 --> Output Class Initialized
INFO - 2016-08-11 18:26:20 --> Security Class Initialized
DEBUG - 2016-08-11 18:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:26:20 --> Input Class Initialized
INFO - 2016-08-11 18:26:20 --> Language Class Initialized
ERROR - 2016-08-11 18:26:20 --> 404 Page Not Found: News/3
INFO - 2016-08-11 18:26:22 --> Config Class Initialized
INFO - 2016-08-11 18:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:26:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:26:22 --> Utf8 Class Initialized
INFO - 2016-08-11 18:26:22 --> URI Class Initialized
INFO - 2016-08-11 18:26:23 --> Router Class Initialized
INFO - 2016-08-11 18:26:23 --> Output Class Initialized
INFO - 2016-08-11 18:26:23 --> Security Class Initialized
DEBUG - 2016-08-11 18:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:26:23 --> Input Class Initialized
INFO - 2016-08-11 18:26:23 --> Language Class Initialized
INFO - 2016-08-11 18:26:23 --> Loader Class Initialized
INFO - 2016-08-11 18:26:23 --> Helper loaded: url_helper
INFO - 2016-08-11 18:26:23 --> Helper loaded: date_helper
INFO - 2016-08-11 18:26:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:26:23 --> Database Driver Class Initialized
INFO - 2016-08-11 18:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:26:23 --> Email Class Initialized
INFO - 2016-08-11 18:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:26:23 --> Pagination Class Initialized
INFO - 2016-08-11 18:26:23 --> Model Class Initialized
INFO - 2016-08-11 18:26:23 --> Controller Class Initialized
INFO - 2016-08-11 18:26:23 --> Model Class Initialized
INFO - 2016-08-11 18:26:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:26:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:26:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:26:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:26:23 --> Final output sent to browser
DEBUG - 2016-08-11 18:26:23 --> Total execution time: 0.6042
INFO - 2016-08-11 18:27:35 --> Config Class Initialized
INFO - 2016-08-11 18:27:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:27:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:27:35 --> Utf8 Class Initialized
INFO - 2016-08-11 18:27:35 --> URI Class Initialized
INFO - 2016-08-11 18:27:35 --> Router Class Initialized
INFO - 2016-08-11 18:27:35 --> Output Class Initialized
INFO - 2016-08-11 18:27:35 --> Security Class Initialized
DEBUG - 2016-08-11 18:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:27:35 --> Input Class Initialized
INFO - 2016-08-11 18:27:35 --> Language Class Initialized
INFO - 2016-08-11 18:27:35 --> Loader Class Initialized
INFO - 2016-08-11 18:27:35 --> Helper loaded: url_helper
INFO - 2016-08-11 18:27:35 --> Helper loaded: date_helper
INFO - 2016-08-11 18:27:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:27:35 --> Database Driver Class Initialized
INFO - 2016-08-11 18:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:27:35 --> Email Class Initialized
INFO - 2016-08-11 18:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:27:35 --> Pagination Class Initialized
INFO - 2016-08-11 18:27:35 --> Model Class Initialized
INFO - 2016-08-11 18:27:35 --> Controller Class Initialized
INFO - 2016-08-11 18:27:35 --> Model Class Initialized
INFO - 2016-08-11 18:27:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:27:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:27:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:27:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:27:35 --> Final output sent to browser
DEBUG - 2016-08-11 18:27:35 --> Total execution time: 0.7202
INFO - 2016-08-11 18:27:40 --> Config Class Initialized
INFO - 2016-08-11 18:27:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:27:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:27:40 --> Utf8 Class Initialized
INFO - 2016-08-11 18:27:40 --> URI Class Initialized
INFO - 2016-08-11 18:27:40 --> Router Class Initialized
INFO - 2016-08-11 18:27:40 --> Output Class Initialized
INFO - 2016-08-11 18:27:40 --> Security Class Initialized
DEBUG - 2016-08-11 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:27:40 --> Input Class Initialized
INFO - 2016-08-11 18:27:40 --> Language Class Initialized
INFO - 2016-08-11 18:27:40 --> Loader Class Initialized
INFO - 2016-08-11 18:27:40 --> Helper loaded: url_helper
INFO - 2016-08-11 18:27:40 --> Helper loaded: date_helper
INFO - 2016-08-11 18:27:41 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:27:41 --> Database Driver Class Initialized
INFO - 2016-08-11 18:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:27:41 --> Email Class Initialized
INFO - 2016-08-11 18:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:27:41 --> Pagination Class Initialized
INFO - 2016-08-11 18:27:41 --> Model Class Initialized
INFO - 2016-08-11 18:27:41 --> Controller Class Initialized
INFO - 2016-08-11 18:27:41 --> Model Class Initialized
INFO - 2016-08-11 18:27:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:27:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:27:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:27:41 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:27:41 --> Final output sent to browser
DEBUG - 2016-08-11 18:27:41 --> Total execution time: 0.5949
INFO - 2016-08-11 18:27:47 --> Config Class Initialized
INFO - 2016-08-11 18:27:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:27:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:27:47 --> Utf8 Class Initialized
INFO - 2016-08-11 18:27:47 --> URI Class Initialized
INFO - 2016-08-11 18:27:47 --> Router Class Initialized
INFO - 2016-08-11 18:27:47 --> Output Class Initialized
INFO - 2016-08-11 18:27:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:27:48 --> Input Class Initialized
INFO - 2016-08-11 18:27:48 --> Language Class Initialized
INFO - 2016-08-11 18:27:48 --> Loader Class Initialized
INFO - 2016-08-11 18:27:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:27:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:27:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:27:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:27:48 --> Email Class Initialized
INFO - 2016-08-11 18:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:27:48 --> Pagination Class Initialized
INFO - 2016-08-11 18:27:48 --> Model Class Initialized
INFO - 2016-08-11 18:27:48 --> Controller Class Initialized
INFO - 2016-08-11 18:27:48 --> Model Class Initialized
INFO - 2016-08-11 18:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:27:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:27:48 --> Final output sent to browser
DEBUG - 2016-08-11 18:27:48 --> Total execution time: 0.6439
INFO - 2016-08-11 18:28:11 --> Config Class Initialized
INFO - 2016-08-11 18:28:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:28:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:28:11 --> Utf8 Class Initialized
INFO - 2016-08-11 18:28:11 --> URI Class Initialized
INFO - 2016-08-11 18:28:11 --> Router Class Initialized
INFO - 2016-08-11 18:28:11 --> Output Class Initialized
INFO - 2016-08-11 18:28:11 --> Security Class Initialized
DEBUG - 2016-08-11 18:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:28:12 --> Input Class Initialized
INFO - 2016-08-11 18:28:12 --> Language Class Initialized
INFO - 2016-08-11 18:28:12 --> Loader Class Initialized
INFO - 2016-08-11 18:28:12 --> Helper loaded: url_helper
INFO - 2016-08-11 18:28:12 --> Helper loaded: date_helper
INFO - 2016-08-11 18:28:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:28:12 --> Database Driver Class Initialized
INFO - 2016-08-11 18:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:28:12 --> Email Class Initialized
INFO - 2016-08-11 18:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:28:12 --> Pagination Class Initialized
INFO - 2016-08-11 18:28:12 --> Model Class Initialized
INFO - 2016-08-11 18:28:12 --> Controller Class Initialized
INFO - 2016-08-11 18:28:12 --> Model Class Initialized
INFO - 2016-08-11 18:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:28:12 --> Final output sent to browser
DEBUG - 2016-08-11 18:28:12 --> Total execution time: 0.5992
INFO - 2016-08-11 18:29:12 --> Config Class Initialized
INFO - 2016-08-11 18:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:29:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:29:12 --> Utf8 Class Initialized
INFO - 2016-08-11 18:29:12 --> URI Class Initialized
INFO - 2016-08-11 18:29:12 --> Router Class Initialized
INFO - 2016-08-11 18:29:13 --> Output Class Initialized
INFO - 2016-08-11 18:29:13 --> Security Class Initialized
DEBUG - 2016-08-11 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:29:13 --> Input Class Initialized
INFO - 2016-08-11 18:29:13 --> Language Class Initialized
INFO - 2016-08-11 18:29:13 --> Loader Class Initialized
INFO - 2016-08-11 18:29:13 --> Helper loaded: url_helper
INFO - 2016-08-11 18:29:13 --> Helper loaded: date_helper
INFO - 2016-08-11 18:29:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:29:13 --> Database Driver Class Initialized
INFO - 2016-08-11 18:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:29:13 --> Email Class Initialized
INFO - 2016-08-11 18:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:29:13 --> Pagination Class Initialized
INFO - 2016-08-11 18:29:13 --> Model Class Initialized
INFO - 2016-08-11 18:29:13 --> Controller Class Initialized
INFO - 2016-08-11 18:29:13 --> Model Class Initialized
INFO - 2016-08-11 18:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:29:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:29:13 --> Final output sent to browser
DEBUG - 2016-08-11 18:29:13 --> Total execution time: 0.6001
INFO - 2016-08-11 18:29:39 --> Config Class Initialized
INFO - 2016-08-11 18:29:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:29:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:29:39 --> Utf8 Class Initialized
INFO - 2016-08-11 18:29:39 --> URI Class Initialized
INFO - 2016-08-11 18:29:39 --> Router Class Initialized
INFO - 2016-08-11 18:29:39 --> Output Class Initialized
INFO - 2016-08-11 18:29:39 --> Security Class Initialized
DEBUG - 2016-08-11 18:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:29:39 --> Input Class Initialized
INFO - 2016-08-11 18:29:39 --> Language Class Initialized
INFO - 2016-08-11 18:29:39 --> Loader Class Initialized
INFO - 2016-08-11 18:29:39 --> Helper loaded: url_helper
INFO - 2016-08-11 18:29:39 --> Helper loaded: date_helper
INFO - 2016-08-11 18:29:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:29:39 --> Database Driver Class Initialized
INFO - 2016-08-11 18:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:29:39 --> Email Class Initialized
INFO - 2016-08-11 18:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:29:39 --> Pagination Class Initialized
INFO - 2016-08-11 18:29:39 --> Model Class Initialized
INFO - 2016-08-11 18:29:39 --> Controller Class Initialized
INFO - 2016-08-11 18:29:39 --> Model Class Initialized
INFO - 2016-08-11 18:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:29:39 --> Final output sent to browser
DEBUG - 2016-08-11 18:29:39 --> Total execution time: 0.5925
INFO - 2016-08-11 18:29:48 --> Config Class Initialized
INFO - 2016-08-11 18:29:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:29:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:29:48 --> Utf8 Class Initialized
INFO - 2016-08-11 18:29:48 --> URI Class Initialized
INFO - 2016-08-11 18:29:48 --> Router Class Initialized
INFO - 2016-08-11 18:29:48 --> Output Class Initialized
INFO - 2016-08-11 18:29:48 --> Security Class Initialized
DEBUG - 2016-08-11 18:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:29:48 --> Input Class Initialized
INFO - 2016-08-11 18:29:48 --> Language Class Initialized
INFO - 2016-08-11 18:29:48 --> Loader Class Initialized
INFO - 2016-08-11 18:29:48 --> Helper loaded: url_helper
INFO - 2016-08-11 18:29:48 --> Helper loaded: date_helper
INFO - 2016-08-11 18:29:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:29:48 --> Database Driver Class Initialized
INFO - 2016-08-11 18:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:29:48 --> Email Class Initialized
INFO - 2016-08-11 18:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:29:48 --> Pagination Class Initialized
INFO - 2016-08-11 18:29:48 --> Model Class Initialized
INFO - 2016-08-11 18:29:48 --> Controller Class Initialized
INFO - 2016-08-11 18:29:48 --> Model Class Initialized
INFO - 2016-08-11 18:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:29:48 --> Final output sent to browser
DEBUG - 2016-08-11 18:29:48 --> Total execution time: 0.6614
INFO - 2016-08-11 18:30:50 --> Config Class Initialized
INFO - 2016-08-11 18:30:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:30:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:30:50 --> Utf8 Class Initialized
INFO - 2016-08-11 18:30:50 --> URI Class Initialized
INFO - 2016-08-11 18:30:50 --> Router Class Initialized
INFO - 2016-08-11 18:30:50 --> Output Class Initialized
INFO - 2016-08-11 18:30:50 --> Security Class Initialized
DEBUG - 2016-08-11 18:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:30:50 --> Input Class Initialized
INFO - 2016-08-11 18:30:50 --> Language Class Initialized
INFO - 2016-08-11 18:30:50 --> Loader Class Initialized
INFO - 2016-08-11 18:30:50 --> Helper loaded: url_helper
INFO - 2016-08-11 18:30:50 --> Helper loaded: date_helper
INFO - 2016-08-11 18:30:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:30:50 --> Database Driver Class Initialized
INFO - 2016-08-11 18:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:30:50 --> Email Class Initialized
INFO - 2016-08-11 18:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:30:50 --> Pagination Class Initialized
INFO - 2016-08-11 18:30:50 --> Model Class Initialized
INFO - 2016-08-11 18:30:50 --> Controller Class Initialized
INFO - 2016-08-11 18:30:51 --> Model Class Initialized
INFO - 2016-08-11 18:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:30:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:30:51 --> Final output sent to browser
DEBUG - 2016-08-11 18:30:51 --> Total execution time: 0.6401
INFO - 2016-08-11 18:31:56 --> Config Class Initialized
INFO - 2016-08-11 18:31:56 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:31:56 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:31:56 --> Utf8 Class Initialized
INFO - 2016-08-11 18:31:56 --> URI Class Initialized
INFO - 2016-08-11 18:31:56 --> Router Class Initialized
INFO - 2016-08-11 18:31:56 --> Output Class Initialized
INFO - 2016-08-11 18:31:56 --> Security Class Initialized
DEBUG - 2016-08-11 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:31:56 --> Input Class Initialized
INFO - 2016-08-11 18:31:56 --> Language Class Initialized
INFO - 2016-08-11 18:31:56 --> Loader Class Initialized
INFO - 2016-08-11 18:31:56 --> Helper loaded: url_helper
INFO - 2016-08-11 18:31:56 --> Helper loaded: date_helper
INFO - 2016-08-11 18:31:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:31:56 --> Database Driver Class Initialized
INFO - 2016-08-11 18:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:31:57 --> Email Class Initialized
INFO - 2016-08-11 18:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:31:57 --> Pagination Class Initialized
INFO - 2016-08-11 18:31:57 --> Model Class Initialized
INFO - 2016-08-11 18:31:57 --> Controller Class Initialized
INFO - 2016-08-11 18:31:57 --> Model Class Initialized
INFO - 2016-08-11 18:31:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:31:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:31:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:31:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:31:57 --> Final output sent to browser
DEBUG - 2016-08-11 18:31:57 --> Total execution time: 0.5987
INFO - 2016-08-11 18:34:06 --> Config Class Initialized
INFO - 2016-08-11 18:34:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:34:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:34:06 --> Utf8 Class Initialized
INFO - 2016-08-11 18:34:06 --> URI Class Initialized
INFO - 2016-08-11 18:34:06 --> Router Class Initialized
INFO - 2016-08-11 18:34:06 --> Output Class Initialized
INFO - 2016-08-11 18:34:06 --> Security Class Initialized
DEBUG - 2016-08-11 18:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:34:06 --> Input Class Initialized
INFO - 2016-08-11 18:34:06 --> Language Class Initialized
INFO - 2016-08-11 18:34:06 --> Loader Class Initialized
INFO - 2016-08-11 18:34:07 --> Helper loaded: url_helper
INFO - 2016-08-11 18:34:07 --> Helper loaded: date_helper
INFO - 2016-08-11 18:34:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:34:07 --> Database Driver Class Initialized
INFO - 2016-08-11 18:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:34:07 --> Email Class Initialized
INFO - 2016-08-11 18:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:34:07 --> Pagination Class Initialized
INFO - 2016-08-11 18:34:07 --> Model Class Initialized
INFO - 2016-08-11 18:34:07 --> Controller Class Initialized
INFO - 2016-08-11 18:34:07 --> Model Class Initialized
INFO - 2016-08-11 18:34:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:34:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:34:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:34:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:34:07 --> Final output sent to browser
DEBUG - 2016-08-11 18:34:07 --> Total execution time: 0.6235
INFO - 2016-08-11 18:34:14 --> Config Class Initialized
INFO - 2016-08-11 18:34:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:34:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:34:14 --> Utf8 Class Initialized
INFO - 2016-08-11 18:34:14 --> URI Class Initialized
INFO - 2016-08-11 18:34:14 --> Router Class Initialized
INFO - 2016-08-11 18:34:14 --> Output Class Initialized
INFO - 2016-08-11 18:34:14 --> Security Class Initialized
DEBUG - 2016-08-11 18:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:34:14 --> Input Class Initialized
INFO - 2016-08-11 18:34:14 --> Language Class Initialized
INFO - 2016-08-11 18:34:14 --> Loader Class Initialized
INFO - 2016-08-11 18:34:14 --> Helper loaded: url_helper
INFO - 2016-08-11 18:34:14 --> Helper loaded: date_helper
INFO - 2016-08-11 18:34:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:34:14 --> Database Driver Class Initialized
INFO - 2016-08-11 18:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:34:14 --> Email Class Initialized
INFO - 2016-08-11 18:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:34:14 --> Pagination Class Initialized
INFO - 2016-08-11 18:34:14 --> Model Class Initialized
INFO - 2016-08-11 18:34:14 --> Controller Class Initialized
INFO - 2016-08-11 18:34:14 --> Model Class Initialized
INFO - 2016-08-11 18:34:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:34:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:34:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:34:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:34:15 --> Final output sent to browser
DEBUG - 2016-08-11 18:34:15 --> Total execution time: 0.6592
INFO - 2016-08-11 18:34:19 --> Config Class Initialized
INFO - 2016-08-11 18:34:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:34:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:34:19 --> Utf8 Class Initialized
INFO - 2016-08-11 18:34:19 --> URI Class Initialized
INFO - 2016-08-11 18:34:19 --> Router Class Initialized
INFO - 2016-08-11 18:34:19 --> Output Class Initialized
INFO - 2016-08-11 18:34:19 --> Security Class Initialized
DEBUG - 2016-08-11 18:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:34:19 --> Input Class Initialized
INFO - 2016-08-11 18:34:19 --> Language Class Initialized
INFO - 2016-08-11 18:34:19 --> Loader Class Initialized
INFO - 2016-08-11 18:34:19 --> Helper loaded: url_helper
INFO - 2016-08-11 18:34:19 --> Helper loaded: date_helper
INFO - 2016-08-11 18:34:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:34:19 --> Database Driver Class Initialized
INFO - 2016-08-11 18:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:34:19 --> Email Class Initialized
INFO - 2016-08-11 18:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:34:19 --> Pagination Class Initialized
INFO - 2016-08-11 18:34:19 --> Model Class Initialized
INFO - 2016-08-11 18:34:19 --> Controller Class Initialized
INFO - 2016-08-11 18:34:19 --> Model Class Initialized
INFO - 2016-08-11 18:34:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:34:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:34:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:34:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:34:19 --> Final output sent to browser
DEBUG - 2016-08-11 18:34:19 --> Total execution time: 0.6115
INFO - 2016-08-11 18:34:56 --> Config Class Initialized
INFO - 2016-08-11 18:34:56 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:34:56 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:34:56 --> Utf8 Class Initialized
INFO - 2016-08-11 18:34:56 --> URI Class Initialized
INFO - 2016-08-11 18:34:56 --> Router Class Initialized
INFO - 2016-08-11 18:34:56 --> Output Class Initialized
INFO - 2016-08-11 18:34:56 --> Security Class Initialized
DEBUG - 2016-08-11 18:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:34:56 --> Input Class Initialized
INFO - 2016-08-11 18:34:56 --> Language Class Initialized
INFO - 2016-08-11 18:34:56 --> Loader Class Initialized
INFO - 2016-08-11 18:34:56 --> Helper loaded: url_helper
INFO - 2016-08-11 18:34:56 --> Helper loaded: date_helper
INFO - 2016-08-11 18:34:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:34:56 --> Database Driver Class Initialized
INFO - 2016-08-11 18:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:34:56 --> Email Class Initialized
INFO - 2016-08-11 18:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:34:56 --> Pagination Class Initialized
INFO - 2016-08-11 18:34:56 --> Model Class Initialized
INFO - 2016-08-11 18:34:57 --> Controller Class Initialized
INFO - 2016-08-11 18:34:57 --> Model Class Initialized
INFO - 2016-08-11 18:34:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:34:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:34:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:34:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:34:57 --> Final output sent to browser
DEBUG - 2016-08-11 18:34:57 --> Total execution time: 0.6556
INFO - 2016-08-11 18:38:46 --> Config Class Initialized
INFO - 2016-08-11 18:38:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:38:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:38:46 --> Utf8 Class Initialized
INFO - 2016-08-11 18:38:46 --> URI Class Initialized
INFO - 2016-08-11 18:38:46 --> Router Class Initialized
INFO - 2016-08-11 18:38:46 --> Output Class Initialized
INFO - 2016-08-11 18:38:46 --> Security Class Initialized
DEBUG - 2016-08-11 18:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:38:46 --> Input Class Initialized
INFO - 2016-08-11 18:38:46 --> Language Class Initialized
INFO - 2016-08-11 18:38:46 --> Loader Class Initialized
INFO - 2016-08-11 18:38:46 --> Helper loaded: url_helper
INFO - 2016-08-11 18:38:46 --> Helper loaded: date_helper
INFO - 2016-08-11 18:38:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:38:47 --> Database Driver Class Initialized
INFO - 2016-08-11 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:38:47 --> Email Class Initialized
INFO - 2016-08-11 18:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:38:47 --> Pagination Class Initialized
INFO - 2016-08-11 18:38:47 --> Model Class Initialized
INFO - 2016-08-11 18:38:47 --> Controller Class Initialized
INFO - 2016-08-11 18:38:47 --> Model Class Initialized
INFO - 2016-08-11 18:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:38:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:38:47 --> Final output sent to browser
DEBUG - 2016-08-11 18:38:47 --> Total execution time: 0.6080
INFO - 2016-08-11 18:38:50 --> Config Class Initialized
INFO - 2016-08-11 18:38:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:38:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:38:50 --> Utf8 Class Initialized
INFO - 2016-08-11 18:38:50 --> URI Class Initialized
INFO - 2016-08-11 18:38:50 --> Router Class Initialized
INFO - 2016-08-11 18:38:50 --> Output Class Initialized
INFO - 2016-08-11 18:38:50 --> Security Class Initialized
DEBUG - 2016-08-11 18:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:38:50 --> Input Class Initialized
INFO - 2016-08-11 18:38:50 --> Language Class Initialized
INFO - 2016-08-11 18:38:50 --> Loader Class Initialized
INFO - 2016-08-11 18:38:50 --> Helper loaded: url_helper
INFO - 2016-08-11 18:38:50 --> Helper loaded: date_helper
INFO - 2016-08-11 18:38:50 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:38:51 --> Database Driver Class Initialized
INFO - 2016-08-11 18:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:38:51 --> Email Class Initialized
INFO - 2016-08-11 18:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:38:51 --> Pagination Class Initialized
INFO - 2016-08-11 18:38:51 --> Model Class Initialized
INFO - 2016-08-11 18:38:51 --> Controller Class Initialized
INFO - 2016-08-11 18:38:51 --> Model Class Initialized
INFO - 2016-08-11 18:38:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:38:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:38:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:38:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:38:51 --> Final output sent to browser
DEBUG - 2016-08-11 18:38:51 --> Total execution time: 0.6427
INFO - 2016-08-11 18:53:56 --> Config Class Initialized
INFO - 2016-08-11 18:53:57 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:53:57 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:53:57 --> Utf8 Class Initialized
INFO - 2016-08-11 18:53:57 --> URI Class Initialized
INFO - 2016-08-11 18:53:57 --> Router Class Initialized
INFO - 2016-08-11 18:53:57 --> Output Class Initialized
INFO - 2016-08-11 18:53:57 --> Security Class Initialized
DEBUG - 2016-08-11 18:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:53:57 --> Input Class Initialized
INFO - 2016-08-11 18:53:57 --> Language Class Initialized
INFO - 2016-08-11 18:53:57 --> Loader Class Initialized
INFO - 2016-08-11 18:53:57 --> Helper loaded: url_helper
INFO - 2016-08-11 18:53:57 --> Helper loaded: date_helper
INFO - 2016-08-11 18:53:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:53:57 --> Database Driver Class Initialized
INFO - 2016-08-11 18:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:53:57 --> Email Class Initialized
INFO - 2016-08-11 18:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:53:57 --> Pagination Class Initialized
INFO - 2016-08-11 18:53:57 --> Model Class Initialized
INFO - 2016-08-11 18:53:57 --> Controller Class Initialized
INFO - 2016-08-11 18:53:57 --> Model Class Initialized
INFO - 2016-08-11 18:53:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:53:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:53:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:53:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:53:57 --> Final output sent to browser
DEBUG - 2016-08-11 18:53:57 --> Total execution time: 0.6398
INFO - 2016-08-11 18:54:02 --> Config Class Initialized
INFO - 2016-08-11 18:54:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 18:54:02 --> UTF-8 Support Enabled
INFO - 2016-08-11 18:54:02 --> Utf8 Class Initialized
INFO - 2016-08-11 18:54:02 --> URI Class Initialized
INFO - 2016-08-11 18:54:02 --> Router Class Initialized
INFO - 2016-08-11 18:54:02 --> Output Class Initialized
INFO - 2016-08-11 18:54:02 --> Security Class Initialized
DEBUG - 2016-08-11 18:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 18:54:02 --> Input Class Initialized
INFO - 2016-08-11 18:54:02 --> Language Class Initialized
INFO - 2016-08-11 18:54:02 --> Loader Class Initialized
INFO - 2016-08-11 18:54:02 --> Helper loaded: url_helper
INFO - 2016-08-11 18:54:02 --> Helper loaded: date_helper
INFO - 2016-08-11 18:54:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 18:54:02 --> Database Driver Class Initialized
INFO - 2016-08-11 18:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 18:54:02 --> Email Class Initialized
INFO - 2016-08-11 18:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 18:54:02 --> Pagination Class Initialized
INFO - 2016-08-11 18:54:02 --> Model Class Initialized
INFO - 2016-08-11 18:54:02 --> Controller Class Initialized
INFO - 2016-08-11 18:54:02 --> Model Class Initialized
INFO - 2016-08-11 18:54:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 18:54:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 18:54:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 18:54:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 18:54:03 --> Final output sent to browser
DEBUG - 2016-08-11 18:54:03 --> Total execution time: 0.6006
INFO - 2016-08-11 21:02:35 --> Config Class Initialized
INFO - 2016-08-11 21:02:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:02:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:02:35 --> Utf8 Class Initialized
INFO - 2016-08-11 21:02:35 --> URI Class Initialized
DEBUG - 2016-08-11 21:02:35 --> No URI present. Default controller set.
INFO - 2016-08-11 21:02:35 --> Router Class Initialized
INFO - 2016-08-11 21:02:35 --> Output Class Initialized
INFO - 2016-08-11 21:02:35 --> Security Class Initialized
DEBUG - 2016-08-11 21:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:02:35 --> Input Class Initialized
INFO - 2016-08-11 21:02:35 --> Language Class Initialized
INFO - 2016-08-11 21:02:35 --> Loader Class Initialized
INFO - 2016-08-11 21:02:35 --> Helper loaded: url_helper
INFO - 2016-08-11 21:02:35 --> Helper loaded: date_helper
INFO - 2016-08-11 21:02:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:02:36 --> Database Driver Class Initialized
INFO - 2016-08-11 21:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:02:36 --> Email Class Initialized
INFO - 2016-08-11 21:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:02:36 --> Pagination Class Initialized
INFO - 2016-08-11 21:02:36 --> Model Class Initialized
INFO - 2016-08-11 21:02:36 --> Controller Class Initialized
INFO - 2016-08-11 21:02:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:02:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:02:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 21:02:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:02:36 --> Final output sent to browser
DEBUG - 2016-08-11 21:02:36 --> Total execution time: 0.8284
INFO - 2016-08-11 21:02:39 --> Config Class Initialized
INFO - 2016-08-11 21:02:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:02:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:02:39 --> Utf8 Class Initialized
INFO - 2016-08-11 21:02:39 --> URI Class Initialized
DEBUG - 2016-08-11 21:02:39 --> No URI present. Default controller set.
INFO - 2016-08-11 21:02:39 --> Router Class Initialized
INFO - 2016-08-11 21:02:39 --> Output Class Initialized
INFO - 2016-08-11 21:02:39 --> Security Class Initialized
DEBUG - 2016-08-11 21:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:02:39 --> Input Class Initialized
INFO - 2016-08-11 21:02:40 --> Language Class Initialized
INFO - 2016-08-11 21:02:40 --> Loader Class Initialized
INFO - 2016-08-11 21:02:40 --> Helper loaded: url_helper
INFO - 2016-08-11 21:02:40 --> Helper loaded: date_helper
INFO - 2016-08-11 21:02:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:02:40 --> Database Driver Class Initialized
INFO - 2016-08-11 21:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:02:40 --> Email Class Initialized
INFO - 2016-08-11 21:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:02:40 --> Pagination Class Initialized
INFO - 2016-08-11 21:02:40 --> Model Class Initialized
INFO - 2016-08-11 21:02:40 --> Controller Class Initialized
INFO - 2016-08-11 21:02:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:02:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:02:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 21:02:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:02:40 --> Final output sent to browser
DEBUG - 2016-08-11 21:02:40 --> Total execution time: 0.6197
INFO - 2016-08-11 21:02:50 --> Config Class Initialized
INFO - 2016-08-11 21:02:50 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:02:50 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:02:51 --> Utf8 Class Initialized
INFO - 2016-08-11 21:02:51 --> URI Class Initialized
DEBUG - 2016-08-11 21:02:51 --> No URI present. Default controller set.
INFO - 2016-08-11 21:02:51 --> Router Class Initialized
INFO - 2016-08-11 21:02:51 --> Output Class Initialized
INFO - 2016-08-11 21:02:51 --> Security Class Initialized
DEBUG - 2016-08-11 21:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:02:51 --> Input Class Initialized
INFO - 2016-08-11 21:02:51 --> Language Class Initialized
INFO - 2016-08-11 21:02:51 --> Loader Class Initialized
INFO - 2016-08-11 21:02:51 --> Helper loaded: url_helper
INFO - 2016-08-11 21:02:51 --> Helper loaded: date_helper
INFO - 2016-08-11 21:02:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:02:51 --> Database Driver Class Initialized
INFO - 2016-08-11 21:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:02:51 --> Email Class Initialized
INFO - 2016-08-11 21:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:02:51 --> Pagination Class Initialized
INFO - 2016-08-11 21:02:51 --> Model Class Initialized
INFO - 2016-08-11 21:02:51 --> Controller Class Initialized
INFO - 2016-08-11 21:02:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:02:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:02:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 21:02:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:02:51 --> Final output sent to browser
DEBUG - 2016-08-11 21:02:51 --> Total execution time: 0.6026
INFO - 2016-08-11 21:03:08 --> Config Class Initialized
INFO - 2016-08-11 21:03:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:03:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:03:08 --> Utf8 Class Initialized
INFO - 2016-08-11 21:03:08 --> URI Class Initialized
DEBUG - 2016-08-11 21:03:08 --> No URI present. Default controller set.
INFO - 2016-08-11 21:03:08 --> Router Class Initialized
INFO - 2016-08-11 21:03:08 --> Output Class Initialized
INFO - 2016-08-11 21:03:08 --> Security Class Initialized
DEBUG - 2016-08-11 21:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:03:08 --> Input Class Initialized
INFO - 2016-08-11 21:03:08 --> Language Class Initialized
INFO - 2016-08-11 21:03:08 --> Loader Class Initialized
INFO - 2016-08-11 21:03:08 --> Helper loaded: url_helper
INFO - 2016-08-11 21:03:08 --> Helper loaded: date_helper
INFO - 2016-08-11 21:03:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:03:08 --> Database Driver Class Initialized
INFO - 2016-08-11 21:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:03:08 --> Email Class Initialized
INFO - 2016-08-11 21:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:03:08 --> Pagination Class Initialized
INFO - 2016-08-11 21:03:08 --> Model Class Initialized
INFO - 2016-08-11 21:03:08 --> Controller Class Initialized
INFO - 2016-08-11 21:03:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:03:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:03:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 21:03:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:03:08 --> Final output sent to browser
DEBUG - 2016-08-11 21:03:09 --> Total execution time: 0.6063
INFO - 2016-08-11 21:03:18 --> Config Class Initialized
INFO - 2016-08-11 21:03:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:03:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:03:18 --> Utf8 Class Initialized
INFO - 2016-08-11 21:03:18 --> URI Class Initialized
DEBUG - 2016-08-11 21:03:18 --> No URI present. Default controller set.
INFO - 2016-08-11 21:03:18 --> Router Class Initialized
INFO - 2016-08-11 21:03:18 --> Output Class Initialized
INFO - 2016-08-11 21:03:18 --> Security Class Initialized
DEBUG - 2016-08-11 21:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:03:18 --> Input Class Initialized
INFO - 2016-08-11 21:03:18 --> Language Class Initialized
INFO - 2016-08-11 21:03:18 --> Loader Class Initialized
INFO - 2016-08-11 21:03:18 --> Helper loaded: url_helper
INFO - 2016-08-11 21:03:18 --> Helper loaded: date_helper
INFO - 2016-08-11 21:03:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:03:18 --> Database Driver Class Initialized
INFO - 2016-08-11 21:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:03:18 --> Email Class Initialized
INFO - 2016-08-11 21:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:03:18 --> Pagination Class Initialized
INFO - 2016-08-11 21:03:18 --> Model Class Initialized
INFO - 2016-08-11 21:03:18 --> Controller Class Initialized
INFO - 2016-08-11 21:03:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:03:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:03:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-11 21:03:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:03:19 --> Final output sent to browser
DEBUG - 2016-08-11 21:03:19 --> Total execution time: 0.7088
INFO - 2016-08-11 21:03:28 --> Config Class Initialized
INFO - 2016-08-11 21:03:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 21:03:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 21:03:28 --> Utf8 Class Initialized
INFO - 2016-08-11 21:03:28 --> URI Class Initialized
INFO - 2016-08-11 21:03:28 --> Router Class Initialized
INFO - 2016-08-11 21:03:28 --> Output Class Initialized
INFO - 2016-08-11 21:03:28 --> Security Class Initialized
DEBUG - 2016-08-11 21:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 21:03:28 --> Input Class Initialized
INFO - 2016-08-11 21:03:28 --> Language Class Initialized
INFO - 2016-08-11 21:03:28 --> Loader Class Initialized
INFO - 2016-08-11 21:03:28 --> Helper loaded: url_helper
INFO - 2016-08-11 21:03:28 --> Helper loaded: date_helper
INFO - 2016-08-11 21:03:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 21:03:28 --> Database Driver Class Initialized
INFO - 2016-08-11 21:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 21:03:28 --> Email Class Initialized
INFO - 2016-08-11 21:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 21:03:28 --> Pagination Class Initialized
INFO - 2016-08-11 21:03:28 --> Model Class Initialized
INFO - 2016-08-11 21:03:28 --> Controller Class Initialized
INFO - 2016-08-11 21:03:28 --> Model Class Initialized
INFO - 2016-08-11 21:03:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 21:03:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 21:03:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 21:03:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 21:03:29 --> Final output sent to browser
DEBUG - 2016-08-11 21:03:29 --> Total execution time: 1.0643
INFO - 2016-08-11 22:18:10 --> Config Class Initialized
INFO - 2016-08-11 22:18:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:18:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:18:10 --> Utf8 Class Initialized
INFO - 2016-08-11 22:18:10 --> URI Class Initialized
INFO - 2016-08-11 22:18:10 --> Router Class Initialized
INFO - 2016-08-11 22:18:11 --> Output Class Initialized
INFO - 2016-08-11 22:18:11 --> Security Class Initialized
DEBUG - 2016-08-11 22:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:18:11 --> Input Class Initialized
INFO - 2016-08-11 22:18:11 --> Language Class Initialized
INFO - 2016-08-11 22:18:11 --> Loader Class Initialized
INFO - 2016-08-11 22:18:11 --> Helper loaded: url_helper
INFO - 2016-08-11 22:18:11 --> Helper loaded: date_helper
INFO - 2016-08-11 22:18:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:18:11 --> Database Driver Class Initialized
INFO - 2016-08-11 22:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:18:11 --> Email Class Initialized
INFO - 2016-08-11 22:18:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:18:11 --> Pagination Class Initialized
INFO - 2016-08-11 22:18:11 --> Model Class Initialized
INFO - 2016-08-11 22:18:11 --> Controller Class Initialized
INFO - 2016-08-11 22:18:11 --> Model Class Initialized
INFO - 2016-08-11 22:18:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:18:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:18:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:18:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:18:11 --> Final output sent to browser
DEBUG - 2016-08-11 22:18:11 --> Total execution time: 0.7830
INFO - 2016-08-11 22:18:22 --> Config Class Initialized
INFO - 2016-08-11 22:18:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:18:22 --> Utf8 Class Initialized
INFO - 2016-08-11 22:18:22 --> URI Class Initialized
INFO - 2016-08-11 22:18:22 --> Router Class Initialized
INFO - 2016-08-11 22:18:22 --> Output Class Initialized
INFO - 2016-08-11 22:18:22 --> Security Class Initialized
DEBUG - 2016-08-11 22:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:18:22 --> Input Class Initialized
INFO - 2016-08-11 22:18:22 --> Language Class Initialized
INFO - 2016-08-11 22:18:23 --> Loader Class Initialized
INFO - 2016-08-11 22:18:23 --> Helper loaded: url_helper
INFO - 2016-08-11 22:18:23 --> Helper loaded: date_helper
INFO - 2016-08-11 22:18:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:18:23 --> Database Driver Class Initialized
INFO - 2016-08-11 22:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:18:23 --> Email Class Initialized
INFO - 2016-08-11 22:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:18:23 --> Pagination Class Initialized
INFO - 2016-08-11 22:18:23 --> Model Class Initialized
INFO - 2016-08-11 22:18:23 --> Controller Class Initialized
INFO - 2016-08-11 22:18:23 --> Model Class Initialized
INFO - 2016-08-11 22:18:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:18:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:18:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:18:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:18:23 --> Final output sent to browser
DEBUG - 2016-08-11 22:18:23 --> Total execution time: 0.6145
INFO - 2016-08-11 22:20:12 --> Config Class Initialized
INFO - 2016-08-11 22:20:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:12 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:12 --> URI Class Initialized
INFO - 2016-08-11 22:20:12 --> Router Class Initialized
INFO - 2016-08-11 22:20:12 --> Output Class Initialized
INFO - 2016-08-11 22:20:12 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:12 --> Input Class Initialized
INFO - 2016-08-11 22:20:12 --> Language Class Initialized
INFO - 2016-08-11 22:20:12 --> Loader Class Initialized
INFO - 2016-08-11 22:20:12 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:12 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:12 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:12 --> Email Class Initialized
INFO - 2016-08-11 22:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:12 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:12 --> Model Class Initialized
INFO - 2016-08-11 22:20:12 --> Controller Class Initialized
INFO - 2016-08-11 22:20:12 --> Model Class Initialized
INFO - 2016-08-11 22:20:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:20:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:20:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:20:13 --> Final output sent to browser
DEBUG - 2016-08-11 22:20:13 --> Total execution time: 0.6412
INFO - 2016-08-11 22:20:17 --> Config Class Initialized
INFO - 2016-08-11 22:20:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:17 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:17 --> URI Class Initialized
INFO - 2016-08-11 22:20:17 --> Router Class Initialized
INFO - 2016-08-11 22:20:17 --> Output Class Initialized
INFO - 2016-08-11 22:20:17 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:17 --> Input Class Initialized
INFO - 2016-08-11 22:20:17 --> Language Class Initialized
INFO - 2016-08-11 22:20:17 --> Loader Class Initialized
INFO - 2016-08-11 22:20:17 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:17 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:17 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:17 --> Email Class Initialized
INFO - 2016-08-11 22:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:18 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:18 --> Model Class Initialized
INFO - 2016-08-11 22:20:18 --> Controller Class Initialized
INFO - 2016-08-11 22:20:18 --> Model Class Initialized
INFO - 2016-08-11 22:20:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:20:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:20:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:20:18 --> Final output sent to browser
DEBUG - 2016-08-11 22:20:18 --> Total execution time: 0.6465
INFO - 2016-08-11 22:20:21 --> Config Class Initialized
INFO - 2016-08-11 22:20:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:21 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:22 --> URI Class Initialized
INFO - 2016-08-11 22:20:22 --> Router Class Initialized
INFO - 2016-08-11 22:20:22 --> Output Class Initialized
INFO - 2016-08-11 22:20:22 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:22 --> Input Class Initialized
INFO - 2016-08-11 22:20:22 --> Language Class Initialized
INFO - 2016-08-11 22:20:22 --> Loader Class Initialized
INFO - 2016-08-11 22:20:22 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:22 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:22 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:22 --> Email Class Initialized
INFO - 2016-08-11 22:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:22 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:22 --> Model Class Initialized
INFO - 2016-08-11 22:20:22 --> Controller Class Initialized
INFO - 2016-08-11 22:20:22 --> Model Class Initialized
INFO - 2016-08-11 22:20:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:20:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:20:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:20:22 --> Final output sent to browser
DEBUG - 2016-08-11 22:20:22 --> Total execution time: 0.6265
INFO - 2016-08-11 22:20:32 --> Config Class Initialized
INFO - 2016-08-11 22:20:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:33 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:33 --> URI Class Initialized
INFO - 2016-08-11 22:20:33 --> Router Class Initialized
INFO - 2016-08-11 22:20:33 --> Output Class Initialized
INFO - 2016-08-11 22:20:33 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:33 --> Input Class Initialized
INFO - 2016-08-11 22:20:33 --> Language Class Initialized
INFO - 2016-08-11 22:20:33 --> Loader Class Initialized
INFO - 2016-08-11 22:20:33 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:33 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:33 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:33 --> Email Class Initialized
INFO - 2016-08-11 22:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:33 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:33 --> Model Class Initialized
INFO - 2016-08-11 22:20:33 --> Controller Class Initialized
INFO - 2016-08-11 22:20:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 22:20:33 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\aqiqahsehati\application\views\news.php 30
ERROR - 2016-08-11 22:20:33 --> Severity: Notice --> Undefined variable: news D:\xampp\htdocs\aqiqahsehati\application\views\news.php 92
ERROR - 2016-08-11 22:20:33 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\news.php 92
INFO - 2016-08-11 22:20:35 --> Config Class Initialized
INFO - 2016-08-11 22:20:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:35 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:35 --> URI Class Initialized
INFO - 2016-08-11 22:20:35 --> Router Class Initialized
INFO - 2016-08-11 22:20:35 --> Output Class Initialized
INFO - 2016-08-11 22:20:36 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:36 --> Input Class Initialized
INFO - 2016-08-11 22:20:36 --> Language Class Initialized
INFO - 2016-08-11 22:20:36 --> Loader Class Initialized
INFO - 2016-08-11 22:20:36 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:36 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:36 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:36 --> Email Class Initialized
INFO - 2016-08-11 22:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:36 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:36 --> Model Class Initialized
INFO - 2016-08-11 22:20:36 --> Controller Class Initialized
INFO - 2016-08-11 22:20:36 --> Model Class Initialized
INFO - 2016-08-11 22:20:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:20:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:20:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:20:36 --> Final output sent to browser
DEBUG - 2016-08-11 22:20:36 --> Total execution time: 0.7896
INFO - 2016-08-11 22:20:54 --> Config Class Initialized
INFO - 2016-08-11 22:20:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:20:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:20:54 --> Utf8 Class Initialized
INFO - 2016-08-11 22:20:54 --> URI Class Initialized
INFO - 2016-08-11 22:20:54 --> Router Class Initialized
INFO - 2016-08-11 22:20:54 --> Output Class Initialized
INFO - 2016-08-11 22:20:54 --> Security Class Initialized
DEBUG - 2016-08-11 22:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:20:54 --> Input Class Initialized
INFO - 2016-08-11 22:20:54 --> Language Class Initialized
INFO - 2016-08-11 22:20:55 --> Loader Class Initialized
INFO - 2016-08-11 22:20:55 --> Helper loaded: url_helper
INFO - 2016-08-11 22:20:55 --> Helper loaded: date_helper
INFO - 2016-08-11 22:20:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:20:55 --> Database Driver Class Initialized
INFO - 2016-08-11 22:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:20:55 --> Email Class Initialized
INFO - 2016-08-11 22:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:20:55 --> Pagination Class Initialized
INFO - 2016-08-11 22:20:55 --> Model Class Initialized
INFO - 2016-08-11 22:20:55 --> Controller Class Initialized
INFO - 2016-08-11 22:20:55 --> Model Class Initialized
INFO - 2016-08-11 22:20:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:20:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:20:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:20:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:20:55 --> Final output sent to browser
DEBUG - 2016-08-11 22:20:55 --> Total execution time: 0.7833
INFO - 2016-08-11 22:21:01 --> Config Class Initialized
INFO - 2016-08-11 22:21:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:21:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:21:01 --> Utf8 Class Initialized
INFO - 2016-08-11 22:21:01 --> URI Class Initialized
INFO - 2016-08-11 22:21:01 --> Router Class Initialized
INFO - 2016-08-11 22:21:01 --> Output Class Initialized
INFO - 2016-08-11 22:21:01 --> Security Class Initialized
DEBUG - 2016-08-11 22:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:21:01 --> Input Class Initialized
INFO - 2016-08-11 22:21:01 --> Language Class Initialized
INFO - 2016-08-11 22:21:01 --> Loader Class Initialized
INFO - 2016-08-11 22:21:01 --> Helper loaded: url_helper
INFO - 2016-08-11 22:21:01 --> Helper loaded: date_helper
INFO - 2016-08-11 22:21:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:21:01 --> Database Driver Class Initialized
INFO - 2016-08-11 22:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:21:01 --> Email Class Initialized
INFO - 2016-08-11 22:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:21:01 --> Pagination Class Initialized
INFO - 2016-08-11 22:21:01 --> Model Class Initialized
INFO - 2016-08-11 22:21:01 --> Controller Class Initialized
INFO - 2016-08-11 22:21:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
ERROR - 2016-08-11 22:21:01 --> Severity: Notice --> Undefined variable: menu D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
ERROR - 2016-08-11 22:21:01 --> Severity: Error --> Call to a member function result() on a non-object D:\xampp\htdocs\aqiqahsehati\application\views\template\nav.php 41
INFO - 2016-08-11 22:21:04 --> Config Class Initialized
INFO - 2016-08-11 22:21:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:21:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:21:04 --> Utf8 Class Initialized
INFO - 2016-08-11 22:21:04 --> URI Class Initialized
INFO - 2016-08-11 22:21:04 --> Router Class Initialized
INFO - 2016-08-11 22:21:04 --> Output Class Initialized
INFO - 2016-08-11 22:21:04 --> Security Class Initialized
DEBUG - 2016-08-11 22:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:21:04 --> Input Class Initialized
INFO - 2016-08-11 22:21:04 --> Language Class Initialized
INFO - 2016-08-11 22:21:04 --> Loader Class Initialized
INFO - 2016-08-11 22:21:04 --> Helper loaded: url_helper
INFO - 2016-08-11 22:21:04 --> Helper loaded: date_helper
INFO - 2016-08-11 22:21:04 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:21:04 --> Database Driver Class Initialized
INFO - 2016-08-11 22:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:21:04 --> Email Class Initialized
INFO - 2016-08-11 22:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:21:04 --> Pagination Class Initialized
INFO - 2016-08-11 22:21:04 --> Model Class Initialized
INFO - 2016-08-11 22:21:04 --> Controller Class Initialized
INFO - 2016-08-11 22:21:04 --> Model Class Initialized
INFO - 2016-08-11 22:21:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:21:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:21:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:21:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:21:04 --> Final output sent to browser
DEBUG - 2016-08-11 22:21:04 --> Total execution time: 0.6665
INFO - 2016-08-11 22:21:06 --> Config Class Initialized
INFO - 2016-08-11 22:21:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:21:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:21:06 --> Utf8 Class Initialized
INFO - 2016-08-11 22:21:06 --> URI Class Initialized
INFO - 2016-08-11 22:21:06 --> Router Class Initialized
INFO - 2016-08-11 22:21:06 --> Output Class Initialized
INFO - 2016-08-11 22:21:06 --> Security Class Initialized
DEBUG - 2016-08-11 22:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:21:06 --> Input Class Initialized
INFO - 2016-08-11 22:21:06 --> Language Class Initialized
INFO - 2016-08-11 22:21:06 --> Loader Class Initialized
INFO - 2016-08-11 22:21:06 --> Helper loaded: url_helper
INFO - 2016-08-11 22:21:06 --> Helper loaded: date_helper
INFO - 2016-08-11 22:21:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:21:06 --> Database Driver Class Initialized
INFO - 2016-08-11 22:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:21:06 --> Email Class Initialized
INFO - 2016-08-11 22:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:21:06 --> Pagination Class Initialized
INFO - 2016-08-11 22:21:06 --> Model Class Initialized
INFO - 2016-08-11 22:21:06 --> Controller Class Initialized
INFO - 2016-08-11 22:21:06 --> Model Class Initialized
INFO - 2016-08-11 22:21:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:21:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:21:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:21:07 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:21:07 --> Final output sent to browser
DEBUG - 2016-08-11 22:21:07 --> Total execution time: 0.6398
INFO - 2016-08-11 22:21:10 --> Config Class Initialized
INFO - 2016-08-11 22:21:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:21:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:21:10 --> Utf8 Class Initialized
INFO - 2016-08-11 22:21:10 --> URI Class Initialized
INFO - 2016-08-11 22:21:10 --> Router Class Initialized
INFO - 2016-08-11 22:21:10 --> Output Class Initialized
INFO - 2016-08-11 22:21:10 --> Security Class Initialized
DEBUG - 2016-08-11 22:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:21:11 --> Input Class Initialized
INFO - 2016-08-11 22:21:11 --> Language Class Initialized
INFO - 2016-08-11 22:21:11 --> Loader Class Initialized
INFO - 2016-08-11 22:21:11 --> Helper loaded: url_helper
INFO - 2016-08-11 22:21:11 --> Helper loaded: date_helper
INFO - 2016-08-11 22:21:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:21:11 --> Database Driver Class Initialized
INFO - 2016-08-11 22:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:21:11 --> Email Class Initialized
INFO - 2016-08-11 22:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:21:11 --> Pagination Class Initialized
INFO - 2016-08-11 22:21:11 --> Model Class Initialized
INFO - 2016-08-11 22:21:11 --> Controller Class Initialized
INFO - 2016-08-11 22:21:11 --> Model Class Initialized
INFO - 2016-08-11 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:21:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:21:11 --> Final output sent to browser
DEBUG - 2016-08-11 22:21:11 --> Total execution time: 0.6388
INFO - 2016-08-11 22:21:22 --> Config Class Initialized
INFO - 2016-08-11 22:21:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:21:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:21:22 --> Utf8 Class Initialized
INFO - 2016-08-11 22:21:22 --> URI Class Initialized
INFO - 2016-08-11 22:21:22 --> Router Class Initialized
INFO - 2016-08-11 22:21:22 --> Output Class Initialized
INFO - 2016-08-11 22:21:22 --> Security Class Initialized
DEBUG - 2016-08-11 22:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:21:22 --> Input Class Initialized
INFO - 2016-08-11 22:21:22 --> Language Class Initialized
INFO - 2016-08-11 22:21:22 --> Loader Class Initialized
INFO - 2016-08-11 22:21:22 --> Helper loaded: url_helper
INFO - 2016-08-11 22:21:22 --> Helper loaded: date_helper
INFO - 2016-08-11 22:21:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:21:22 --> Database Driver Class Initialized
INFO - 2016-08-11 22:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:21:22 --> Email Class Initialized
INFO - 2016-08-11 22:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:21:22 --> Pagination Class Initialized
INFO - 2016-08-11 22:21:22 --> Model Class Initialized
INFO - 2016-08-11 22:21:22 --> Controller Class Initialized
INFO - 2016-08-11 22:21:22 --> Model Class Initialized
INFO - 2016-08-11 22:21:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:21:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:21:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:21:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:21:22 --> Final output sent to browser
DEBUG - 2016-08-11 22:21:22 --> Total execution time: 0.6472
INFO - 2016-08-11 22:25:15 --> Config Class Initialized
INFO - 2016-08-11 22:25:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:25:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:25:15 --> Utf8 Class Initialized
INFO - 2016-08-11 22:25:15 --> URI Class Initialized
INFO - 2016-08-11 22:25:15 --> Router Class Initialized
INFO - 2016-08-11 22:25:15 --> Output Class Initialized
INFO - 2016-08-11 22:25:15 --> Security Class Initialized
DEBUG - 2016-08-11 22:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:25:15 --> Input Class Initialized
INFO - 2016-08-11 22:25:15 --> Language Class Initialized
INFO - 2016-08-11 22:25:15 --> Loader Class Initialized
INFO - 2016-08-11 22:25:15 --> Helper loaded: url_helper
INFO - 2016-08-11 22:25:15 --> Helper loaded: date_helper
INFO - 2016-08-11 22:25:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:25:15 --> Database Driver Class Initialized
INFO - 2016-08-11 22:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:25:15 --> Email Class Initialized
INFO - 2016-08-11 22:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:25:15 --> Pagination Class Initialized
INFO - 2016-08-11 22:25:15 --> Model Class Initialized
INFO - 2016-08-11 22:25:15 --> Controller Class Initialized
INFO - 2016-08-11 22:25:15 --> Model Class Initialized
INFO - 2016-08-11 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:25:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 22:25:16 --> Severity: Error --> Call to undefined function character_limiter() D:\xampp\htdocs\aqiqahsehati\application\views\news.php 122
INFO - 2016-08-11 22:25:57 --> Config Class Initialized
INFO - 2016-08-11 22:25:57 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:25:57 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:25:57 --> Utf8 Class Initialized
INFO - 2016-08-11 22:25:57 --> URI Class Initialized
INFO - 2016-08-11 22:25:57 --> Router Class Initialized
INFO - 2016-08-11 22:25:57 --> Output Class Initialized
INFO - 2016-08-11 22:25:57 --> Security Class Initialized
DEBUG - 2016-08-11 22:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:25:57 --> Input Class Initialized
INFO - 2016-08-11 22:25:57 --> Language Class Initialized
INFO - 2016-08-11 22:25:57 --> Loader Class Initialized
INFO - 2016-08-11 22:25:57 --> Helper loaded: url_helper
INFO - 2016-08-11 22:25:57 --> Helper loaded: date_helper
INFO - 2016-08-11 22:25:57 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:25:57 --> Database Driver Class Initialized
INFO - 2016-08-11 22:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:25:57 --> Email Class Initialized
INFO - 2016-08-11 22:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:25:57 --> Pagination Class Initialized
INFO - 2016-08-11 22:25:57 --> Model Class Initialized
INFO - 2016-08-11 22:25:57 --> Controller Class Initialized
INFO - 2016-08-11 22:25:57 --> Model Class Initialized
INFO - 2016-08-11 22:25:57 --> Helper loaded: text_helper
INFO - 2016-08-11 22:25:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:25:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:25:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:25:57 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:25:57 --> Final output sent to browser
DEBUG - 2016-08-11 22:25:57 --> Total execution time: 0.7318
INFO - 2016-08-11 22:25:58 --> Config Class Initialized
INFO - 2016-08-11 22:25:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:25:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:25:58 --> Utf8 Class Initialized
INFO - 2016-08-11 22:25:58 --> URI Class Initialized
INFO - 2016-08-11 22:25:58 --> Router Class Initialized
INFO - 2016-08-11 22:25:58 --> Output Class Initialized
INFO - 2016-08-11 22:25:58 --> Security Class Initialized
DEBUG - 2016-08-11 22:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:25:58 --> Input Class Initialized
INFO - 2016-08-11 22:25:58 --> Language Class Initialized
ERROR - 2016-08-11 22:25:58 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 22:26:13 --> Config Class Initialized
INFO - 2016-08-11 22:26:13 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:26:13 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:26:13 --> Utf8 Class Initialized
INFO - 2016-08-11 22:26:13 --> URI Class Initialized
INFO - 2016-08-11 22:26:13 --> Router Class Initialized
INFO - 2016-08-11 22:26:13 --> Output Class Initialized
INFO - 2016-08-11 22:26:13 --> Security Class Initialized
DEBUG - 2016-08-11 22:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:26:13 --> Input Class Initialized
INFO - 2016-08-11 22:26:13 --> Language Class Initialized
INFO - 2016-08-11 22:26:13 --> Loader Class Initialized
INFO - 2016-08-11 22:26:13 --> Helper loaded: url_helper
INFO - 2016-08-11 22:26:13 --> Helper loaded: date_helper
INFO - 2016-08-11 22:26:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:26:13 --> Database Driver Class Initialized
INFO - 2016-08-11 22:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:26:13 --> Email Class Initialized
INFO - 2016-08-11 22:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:26:13 --> Pagination Class Initialized
INFO - 2016-08-11 22:26:13 --> Model Class Initialized
INFO - 2016-08-11 22:26:13 --> Controller Class Initialized
INFO - 2016-08-11 22:26:13 --> Model Class Initialized
INFO - 2016-08-11 22:26:13 --> Helper loaded: text_helper
INFO - 2016-08-11 22:26:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:26:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:26:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:26:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:26:13 --> Final output sent to browser
DEBUG - 2016-08-11 22:26:13 --> Total execution time: 0.6604
INFO - 2016-08-11 22:28:11 --> Config Class Initialized
INFO - 2016-08-11 22:28:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:28:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:28:11 --> Utf8 Class Initialized
INFO - 2016-08-11 22:28:11 --> URI Class Initialized
INFO - 2016-08-11 22:28:11 --> Router Class Initialized
INFO - 2016-08-11 22:28:11 --> Output Class Initialized
INFO - 2016-08-11 22:28:11 --> Security Class Initialized
DEBUG - 2016-08-11 22:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:28:11 --> Input Class Initialized
INFO - 2016-08-11 22:28:11 --> Language Class Initialized
INFO - 2016-08-11 22:28:11 --> Loader Class Initialized
INFO - 2016-08-11 22:28:11 --> Helper loaded: url_helper
INFO - 2016-08-11 22:28:11 --> Helper loaded: date_helper
INFO - 2016-08-11 22:28:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:28:12 --> Database Driver Class Initialized
INFO - 2016-08-11 22:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:28:12 --> Email Class Initialized
INFO - 2016-08-11 22:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:28:12 --> Pagination Class Initialized
INFO - 2016-08-11 22:28:12 --> Model Class Initialized
INFO - 2016-08-11 22:28:12 --> Controller Class Initialized
INFO - 2016-08-11 22:28:12 --> Model Class Initialized
INFO - 2016-08-11 22:28:12 --> Helper loaded: text_helper
INFO - 2016-08-11 22:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:28:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:28:12 --> Final output sent to browser
DEBUG - 2016-08-11 22:28:12 --> Total execution time: 0.7336
INFO - 2016-08-11 22:28:17 --> Config Class Initialized
INFO - 2016-08-11 22:28:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:28:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:28:17 --> Utf8 Class Initialized
INFO - 2016-08-11 22:28:17 --> URI Class Initialized
INFO - 2016-08-11 22:28:17 --> Router Class Initialized
INFO - 2016-08-11 22:28:17 --> Output Class Initialized
INFO - 2016-08-11 22:28:17 --> Security Class Initialized
DEBUG - 2016-08-11 22:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:28:17 --> Input Class Initialized
INFO - 2016-08-11 22:28:17 --> Language Class Initialized
INFO - 2016-08-11 22:28:17 --> Loader Class Initialized
INFO - 2016-08-11 22:28:17 --> Helper loaded: url_helper
INFO - 2016-08-11 22:28:17 --> Helper loaded: date_helper
INFO - 2016-08-11 22:28:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:28:17 --> Database Driver Class Initialized
INFO - 2016-08-11 22:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:28:17 --> Email Class Initialized
INFO - 2016-08-11 22:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:28:17 --> Pagination Class Initialized
INFO - 2016-08-11 22:28:17 --> Model Class Initialized
INFO - 2016-08-11 22:28:17 --> Controller Class Initialized
INFO - 2016-08-11 22:28:17 --> Model Class Initialized
INFO - 2016-08-11 22:28:17 --> Helper loaded: text_helper
INFO - 2016-08-11 22:28:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:28:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:28:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:28:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:28:17 --> Final output sent to browser
DEBUG - 2016-08-11 22:28:17 --> Total execution time: 0.6400
INFO - 2016-08-11 22:28:25 --> Config Class Initialized
INFO - 2016-08-11 22:28:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:28:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:28:25 --> Utf8 Class Initialized
INFO - 2016-08-11 22:28:25 --> URI Class Initialized
INFO - 2016-08-11 22:28:25 --> Router Class Initialized
INFO - 2016-08-11 22:28:25 --> Output Class Initialized
INFO - 2016-08-11 22:28:25 --> Security Class Initialized
DEBUG - 2016-08-11 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:28:25 --> Input Class Initialized
INFO - 2016-08-11 22:28:25 --> Language Class Initialized
INFO - 2016-08-11 22:28:25 --> Loader Class Initialized
INFO - 2016-08-11 22:28:25 --> Helper loaded: url_helper
INFO - 2016-08-11 22:28:25 --> Helper loaded: date_helper
INFO - 2016-08-11 22:28:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:28:25 --> Database Driver Class Initialized
INFO - 2016-08-11 22:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:28:25 --> Email Class Initialized
INFO - 2016-08-11 22:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:28:25 --> Pagination Class Initialized
INFO - 2016-08-11 22:28:25 --> Model Class Initialized
INFO - 2016-08-11 22:28:25 --> Controller Class Initialized
INFO - 2016-08-11 22:28:25 --> Model Class Initialized
INFO - 2016-08-11 22:28:25 --> Helper loaded: text_helper
INFO - 2016-08-11 22:28:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:28:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:28:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:28:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:28:25 --> Final output sent to browser
DEBUG - 2016-08-11 22:28:25 --> Total execution time: 0.6270
INFO - 2016-08-11 22:29:29 --> Config Class Initialized
INFO - 2016-08-11 22:29:29 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:29:29 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:29:29 --> Utf8 Class Initialized
INFO - 2016-08-11 22:29:29 --> URI Class Initialized
INFO - 2016-08-11 22:29:29 --> Router Class Initialized
INFO - 2016-08-11 22:29:29 --> Output Class Initialized
INFO - 2016-08-11 22:29:29 --> Security Class Initialized
DEBUG - 2016-08-11 22:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:29:29 --> Input Class Initialized
INFO - 2016-08-11 22:29:29 --> Language Class Initialized
INFO - 2016-08-11 22:29:29 --> Loader Class Initialized
INFO - 2016-08-11 22:29:29 --> Helper loaded: url_helper
INFO - 2016-08-11 22:29:29 --> Helper loaded: date_helper
INFO - 2016-08-11 22:29:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:29:29 --> Database Driver Class Initialized
INFO - 2016-08-11 22:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:29:29 --> Email Class Initialized
INFO - 2016-08-11 22:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:29:29 --> Pagination Class Initialized
INFO - 2016-08-11 22:29:29 --> Model Class Initialized
INFO - 2016-08-11 22:29:29 --> Controller Class Initialized
DEBUG - 2016-08-11 22:29:29 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:29:29 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:29:29 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:29:29 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:30 --> Model Class Initialized
INFO - 2016-08-11 22:29:30 --> Config Class Initialized
INFO - 2016-08-11 22:29:30 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:29:30 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:29:30 --> Utf8 Class Initialized
INFO - 2016-08-11 22:29:30 --> URI Class Initialized
INFO - 2016-08-11 22:29:30 --> Router Class Initialized
INFO - 2016-08-11 22:29:30 --> Output Class Initialized
INFO - 2016-08-11 22:29:30 --> Security Class Initialized
DEBUG - 2016-08-11 22:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:29:30 --> Input Class Initialized
INFO - 2016-08-11 22:29:30 --> Language Class Initialized
INFO - 2016-08-11 22:29:30 --> Loader Class Initialized
INFO - 2016-08-11 22:29:30 --> Helper loaded: url_helper
INFO - 2016-08-11 22:29:30 --> Helper loaded: date_helper
INFO - 2016-08-11 22:29:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:29:30 --> Database Driver Class Initialized
INFO - 2016-08-11 22:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:29:30 --> Email Class Initialized
INFO - 2016-08-11 22:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:29:30 --> Pagination Class Initialized
INFO - 2016-08-11 22:29:30 --> Model Class Initialized
INFO - 2016-08-11 22:29:30 --> Controller Class Initialized
DEBUG - 2016-08-11 22:29:30 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:29:30 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:29:30 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:29:30 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:30 --> Model Class Initialized
INFO - 2016-08-11 22:29:31 --> Helper loaded: form_helper
INFO - 2016-08-11 22:29:31 --> Form Validation Class Initialized
INFO - 2016-08-11 22:29:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 22:29:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\auth/login.php
INFO - 2016-08-11 22:29:31 --> Final output sent to browser
DEBUG - 2016-08-11 22:29:31 --> Total execution time: 1.0732
INFO - 2016-08-11 22:29:37 --> Config Class Initialized
INFO - 2016-08-11 22:29:37 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:29:37 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:29:37 --> Utf8 Class Initialized
INFO - 2016-08-11 22:29:37 --> URI Class Initialized
INFO - 2016-08-11 22:29:37 --> Router Class Initialized
INFO - 2016-08-11 22:29:37 --> Output Class Initialized
INFO - 2016-08-11 22:29:38 --> Security Class Initialized
DEBUG - 2016-08-11 22:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:29:38 --> Input Class Initialized
INFO - 2016-08-11 22:29:38 --> Language Class Initialized
INFO - 2016-08-11 22:29:38 --> Loader Class Initialized
INFO - 2016-08-11 22:29:38 --> Helper loaded: url_helper
INFO - 2016-08-11 22:29:38 --> Helper loaded: date_helper
INFO - 2016-08-11 22:29:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:29:38 --> Database Driver Class Initialized
INFO - 2016-08-11 22:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:29:38 --> Email Class Initialized
INFO - 2016-08-11 22:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:29:38 --> Pagination Class Initialized
INFO - 2016-08-11 22:29:38 --> Model Class Initialized
INFO - 2016-08-11 22:29:38 --> Controller Class Initialized
DEBUG - 2016-08-11 22:29:38 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:29:38 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:29:38 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:29:38 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:29:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:38 --> Model Class Initialized
INFO - 2016-08-11 22:29:38 --> Helper loaded: form_helper
INFO - 2016-08-11 22:29:38 --> Form Validation Class Initialized
INFO - 2016-08-11 22:29:38 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-08-11 22:29:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-11 22:29:38 --> Config Class Initialized
INFO - 2016-08-11 22:29:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:29:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:29:38 --> Utf8 Class Initialized
INFO - 2016-08-11 22:29:39 --> URI Class Initialized
INFO - 2016-08-11 22:29:39 --> Router Class Initialized
INFO - 2016-08-11 22:29:39 --> Output Class Initialized
INFO - 2016-08-11 22:29:39 --> Security Class Initialized
DEBUG - 2016-08-11 22:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:29:39 --> Input Class Initialized
INFO - 2016-08-11 22:29:39 --> Language Class Initialized
INFO - 2016-08-11 22:29:39 --> Loader Class Initialized
INFO - 2016-08-11 22:29:39 --> Helper loaded: url_helper
INFO - 2016-08-11 22:29:39 --> Helper loaded: date_helper
INFO - 2016-08-11 22:29:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:29:39 --> Database Driver Class Initialized
INFO - 2016-08-11 22:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:29:39 --> Email Class Initialized
INFO - 2016-08-11 22:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:29:39 --> Pagination Class Initialized
INFO - 2016-08-11 22:29:39 --> Model Class Initialized
INFO - 2016-08-11 22:29:39 --> Controller Class Initialized
DEBUG - 2016-08-11 22:29:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:29:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:29:39 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:29:39 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:29:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:39 --> Model Class Initialized
INFO - 2016-08-11 22:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/home.php
INFO - 2016-08-11 22:29:39 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:29:39 --> Final output sent to browser
DEBUG - 2016-08-11 22:29:40 --> Total execution time: 1.0995
INFO - 2016-08-11 22:29:48 --> Config Class Initialized
INFO - 2016-08-11 22:29:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:29:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:29:48 --> Utf8 Class Initialized
INFO - 2016-08-11 22:29:48 --> URI Class Initialized
INFO - 2016-08-11 22:29:48 --> Router Class Initialized
INFO - 2016-08-11 22:29:48 --> Output Class Initialized
INFO - 2016-08-11 22:29:48 --> Security Class Initialized
DEBUG - 2016-08-11 22:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:29:48 --> Input Class Initialized
INFO - 2016-08-11 22:29:48 --> Language Class Initialized
INFO - 2016-08-11 22:29:48 --> Loader Class Initialized
INFO - 2016-08-11 22:29:48 --> Helper loaded: url_helper
INFO - 2016-08-11 22:29:48 --> Helper loaded: date_helper
INFO - 2016-08-11 22:29:48 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:29:48 --> Database Driver Class Initialized
INFO - 2016-08-11 22:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:29:48 --> Email Class Initialized
INFO - 2016-08-11 22:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:29:48 --> Pagination Class Initialized
INFO - 2016-08-11 22:29:48 --> Model Class Initialized
INFO - 2016-08-11 22:29:48 --> Controller Class Initialized
DEBUG - 2016-08-11 22:29:48 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:29:48 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:29:48 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:29:48 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:29:48 --> Model Class Initialized
INFO - 2016-08-11 22:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:29:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:29:48 --> Final output sent to browser
DEBUG - 2016-08-11 22:29:48 --> Total execution time: 0.7961
INFO - 2016-08-11 22:30:11 --> Config Class Initialized
INFO - 2016-08-11 22:30:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:30:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:30:11 --> Utf8 Class Initialized
INFO - 2016-08-11 22:30:11 --> URI Class Initialized
INFO - 2016-08-11 22:30:11 --> Router Class Initialized
INFO - 2016-08-11 22:30:11 --> Output Class Initialized
INFO - 2016-08-11 22:30:11 --> Security Class Initialized
DEBUG - 2016-08-11 22:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:30:11 --> Input Class Initialized
INFO - 2016-08-11 22:30:11 --> Language Class Initialized
INFO - 2016-08-11 22:30:11 --> Loader Class Initialized
INFO - 2016-08-11 22:30:11 --> Helper loaded: url_helper
INFO - 2016-08-11 22:30:11 --> Helper loaded: date_helper
INFO - 2016-08-11 22:30:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:30:11 --> Database Driver Class Initialized
INFO - 2016-08-11 22:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:30:11 --> Email Class Initialized
INFO - 2016-08-11 22:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:30:11 --> Pagination Class Initialized
INFO - 2016-08-11 22:30:11 --> Model Class Initialized
INFO - 2016-08-11 22:30:11 --> Controller Class Initialized
DEBUG - 2016-08-11 22:30:11 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:30:11 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:30:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:30:11 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:30:11 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:30:11 --> Model Class Initialized
INFO - 2016-08-11 22:30:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:30:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:30:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:30:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 22:30:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:30:12 --> Final output sent to browser
DEBUG - 2016-08-11 22:30:12 --> Total execution time: 0.8825
INFO - 2016-08-11 22:31:45 --> Config Class Initialized
INFO - 2016-08-11 22:31:45 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:31:45 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:31:45 --> Utf8 Class Initialized
INFO - 2016-08-11 22:31:45 --> URI Class Initialized
INFO - 2016-08-11 22:31:45 --> Router Class Initialized
INFO - 2016-08-11 22:31:46 --> Output Class Initialized
INFO - 2016-08-11 22:31:46 --> Security Class Initialized
DEBUG - 2016-08-11 22:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:31:46 --> Input Class Initialized
INFO - 2016-08-11 22:31:46 --> Language Class Initialized
INFO - 2016-08-11 22:31:46 --> Loader Class Initialized
INFO - 2016-08-11 22:31:46 --> Helper loaded: url_helper
INFO - 2016-08-11 22:31:46 --> Helper loaded: date_helper
INFO - 2016-08-11 22:31:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:31:46 --> Database Driver Class Initialized
INFO - 2016-08-11 22:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:31:46 --> Email Class Initialized
INFO - 2016-08-11 22:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:31:46 --> Pagination Class Initialized
INFO - 2016-08-11 22:31:46 --> Model Class Initialized
INFO - 2016-08-11 22:31:46 --> Controller Class Initialized
DEBUG - 2016-08-11 22:31:46 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:31:46 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:31:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:31:46 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:31:46 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:31:46 --> Model Class Initialized
INFO - 2016-08-11 22:31:46 --> Upload Class Initialized
INFO - 2016-08-11 22:31:46 --> Config Class Initialized
INFO - 2016-08-11 22:31:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:31:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:31:46 --> Utf8 Class Initialized
INFO - 2016-08-11 22:31:47 --> URI Class Initialized
INFO - 2016-08-11 22:31:47 --> Router Class Initialized
INFO - 2016-08-11 22:31:47 --> Output Class Initialized
INFO - 2016-08-11 22:31:47 --> Security Class Initialized
DEBUG - 2016-08-11 22:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:31:47 --> Input Class Initialized
INFO - 2016-08-11 22:31:47 --> Language Class Initialized
INFO - 2016-08-11 22:31:47 --> Loader Class Initialized
INFO - 2016-08-11 22:31:47 --> Helper loaded: url_helper
INFO - 2016-08-11 22:31:47 --> Helper loaded: date_helper
INFO - 2016-08-11 22:31:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:31:47 --> Database Driver Class Initialized
INFO - 2016-08-11 22:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:31:47 --> Email Class Initialized
INFO - 2016-08-11 22:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:31:47 --> Pagination Class Initialized
INFO - 2016-08-11 22:31:47 --> Model Class Initialized
INFO - 2016-08-11 22:31:47 --> Controller Class Initialized
DEBUG - 2016-08-11 22:31:47 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:31:47 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:31:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:31:47 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:31:47 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:31:47 --> Model Class Initialized
INFO - 2016-08-11 22:31:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:31:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:31:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:31:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:31:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:31:47 --> Final output sent to browser
DEBUG - 2016-08-11 22:31:47 --> Total execution time: 0.9283
INFO - 2016-08-11 22:31:53 --> Config Class Initialized
INFO - 2016-08-11 22:31:53 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:31:53 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:31:53 --> Utf8 Class Initialized
INFO - 2016-08-11 22:31:53 --> URI Class Initialized
INFO - 2016-08-11 22:31:53 --> Router Class Initialized
INFO - 2016-08-11 22:31:53 --> Output Class Initialized
INFO - 2016-08-11 22:31:53 --> Security Class Initialized
DEBUG - 2016-08-11 22:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:31:53 --> Input Class Initialized
INFO - 2016-08-11 22:31:53 --> Language Class Initialized
INFO - 2016-08-11 22:31:53 --> Loader Class Initialized
INFO - 2016-08-11 22:31:53 --> Helper loaded: url_helper
INFO - 2016-08-11 22:31:53 --> Helper loaded: date_helper
INFO - 2016-08-11 22:31:53 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:31:53 --> Database Driver Class Initialized
INFO - 2016-08-11 22:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:31:53 --> Email Class Initialized
INFO - 2016-08-11 22:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:31:53 --> Pagination Class Initialized
INFO - 2016-08-11 22:31:53 --> Model Class Initialized
INFO - 2016-08-11 22:31:53 --> Controller Class Initialized
INFO - 2016-08-11 22:31:53 --> Model Class Initialized
INFO - 2016-08-11 22:31:53 --> Helper loaded: text_helper
INFO - 2016-08-11 22:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:31:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:31:53 --> Final output sent to browser
DEBUG - 2016-08-11 22:31:53 --> Total execution time: 0.7235
INFO - 2016-08-11 22:32:08 --> Config Class Initialized
INFO - 2016-08-11 22:32:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:32:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:32:08 --> Utf8 Class Initialized
INFO - 2016-08-11 22:32:08 --> URI Class Initialized
INFO - 2016-08-11 22:32:08 --> Router Class Initialized
INFO - 2016-08-11 22:32:08 --> Output Class Initialized
INFO - 2016-08-11 22:32:08 --> Security Class Initialized
DEBUG - 2016-08-11 22:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:32:08 --> Config Class Initialized
INFO - 2016-08-11 22:32:08 --> Hooks Class Initialized
INFO - 2016-08-11 22:32:08 --> Input Class Initialized
INFO - 2016-08-11 22:32:08 --> Language Class Initialized
DEBUG - 2016-08-11 22:32:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:32:08 --> Utf8 Class Initialized
INFO - 2016-08-11 22:32:08 --> Loader Class Initialized
INFO - 2016-08-11 22:32:08 --> URI Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: url_helper
INFO - 2016-08-11 22:32:08 --> Helper loaded: date_helper
INFO - 2016-08-11 22:32:08 --> Router Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:32:08 --> Output Class Initialized
INFO - 2016-08-11 22:32:08 --> Security Class Initialized
INFO - 2016-08-11 22:32:08 --> Database Driver Class Initialized
DEBUG - 2016-08-11 22:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:32:08 --> Input Class Initialized
INFO - 2016-08-11 22:32:08 --> Email Class Initialized
INFO - 2016-08-11 22:32:08 --> Language Class Initialized
INFO - 2016-08-11 22:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:32:08 --> Pagination Class Initialized
INFO - 2016-08-11 22:32:08 --> Loader Class Initialized
INFO - 2016-08-11 22:32:08 --> Model Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: url_helper
INFO - 2016-08-11 22:32:08 --> Controller Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: date_helper
INFO - 2016-08-11 22:32:08 --> Model Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:32:08 --> Helper loaded: text_helper
INFO - 2016-08-11 22:32:08 --> Database Driver Class Initialized
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:32:08 --> Final output sent to browser
DEBUG - 2016-08-11 22:32:08 --> Total execution time: 0.6854
INFO - 2016-08-11 22:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:32:08 --> Email Class Initialized
INFO - 2016-08-11 22:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:32:08 --> Pagination Class Initialized
INFO - 2016-08-11 22:32:08 --> Model Class Initialized
INFO - 2016-08-11 22:32:08 --> Controller Class Initialized
INFO - 2016-08-11 22:32:08 --> Model Class Initialized
INFO - 2016-08-11 22:32:08 --> Helper loaded: text_helper
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:32:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:32:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:32:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:32:09 --> Final output sent to browser
DEBUG - 2016-08-11 22:32:09 --> Total execution time: 0.7690
INFO - 2016-08-11 22:32:35 --> Config Class Initialized
INFO - 2016-08-11 22:32:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:32:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:32:35 --> Utf8 Class Initialized
INFO - 2016-08-11 22:32:35 --> URI Class Initialized
INFO - 2016-08-11 22:32:35 --> Router Class Initialized
INFO - 2016-08-11 22:32:35 --> Output Class Initialized
INFO - 2016-08-11 22:32:35 --> Security Class Initialized
DEBUG - 2016-08-11 22:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:32:35 --> Input Class Initialized
INFO - 2016-08-11 22:32:35 --> Language Class Initialized
INFO - 2016-08-11 22:32:35 --> Loader Class Initialized
INFO - 2016-08-11 22:32:35 --> Helper loaded: url_helper
INFO - 2016-08-11 22:32:35 --> Helper loaded: date_helper
INFO - 2016-08-11 22:32:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:32:35 --> Database Driver Class Initialized
INFO - 2016-08-11 22:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:32:35 --> Email Class Initialized
INFO - 2016-08-11 22:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:32:35 --> Pagination Class Initialized
INFO - 2016-08-11 22:32:35 --> Model Class Initialized
INFO - 2016-08-11 22:32:35 --> Controller Class Initialized
INFO - 2016-08-11 22:32:35 --> Model Class Initialized
INFO - 2016-08-11 22:32:35 --> Helper loaded: text_helper
INFO - 2016-08-11 22:32:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:32:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:32:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:32:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:32:35 --> Final output sent to browser
DEBUG - 2016-08-11 22:32:35 --> Total execution time: 0.6571
INFO - 2016-08-11 22:32:46 --> Config Class Initialized
INFO - 2016-08-11 22:32:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:32:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:32:46 --> Utf8 Class Initialized
INFO - 2016-08-11 22:32:46 --> URI Class Initialized
INFO - 2016-08-11 22:32:46 --> Router Class Initialized
INFO - 2016-08-11 22:32:46 --> Output Class Initialized
INFO - 2016-08-11 22:32:46 --> Security Class Initialized
DEBUG - 2016-08-11 22:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:32:46 --> Input Class Initialized
INFO - 2016-08-11 22:32:46 --> Language Class Initialized
INFO - 2016-08-11 22:32:46 --> Loader Class Initialized
INFO - 2016-08-11 22:32:46 --> Helper loaded: url_helper
INFO - 2016-08-11 22:32:46 --> Helper loaded: date_helper
INFO - 2016-08-11 22:32:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:32:46 --> Database Driver Class Initialized
INFO - 2016-08-11 22:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:32:46 --> Email Class Initialized
INFO - 2016-08-11 22:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:32:46 --> Pagination Class Initialized
INFO - 2016-08-11 22:32:46 --> Model Class Initialized
INFO - 2016-08-11 22:32:46 --> Controller Class Initialized
INFO - 2016-08-11 22:32:46 --> Model Class Initialized
INFO - 2016-08-11 22:32:46 --> Helper loaded: text_helper
INFO - 2016-08-11 22:32:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:32:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:32:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:32:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:32:46 --> Final output sent to browser
DEBUG - 2016-08-11 22:32:46 --> Total execution time: 0.6465
INFO - 2016-08-11 22:32:51 --> Config Class Initialized
INFO - 2016-08-11 22:32:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:32:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:32:51 --> Utf8 Class Initialized
INFO - 2016-08-11 22:32:51 --> URI Class Initialized
INFO - 2016-08-11 22:32:51 --> Router Class Initialized
INFO - 2016-08-11 22:32:51 --> Output Class Initialized
INFO - 2016-08-11 22:32:51 --> Security Class Initialized
DEBUG - 2016-08-11 22:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:32:51 --> Input Class Initialized
INFO - 2016-08-11 22:32:51 --> Language Class Initialized
INFO - 2016-08-11 22:32:51 --> Loader Class Initialized
INFO - 2016-08-11 22:32:51 --> Helper loaded: url_helper
INFO - 2016-08-11 22:32:51 --> Helper loaded: date_helper
INFO - 2016-08-11 22:32:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:32:51 --> Database Driver Class Initialized
INFO - 2016-08-11 22:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:32:51 --> Email Class Initialized
INFO - 2016-08-11 22:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:32:51 --> Pagination Class Initialized
INFO - 2016-08-11 22:32:51 --> Model Class Initialized
INFO - 2016-08-11 22:32:52 --> Controller Class Initialized
INFO - 2016-08-11 22:32:52 --> Model Class Initialized
INFO - 2016-08-11 22:32:52 --> Helper loaded: text_helper
INFO - 2016-08-11 22:32:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:32:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:32:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:32:52 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:32:52 --> Final output sent to browser
DEBUG - 2016-08-11 22:32:52 --> Total execution time: 0.7145
INFO - 2016-08-11 22:33:02 --> Config Class Initialized
INFO - 2016-08-11 22:33:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:03 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:03 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:03 --> URI Class Initialized
INFO - 2016-08-11 22:33:03 --> Router Class Initialized
INFO - 2016-08-11 22:33:03 --> Output Class Initialized
INFO - 2016-08-11 22:33:03 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:03 --> Input Class Initialized
INFO - 2016-08-11 22:33:03 --> Language Class Initialized
INFO - 2016-08-11 22:33:03 --> Loader Class Initialized
INFO - 2016-08-11 22:33:03 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:03 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:03 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:03 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:03 --> Email Class Initialized
INFO - 2016-08-11 22:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:03 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:03 --> Model Class Initialized
INFO - 2016-08-11 22:33:03 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:03 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:03 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:03 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:03 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:03 --> Model Class Initialized
INFO - 2016-08-11 22:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-11 22:33:03 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:03 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:03 --> Total execution time: 0.8209
INFO - 2016-08-11 22:33:13 --> Config Class Initialized
INFO - 2016-08-11 22:33:13 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:13 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:13 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:13 --> URI Class Initialized
INFO - 2016-08-11 22:33:13 --> Router Class Initialized
INFO - 2016-08-11 22:33:13 --> Output Class Initialized
INFO - 2016-08-11 22:33:13 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:13 --> Input Class Initialized
INFO - 2016-08-11 22:33:14 --> Language Class Initialized
INFO - 2016-08-11 22:33:14 --> Loader Class Initialized
INFO - 2016-08-11 22:33:14 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:14 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:14 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:14 --> Email Class Initialized
INFO - 2016-08-11 22:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:14 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:14 --> Model Class Initialized
INFO - 2016-08-11 22:33:14 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:14 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:14 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:14 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:14 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:14 --> Model Class Initialized
INFO - 2016-08-11 22:33:14 --> Upload Class Initialized
INFO - 2016-08-11 22:33:14 --> Helper loaded: file_helper
INFO - 2016-08-11 22:33:14 --> Config Class Initialized
INFO - 2016-08-11 22:33:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:14 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:14 --> URI Class Initialized
INFO - 2016-08-11 22:33:14 --> Router Class Initialized
INFO - 2016-08-11 22:33:14 --> Output Class Initialized
INFO - 2016-08-11 22:33:14 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:14 --> Input Class Initialized
INFO - 2016-08-11 22:33:14 --> Language Class Initialized
INFO - 2016-08-11 22:33:14 --> Loader Class Initialized
INFO - 2016-08-11 22:33:14 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:15 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:15 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:15 --> Email Class Initialized
INFO - 2016-08-11 22:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:15 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:15 --> Model Class Initialized
INFO - 2016-08-11 22:33:15 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:15 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:15 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:15 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:15 --> Model Class Initialized
INFO - 2016-08-11 22:33:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:33:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:15 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:15 --> Total execution time: 0.8649
INFO - 2016-08-11 22:33:18 --> Config Class Initialized
INFO - 2016-08-11 22:33:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:18 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:18 --> URI Class Initialized
INFO - 2016-08-11 22:33:18 --> Router Class Initialized
INFO - 2016-08-11 22:33:18 --> Output Class Initialized
INFO - 2016-08-11 22:33:19 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:19 --> Input Class Initialized
INFO - 2016-08-11 22:33:19 --> Language Class Initialized
INFO - 2016-08-11 22:33:19 --> Loader Class Initialized
INFO - 2016-08-11 22:33:19 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:19 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:19 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:19 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:19 --> Email Class Initialized
INFO - 2016-08-11 22:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:19 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:19 --> Model Class Initialized
INFO - 2016-08-11 22:33:19 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:19 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:19 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:19 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:19 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:19 --> Model Class Initialized
INFO - 2016-08-11 22:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-11 22:33:19 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:19 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:19 --> Total execution time: 0.7990
INFO - 2016-08-11 22:33:27 --> Config Class Initialized
INFO - 2016-08-11 22:33:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:27 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:27 --> URI Class Initialized
INFO - 2016-08-11 22:33:27 --> Router Class Initialized
INFO - 2016-08-11 22:33:27 --> Output Class Initialized
INFO - 2016-08-11 22:33:27 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:27 --> Input Class Initialized
INFO - 2016-08-11 22:33:27 --> Language Class Initialized
INFO - 2016-08-11 22:33:27 --> Loader Class Initialized
INFO - 2016-08-11 22:33:27 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:27 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:27 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:27 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:27 --> Email Class Initialized
INFO - 2016-08-11 22:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:27 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:27 --> Model Class Initialized
INFO - 2016-08-11 22:33:27 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:27 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:27 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:27 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:27 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:27 --> Model Class Initialized
INFO - 2016-08-11 22:33:27 --> Upload Class Initialized
INFO - 2016-08-11 22:33:27 --> Helper loaded: file_helper
INFO - 2016-08-11 22:33:27 --> Config Class Initialized
INFO - 2016-08-11 22:33:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:27 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:27 --> URI Class Initialized
INFO - 2016-08-11 22:33:27 --> Router Class Initialized
INFO - 2016-08-11 22:33:27 --> Output Class Initialized
INFO - 2016-08-11 22:33:28 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:28 --> Input Class Initialized
INFO - 2016-08-11 22:33:28 --> Language Class Initialized
INFO - 2016-08-11 22:33:28 --> Loader Class Initialized
INFO - 2016-08-11 22:33:28 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:28 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:28 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:28 --> Email Class Initialized
INFO - 2016-08-11 22:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:28 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:28 --> Model Class Initialized
INFO - 2016-08-11 22:33:28 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:28 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:28 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:28 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:28 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:28 --> Model Class Initialized
INFO - 2016-08-11 22:33:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:33:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:28 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:28 --> Total execution time: 0.7872
INFO - 2016-08-11 22:33:32 --> Config Class Initialized
INFO - 2016-08-11 22:33:32 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:32 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:32 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:32 --> URI Class Initialized
INFO - 2016-08-11 22:33:32 --> Router Class Initialized
INFO - 2016-08-11 22:33:32 --> Output Class Initialized
INFO - 2016-08-11 22:33:32 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:32 --> Input Class Initialized
INFO - 2016-08-11 22:33:32 --> Language Class Initialized
INFO - 2016-08-11 22:33:32 --> Loader Class Initialized
INFO - 2016-08-11 22:33:32 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:32 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:32 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:32 --> Email Class Initialized
INFO - 2016-08-11 22:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:32 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:32 --> Model Class Initialized
INFO - 2016-08-11 22:33:32 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:32 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:32 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:32 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:32 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:32 --> Model Class Initialized
INFO - 2016-08-11 22:33:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-11 22:33:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:32 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:32 --> Total execution time: 0.7926
INFO - 2016-08-11 22:33:38 --> Config Class Initialized
INFO - 2016-08-11 22:33:38 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:38 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:38 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:38 --> URI Class Initialized
INFO - 2016-08-11 22:33:38 --> Router Class Initialized
INFO - 2016-08-11 22:33:38 --> Output Class Initialized
INFO - 2016-08-11 22:33:38 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:38 --> Input Class Initialized
INFO - 2016-08-11 22:33:38 --> Language Class Initialized
INFO - 2016-08-11 22:33:38 --> Loader Class Initialized
INFO - 2016-08-11 22:33:38 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:38 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:38 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:38 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:38 --> Email Class Initialized
INFO - 2016-08-11 22:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:39 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:39 --> Model Class Initialized
INFO - 2016-08-11 22:33:39 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:39 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:39 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:39 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:39 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:39 --> Model Class Initialized
INFO - 2016-08-11 22:33:39 --> Upload Class Initialized
INFO - 2016-08-11 22:33:39 --> Helper loaded: file_helper
INFO - 2016-08-11 22:33:39 --> Config Class Initialized
INFO - 2016-08-11 22:33:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:39 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:39 --> URI Class Initialized
INFO - 2016-08-11 22:33:39 --> Router Class Initialized
INFO - 2016-08-11 22:33:39 --> Output Class Initialized
INFO - 2016-08-11 22:33:39 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:39 --> Input Class Initialized
INFO - 2016-08-11 22:33:39 --> Language Class Initialized
INFO - 2016-08-11 22:33:39 --> Loader Class Initialized
INFO - 2016-08-11 22:33:39 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:39 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:39 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:40 --> Email Class Initialized
INFO - 2016-08-11 22:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:40 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:40 --> Model Class Initialized
INFO - 2016-08-11 22:33:40 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:40 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:40 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:40 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:40 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:40 --> Model Class Initialized
INFO - 2016-08-11 22:33:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:33:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:40 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:40 --> Total execution time: 1.0035
INFO - 2016-08-11 22:33:42 --> Config Class Initialized
INFO - 2016-08-11 22:33:42 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:42 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:42 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:42 --> URI Class Initialized
INFO - 2016-08-11 22:33:42 --> Router Class Initialized
INFO - 2016-08-11 22:33:42 --> Output Class Initialized
INFO - 2016-08-11 22:33:42 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:42 --> Input Class Initialized
INFO - 2016-08-11 22:33:42 --> Language Class Initialized
INFO - 2016-08-11 22:33:42 --> Loader Class Initialized
INFO - 2016-08-11 22:33:42 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:42 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:42 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:42 --> Email Class Initialized
INFO - 2016-08-11 22:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:43 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:43 --> Model Class Initialized
INFO - 2016-08-11 22:33:43 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:43 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:43 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:43 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:43 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:43 --> Model Class Initialized
INFO - 2016-08-11 22:33:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/update_posting.php
INFO - 2016-08-11 22:33:43 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:43 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:43 --> Total execution time: 0.7970
INFO - 2016-08-11 22:33:51 --> Config Class Initialized
INFO - 2016-08-11 22:33:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:51 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:51 --> URI Class Initialized
INFO - 2016-08-11 22:33:51 --> Router Class Initialized
INFO - 2016-08-11 22:33:51 --> Output Class Initialized
INFO - 2016-08-11 22:33:51 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:51 --> Input Class Initialized
INFO - 2016-08-11 22:33:51 --> Language Class Initialized
INFO - 2016-08-11 22:33:51 --> Loader Class Initialized
INFO - 2016-08-11 22:33:51 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:51 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:52 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:52 --> Email Class Initialized
INFO - 2016-08-11 22:33:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:52 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:52 --> Model Class Initialized
INFO - 2016-08-11 22:33:52 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:52 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:52 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:52 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:52 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:52 --> Model Class Initialized
INFO - 2016-08-11 22:33:52 --> Upload Class Initialized
INFO - 2016-08-11 22:33:52 --> Helper loaded: file_helper
INFO - 2016-08-11 22:33:52 --> Config Class Initialized
INFO - 2016-08-11 22:33:52 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:52 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:52 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:52 --> URI Class Initialized
INFO - 2016-08-11 22:33:52 --> Router Class Initialized
INFO - 2016-08-11 22:33:52 --> Output Class Initialized
INFO - 2016-08-11 22:33:52 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:52 --> Input Class Initialized
INFO - 2016-08-11 22:33:52 --> Language Class Initialized
INFO - 2016-08-11 22:33:52 --> Loader Class Initialized
INFO - 2016-08-11 22:33:52 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:52 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:52 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:53 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:53 --> Email Class Initialized
INFO - 2016-08-11 22:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:53 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:53 --> Model Class Initialized
INFO - 2016-08-11 22:33:53 --> Controller Class Initialized
DEBUG - 2016-08-11 22:33:53 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:33:53 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:33:53 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:33:53 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:33:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:33:53 --> Model Class Initialized
INFO - 2016-08-11 22:33:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:33:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:33:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:33:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:33:53 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:33:53 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:53 --> Total execution time: 0.9108
INFO - 2016-08-11 22:33:55 --> Config Class Initialized
INFO - 2016-08-11 22:33:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:33:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:33:55 --> Utf8 Class Initialized
INFO - 2016-08-11 22:33:55 --> URI Class Initialized
INFO - 2016-08-11 22:33:55 --> Router Class Initialized
INFO - 2016-08-11 22:33:55 --> Output Class Initialized
INFO - 2016-08-11 22:33:55 --> Security Class Initialized
DEBUG - 2016-08-11 22:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:33:55 --> Input Class Initialized
INFO - 2016-08-11 22:33:55 --> Language Class Initialized
INFO - 2016-08-11 22:33:55 --> Loader Class Initialized
INFO - 2016-08-11 22:33:55 --> Helper loaded: url_helper
INFO - 2016-08-11 22:33:55 --> Helper loaded: date_helper
INFO - 2016-08-11 22:33:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:33:55 --> Database Driver Class Initialized
INFO - 2016-08-11 22:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:33:55 --> Email Class Initialized
INFO - 2016-08-11 22:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:33:55 --> Pagination Class Initialized
INFO - 2016-08-11 22:33:55 --> Model Class Initialized
INFO - 2016-08-11 22:33:55 --> Controller Class Initialized
INFO - 2016-08-11 22:33:55 --> Model Class Initialized
INFO - 2016-08-11 22:33:55 --> Helper loaded: text_helper
INFO - 2016-08-11 22:33:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:33:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:33:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:33:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:33:55 --> Final output sent to browser
DEBUG - 2016-08-11 22:33:56 --> Total execution time: 0.6825
INFO - 2016-08-11 22:34:02 --> Config Class Initialized
INFO - 2016-08-11 22:34:02 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:34:02 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:34:02 --> Utf8 Class Initialized
INFO - 2016-08-11 22:34:02 --> URI Class Initialized
INFO - 2016-08-11 22:34:02 --> Router Class Initialized
INFO - 2016-08-11 22:34:02 --> Output Class Initialized
INFO - 2016-08-11 22:34:02 --> Security Class Initialized
DEBUG - 2016-08-11 22:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:34:02 --> Input Class Initialized
INFO - 2016-08-11 22:34:02 --> Language Class Initialized
INFO - 2016-08-11 22:34:02 --> Loader Class Initialized
INFO - 2016-08-11 22:34:02 --> Helper loaded: url_helper
INFO - 2016-08-11 22:34:02 --> Helper loaded: date_helper
INFO - 2016-08-11 22:34:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:34:02 --> Database Driver Class Initialized
INFO - 2016-08-11 22:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:34:02 --> Email Class Initialized
INFO - 2016-08-11 22:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:34:02 --> Pagination Class Initialized
INFO - 2016-08-11 22:34:02 --> Model Class Initialized
INFO - 2016-08-11 22:34:02 --> Controller Class Initialized
INFO - 2016-08-11 22:34:02 --> Model Class Initialized
INFO - 2016-08-11 22:34:02 --> Helper loaded: text_helper
INFO - 2016-08-11 22:34:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:34:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:34:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:34:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:34:02 --> Final output sent to browser
DEBUG - 2016-08-11 22:34:02 --> Total execution time: 0.6831
INFO - 2016-08-11 22:35:11 --> Config Class Initialized
INFO - 2016-08-11 22:35:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:35:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:35:11 --> Utf8 Class Initialized
INFO - 2016-08-11 22:35:11 --> URI Class Initialized
INFO - 2016-08-11 22:35:11 --> Router Class Initialized
INFO - 2016-08-11 22:35:11 --> Output Class Initialized
INFO - 2016-08-11 22:35:11 --> Security Class Initialized
DEBUG - 2016-08-11 22:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:35:11 --> Input Class Initialized
INFO - 2016-08-11 22:35:11 --> Language Class Initialized
INFO - 2016-08-11 22:35:11 --> Loader Class Initialized
INFO - 2016-08-11 22:35:11 --> Helper loaded: url_helper
INFO - 2016-08-11 22:35:11 --> Helper loaded: date_helper
INFO - 2016-08-11 22:35:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:35:11 --> Database Driver Class Initialized
INFO - 2016-08-11 22:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:35:11 --> Email Class Initialized
INFO - 2016-08-11 22:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:35:11 --> Pagination Class Initialized
INFO - 2016-08-11 22:35:11 --> Model Class Initialized
INFO - 2016-08-11 22:35:11 --> Controller Class Initialized
INFO - 2016-08-11 22:35:11 --> Model Class Initialized
INFO - 2016-08-11 22:35:11 --> Helper loaded: text_helper
INFO - 2016-08-11 22:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:35:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:35:11 --> Final output sent to browser
DEBUG - 2016-08-11 22:35:12 --> Total execution time: 0.6836
INFO - 2016-08-11 22:35:21 --> Config Class Initialized
INFO - 2016-08-11 22:35:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:35:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:35:21 --> Utf8 Class Initialized
INFO - 2016-08-11 22:35:21 --> URI Class Initialized
INFO - 2016-08-11 22:35:21 --> Router Class Initialized
INFO - 2016-08-11 22:35:21 --> Output Class Initialized
INFO - 2016-08-11 22:35:21 --> Security Class Initialized
DEBUG - 2016-08-11 22:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:35:21 --> Input Class Initialized
INFO - 2016-08-11 22:35:21 --> Language Class Initialized
INFO - 2016-08-11 22:35:21 --> Loader Class Initialized
INFO - 2016-08-11 22:35:21 --> Helper loaded: url_helper
INFO - 2016-08-11 22:35:21 --> Helper loaded: date_helper
INFO - 2016-08-11 22:35:21 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:35:21 --> Database Driver Class Initialized
INFO - 2016-08-11 22:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:35:21 --> Email Class Initialized
INFO - 2016-08-11 22:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:35:21 --> Pagination Class Initialized
INFO - 2016-08-11 22:35:21 --> Model Class Initialized
INFO - 2016-08-11 22:35:21 --> Controller Class Initialized
INFO - 2016-08-11 22:35:21 --> Model Class Initialized
INFO - 2016-08-11 22:35:21 --> Helper loaded: text_helper
INFO - 2016-08-11 22:35:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:35:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:35:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:35:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:35:22 --> Final output sent to browser
DEBUG - 2016-08-11 22:35:22 --> Total execution time: 0.6803
INFO - 2016-08-11 22:35:35 --> Config Class Initialized
INFO - 2016-08-11 22:35:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:35:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:35:35 --> Utf8 Class Initialized
INFO - 2016-08-11 22:35:35 --> URI Class Initialized
INFO - 2016-08-11 22:35:35 --> Router Class Initialized
INFO - 2016-08-11 22:35:35 --> Output Class Initialized
INFO - 2016-08-11 22:35:35 --> Security Class Initialized
DEBUG - 2016-08-11 22:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:35:35 --> Input Class Initialized
INFO - 2016-08-11 22:35:35 --> Language Class Initialized
INFO - 2016-08-11 22:35:35 --> Loader Class Initialized
INFO - 2016-08-11 22:35:35 --> Helper loaded: url_helper
INFO - 2016-08-11 22:35:35 --> Helper loaded: date_helper
INFO - 2016-08-11 22:35:35 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:35:35 --> Database Driver Class Initialized
INFO - 2016-08-11 22:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:35:35 --> Email Class Initialized
INFO - 2016-08-11 22:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:35:35 --> Pagination Class Initialized
INFO - 2016-08-11 22:35:35 --> Model Class Initialized
INFO - 2016-08-11 22:35:36 --> Controller Class Initialized
INFO - 2016-08-11 22:35:36 --> Model Class Initialized
INFO - 2016-08-11 22:35:36 --> Helper loaded: text_helper
INFO - 2016-08-11 22:35:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:35:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:35:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:35:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:35:36 --> Final output sent to browser
DEBUG - 2016-08-11 22:35:36 --> Total execution time: 0.7254
INFO - 2016-08-11 22:36:14 --> Config Class Initialized
INFO - 2016-08-11 22:36:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:36:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:36:14 --> Utf8 Class Initialized
INFO - 2016-08-11 22:36:14 --> URI Class Initialized
INFO - 2016-08-11 22:36:14 --> Router Class Initialized
INFO - 2016-08-11 22:36:14 --> Output Class Initialized
INFO - 2016-08-11 22:36:14 --> Security Class Initialized
DEBUG - 2016-08-11 22:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:36:14 --> Input Class Initialized
INFO - 2016-08-11 22:36:14 --> Language Class Initialized
INFO - 2016-08-11 22:36:14 --> Loader Class Initialized
INFO - 2016-08-11 22:36:14 --> Helper loaded: url_helper
INFO - 2016-08-11 22:36:14 --> Helper loaded: date_helper
INFO - 2016-08-11 22:36:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:36:15 --> Database Driver Class Initialized
INFO - 2016-08-11 22:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:36:15 --> Email Class Initialized
INFO - 2016-08-11 22:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:36:15 --> Pagination Class Initialized
INFO - 2016-08-11 22:36:15 --> Model Class Initialized
INFO - 2016-08-11 22:36:15 --> Controller Class Initialized
INFO - 2016-08-11 22:36:15 --> Model Class Initialized
INFO - 2016-08-11 22:36:15 --> Helper loaded: text_helper
INFO - 2016-08-11 22:36:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:36:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:36:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:36:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:36:15 --> Final output sent to browser
DEBUG - 2016-08-11 22:36:15 --> Total execution time: 0.6696
INFO - 2016-08-11 22:36:19 --> Config Class Initialized
INFO - 2016-08-11 22:36:19 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:36:19 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:36:19 --> Utf8 Class Initialized
INFO - 2016-08-11 22:36:19 --> URI Class Initialized
INFO - 2016-08-11 22:36:19 --> Router Class Initialized
INFO - 2016-08-11 22:36:19 --> Output Class Initialized
INFO - 2016-08-11 22:36:20 --> Security Class Initialized
DEBUG - 2016-08-11 22:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:36:20 --> Input Class Initialized
INFO - 2016-08-11 22:36:20 --> Language Class Initialized
INFO - 2016-08-11 22:36:20 --> Loader Class Initialized
INFO - 2016-08-11 22:36:20 --> Helper loaded: url_helper
INFO - 2016-08-11 22:36:20 --> Helper loaded: date_helper
INFO - 2016-08-11 22:36:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:36:20 --> Database Driver Class Initialized
INFO - 2016-08-11 22:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:36:20 --> Email Class Initialized
INFO - 2016-08-11 22:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:36:20 --> Pagination Class Initialized
INFO - 2016-08-11 22:36:20 --> Model Class Initialized
INFO - 2016-08-11 22:36:20 --> Controller Class Initialized
INFO - 2016-08-11 22:36:20 --> Model Class Initialized
INFO - 2016-08-11 22:36:20 --> Helper loaded: text_helper
INFO - 2016-08-11 22:36:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:36:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:36:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:36:20 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:36:20 --> Final output sent to browser
DEBUG - 2016-08-11 22:36:20 --> Total execution time: 0.6844
INFO - 2016-08-11 22:36:28 --> Config Class Initialized
INFO - 2016-08-11 22:36:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:36:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:36:28 --> Utf8 Class Initialized
INFO - 2016-08-11 22:36:28 --> URI Class Initialized
INFO - 2016-08-11 22:36:28 --> Router Class Initialized
INFO - 2016-08-11 22:36:28 --> Output Class Initialized
INFO - 2016-08-11 22:36:28 --> Security Class Initialized
DEBUG - 2016-08-11 22:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:36:28 --> Input Class Initialized
INFO - 2016-08-11 22:36:28 --> Language Class Initialized
INFO - 2016-08-11 22:36:28 --> Loader Class Initialized
INFO - 2016-08-11 22:36:28 --> Helper loaded: url_helper
INFO - 2016-08-11 22:36:28 --> Helper loaded: date_helper
INFO - 2016-08-11 22:36:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:36:28 --> Database Driver Class Initialized
INFO - 2016-08-11 22:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:36:28 --> Email Class Initialized
INFO - 2016-08-11 22:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:36:28 --> Pagination Class Initialized
INFO - 2016-08-11 22:36:28 --> Model Class Initialized
INFO - 2016-08-11 22:36:28 --> Controller Class Initialized
INFO - 2016-08-11 22:36:28 --> Model Class Initialized
INFO - 2016-08-11 22:36:28 --> Helper loaded: text_helper
INFO - 2016-08-11 22:36:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:36:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:36:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:36:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:36:28 --> Final output sent to browser
DEBUG - 2016-08-11 22:36:28 --> Total execution time: 0.6733
INFO - 2016-08-11 22:36:55 --> Config Class Initialized
INFO - 2016-08-11 22:36:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:36:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:36:55 --> Utf8 Class Initialized
INFO - 2016-08-11 22:36:55 --> URI Class Initialized
INFO - 2016-08-11 22:36:55 --> Router Class Initialized
INFO - 2016-08-11 22:36:55 --> Output Class Initialized
INFO - 2016-08-11 22:36:55 --> Security Class Initialized
DEBUG - 2016-08-11 22:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:36:55 --> Input Class Initialized
INFO - 2016-08-11 22:36:55 --> Language Class Initialized
INFO - 2016-08-11 22:36:55 --> Loader Class Initialized
INFO - 2016-08-11 22:36:55 --> Helper loaded: url_helper
INFO - 2016-08-11 22:36:55 --> Helper loaded: date_helper
INFO - 2016-08-11 22:36:55 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:36:55 --> Database Driver Class Initialized
INFO - 2016-08-11 22:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:36:55 --> Email Class Initialized
INFO - 2016-08-11 22:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:36:55 --> Pagination Class Initialized
INFO - 2016-08-11 22:36:55 --> Model Class Initialized
INFO - 2016-08-11 22:36:55 --> Controller Class Initialized
INFO - 2016-08-11 22:36:55 --> Model Class Initialized
INFO - 2016-08-11 22:36:55 --> Helper loaded: text_helper
INFO - 2016-08-11 22:36:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:36:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:36:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:36:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:36:55 --> Final output sent to browser
DEBUG - 2016-08-11 22:36:55 --> Total execution time: 0.6819
INFO - 2016-08-11 22:37:11 --> Config Class Initialized
INFO - 2016-08-11 22:37:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:37:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:37:11 --> Utf8 Class Initialized
INFO - 2016-08-11 22:37:11 --> URI Class Initialized
INFO - 2016-08-11 22:37:11 --> Router Class Initialized
INFO - 2016-08-11 22:37:12 --> Output Class Initialized
INFO - 2016-08-11 22:37:12 --> Security Class Initialized
DEBUG - 2016-08-11 22:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:37:12 --> Input Class Initialized
INFO - 2016-08-11 22:37:12 --> Language Class Initialized
INFO - 2016-08-11 22:37:12 --> Loader Class Initialized
INFO - 2016-08-11 22:37:12 --> Helper loaded: url_helper
INFO - 2016-08-11 22:37:12 --> Helper loaded: date_helper
INFO - 2016-08-11 22:37:12 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:37:12 --> Database Driver Class Initialized
INFO - 2016-08-11 22:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:37:12 --> Email Class Initialized
INFO - 2016-08-11 22:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:37:12 --> Pagination Class Initialized
INFO - 2016-08-11 22:37:12 --> Model Class Initialized
INFO - 2016-08-11 22:37:12 --> Controller Class Initialized
INFO - 2016-08-11 22:37:12 --> Model Class Initialized
INFO - 2016-08-11 22:37:12 --> Helper loaded: text_helper
INFO - 2016-08-11 22:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:37:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:37:12 --> Final output sent to browser
DEBUG - 2016-08-11 22:37:12 --> Total execution time: 0.7309
INFO - 2016-08-11 22:39:26 --> Config Class Initialized
INFO - 2016-08-11 22:39:26 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:39:26 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:39:26 --> Utf8 Class Initialized
INFO - 2016-08-11 22:39:26 --> URI Class Initialized
INFO - 2016-08-11 22:39:26 --> Router Class Initialized
INFO - 2016-08-11 22:39:26 --> Output Class Initialized
INFO - 2016-08-11 22:39:26 --> Security Class Initialized
DEBUG - 2016-08-11 22:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:39:26 --> Input Class Initialized
INFO - 2016-08-11 22:39:26 --> Language Class Initialized
INFO - 2016-08-11 22:39:26 --> Loader Class Initialized
INFO - 2016-08-11 22:39:26 --> Helper loaded: url_helper
INFO - 2016-08-11 22:39:26 --> Helper loaded: date_helper
INFO - 2016-08-11 22:39:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:39:26 --> Database Driver Class Initialized
INFO - 2016-08-11 22:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:39:26 --> Email Class Initialized
INFO - 2016-08-11 22:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:39:26 --> Pagination Class Initialized
INFO - 2016-08-11 22:39:26 --> Model Class Initialized
INFO - 2016-08-11 22:39:26 --> Controller Class Initialized
INFO - 2016-08-11 22:39:26 --> Model Class Initialized
INFO - 2016-08-11 22:39:26 --> Helper loaded: text_helper
INFO - 2016-08-11 22:39:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:39:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:39:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:39:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:39:26 --> Final output sent to browser
DEBUG - 2016-08-11 22:39:26 --> Total execution time: 0.7182
INFO - 2016-08-11 22:39:27 --> Config Class Initialized
INFO - 2016-08-11 22:39:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:39:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:39:27 --> Utf8 Class Initialized
INFO - 2016-08-11 22:39:27 --> URI Class Initialized
INFO - 2016-08-11 22:39:27 --> Router Class Initialized
INFO - 2016-08-11 22:39:27 --> Output Class Initialized
INFO - 2016-08-11 22:39:27 --> Security Class Initialized
DEBUG - 2016-08-11 22:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:39:27 --> Input Class Initialized
INFO - 2016-08-11 22:39:27 --> Language Class Initialized
ERROR - 2016-08-11 22:39:27 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 22:40:00 --> Config Class Initialized
INFO - 2016-08-11 22:40:00 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:40:00 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:40:00 --> Utf8 Class Initialized
INFO - 2016-08-11 22:40:00 --> URI Class Initialized
INFO - 2016-08-11 22:40:00 --> Router Class Initialized
INFO - 2016-08-11 22:40:00 --> Output Class Initialized
INFO - 2016-08-11 22:40:00 --> Security Class Initialized
DEBUG - 2016-08-11 22:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:40:00 --> Input Class Initialized
INFO - 2016-08-11 22:40:00 --> Language Class Initialized
INFO - 2016-08-11 22:40:00 --> Loader Class Initialized
INFO - 2016-08-11 22:40:00 --> Helper loaded: url_helper
INFO - 2016-08-11 22:40:00 --> Helper loaded: date_helper
INFO - 2016-08-11 22:40:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:40:00 --> Database Driver Class Initialized
INFO - 2016-08-11 22:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:40:00 --> Email Class Initialized
INFO - 2016-08-11 22:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:40:00 --> Pagination Class Initialized
INFO - 2016-08-11 22:40:00 --> Model Class Initialized
INFO - 2016-08-11 22:40:00 --> Controller Class Initialized
INFO - 2016-08-11 22:40:00 --> Model Class Initialized
INFO - 2016-08-11 22:40:00 --> Helper loaded: text_helper
ERROR - 2016-08-11 22:40:01 --> Severity: Error --> Call to a member function num_rows() on a non-object D:\xampp\htdocs\aqiqahsehati\application\controllers\News.php 31
INFO - 2016-08-11 22:40:05 --> Config Class Initialized
INFO - 2016-08-11 22:40:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:40:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:40:05 --> Utf8 Class Initialized
INFO - 2016-08-11 22:40:05 --> URI Class Initialized
INFO - 2016-08-11 22:40:06 --> Router Class Initialized
INFO - 2016-08-11 22:40:06 --> Output Class Initialized
INFO - 2016-08-11 22:40:06 --> Security Class Initialized
DEBUG - 2016-08-11 22:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:40:06 --> Input Class Initialized
INFO - 2016-08-11 22:40:06 --> Language Class Initialized
INFO - 2016-08-11 22:40:06 --> Loader Class Initialized
INFO - 2016-08-11 22:40:06 --> Helper loaded: url_helper
INFO - 2016-08-11 22:40:06 --> Helper loaded: date_helper
INFO - 2016-08-11 22:40:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:40:06 --> Database Driver Class Initialized
INFO - 2016-08-11 22:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:40:06 --> Email Class Initialized
INFO - 2016-08-11 22:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:40:06 --> Pagination Class Initialized
INFO - 2016-08-11 22:40:06 --> Model Class Initialized
INFO - 2016-08-11 22:40:06 --> Controller Class Initialized
INFO - 2016-08-11 22:40:06 --> Model Class Initialized
INFO - 2016-08-11 22:40:06 --> Helper loaded: text_helper
INFO - 2016-08-11 22:40:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:40:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:40:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:40:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:40:06 --> Final output sent to browser
DEBUG - 2016-08-11 22:40:06 --> Total execution time: 0.7283
INFO - 2016-08-11 22:40:24 --> Config Class Initialized
INFO - 2016-08-11 22:40:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:40:24 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:40:24 --> Utf8 Class Initialized
INFO - 2016-08-11 22:40:24 --> URI Class Initialized
INFO - 2016-08-11 22:40:24 --> Router Class Initialized
INFO - 2016-08-11 22:40:24 --> Output Class Initialized
INFO - 2016-08-11 22:40:24 --> Security Class Initialized
DEBUG - 2016-08-11 22:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:40:24 --> Input Class Initialized
INFO - 2016-08-11 22:40:24 --> Language Class Initialized
INFO - 2016-08-11 22:40:24 --> Loader Class Initialized
INFO - 2016-08-11 22:40:24 --> Helper loaded: url_helper
INFO - 2016-08-11 22:40:24 --> Helper loaded: date_helper
INFO - 2016-08-11 22:40:24 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:40:24 --> Database Driver Class Initialized
INFO - 2016-08-11 22:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:40:24 --> Email Class Initialized
INFO - 2016-08-11 22:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:40:24 --> Pagination Class Initialized
INFO - 2016-08-11 22:40:24 --> Model Class Initialized
INFO - 2016-08-11 22:40:24 --> Controller Class Initialized
DEBUG - 2016-08-11 22:40:24 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:40:24 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:40:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:40:24 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:40:24 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:40:25 --> Model Class Initialized
INFO - 2016-08-11 22:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/tambah_posting.php
INFO - 2016-08-11 22:40:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:40:25 --> Final output sent to browser
DEBUG - 2016-08-11 22:40:25 --> Total execution time: 0.8252
INFO - 2016-08-11 22:41:17 --> Config Class Initialized
INFO - 2016-08-11 22:41:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:41:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:41:17 --> Utf8 Class Initialized
INFO - 2016-08-11 22:41:17 --> URI Class Initialized
INFO - 2016-08-11 22:41:17 --> Router Class Initialized
INFO - 2016-08-11 22:41:17 --> Output Class Initialized
INFO - 2016-08-11 22:41:17 --> Security Class Initialized
DEBUG - 2016-08-11 22:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:41:17 --> Input Class Initialized
INFO - 2016-08-11 22:41:17 --> Language Class Initialized
INFO - 2016-08-11 22:41:17 --> Loader Class Initialized
INFO - 2016-08-11 22:41:17 --> Helper loaded: url_helper
INFO - 2016-08-11 22:41:17 --> Helper loaded: date_helper
INFO - 2016-08-11 22:41:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:41:17 --> Database Driver Class Initialized
INFO - 2016-08-11 22:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:41:17 --> Email Class Initialized
INFO - 2016-08-11 22:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:41:17 --> Pagination Class Initialized
INFO - 2016-08-11 22:41:17 --> Model Class Initialized
INFO - 2016-08-11 22:41:17 --> Controller Class Initialized
DEBUG - 2016-08-11 22:41:17 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:41:17 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:41:17 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:41:17 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:41:17 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:41:17 --> Model Class Initialized
INFO - 2016-08-11 22:41:17 --> Upload Class Initialized
INFO - 2016-08-11 22:41:18 --> Config Class Initialized
INFO - 2016-08-11 22:41:18 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:41:18 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:41:18 --> Utf8 Class Initialized
INFO - 2016-08-11 22:41:18 --> URI Class Initialized
INFO - 2016-08-11 22:41:18 --> Router Class Initialized
INFO - 2016-08-11 22:41:18 --> Output Class Initialized
INFO - 2016-08-11 22:41:18 --> Security Class Initialized
DEBUG - 2016-08-11 22:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:41:18 --> Input Class Initialized
INFO - 2016-08-11 22:41:18 --> Language Class Initialized
INFO - 2016-08-11 22:41:18 --> Loader Class Initialized
INFO - 2016-08-11 22:41:18 --> Helper loaded: url_helper
INFO - 2016-08-11 22:41:18 --> Helper loaded: date_helper
INFO - 2016-08-11 22:41:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:41:18 --> Database Driver Class Initialized
INFO - 2016-08-11 22:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:41:18 --> Email Class Initialized
INFO - 2016-08-11 22:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:41:18 --> Pagination Class Initialized
INFO - 2016-08-11 22:41:18 --> Model Class Initialized
INFO - 2016-08-11 22:41:18 --> Controller Class Initialized
DEBUG - 2016-08-11 22:41:18 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:41:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:41:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:41:18 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:41:18 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:41:18 --> Model Class Initialized
INFO - 2016-08-11 22:41:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:41:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:41:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:41:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:41:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:41:18 --> Final output sent to browser
DEBUG - 2016-08-11 22:41:18 --> Total execution time: 0.8954
INFO - 2016-08-11 22:41:23 --> Config Class Initialized
INFO - 2016-08-11 22:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:41:23 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:41:23 --> Utf8 Class Initialized
INFO - 2016-08-11 22:41:23 --> URI Class Initialized
INFO - 2016-08-11 22:41:23 --> Router Class Initialized
INFO - 2016-08-11 22:41:23 --> Output Class Initialized
INFO - 2016-08-11 22:41:23 --> Security Class Initialized
DEBUG - 2016-08-11 22:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:41:23 --> Input Class Initialized
INFO - 2016-08-11 22:41:23 --> Language Class Initialized
INFO - 2016-08-11 22:41:23 --> Loader Class Initialized
INFO - 2016-08-11 22:41:23 --> Helper loaded: url_helper
INFO - 2016-08-11 22:41:23 --> Helper loaded: date_helper
INFO - 2016-08-11 22:41:23 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:41:23 --> Database Driver Class Initialized
INFO - 2016-08-11 22:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:41:23 --> Email Class Initialized
INFO - 2016-08-11 22:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:41:23 --> Pagination Class Initialized
INFO - 2016-08-11 22:41:23 --> Model Class Initialized
INFO - 2016-08-11 22:41:23 --> Controller Class Initialized
INFO - 2016-08-11 22:41:23 --> Model Class Initialized
INFO - 2016-08-11 22:41:23 --> Helper loaded: text_helper
INFO - 2016-08-11 22:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:41:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:41:23 --> Final output sent to browser
DEBUG - 2016-08-11 22:41:23 --> Total execution time: 0.7058
INFO - 2016-08-11 22:41:39 --> Config Class Initialized
INFO - 2016-08-11 22:41:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:41:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:41:40 --> Utf8 Class Initialized
INFO - 2016-08-11 22:41:40 --> URI Class Initialized
INFO - 2016-08-11 22:41:40 --> Router Class Initialized
INFO - 2016-08-11 22:41:40 --> Output Class Initialized
INFO - 2016-08-11 22:41:40 --> Security Class Initialized
DEBUG - 2016-08-11 22:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:41:40 --> Input Class Initialized
INFO - 2016-08-11 22:41:40 --> Language Class Initialized
INFO - 2016-08-11 22:41:40 --> Loader Class Initialized
INFO - 2016-08-11 22:41:40 --> Helper loaded: url_helper
INFO - 2016-08-11 22:41:40 --> Helper loaded: date_helper
INFO - 2016-08-11 22:41:40 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:41:40 --> Database Driver Class Initialized
INFO - 2016-08-11 22:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:41:40 --> Email Class Initialized
INFO - 2016-08-11 22:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:41:40 --> Pagination Class Initialized
INFO - 2016-08-11 22:41:40 --> Model Class Initialized
INFO - 2016-08-11 22:41:40 --> Controller Class Initialized
INFO - 2016-08-11 22:41:40 --> Model Class Initialized
INFO - 2016-08-11 22:41:40 --> Helper loaded: text_helper
INFO - 2016-08-11 22:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:41:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:41:40 --> Final output sent to browser
DEBUG - 2016-08-11 22:41:40 --> Total execution time: 0.7204
INFO - 2016-08-11 22:41:49 --> Config Class Initialized
INFO - 2016-08-11 22:41:49 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:41:49 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:41:49 --> Utf8 Class Initialized
INFO - 2016-08-11 22:41:49 --> URI Class Initialized
INFO - 2016-08-11 22:41:49 --> Router Class Initialized
INFO - 2016-08-11 22:41:49 --> Output Class Initialized
INFO - 2016-08-11 22:41:49 --> Security Class Initialized
DEBUG - 2016-08-11 22:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:41:49 --> Input Class Initialized
INFO - 2016-08-11 22:41:49 --> Language Class Initialized
INFO - 2016-08-11 22:41:49 --> Loader Class Initialized
INFO - 2016-08-11 22:41:49 --> Helper loaded: url_helper
INFO - 2016-08-11 22:41:49 --> Helper loaded: date_helper
INFO - 2016-08-11 22:41:49 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:41:49 --> Database Driver Class Initialized
INFO - 2016-08-11 22:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:41:49 --> Email Class Initialized
INFO - 2016-08-11 22:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:41:49 --> Pagination Class Initialized
INFO - 2016-08-11 22:41:49 --> Model Class Initialized
INFO - 2016-08-11 22:41:49 --> Controller Class Initialized
INFO - 2016-08-11 22:41:49 --> Model Class Initialized
INFO - 2016-08-11 22:41:49 --> Helper loaded: text_helper
INFO - 2016-08-11 22:41:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:41:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:41:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:41:50 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:41:50 --> Final output sent to browser
DEBUG - 2016-08-11 22:41:50 --> Total execution time: 0.7036
INFO - 2016-08-11 22:42:26 --> Config Class Initialized
INFO - 2016-08-11 22:42:26 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:42:26 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:42:26 --> Utf8 Class Initialized
INFO - 2016-08-11 22:42:26 --> URI Class Initialized
INFO - 2016-08-11 22:42:26 --> Router Class Initialized
INFO - 2016-08-11 22:42:26 --> Output Class Initialized
INFO - 2016-08-11 22:42:26 --> Security Class Initialized
DEBUG - 2016-08-11 22:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:42:26 --> Input Class Initialized
INFO - 2016-08-11 22:42:26 --> Language Class Initialized
INFO - 2016-08-11 22:42:26 --> Loader Class Initialized
INFO - 2016-08-11 22:42:26 --> Helper loaded: url_helper
INFO - 2016-08-11 22:42:26 --> Helper loaded: date_helper
INFO - 2016-08-11 22:42:26 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:42:26 --> Database Driver Class Initialized
INFO - 2016-08-11 22:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:42:26 --> Email Class Initialized
INFO - 2016-08-11 22:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:42:26 --> Pagination Class Initialized
INFO - 2016-08-11 22:42:26 --> Model Class Initialized
INFO - 2016-08-11 22:42:26 --> Controller Class Initialized
DEBUG - 2016-08-11 22:42:26 --> Config file loaded: D:\xampp\htdocs\aqiqahsehati\application\config/ion_auth.php
DEBUG - 2016-08-11 22:42:26 --> Email class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:42:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-08-11 22:42:26 --> Helper loaded: cookie_helper
INFO - 2016-08-11 22:42:26 --> Helper loaded: language_helper
DEBUG - 2016-08-11 22:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-08-11 22:42:26 --> Model Class Initialized
INFO - 2016-08-11 22:42:26 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/head.php
INFO - 2016-08-11 22:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/nav.php
INFO - 2016-08-11 22:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/menu.php
INFO - 2016-08-11 22:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/posting/view_posting.php
INFO - 2016-08-11 22:42:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\admin/template/foot.php
INFO - 2016-08-11 22:42:27 --> Final output sent to browser
DEBUG - 2016-08-11 22:42:27 --> Total execution time: 0.8642
INFO - 2016-08-11 22:42:28 --> Config Class Initialized
INFO - 2016-08-11 22:42:28 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:42:28 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:42:28 --> Utf8 Class Initialized
INFO - 2016-08-11 22:42:28 --> URI Class Initialized
INFO - 2016-08-11 22:42:28 --> Router Class Initialized
INFO - 2016-08-11 22:42:28 --> Output Class Initialized
INFO - 2016-08-11 22:42:28 --> Security Class Initialized
DEBUG - 2016-08-11 22:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:42:28 --> Input Class Initialized
INFO - 2016-08-11 22:42:29 --> Language Class Initialized
INFO - 2016-08-11 22:42:29 --> Loader Class Initialized
INFO - 2016-08-11 22:42:29 --> Helper loaded: url_helper
INFO - 2016-08-11 22:42:29 --> Helper loaded: date_helper
INFO - 2016-08-11 22:42:29 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:42:29 --> Database Driver Class Initialized
INFO - 2016-08-11 22:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:42:29 --> Email Class Initialized
INFO - 2016-08-11 22:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:42:29 --> Pagination Class Initialized
INFO - 2016-08-11 22:42:29 --> Model Class Initialized
INFO - 2016-08-11 22:42:29 --> Controller Class Initialized
INFO - 2016-08-11 22:42:29 --> Model Class Initialized
INFO - 2016-08-11 22:42:29 --> Helper loaded: text_helper
INFO - 2016-08-11 22:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:42:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:42:29 --> Final output sent to browser
DEBUG - 2016-08-11 22:42:29 --> Total execution time: 0.8564
INFO - 2016-08-11 22:42:33 --> Config Class Initialized
INFO - 2016-08-11 22:42:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:42:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:42:33 --> Utf8 Class Initialized
INFO - 2016-08-11 22:42:33 --> URI Class Initialized
INFO - 2016-08-11 22:42:33 --> Router Class Initialized
INFO - 2016-08-11 22:42:33 --> Output Class Initialized
INFO - 2016-08-11 22:42:33 --> Security Class Initialized
DEBUG - 2016-08-11 22:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:42:33 --> Input Class Initialized
INFO - 2016-08-11 22:42:33 --> Language Class Initialized
INFO - 2016-08-11 22:42:33 --> Loader Class Initialized
INFO - 2016-08-11 22:42:33 --> Helper loaded: url_helper
INFO - 2016-08-11 22:42:33 --> Helper loaded: date_helper
INFO - 2016-08-11 22:42:33 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:42:33 --> Database Driver Class Initialized
INFO - 2016-08-11 22:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:42:33 --> Email Class Initialized
INFO - 2016-08-11 22:42:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:42:33 --> Pagination Class Initialized
INFO - 2016-08-11 22:42:33 --> Model Class Initialized
INFO - 2016-08-11 22:42:33 --> Controller Class Initialized
INFO - 2016-08-11 22:42:33 --> Model Class Initialized
INFO - 2016-08-11 22:42:33 --> Helper loaded: text_helper
INFO - 2016-08-11 22:42:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:42:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:42:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:42:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:42:34 --> Final output sent to browser
DEBUG - 2016-08-11 22:42:34 --> Total execution time: 0.8409
INFO - 2016-08-11 22:42:37 --> Config Class Initialized
INFO - 2016-08-11 22:42:37 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:42:37 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:42:37 --> Utf8 Class Initialized
INFO - 2016-08-11 22:42:37 --> URI Class Initialized
INFO - 2016-08-11 22:42:37 --> Router Class Initialized
INFO - 2016-08-11 22:42:37 --> Output Class Initialized
INFO - 2016-08-11 22:42:37 --> Security Class Initialized
DEBUG - 2016-08-11 22:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:42:37 --> Input Class Initialized
INFO - 2016-08-11 22:42:37 --> Language Class Initialized
INFO - 2016-08-11 22:42:37 --> Loader Class Initialized
INFO - 2016-08-11 22:42:37 --> Helper loaded: url_helper
INFO - 2016-08-11 22:42:37 --> Helper loaded: date_helper
INFO - 2016-08-11 22:42:37 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:42:37 --> Database Driver Class Initialized
INFO - 2016-08-11 22:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:42:38 --> Email Class Initialized
INFO - 2016-08-11 22:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:42:38 --> Pagination Class Initialized
INFO - 2016-08-11 22:42:38 --> Model Class Initialized
INFO - 2016-08-11 22:42:38 --> Controller Class Initialized
INFO - 2016-08-11 22:42:38 --> Model Class Initialized
INFO - 2016-08-11 22:42:38 --> Helper loaded: text_helper
INFO - 2016-08-11 22:42:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:42:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:42:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:42:38 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:42:38 --> Final output sent to browser
DEBUG - 2016-08-11 22:42:38 --> Total execution time: 0.7607
INFO - 2016-08-11 22:45:13 --> Config Class Initialized
INFO - 2016-08-11 22:45:13 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:13 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:13 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:13 --> URI Class Initialized
INFO - 2016-08-11 22:45:13 --> Router Class Initialized
INFO - 2016-08-11 22:45:13 --> Output Class Initialized
INFO - 2016-08-11 22:45:13 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:13 --> Input Class Initialized
INFO - 2016-08-11 22:45:13 --> Language Class Initialized
INFO - 2016-08-11 22:45:13 --> Loader Class Initialized
INFO - 2016-08-11 22:45:13 --> Helper loaded: url_helper
INFO - 2016-08-11 22:45:13 --> Helper loaded: date_helper
INFO - 2016-08-11 22:45:13 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:45:13 --> Database Driver Class Initialized
INFO - 2016-08-11 22:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:45:13 --> Email Class Initialized
INFO - 2016-08-11 22:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:45:13 --> Pagination Class Initialized
INFO - 2016-08-11 22:45:13 --> Model Class Initialized
INFO - 2016-08-11 22:45:13 --> Controller Class Initialized
INFO - 2016-08-11 22:45:13 --> Model Class Initialized
INFO - 2016-08-11 22:45:13 --> Helper loaded: text_helper
INFO - 2016-08-11 22:45:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:45:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:45:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:45:13 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:45:14 --> Final output sent to browser
DEBUG - 2016-08-11 22:45:14 --> Total execution time: 0.7454
INFO - 2016-08-11 22:45:14 --> Config Class Initialized
INFO - 2016-08-11 22:45:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:14 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:14 --> URI Class Initialized
INFO - 2016-08-11 22:45:14 --> Router Class Initialized
INFO - 2016-08-11 22:45:14 --> Output Class Initialized
INFO - 2016-08-11 22:45:14 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:14 --> Input Class Initialized
INFO - 2016-08-11 22:45:14 --> Language Class Initialized
ERROR - 2016-08-11 22:45:14 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 22:45:17 --> Config Class Initialized
INFO - 2016-08-11 22:45:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:17 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:17 --> URI Class Initialized
INFO - 2016-08-11 22:45:18 --> Router Class Initialized
INFO - 2016-08-11 22:45:18 --> Output Class Initialized
INFO - 2016-08-11 22:45:18 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:18 --> Input Class Initialized
INFO - 2016-08-11 22:45:18 --> Language Class Initialized
INFO - 2016-08-11 22:45:18 --> Loader Class Initialized
INFO - 2016-08-11 22:45:18 --> Helper loaded: url_helper
INFO - 2016-08-11 22:45:18 --> Helper loaded: date_helper
INFO - 2016-08-11 22:45:18 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:45:18 --> Database Driver Class Initialized
INFO - 2016-08-11 22:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:45:18 --> Email Class Initialized
INFO - 2016-08-11 22:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:45:18 --> Pagination Class Initialized
INFO - 2016-08-11 22:45:18 --> Model Class Initialized
INFO - 2016-08-11 22:45:18 --> Controller Class Initialized
INFO - 2016-08-11 22:45:18 --> Model Class Initialized
INFO - 2016-08-11 22:45:18 --> Helper loaded: text_helper
INFO - 2016-08-11 22:45:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:45:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:45:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:45:18 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:45:18 --> Final output sent to browser
DEBUG - 2016-08-11 22:45:18 --> Total execution time: 0.8647
INFO - 2016-08-11 22:45:22 --> Config Class Initialized
INFO - 2016-08-11 22:45:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:22 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:22 --> URI Class Initialized
INFO - 2016-08-11 22:45:22 --> Router Class Initialized
INFO - 2016-08-11 22:45:22 --> Output Class Initialized
INFO - 2016-08-11 22:45:22 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:22 --> Input Class Initialized
INFO - 2016-08-11 22:45:22 --> Language Class Initialized
INFO - 2016-08-11 22:45:22 --> Loader Class Initialized
INFO - 2016-08-11 22:45:22 --> Helper loaded: url_helper
INFO - 2016-08-11 22:45:22 --> Helper loaded: date_helper
INFO - 2016-08-11 22:45:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:45:22 --> Database Driver Class Initialized
INFO - 2016-08-11 22:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:45:22 --> Email Class Initialized
INFO - 2016-08-11 22:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:45:22 --> Pagination Class Initialized
INFO - 2016-08-11 22:45:22 --> Model Class Initialized
INFO - 2016-08-11 22:45:22 --> Controller Class Initialized
INFO - 2016-08-11 22:45:22 --> Model Class Initialized
INFO - 2016-08-11 22:45:22 --> Helper loaded: text_helper
INFO - 2016-08-11 22:45:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:45:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:45:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:45:22 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:45:22 --> Final output sent to browser
DEBUG - 2016-08-11 22:45:22 --> Total execution time: 0.7502
INFO - 2016-08-11 22:45:29 --> Config Class Initialized
INFO - 2016-08-11 22:45:29 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:29 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:29 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:29 --> URI Class Initialized
INFO - 2016-08-11 22:45:29 --> Router Class Initialized
INFO - 2016-08-11 22:45:29 --> Output Class Initialized
INFO - 2016-08-11 22:45:29 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:29 --> Input Class Initialized
INFO - 2016-08-11 22:45:30 --> Language Class Initialized
INFO - 2016-08-11 22:45:30 --> Loader Class Initialized
INFO - 2016-08-11 22:45:30 --> Helper loaded: url_helper
INFO - 2016-08-11 22:45:30 --> Helper loaded: date_helper
INFO - 2016-08-11 22:45:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:45:30 --> Database Driver Class Initialized
INFO - 2016-08-11 22:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:45:30 --> Email Class Initialized
INFO - 2016-08-11 22:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:45:30 --> Pagination Class Initialized
INFO - 2016-08-11 22:45:30 --> Model Class Initialized
INFO - 2016-08-11 22:45:30 --> Controller Class Initialized
INFO - 2016-08-11 22:45:30 --> Model Class Initialized
INFO - 2016-08-11 22:45:30 --> Helper loaded: text_helper
INFO - 2016-08-11 22:45:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:45:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:45:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:45:30 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:45:30 --> Final output sent to browser
DEBUG - 2016-08-11 22:45:30 --> Total execution time: 0.7682
INFO - 2016-08-11 22:45:51 --> Config Class Initialized
INFO - 2016-08-11 22:45:51 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:45:51 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:45:51 --> Utf8 Class Initialized
INFO - 2016-08-11 22:45:51 --> URI Class Initialized
INFO - 2016-08-11 22:45:51 --> Router Class Initialized
INFO - 2016-08-11 22:45:51 --> Output Class Initialized
INFO - 2016-08-11 22:45:51 --> Security Class Initialized
DEBUG - 2016-08-11 22:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:45:51 --> Input Class Initialized
INFO - 2016-08-11 22:45:51 --> Language Class Initialized
INFO - 2016-08-11 22:45:51 --> Loader Class Initialized
INFO - 2016-08-11 22:45:51 --> Helper loaded: url_helper
INFO - 2016-08-11 22:45:51 --> Helper loaded: date_helper
INFO - 2016-08-11 22:45:51 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:45:51 --> Database Driver Class Initialized
INFO - 2016-08-11 22:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:45:51 --> Email Class Initialized
INFO - 2016-08-11 22:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:45:51 --> Pagination Class Initialized
INFO - 2016-08-11 22:45:51 --> Model Class Initialized
INFO - 2016-08-11 22:45:51 --> Controller Class Initialized
INFO - 2016-08-11 22:45:51 --> Model Class Initialized
INFO - 2016-08-11 22:45:51 --> Helper loaded: text_helper
INFO - 2016-08-11 22:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:45:51 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:45:51 --> Final output sent to browser
DEBUG - 2016-08-11 22:45:51 --> Total execution time: 0.8299
INFO - 2016-08-11 22:48:07 --> Config Class Initialized
INFO - 2016-08-11 22:48:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 22:48:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 22:48:07 --> Utf8 Class Initialized
INFO - 2016-08-11 22:48:07 --> URI Class Initialized
INFO - 2016-08-11 22:48:07 --> Router Class Initialized
INFO - 2016-08-11 22:48:07 --> Output Class Initialized
INFO - 2016-08-11 22:48:07 --> Security Class Initialized
DEBUG - 2016-08-11 22:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 22:48:07 --> Input Class Initialized
INFO - 2016-08-11 22:48:07 --> Language Class Initialized
INFO - 2016-08-11 22:48:07 --> Loader Class Initialized
INFO - 2016-08-11 22:48:07 --> Helper loaded: url_helper
INFO - 2016-08-11 22:48:07 --> Helper loaded: date_helper
INFO - 2016-08-11 22:48:07 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 22:48:07 --> Database Driver Class Initialized
INFO - 2016-08-11 22:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 22:48:07 --> Email Class Initialized
INFO - 2016-08-11 22:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 22:48:07 --> Pagination Class Initialized
INFO - 2016-08-11 22:48:08 --> Model Class Initialized
INFO - 2016-08-11 22:48:08 --> Controller Class Initialized
INFO - 2016-08-11 22:48:08 --> Model Class Initialized
INFO - 2016-08-11 22:48:08 --> Helper loaded: text_helper
INFO - 2016-08-11 22:48:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 22:48:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 22:48:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 22:48:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 22:48:08 --> Final output sent to browser
DEBUG - 2016-08-11 22:48:08 --> Total execution time: 0.7255
INFO - 2016-08-11 23:00:47 --> Config Class Initialized
INFO - 2016-08-11 23:00:47 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:00:47 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:00:47 --> Utf8 Class Initialized
INFO - 2016-08-11 23:00:47 --> URI Class Initialized
INFO - 2016-08-11 23:00:47 --> Router Class Initialized
INFO - 2016-08-11 23:00:47 --> Output Class Initialized
INFO - 2016-08-11 23:00:47 --> Security Class Initialized
DEBUG - 2016-08-11 23:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:00:47 --> Input Class Initialized
INFO - 2016-08-11 23:00:47 --> Language Class Initialized
INFO - 2016-08-11 23:00:47 --> Loader Class Initialized
INFO - 2016-08-11 23:00:47 --> Helper loaded: url_helper
INFO - 2016-08-11 23:00:47 --> Helper loaded: date_helper
INFO - 2016-08-11 23:00:47 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:00:47 --> Database Driver Class Initialized
INFO - 2016-08-11 23:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:00:47 --> Email Class Initialized
INFO - 2016-08-11 23:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:00:47 --> Pagination Class Initialized
INFO - 2016-08-11 23:00:47 --> Model Class Initialized
INFO - 2016-08-11 23:00:47 --> Controller Class Initialized
INFO - 2016-08-11 23:00:47 --> Model Class Initialized
INFO - 2016-08-11 23:00:48 --> Helper loaded: text_helper
INFO - 2016-08-11 23:00:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:00:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:00:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:00:48 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:00:48 --> Final output sent to browser
DEBUG - 2016-08-11 23:00:48 --> Total execution time: 0.8171
INFO - 2016-08-11 23:00:48 --> Config Class Initialized
INFO - 2016-08-11 23:00:48 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:00:48 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:00:48 --> Utf8 Class Initialized
INFO - 2016-08-11 23:00:48 --> URI Class Initialized
INFO - 2016-08-11 23:00:48 --> Router Class Initialized
INFO - 2016-08-11 23:00:48 --> Output Class Initialized
INFO - 2016-08-11 23:00:49 --> Security Class Initialized
DEBUG - 2016-08-11 23:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:00:49 --> Input Class Initialized
INFO - 2016-08-11 23:00:49 --> Language Class Initialized
ERROR - 2016-08-11 23:00:49 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:02:25 --> Config Class Initialized
INFO - 2016-08-11 23:02:25 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:02:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:02:25 --> Utf8 Class Initialized
INFO - 2016-08-11 23:02:25 --> URI Class Initialized
INFO - 2016-08-11 23:02:25 --> Router Class Initialized
INFO - 2016-08-11 23:02:25 --> Output Class Initialized
INFO - 2016-08-11 23:02:25 --> Security Class Initialized
DEBUG - 2016-08-11 23:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:02:25 --> Input Class Initialized
INFO - 2016-08-11 23:02:25 --> Language Class Initialized
INFO - 2016-08-11 23:02:25 --> Loader Class Initialized
INFO - 2016-08-11 23:02:25 --> Helper loaded: url_helper
INFO - 2016-08-11 23:02:25 --> Helper loaded: date_helper
INFO - 2016-08-11 23:02:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:02:25 --> Database Driver Class Initialized
INFO - 2016-08-11 23:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:02:25 --> Email Class Initialized
INFO - 2016-08-11 23:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:02:25 --> Pagination Class Initialized
INFO - 2016-08-11 23:02:25 --> Model Class Initialized
INFO - 2016-08-11 23:02:25 --> Controller Class Initialized
INFO - 2016-08-11 23:02:25 --> Model Class Initialized
INFO - 2016-08-11 23:02:25 --> Helper loaded: text_helper
INFO - 2016-08-11 23:02:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:02:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:02:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:02:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:02:25 --> Final output sent to browser
DEBUG - 2016-08-11 23:02:25 --> Total execution time: 0.7111
INFO - 2016-08-11 23:03:58 --> Config Class Initialized
INFO - 2016-08-11 23:03:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:03:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:03:58 --> Utf8 Class Initialized
INFO - 2016-08-11 23:03:58 --> URI Class Initialized
INFO - 2016-08-11 23:03:58 --> Router Class Initialized
INFO - 2016-08-11 23:03:58 --> Output Class Initialized
INFO - 2016-08-11 23:03:58 --> Security Class Initialized
DEBUG - 2016-08-11 23:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:03:58 --> Input Class Initialized
INFO - 2016-08-11 23:03:58 --> Language Class Initialized
INFO - 2016-08-11 23:03:58 --> Loader Class Initialized
INFO - 2016-08-11 23:03:58 --> Helper loaded: url_helper
INFO - 2016-08-11 23:03:58 --> Helper loaded: date_helper
INFO - 2016-08-11 23:03:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:03:59 --> Database Driver Class Initialized
INFO - 2016-08-11 23:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:03:59 --> Email Class Initialized
INFO - 2016-08-11 23:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:03:59 --> Pagination Class Initialized
INFO - 2016-08-11 23:03:59 --> Model Class Initialized
INFO - 2016-08-11 23:03:59 --> Controller Class Initialized
INFO - 2016-08-11 23:03:59 --> Model Class Initialized
INFO - 2016-08-11 23:03:59 --> Helper loaded: text_helper
INFO - 2016-08-11 23:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:03:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:03:59 --> Final output sent to browser
DEBUG - 2016-08-11 23:03:59 --> Total execution time: 0.8304
INFO - 2016-08-11 23:04:04 --> Config Class Initialized
INFO - 2016-08-11 23:04:04 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:04 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:04 --> Utf8 Class Initialized
INFO - 2016-08-11 23:04:04 --> URI Class Initialized
INFO - 2016-08-11 23:04:05 --> Router Class Initialized
INFO - 2016-08-11 23:04:05 --> Output Class Initialized
INFO - 2016-08-11 23:04:05 --> Security Class Initialized
DEBUG - 2016-08-11 23:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:04:05 --> Input Class Initialized
INFO - 2016-08-11 23:04:05 --> Language Class Initialized
INFO - 2016-08-11 23:04:05 --> Loader Class Initialized
INFO - 2016-08-11 23:04:05 --> Helper loaded: url_helper
INFO - 2016-08-11 23:04:05 --> Helper loaded: date_helper
INFO - 2016-08-11 23:04:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:04:05 --> Database Driver Class Initialized
INFO - 2016-08-11 23:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:04:05 --> Email Class Initialized
INFO - 2016-08-11 23:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:04:05 --> Pagination Class Initialized
INFO - 2016-08-11 23:04:05 --> Model Class Initialized
INFO - 2016-08-11 23:04:05 --> Controller Class Initialized
INFO - 2016-08-11 23:04:05 --> Model Class Initialized
INFO - 2016-08-11 23:04:05 --> Helper loaded: text_helper
INFO - 2016-08-11 23:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:04:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:04:05 --> Final output sent to browser
DEBUG - 2016-08-11 23:04:05 --> Total execution time: 0.7022
INFO - 2016-08-11 23:04:11 --> Config Class Initialized
INFO - 2016-08-11 23:04:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:11 --> Utf8 Class Initialized
INFO - 2016-08-11 23:04:11 --> URI Class Initialized
INFO - 2016-08-11 23:04:11 --> Router Class Initialized
INFO - 2016-08-11 23:04:11 --> Output Class Initialized
INFO - 2016-08-11 23:04:11 --> Security Class Initialized
DEBUG - 2016-08-11 23:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:04:11 --> Input Class Initialized
INFO - 2016-08-11 23:04:11 --> Language Class Initialized
INFO - 2016-08-11 23:04:11 --> Loader Class Initialized
INFO - 2016-08-11 23:04:11 --> Helper loaded: url_helper
INFO - 2016-08-11 23:04:11 --> Helper loaded: date_helper
INFO - 2016-08-11 23:04:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:04:11 --> Database Driver Class Initialized
INFO - 2016-08-11 23:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:04:11 --> Email Class Initialized
INFO - 2016-08-11 23:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:04:11 --> Pagination Class Initialized
INFO - 2016-08-11 23:04:11 --> Model Class Initialized
INFO - 2016-08-11 23:04:11 --> Controller Class Initialized
INFO - 2016-08-11 23:04:11 --> Model Class Initialized
INFO - 2016-08-11 23:04:11 --> Helper loaded: text_helper
ERROR - 2016-08-11 23:04:11 --> Severity: Warning --> Missing argument 1 for News::page() D:\xampp\htdocs\aqiqahsehati\application\controllers\News.php 57
ERROR - 2016-08-11 23:04:11 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\aqiqahsehati\application\controllers\News.php 85
INFO - 2016-08-11 23:04:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:04:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:04:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:04:11 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:04:11 --> Final output sent to browser
DEBUG - 2016-08-11 23:04:11 --> Total execution time: 0.7480
INFO - 2016-08-11 23:04:12 --> Config Class Initialized
INFO - 2016-08-11 23:04:12 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:12 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:12 --> Utf8 Class Initialized
INFO - 2016-08-11 23:04:12 --> URI Class Initialized
INFO - 2016-08-11 23:04:12 --> Router Class Initialized
INFO - 2016-08-11 23:04:12 --> Output Class Initialized
INFO - 2016-08-11 23:04:12 --> Security Class Initialized
DEBUG - 2016-08-11 23:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:04:12 --> Input Class Initialized
INFO - 2016-08-11 23:04:12 --> Language Class Initialized
ERROR - 2016-08-11 23:04:12 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:04:14 --> Config Class Initialized
INFO - 2016-08-11 23:04:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:14 --> Utf8 Class Initialized
INFO - 2016-08-11 23:04:14 --> URI Class Initialized
INFO - 2016-08-11 23:04:14 --> Router Class Initialized
INFO - 2016-08-11 23:04:14 --> Output Class Initialized
INFO - 2016-08-11 23:04:14 --> Security Class Initialized
DEBUG - 2016-08-11 23:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:04:14 --> Input Class Initialized
INFO - 2016-08-11 23:04:14 --> Language Class Initialized
INFO - 2016-08-11 23:04:14 --> Loader Class Initialized
INFO - 2016-08-11 23:04:14 --> Helper loaded: url_helper
INFO - 2016-08-11 23:04:14 --> Helper loaded: date_helper
INFO - 2016-08-11 23:04:14 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:04:14 --> Database Driver Class Initialized
INFO - 2016-08-11 23:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:04:14 --> Email Class Initialized
INFO - 2016-08-11 23:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:04:14 --> Pagination Class Initialized
INFO - 2016-08-11 23:04:14 --> Model Class Initialized
INFO - 2016-08-11 23:04:14 --> Controller Class Initialized
INFO - 2016-08-11 23:04:14 --> Model Class Initialized
INFO - 2016-08-11 23:04:14 --> Helper loaded: text_helper
INFO - 2016-08-11 23:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:04:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:04:15 --> Final output sent to browser
DEBUG - 2016-08-11 23:04:15 --> Total execution time: 0.7075
INFO - 2016-08-11 23:04:55 --> Config Class Initialized
INFO - 2016-08-11 23:04:55 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:55 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:55 --> Utf8 Class Initialized
INFO - 2016-08-11 23:04:56 --> URI Class Initialized
INFO - 2016-08-11 23:04:56 --> Router Class Initialized
INFO - 2016-08-11 23:04:56 --> Output Class Initialized
INFO - 2016-08-11 23:04:56 --> Security Class Initialized
DEBUG - 2016-08-11 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:04:56 --> Input Class Initialized
INFO - 2016-08-11 23:04:56 --> Language Class Initialized
INFO - 2016-08-11 23:04:56 --> Loader Class Initialized
INFO - 2016-08-11 23:04:56 --> Helper loaded: url_helper
INFO - 2016-08-11 23:04:56 --> Helper loaded: date_helper
INFO - 2016-08-11 23:04:56 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:04:56 --> Database Driver Class Initialized
INFO - 2016-08-11 23:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:04:56 --> Email Class Initialized
INFO - 2016-08-11 23:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:04:56 --> Pagination Class Initialized
INFO - 2016-08-11 23:04:56 --> Model Class Initialized
INFO - 2016-08-11 23:04:56 --> Controller Class Initialized
INFO - 2016-08-11 23:04:56 --> Model Class Initialized
INFO - 2016-08-11 23:04:56 --> Helper loaded: text_helper
INFO - 2016-08-11 23:04:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:04:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:04:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:04:56 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:04:56 --> Final output sent to browser
DEBUG - 2016-08-11 23:04:56 --> Total execution time: 0.7398
INFO - 2016-08-11 23:04:59 --> Config Class Initialized
INFO - 2016-08-11 23:04:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:04:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:04:59 --> Utf8 Class Initialized
INFO - 2016-08-11 23:05:00 --> URI Class Initialized
INFO - 2016-08-11 23:05:00 --> Router Class Initialized
INFO - 2016-08-11 23:05:00 --> Output Class Initialized
INFO - 2016-08-11 23:05:00 --> Security Class Initialized
DEBUG - 2016-08-11 23:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:05:00 --> Input Class Initialized
INFO - 2016-08-11 23:05:00 --> Language Class Initialized
INFO - 2016-08-11 23:05:00 --> Loader Class Initialized
INFO - 2016-08-11 23:05:00 --> Helper loaded: url_helper
INFO - 2016-08-11 23:05:00 --> Helper loaded: date_helper
INFO - 2016-08-11 23:05:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:05:00 --> Database Driver Class Initialized
INFO - 2016-08-11 23:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:05:00 --> Email Class Initialized
INFO - 2016-08-11 23:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:05:00 --> Pagination Class Initialized
INFO - 2016-08-11 23:05:00 --> Model Class Initialized
INFO - 2016-08-11 23:05:00 --> Controller Class Initialized
INFO - 2016-08-11 23:05:00 --> Model Class Initialized
INFO - 2016-08-11 23:05:00 --> Helper loaded: text_helper
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:05:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:05:00 --> Final output sent to browser
DEBUG - 2016-08-11 23:05:00 --> Total execution time: 0.8565
INFO - 2016-08-11 23:05:24 --> Config Class Initialized
INFO - 2016-08-11 23:05:24 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:05:25 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:05:25 --> Utf8 Class Initialized
INFO - 2016-08-11 23:05:25 --> URI Class Initialized
INFO - 2016-08-11 23:05:25 --> Router Class Initialized
INFO - 2016-08-11 23:05:25 --> Output Class Initialized
INFO - 2016-08-11 23:05:25 --> Security Class Initialized
DEBUG - 2016-08-11 23:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:05:25 --> Input Class Initialized
INFO - 2016-08-11 23:05:25 --> Language Class Initialized
INFO - 2016-08-11 23:05:25 --> Loader Class Initialized
INFO - 2016-08-11 23:05:25 --> Helper loaded: url_helper
INFO - 2016-08-11 23:05:25 --> Helper loaded: date_helper
INFO - 2016-08-11 23:05:25 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:05:25 --> Database Driver Class Initialized
INFO - 2016-08-11 23:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:05:25 --> Email Class Initialized
INFO - 2016-08-11 23:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:05:25 --> Pagination Class Initialized
INFO - 2016-08-11 23:05:25 --> Model Class Initialized
INFO - 2016-08-11 23:05:25 --> Controller Class Initialized
INFO - 2016-08-11 23:05:25 --> Model Class Initialized
INFO - 2016-08-11 23:05:25 --> Helper loaded: text_helper
INFO - 2016-08-11 23:05:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:05:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:05:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:05:25 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:05:25 --> Final output sent to browser
DEBUG - 2016-08-11 23:05:25 --> Total execution time: 0.7125
INFO - 2016-08-11 23:05:33 --> Config Class Initialized
INFO - 2016-08-11 23:05:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:05:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:05:33 --> Utf8 Class Initialized
INFO - 2016-08-11 23:05:33 --> URI Class Initialized
INFO - 2016-08-11 23:05:33 --> Router Class Initialized
INFO - 2016-08-11 23:05:33 --> Output Class Initialized
INFO - 2016-08-11 23:05:33 --> Security Class Initialized
DEBUG - 2016-08-11 23:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:05:33 --> Input Class Initialized
INFO - 2016-08-11 23:05:33 --> Language Class Initialized
INFO - 2016-08-11 23:05:33 --> Loader Class Initialized
INFO - 2016-08-11 23:05:33 --> Helper loaded: url_helper
INFO - 2016-08-11 23:05:33 --> Helper loaded: date_helper
INFO - 2016-08-11 23:05:34 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:05:34 --> Database Driver Class Initialized
INFO - 2016-08-11 23:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:05:34 --> Email Class Initialized
INFO - 2016-08-11 23:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:05:34 --> Pagination Class Initialized
INFO - 2016-08-11 23:05:34 --> Model Class Initialized
INFO - 2016-08-11 23:05:34 --> Controller Class Initialized
INFO - 2016-08-11 23:05:34 --> Model Class Initialized
INFO - 2016-08-11 23:05:34 --> Helper loaded: text_helper
INFO - 2016-08-11 23:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:05:34 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:05:34 --> Final output sent to browser
DEBUG - 2016-08-11 23:05:34 --> Total execution time: 0.7096
INFO - 2016-08-11 23:09:31 --> Config Class Initialized
INFO - 2016-08-11 23:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:09:31 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:09:31 --> Utf8 Class Initialized
INFO - 2016-08-11 23:09:31 --> URI Class Initialized
INFO - 2016-08-11 23:09:31 --> Router Class Initialized
INFO - 2016-08-11 23:09:31 --> Output Class Initialized
INFO - 2016-08-11 23:09:31 --> Security Class Initialized
DEBUG - 2016-08-11 23:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:09:31 --> Input Class Initialized
INFO - 2016-08-11 23:09:31 --> Language Class Initialized
INFO - 2016-08-11 23:09:31 --> Loader Class Initialized
INFO - 2016-08-11 23:09:31 --> Helper loaded: url_helper
INFO - 2016-08-11 23:09:31 --> Helper loaded: date_helper
INFO - 2016-08-11 23:09:31 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:09:31 --> Database Driver Class Initialized
INFO - 2016-08-11 23:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:09:31 --> Email Class Initialized
INFO - 2016-08-11 23:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:09:31 --> Pagination Class Initialized
INFO - 2016-08-11 23:09:31 --> Model Class Initialized
INFO - 2016-08-11 23:09:31 --> Controller Class Initialized
INFO - 2016-08-11 23:09:31 --> Model Class Initialized
INFO - 2016-08-11 23:09:31 --> Helper loaded: text_helper
INFO - 2016-08-11 23:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:09:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:09:31 --> Final output sent to browser
DEBUG - 2016-08-11 23:09:31 --> Total execution time: 0.7163
INFO - 2016-08-11 23:09:32 --> Config Class Initialized
INFO - 2016-08-11 23:09:32 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:09:32 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:09:32 --> Utf8 Class Initialized
INFO - 2016-08-11 23:09:32 --> URI Class Initialized
INFO - 2016-08-11 23:09:32 --> Router Class Initialized
INFO - 2016-08-11 23:09:32 --> Output Class Initialized
INFO - 2016-08-11 23:09:32 --> Security Class Initialized
DEBUG - 2016-08-11 23:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:09:32 --> Input Class Initialized
INFO - 2016-08-11 23:09:32 --> Language Class Initialized
ERROR - 2016-08-11 23:09:32 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:12:39 --> Config Class Initialized
INFO - 2016-08-11 23:12:39 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:12:39 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:12:39 --> Utf8 Class Initialized
INFO - 2016-08-11 23:12:39 --> URI Class Initialized
INFO - 2016-08-11 23:12:39 --> Router Class Initialized
INFO - 2016-08-11 23:12:39 --> Output Class Initialized
INFO - 2016-08-11 23:12:39 --> Security Class Initialized
DEBUG - 2016-08-11 23:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:12:39 --> Input Class Initialized
INFO - 2016-08-11 23:12:39 --> Language Class Initialized
INFO - 2016-08-11 23:12:39 --> Loader Class Initialized
INFO - 2016-08-11 23:12:39 --> Helper loaded: url_helper
INFO - 2016-08-11 23:12:39 --> Helper loaded: date_helper
INFO - 2016-08-11 23:12:39 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:12:39 --> Database Driver Class Initialized
INFO - 2016-08-11 23:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:12:39 --> Email Class Initialized
INFO - 2016-08-11 23:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:12:40 --> Pagination Class Initialized
INFO - 2016-08-11 23:12:40 --> Model Class Initialized
INFO - 2016-08-11 23:12:40 --> Controller Class Initialized
INFO - 2016-08-11 23:12:40 --> Model Class Initialized
INFO - 2016-08-11 23:12:40 --> Helper loaded: text_helper
INFO - 2016-08-11 23:12:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:12:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:12:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:12:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:12:40 --> Final output sent to browser
DEBUG - 2016-08-11 23:12:40 --> Total execution time: 0.7200
INFO - 2016-08-11 23:12:40 --> Config Class Initialized
INFO - 2016-08-11 23:12:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:12:40 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:12:40 --> Utf8 Class Initialized
INFO - 2016-08-11 23:12:40 --> URI Class Initialized
INFO - 2016-08-11 23:12:40 --> Router Class Initialized
INFO - 2016-08-11 23:12:40 --> Output Class Initialized
INFO - 2016-08-11 23:12:40 --> Security Class Initialized
DEBUG - 2016-08-11 23:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:12:40 --> Input Class Initialized
INFO - 2016-08-11 23:12:41 --> Language Class Initialized
ERROR - 2016-08-11 23:12:41 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:13:09 --> Config Class Initialized
INFO - 2016-08-11 23:13:09 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:13:09 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:13:09 --> Utf8 Class Initialized
INFO - 2016-08-11 23:13:09 --> URI Class Initialized
INFO - 2016-08-11 23:13:09 --> Router Class Initialized
INFO - 2016-08-11 23:13:09 --> Output Class Initialized
INFO - 2016-08-11 23:13:09 --> Security Class Initialized
DEBUG - 2016-08-11 23:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:13:09 --> Input Class Initialized
INFO - 2016-08-11 23:13:09 --> Language Class Initialized
INFO - 2016-08-11 23:13:09 --> Loader Class Initialized
INFO - 2016-08-11 23:13:09 --> Helper loaded: url_helper
INFO - 2016-08-11 23:13:09 --> Helper loaded: date_helper
INFO - 2016-08-11 23:13:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:13:09 --> Database Driver Class Initialized
INFO - 2016-08-11 23:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:13:09 --> Email Class Initialized
INFO - 2016-08-11 23:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:13:09 --> Pagination Class Initialized
INFO - 2016-08-11 23:13:09 --> Model Class Initialized
INFO - 2016-08-11 23:13:09 --> Controller Class Initialized
INFO - 2016-08-11 23:13:09 --> Model Class Initialized
INFO - 2016-08-11 23:13:09 --> Helper loaded: text_helper
INFO - 2016-08-11 23:13:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:13:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:13:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:13:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:13:09 --> Final output sent to browser
DEBUG - 2016-08-11 23:13:09 --> Total execution time: 0.7660
INFO - 2016-08-11 23:13:10 --> Config Class Initialized
INFO - 2016-08-11 23:13:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:13:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:13:10 --> Utf8 Class Initialized
INFO - 2016-08-11 23:13:10 --> URI Class Initialized
INFO - 2016-08-11 23:13:10 --> Router Class Initialized
INFO - 2016-08-11 23:13:10 --> Output Class Initialized
INFO - 2016-08-11 23:13:10 --> Security Class Initialized
DEBUG - 2016-08-11 23:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:13:10 --> Input Class Initialized
INFO - 2016-08-11 23:13:10 --> Language Class Initialized
ERROR - 2016-08-11 23:13:10 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:13:14 --> Config Class Initialized
INFO - 2016-08-11 23:13:14 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:13:14 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:13:14 --> Utf8 Class Initialized
INFO - 2016-08-11 23:13:14 --> URI Class Initialized
INFO - 2016-08-11 23:13:14 --> Router Class Initialized
INFO - 2016-08-11 23:13:14 --> Output Class Initialized
INFO - 2016-08-11 23:13:14 --> Security Class Initialized
DEBUG - 2016-08-11 23:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:13:14 --> Input Class Initialized
INFO - 2016-08-11 23:13:14 --> Language Class Initialized
ERROR - 2016-08-11 23:13:14 --> 404 Page Not Found: News/2
INFO - 2016-08-11 23:14:15 --> Config Class Initialized
INFO - 2016-08-11 23:14:15 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:15 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:15 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:15 --> URI Class Initialized
INFO - 2016-08-11 23:14:15 --> Router Class Initialized
INFO - 2016-08-11 23:14:15 --> Output Class Initialized
INFO - 2016-08-11 23:14:15 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:15 --> Input Class Initialized
INFO - 2016-08-11 23:14:15 --> Language Class Initialized
INFO - 2016-08-11 23:14:15 --> Loader Class Initialized
INFO - 2016-08-11 23:14:15 --> Helper loaded: url_helper
INFO - 2016-08-11 23:14:15 --> Helper loaded: date_helper
INFO - 2016-08-11 23:14:15 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:14:15 --> Database Driver Class Initialized
INFO - 2016-08-11 23:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:14:15 --> Email Class Initialized
INFO - 2016-08-11 23:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:14:15 --> Pagination Class Initialized
INFO - 2016-08-11 23:14:15 --> Model Class Initialized
INFO - 2016-08-11 23:14:15 --> Controller Class Initialized
INFO - 2016-08-11 23:14:15 --> Model Class Initialized
INFO - 2016-08-11 23:14:15 --> Helper loaded: text_helper
INFO - 2016-08-11 23:14:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:14:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:14:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:14:15 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:14:15 --> Final output sent to browser
DEBUG - 2016-08-11 23:14:15 --> Total execution time: 0.7281
INFO - 2016-08-11 23:14:16 --> Config Class Initialized
INFO - 2016-08-11 23:14:16 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:16 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:16 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:16 --> URI Class Initialized
INFO - 2016-08-11 23:14:16 --> Router Class Initialized
INFO - 2016-08-11 23:14:16 --> Output Class Initialized
INFO - 2016-08-11 23:14:16 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:16 --> Input Class Initialized
INFO - 2016-08-11 23:14:16 --> Language Class Initialized
ERROR - 2016-08-11 23:14:16 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:14:20 --> Config Class Initialized
INFO - 2016-08-11 23:14:20 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:20 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:20 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:20 --> URI Class Initialized
INFO - 2016-08-11 23:14:20 --> Router Class Initialized
INFO - 2016-08-11 23:14:20 --> Output Class Initialized
INFO - 2016-08-11 23:14:20 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:20 --> Input Class Initialized
INFO - 2016-08-11 23:14:20 --> Language Class Initialized
INFO - 2016-08-11 23:14:20 --> Loader Class Initialized
INFO - 2016-08-11 23:14:20 --> Helper loaded: url_helper
INFO - 2016-08-11 23:14:20 --> Helper loaded: date_helper
INFO - 2016-08-11 23:14:20 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:14:20 --> Database Driver Class Initialized
INFO - 2016-08-11 23:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:14:20 --> Email Class Initialized
INFO - 2016-08-11 23:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:14:20 --> Pagination Class Initialized
INFO - 2016-08-11 23:14:20 --> Model Class Initialized
INFO - 2016-08-11 23:14:21 --> Controller Class Initialized
INFO - 2016-08-11 23:14:21 --> Model Class Initialized
INFO - 2016-08-11 23:14:21 --> Helper loaded: text_helper
INFO - 2016-08-11 23:14:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:14:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:14:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:14:21 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:14:21 --> Final output sent to browser
DEBUG - 2016-08-11 23:14:21 --> Total execution time: 0.7278
INFO - 2016-08-11 23:14:21 --> Config Class Initialized
INFO - 2016-08-11 23:14:21 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:21 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:21 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:21 --> URI Class Initialized
INFO - 2016-08-11 23:14:21 --> Router Class Initialized
INFO - 2016-08-11 23:14:21 --> Output Class Initialized
INFO - 2016-08-11 23:14:21 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:21 --> Input Class Initialized
INFO - 2016-08-11 23:14:21 --> Language Class Initialized
ERROR - 2016-08-11 23:14:21 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:14:32 --> Config Class Initialized
INFO - 2016-08-11 23:14:32 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:32 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:32 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:32 --> URI Class Initialized
INFO - 2016-08-11 23:14:32 --> Router Class Initialized
INFO - 2016-08-11 23:14:32 --> Output Class Initialized
INFO - 2016-08-11 23:14:32 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:32 --> Input Class Initialized
INFO - 2016-08-11 23:14:32 --> Language Class Initialized
INFO - 2016-08-11 23:14:32 --> Loader Class Initialized
INFO - 2016-08-11 23:14:32 --> Helper loaded: url_helper
INFO - 2016-08-11 23:14:32 --> Helper loaded: date_helper
INFO - 2016-08-11 23:14:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:14:32 --> Database Driver Class Initialized
INFO - 2016-08-11 23:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:14:32 --> Email Class Initialized
INFO - 2016-08-11 23:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:14:32 --> Pagination Class Initialized
INFO - 2016-08-11 23:14:32 --> Model Class Initialized
INFO - 2016-08-11 23:14:32 --> Controller Class Initialized
INFO - 2016-08-11 23:14:32 --> Model Class Initialized
INFO - 2016-08-11 23:14:32 --> Helper loaded: text_helper
INFO - 2016-08-11 23:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:14:32 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:14:32 --> Final output sent to browser
DEBUG - 2016-08-11 23:14:32 --> Total execution time: 0.7158
INFO - 2016-08-11 23:14:33 --> Config Class Initialized
INFO - 2016-08-11 23:14:33 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:14:33 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:14:33 --> Utf8 Class Initialized
INFO - 2016-08-11 23:14:33 --> URI Class Initialized
INFO - 2016-08-11 23:14:33 --> Router Class Initialized
INFO - 2016-08-11 23:14:33 --> Output Class Initialized
INFO - 2016-08-11 23:14:33 --> Security Class Initialized
DEBUG - 2016-08-11 23:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:14:33 --> Input Class Initialized
INFO - 2016-08-11 23:14:33 --> Language Class Initialized
ERROR - 2016-08-11 23:14:33 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:15:08 --> Config Class Initialized
INFO - 2016-08-11 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:15:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:15:08 --> Config Class Initialized
INFO - 2016-08-11 23:15:08 --> Hooks Class Initialized
INFO - 2016-08-11 23:15:08 --> Utf8 Class Initialized
INFO - 2016-08-11 23:15:08 --> URI Class Initialized
DEBUG - 2016-08-11 23:15:08 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:15:08 --> Utf8 Class Initialized
INFO - 2016-08-11 23:15:08 --> Router Class Initialized
INFO - 2016-08-11 23:15:08 --> URI Class Initialized
INFO - 2016-08-11 23:15:08 --> Output Class Initialized
INFO - 2016-08-11 23:15:08 --> Security Class Initialized
INFO - 2016-08-11 23:15:08 --> Router Class Initialized
DEBUG - 2016-08-11 23:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:15:08 --> Output Class Initialized
INFO - 2016-08-11 23:15:08 --> Input Class Initialized
INFO - 2016-08-11 23:15:08 --> Security Class Initialized
INFO - 2016-08-11 23:15:09 --> Language Class Initialized
DEBUG - 2016-08-11 23:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:15:09 --> Input Class Initialized
INFO - 2016-08-11 23:15:09 --> Loader Class Initialized
INFO - 2016-08-11 23:15:09 --> Language Class Initialized
INFO - 2016-08-11 23:15:09 --> Helper loaded: url_helper
INFO - 2016-08-11 23:15:09 --> Helper loaded: date_helper
INFO - 2016-08-11 23:15:09 --> Loader Class Initialized
INFO - 2016-08-11 23:15:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:15:09 --> Helper loaded: url_helper
INFO - 2016-08-11 23:15:09 --> Helper loaded: date_helper
INFO - 2016-08-11 23:15:09 --> Database Driver Class Initialized
INFO - 2016-08-11 23:15:09 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:15:09 --> Email Class Initialized
INFO - 2016-08-11 23:15:09 --> Database Driver Class Initialized
INFO - 2016-08-11 23:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:15:09 --> Pagination Class Initialized
INFO - 2016-08-11 23:15:09 --> Model Class Initialized
INFO - 2016-08-11 23:15:09 --> Controller Class Initialized
INFO - 2016-08-11 23:15:09 --> Model Class Initialized
INFO - 2016-08-11 23:15:09 --> Helper loaded: text_helper
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:15:09 --> Final output sent to browser
DEBUG - 2016-08-11 23:15:09 --> Total execution time: 0.7393
INFO - 2016-08-11 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:15:09 --> Email Class Initialized
INFO - 2016-08-11 23:15:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:15:09 --> Pagination Class Initialized
INFO - 2016-08-11 23:15:09 --> Model Class Initialized
INFO - 2016-08-11 23:15:09 --> Controller Class Initialized
INFO - 2016-08-11 23:15:09 --> Model Class Initialized
INFO - 2016-08-11 23:15:09 --> Helper loaded: text_helper
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:15:09 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:15:09 --> Final output sent to browser
DEBUG - 2016-08-11 23:15:09 --> Total execution time: 1.0682
INFO - 2016-08-11 23:15:10 --> Config Class Initialized
INFO - 2016-08-11 23:15:10 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:15:10 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:15:10 --> Utf8 Class Initialized
INFO - 2016-08-11 23:15:10 --> URI Class Initialized
INFO - 2016-08-11 23:15:10 --> Router Class Initialized
INFO - 2016-08-11 23:15:10 --> Output Class Initialized
INFO - 2016-08-11 23:15:10 --> Security Class Initialized
DEBUG - 2016-08-11 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:15:10 --> Input Class Initialized
INFO - 2016-08-11 23:15:10 --> Language Class Initialized
ERROR - 2016-08-11 23:15:10 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:15:58 --> Config Class Initialized
INFO - 2016-08-11 23:15:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:15:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:15:58 --> Utf8 Class Initialized
INFO - 2016-08-11 23:15:58 --> URI Class Initialized
INFO - 2016-08-11 23:15:58 --> Router Class Initialized
INFO - 2016-08-11 23:15:58 --> Output Class Initialized
INFO - 2016-08-11 23:15:58 --> Security Class Initialized
DEBUG - 2016-08-11 23:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:15:58 --> Input Class Initialized
INFO - 2016-08-11 23:15:58 --> Language Class Initialized
INFO - 2016-08-11 23:15:58 --> Loader Class Initialized
INFO - 2016-08-11 23:15:58 --> Helper loaded: url_helper
INFO - 2016-08-11 23:15:58 --> Helper loaded: date_helper
INFO - 2016-08-11 23:15:58 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:15:58 --> Database Driver Class Initialized
INFO - 2016-08-11 23:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:15:58 --> Email Class Initialized
INFO - 2016-08-11 23:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:15:58 --> Pagination Class Initialized
INFO - 2016-08-11 23:15:58 --> Model Class Initialized
INFO - 2016-08-11 23:15:58 --> Controller Class Initialized
INFO - 2016-08-11 23:15:58 --> Model Class Initialized
INFO - 2016-08-11 23:15:58 --> Helper loaded: text_helper
INFO - 2016-08-11 23:15:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:15:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:15:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:15:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:15:58 --> Final output sent to browser
DEBUG - 2016-08-11 23:15:59 --> Total execution time: 0.8278
INFO - 2016-08-11 23:16:05 --> Config Class Initialized
INFO - 2016-08-11 23:16:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:16:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:16:05 --> Utf8 Class Initialized
INFO - 2016-08-11 23:16:05 --> URI Class Initialized
INFO - 2016-08-11 23:16:05 --> Router Class Initialized
INFO - 2016-08-11 23:16:05 --> Output Class Initialized
INFO - 2016-08-11 23:16:05 --> Security Class Initialized
DEBUG - 2016-08-11 23:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:16:06 --> Input Class Initialized
INFO - 2016-08-11 23:16:06 --> Language Class Initialized
INFO - 2016-08-11 23:16:06 --> Loader Class Initialized
INFO - 2016-08-11 23:16:06 --> Helper loaded: url_helper
INFO - 2016-08-11 23:16:06 --> Helper loaded: date_helper
INFO - 2016-08-11 23:16:06 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:16:06 --> Database Driver Class Initialized
INFO - 2016-08-11 23:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:16:06 --> Email Class Initialized
INFO - 2016-08-11 23:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:16:06 --> Pagination Class Initialized
INFO - 2016-08-11 23:16:06 --> Model Class Initialized
INFO - 2016-08-11 23:16:06 --> Controller Class Initialized
INFO - 2016-08-11 23:16:06 --> Model Class Initialized
INFO - 2016-08-11 23:16:06 --> Helper loaded: text_helper
INFO - 2016-08-11 23:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:16:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:16:06 --> Final output sent to browser
DEBUG - 2016-08-11 23:16:06 --> Total execution time: 0.7821
INFO - 2016-08-11 23:17:54 --> Config Class Initialized
INFO - 2016-08-11 23:17:54 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:17:54 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:17:54 --> Utf8 Class Initialized
INFO - 2016-08-11 23:17:54 --> URI Class Initialized
INFO - 2016-08-11 23:17:54 --> Router Class Initialized
INFO - 2016-08-11 23:17:54 --> Output Class Initialized
INFO - 2016-08-11 23:17:54 --> Security Class Initialized
DEBUG - 2016-08-11 23:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:17:54 --> Input Class Initialized
INFO - 2016-08-11 23:17:54 --> Language Class Initialized
INFO - 2016-08-11 23:17:54 --> Loader Class Initialized
INFO - 2016-08-11 23:17:54 --> Helper loaded: url_helper
INFO - 2016-08-11 23:17:54 --> Helper loaded: date_helper
INFO - 2016-08-11 23:17:54 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:17:54 --> Database Driver Class Initialized
INFO - 2016-08-11 23:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:17:54 --> Email Class Initialized
INFO - 2016-08-11 23:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:17:55 --> Pagination Class Initialized
INFO - 2016-08-11 23:17:55 --> Model Class Initialized
INFO - 2016-08-11 23:17:55 --> Controller Class Initialized
INFO - 2016-08-11 23:17:55 --> Model Class Initialized
INFO - 2016-08-11 23:17:55 --> Helper loaded: text_helper
INFO - 2016-08-11 23:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:17:55 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:17:55 --> Final output sent to browser
DEBUG - 2016-08-11 23:17:55 --> Total execution time: 0.7622
INFO - 2016-08-11 23:17:59 --> Config Class Initialized
INFO - 2016-08-11 23:17:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:17:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:17:59 --> Utf8 Class Initialized
INFO - 2016-08-11 23:17:59 --> URI Class Initialized
INFO - 2016-08-11 23:18:00 --> Router Class Initialized
INFO - 2016-08-11 23:18:00 --> Output Class Initialized
INFO - 2016-08-11 23:18:00 --> Security Class Initialized
DEBUG - 2016-08-11 23:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:18:00 --> Input Class Initialized
INFO - 2016-08-11 23:18:00 --> Language Class Initialized
INFO - 2016-08-11 23:18:00 --> Loader Class Initialized
INFO - 2016-08-11 23:18:00 --> Helper loaded: url_helper
INFO - 2016-08-11 23:18:00 --> Helper loaded: date_helper
INFO - 2016-08-11 23:18:00 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:18:00 --> Database Driver Class Initialized
INFO - 2016-08-11 23:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:18:00 --> Email Class Initialized
INFO - 2016-08-11 23:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:18:00 --> Pagination Class Initialized
INFO - 2016-08-11 23:18:00 --> Model Class Initialized
INFO - 2016-08-11 23:18:00 --> Controller Class Initialized
INFO - 2016-08-11 23:18:00 --> Model Class Initialized
INFO - 2016-08-11 23:18:00 --> Helper loaded: text_helper
INFO - 2016-08-11 23:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:18:00 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:18:00 --> Final output sent to browser
DEBUG - 2016-08-11 23:18:00 --> Total execution time: 0.8256
INFO - 2016-08-11 23:18:30 --> Config Class Initialized
INFO - 2016-08-11 23:18:30 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:18:30 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:18:30 --> Utf8 Class Initialized
INFO - 2016-08-11 23:18:30 --> URI Class Initialized
INFO - 2016-08-11 23:18:30 --> Router Class Initialized
INFO - 2016-08-11 23:18:30 --> Output Class Initialized
INFO - 2016-08-11 23:18:30 --> Security Class Initialized
DEBUG - 2016-08-11 23:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:18:30 --> Input Class Initialized
INFO - 2016-08-11 23:18:30 --> Language Class Initialized
INFO - 2016-08-11 23:18:30 --> Loader Class Initialized
INFO - 2016-08-11 23:18:30 --> Helper loaded: url_helper
INFO - 2016-08-11 23:18:30 --> Helper loaded: date_helper
INFO - 2016-08-11 23:18:30 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:18:30 --> Database Driver Class Initialized
INFO - 2016-08-11 23:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:18:30 --> Email Class Initialized
INFO - 2016-08-11 23:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:18:30 --> Pagination Class Initialized
INFO - 2016-08-11 23:18:31 --> Model Class Initialized
INFO - 2016-08-11 23:18:31 --> Controller Class Initialized
INFO - 2016-08-11 23:18:31 --> Model Class Initialized
INFO - 2016-08-11 23:18:31 --> Helper loaded: text_helper
INFO - 2016-08-11 23:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:18:31 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:18:31 --> Final output sent to browser
DEBUG - 2016-08-11 23:18:31 --> Total execution time: 0.8094
INFO - 2016-08-11 23:24:01 --> Config Class Initialized
INFO - 2016-08-11 23:24:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:24:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:24:01 --> Utf8 Class Initialized
INFO - 2016-08-11 23:24:01 --> URI Class Initialized
INFO - 2016-08-11 23:24:01 --> Router Class Initialized
INFO - 2016-08-11 23:24:01 --> Output Class Initialized
INFO - 2016-08-11 23:24:01 --> Security Class Initialized
DEBUG - 2016-08-11 23:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:24:01 --> Input Class Initialized
INFO - 2016-08-11 23:24:01 --> Language Class Initialized
INFO - 2016-08-11 23:24:01 --> Loader Class Initialized
INFO - 2016-08-11 23:24:01 --> Helper loaded: url_helper
INFO - 2016-08-11 23:24:01 --> Helper loaded: date_helper
INFO - 2016-08-11 23:24:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:24:01 --> Database Driver Class Initialized
INFO - 2016-08-11 23:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:24:01 --> Email Class Initialized
INFO - 2016-08-11 23:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:24:01 --> Pagination Class Initialized
INFO - 2016-08-11 23:24:01 --> Model Class Initialized
INFO - 2016-08-11 23:24:01 --> Controller Class Initialized
INFO - 2016-08-11 23:24:01 --> Model Class Initialized
INFO - 2016-08-11 23:24:01 --> Helper loaded: text_helper
INFO - 2016-08-11 23:24:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:24:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:24:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:24:01 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:24:01 --> Final output sent to browser
DEBUG - 2016-08-11 23:24:01 --> Total execution time: 0.8006
INFO - 2016-08-11 23:33:05 --> Config Class Initialized
INFO - 2016-08-11 23:33:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:33:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:33:05 --> Utf8 Class Initialized
INFO - 2016-08-11 23:33:05 --> URI Class Initialized
INFO - 2016-08-11 23:33:05 --> Router Class Initialized
INFO - 2016-08-11 23:33:05 --> Output Class Initialized
INFO - 2016-08-11 23:33:05 --> Security Class Initialized
DEBUG - 2016-08-11 23:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:33:05 --> Input Class Initialized
INFO - 2016-08-11 23:33:05 --> Language Class Initialized
INFO - 2016-08-11 23:33:05 --> Loader Class Initialized
INFO - 2016-08-11 23:33:05 --> Helper loaded: url_helper
INFO - 2016-08-11 23:33:05 --> Helper loaded: date_helper
INFO - 2016-08-11 23:33:05 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:33:05 --> Database Driver Class Initialized
INFO - 2016-08-11 23:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:33:05 --> Email Class Initialized
INFO - 2016-08-11 23:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:33:05 --> Pagination Class Initialized
INFO - 2016-08-11 23:33:05 --> Model Class Initialized
INFO - 2016-08-11 23:33:05 --> Controller Class Initialized
INFO - 2016-08-11 23:33:05 --> Model Class Initialized
INFO - 2016-08-11 23:33:05 --> Helper loaded: text_helper
INFO - 2016-08-11 23:33:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:33:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:33:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:33:06 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:33:06 --> Final output sent to browser
DEBUG - 2016-08-11 23:33:06 --> Total execution time: 0.8179
INFO - 2016-08-11 23:33:06 --> Config Class Initialized
INFO - 2016-08-11 23:33:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:33:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:33:06 --> Utf8 Class Initialized
INFO - 2016-08-11 23:33:06 --> URI Class Initialized
INFO - 2016-08-11 23:33:06 --> Router Class Initialized
INFO - 2016-08-11 23:33:06 --> Output Class Initialized
INFO - 2016-08-11 23:33:06 --> Security Class Initialized
DEBUG - 2016-08-11 23:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:33:07 --> Input Class Initialized
INFO - 2016-08-11 23:33:07 --> Language Class Initialized
ERROR - 2016-08-11 23:33:07 --> 404 Page Not Found: Assets/css
INFO - 2016-08-11 23:33:58 --> Config Class Initialized
INFO - 2016-08-11 23:33:58 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:33:58 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:33:58 --> Utf8 Class Initialized
INFO - 2016-08-11 23:33:58 --> URI Class Initialized
INFO - 2016-08-11 23:33:58 --> Router Class Initialized
INFO - 2016-08-11 23:33:59 --> Output Class Initialized
INFO - 2016-08-11 23:33:59 --> Security Class Initialized
DEBUG - 2016-08-11 23:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:33:59 --> Input Class Initialized
INFO - 2016-08-11 23:33:59 --> Language Class Initialized
INFO - 2016-08-11 23:33:59 --> Loader Class Initialized
INFO - 2016-08-11 23:33:59 --> Helper loaded: url_helper
INFO - 2016-08-11 23:33:59 --> Helper loaded: date_helper
INFO - 2016-08-11 23:33:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:33:59 --> Database Driver Class Initialized
INFO - 2016-08-11 23:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:33:59 --> Email Class Initialized
INFO - 2016-08-11 23:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:33:59 --> Pagination Class Initialized
INFO - 2016-08-11 23:33:59 --> Model Class Initialized
INFO - 2016-08-11 23:33:59 --> Controller Class Initialized
INFO - 2016-08-11 23:33:59 --> Model Class Initialized
INFO - 2016-08-11 23:33:59 --> Helper loaded: text_helper
INFO - 2016-08-11 23:33:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:33:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:33:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:33:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:33:59 --> Final output sent to browser
DEBUG - 2016-08-11 23:33:59 --> Total execution time: 0.8778
INFO - 2016-08-11 23:34:17 --> Config Class Initialized
INFO - 2016-08-11 23:34:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:34:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:34:17 --> Utf8 Class Initialized
INFO - 2016-08-11 23:34:17 --> URI Class Initialized
INFO - 2016-08-11 23:34:17 --> Router Class Initialized
INFO - 2016-08-11 23:34:17 --> Output Class Initialized
INFO - 2016-08-11 23:34:17 --> Security Class Initialized
DEBUG - 2016-08-11 23:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:34:17 --> Input Class Initialized
INFO - 2016-08-11 23:34:17 --> Language Class Initialized
INFO - 2016-08-11 23:34:17 --> Loader Class Initialized
INFO - 2016-08-11 23:34:17 --> Helper loaded: url_helper
INFO - 2016-08-11 23:34:17 --> Helper loaded: date_helper
INFO - 2016-08-11 23:34:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:34:17 --> Database Driver Class Initialized
INFO - 2016-08-11 23:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:34:17 --> Email Class Initialized
INFO - 2016-08-11 23:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:34:17 --> Pagination Class Initialized
INFO - 2016-08-11 23:34:17 --> Model Class Initialized
INFO - 2016-08-11 23:34:17 --> Controller Class Initialized
INFO - 2016-08-11 23:34:17 --> Model Class Initialized
INFO - 2016-08-11 23:34:17 --> Helper loaded: text_helper
INFO - 2016-08-11 23:34:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:34:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:34:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:34:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:34:18 --> Final output sent to browser
DEBUG - 2016-08-11 23:34:18 --> Total execution time: 0.7852
INFO - 2016-08-11 23:35:11 --> Config Class Initialized
INFO - 2016-08-11 23:35:11 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:35:11 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:35:11 --> Utf8 Class Initialized
INFO - 2016-08-11 23:35:11 --> URI Class Initialized
INFO - 2016-08-11 23:35:11 --> Router Class Initialized
INFO - 2016-08-11 23:35:11 --> Output Class Initialized
INFO - 2016-08-11 23:35:11 --> Security Class Initialized
DEBUG - 2016-08-11 23:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:35:11 --> Input Class Initialized
INFO - 2016-08-11 23:35:11 --> Language Class Initialized
INFO - 2016-08-11 23:35:11 --> Loader Class Initialized
INFO - 2016-08-11 23:35:11 --> Helper loaded: url_helper
INFO - 2016-08-11 23:35:11 --> Helper loaded: date_helper
INFO - 2016-08-11 23:35:11 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:35:11 --> Database Driver Class Initialized
INFO - 2016-08-11 23:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:35:11 --> Email Class Initialized
INFO - 2016-08-11 23:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:35:11 --> Pagination Class Initialized
INFO - 2016-08-11 23:35:11 --> Model Class Initialized
INFO - 2016-08-11 23:35:11 --> Controller Class Initialized
INFO - 2016-08-11 23:35:11 --> Model Class Initialized
INFO - 2016-08-11 23:35:11 --> Helper loaded: text_helper
INFO - 2016-08-11 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:35:12 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:35:12 --> Final output sent to browser
DEBUG - 2016-08-11 23:35:12 --> Total execution time: 0.8517
INFO - 2016-08-11 23:35:17 --> Config Class Initialized
INFO - 2016-08-11 23:35:17 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:35:17 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:35:17 --> Utf8 Class Initialized
INFO - 2016-08-11 23:35:17 --> URI Class Initialized
INFO - 2016-08-11 23:35:17 --> Router Class Initialized
INFO - 2016-08-11 23:35:17 --> Output Class Initialized
INFO - 2016-08-11 23:35:17 --> Security Class Initialized
DEBUG - 2016-08-11 23:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:35:17 --> Input Class Initialized
INFO - 2016-08-11 23:35:17 --> Language Class Initialized
INFO - 2016-08-11 23:35:17 --> Loader Class Initialized
INFO - 2016-08-11 23:35:17 --> Helper loaded: url_helper
INFO - 2016-08-11 23:35:17 --> Helper loaded: date_helper
INFO - 2016-08-11 23:35:17 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:35:17 --> Database Driver Class Initialized
INFO - 2016-08-11 23:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:35:17 --> Email Class Initialized
INFO - 2016-08-11 23:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:35:17 --> Pagination Class Initialized
INFO - 2016-08-11 23:35:17 --> Model Class Initialized
INFO - 2016-08-11 23:35:17 --> Controller Class Initialized
INFO - 2016-08-11 23:35:17 --> Model Class Initialized
INFO - 2016-08-11 23:35:17 --> Helper loaded: text_helper
INFO - 2016-08-11 23:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:35:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:35:17 --> Final output sent to browser
DEBUG - 2016-08-11 23:35:17 --> Total execution time: 0.7990
INFO - 2016-08-11 23:35:41 --> Config Class Initialized
INFO - 2016-08-11 23:35:42 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:35:42 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:35:42 --> Utf8 Class Initialized
INFO - 2016-08-11 23:35:42 --> URI Class Initialized
INFO - 2016-08-11 23:35:42 --> Router Class Initialized
INFO - 2016-08-11 23:35:42 --> Output Class Initialized
INFO - 2016-08-11 23:35:42 --> Security Class Initialized
DEBUG - 2016-08-11 23:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:35:42 --> Input Class Initialized
INFO - 2016-08-11 23:35:42 --> Language Class Initialized
INFO - 2016-08-11 23:35:42 --> Loader Class Initialized
INFO - 2016-08-11 23:35:42 --> Helper loaded: url_helper
INFO - 2016-08-11 23:35:42 --> Helper loaded: date_helper
INFO - 2016-08-11 23:35:42 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:35:42 --> Database Driver Class Initialized
INFO - 2016-08-11 23:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:35:42 --> Email Class Initialized
INFO - 2016-08-11 23:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:35:42 --> Pagination Class Initialized
INFO - 2016-08-11 23:35:42 --> Model Class Initialized
INFO - 2016-08-11 23:35:42 --> Controller Class Initialized
INFO - 2016-08-11 23:35:42 --> Model Class Initialized
INFO - 2016-08-11 23:35:42 --> Helper loaded: text_helper
INFO - 2016-08-11 23:35:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:35:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:35:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-11 23:35:42 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:35:42 --> Final output sent to browser
DEBUG - 2016-08-11 23:35:42 --> Total execution time: 0.8735
INFO - 2016-08-11 23:35:46 --> Config Class Initialized
INFO - 2016-08-11 23:35:46 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:35:46 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:35:46 --> Utf8 Class Initialized
INFO - 2016-08-11 23:35:46 --> URI Class Initialized
INFO - 2016-08-11 23:35:46 --> Router Class Initialized
INFO - 2016-08-11 23:35:46 --> Output Class Initialized
INFO - 2016-08-11 23:35:46 --> Security Class Initialized
DEBUG - 2016-08-11 23:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:35:46 --> Input Class Initialized
INFO - 2016-08-11 23:35:46 --> Language Class Initialized
INFO - 2016-08-11 23:35:46 --> Loader Class Initialized
INFO - 2016-08-11 23:35:46 --> Helper loaded: url_helper
INFO - 2016-08-11 23:35:46 --> Helper loaded: date_helper
INFO - 2016-08-11 23:35:46 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:35:46 --> Database Driver Class Initialized
INFO - 2016-08-11 23:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:35:46 --> Email Class Initialized
INFO - 2016-08-11 23:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:35:46 --> Pagination Class Initialized
INFO - 2016-08-11 23:35:46 --> Model Class Initialized
INFO - 2016-08-11 23:35:46 --> Controller Class Initialized
INFO - 2016-08-11 23:35:46 --> Model Class Initialized
INFO - 2016-08-11 23:35:46 --> Helper loaded: text_helper
INFO - 2016-08-11 23:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:35:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:35:47 --> Final output sent to browser
DEBUG - 2016-08-11 23:35:47 --> Total execution time: 0.8771
INFO - 2016-08-11 23:37:22 --> Config Class Initialized
INFO - 2016-08-11 23:37:22 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:37:22 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:37:22 --> Utf8 Class Initialized
INFO - 2016-08-11 23:37:22 --> URI Class Initialized
INFO - 2016-08-11 23:37:22 --> Router Class Initialized
INFO - 2016-08-11 23:37:22 --> Output Class Initialized
INFO - 2016-08-11 23:37:22 --> Security Class Initialized
DEBUG - 2016-08-11 23:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:37:22 --> Input Class Initialized
INFO - 2016-08-11 23:37:22 --> Language Class Initialized
INFO - 2016-08-11 23:37:22 --> Loader Class Initialized
INFO - 2016-08-11 23:37:22 --> Helper loaded: url_helper
INFO - 2016-08-11 23:37:22 --> Helper loaded: date_helper
INFO - 2016-08-11 23:37:22 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:37:22 --> Database Driver Class Initialized
INFO - 2016-08-11 23:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:37:23 --> Email Class Initialized
INFO - 2016-08-11 23:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:37:23 --> Pagination Class Initialized
INFO - 2016-08-11 23:37:23 --> Model Class Initialized
INFO - 2016-08-11 23:37:23 --> Controller Class Initialized
INFO - 2016-08-11 23:37:23 --> Model Class Initialized
INFO - 2016-08-11 23:37:23 --> Helper loaded: text_helper
INFO - 2016-08-11 23:37:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:37:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:37:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:37:23 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:37:23 --> Final output sent to browser
DEBUG - 2016-08-11 23:37:23 --> Total execution time: 0.8639
INFO - 2016-08-11 23:39:59 --> Config Class Initialized
INFO - 2016-08-11 23:39:59 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:39:59 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:39:59 --> Utf8 Class Initialized
INFO - 2016-08-11 23:39:59 --> URI Class Initialized
INFO - 2016-08-11 23:39:59 --> Router Class Initialized
INFO - 2016-08-11 23:39:59 --> Output Class Initialized
INFO - 2016-08-11 23:39:59 --> Security Class Initialized
DEBUG - 2016-08-11 23:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:39:59 --> Input Class Initialized
INFO - 2016-08-11 23:39:59 --> Language Class Initialized
INFO - 2016-08-11 23:39:59 --> Loader Class Initialized
INFO - 2016-08-11 23:39:59 --> Helper loaded: url_helper
INFO - 2016-08-11 23:39:59 --> Helper loaded: date_helper
INFO - 2016-08-11 23:39:59 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:39:59 --> Database Driver Class Initialized
INFO - 2016-08-11 23:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:39:59 --> Email Class Initialized
INFO - 2016-08-11 23:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:39:59 --> Pagination Class Initialized
INFO - 2016-08-11 23:39:59 --> Model Class Initialized
INFO - 2016-08-11 23:39:59 --> Controller Class Initialized
INFO - 2016-08-11 23:39:59 --> Model Class Initialized
INFO - 2016-08-11 23:39:59 --> Helper loaded: text_helper
INFO - 2016-08-11 23:39:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:39:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:39:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:39:59 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:39:59 --> Final output sent to browser
DEBUG - 2016-08-11 23:40:00 --> Total execution time: 0.8156
INFO - 2016-08-11 23:41:27 --> Config Class Initialized
INFO - 2016-08-11 23:41:27 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:41:27 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:41:27 --> Utf8 Class Initialized
INFO - 2016-08-11 23:41:27 --> URI Class Initialized
INFO - 2016-08-11 23:41:27 --> Router Class Initialized
INFO - 2016-08-11 23:41:28 --> Output Class Initialized
INFO - 2016-08-11 23:41:28 --> Security Class Initialized
DEBUG - 2016-08-11 23:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:41:28 --> Input Class Initialized
INFO - 2016-08-11 23:41:28 --> Language Class Initialized
INFO - 2016-08-11 23:41:28 --> Loader Class Initialized
INFO - 2016-08-11 23:41:28 --> Helper loaded: url_helper
INFO - 2016-08-11 23:41:28 --> Helper loaded: date_helper
INFO - 2016-08-11 23:41:28 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:41:28 --> Database Driver Class Initialized
INFO - 2016-08-11 23:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:41:28 --> Email Class Initialized
INFO - 2016-08-11 23:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:41:28 --> Pagination Class Initialized
INFO - 2016-08-11 23:41:28 --> Model Class Initialized
INFO - 2016-08-11 23:41:28 --> Controller Class Initialized
INFO - 2016-08-11 23:41:28 --> Model Class Initialized
INFO - 2016-08-11 23:41:28 --> Helper loaded: text_helper
INFO - 2016-08-11 23:41:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:41:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:41:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:41:28 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:41:28 --> Final output sent to browser
DEBUG - 2016-08-11 23:41:28 --> Total execution time: 0.8744
INFO - 2016-08-11 23:42:32 --> Config Class Initialized
INFO - 2016-08-11 23:42:32 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:42:32 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:42:32 --> Utf8 Class Initialized
INFO - 2016-08-11 23:42:32 --> URI Class Initialized
INFO - 2016-08-11 23:42:32 --> Router Class Initialized
INFO - 2016-08-11 23:42:32 --> Output Class Initialized
INFO - 2016-08-11 23:42:32 --> Security Class Initialized
DEBUG - 2016-08-11 23:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:42:32 --> Input Class Initialized
INFO - 2016-08-11 23:42:32 --> Language Class Initialized
INFO - 2016-08-11 23:42:32 --> Loader Class Initialized
INFO - 2016-08-11 23:42:32 --> Helper loaded: url_helper
INFO - 2016-08-11 23:42:32 --> Helper loaded: date_helper
INFO - 2016-08-11 23:42:32 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:42:32 --> Database Driver Class Initialized
INFO - 2016-08-11 23:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:42:32 --> Email Class Initialized
INFO - 2016-08-11 23:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:42:32 --> Pagination Class Initialized
INFO - 2016-08-11 23:42:33 --> Model Class Initialized
INFO - 2016-08-11 23:42:33 --> Controller Class Initialized
INFO - 2016-08-11 23:42:33 --> Model Class Initialized
INFO - 2016-08-11 23:42:33 --> Helper loaded: text_helper
INFO - 2016-08-11 23:42:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:42:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:42:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:42:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:42:33 --> Final output sent to browser
DEBUG - 2016-08-11 23:42:33 --> Total execution time: 0.8031
INFO - 2016-08-11 23:43:35 --> Config Class Initialized
INFO - 2016-08-11 23:43:35 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:43:35 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:43:35 --> Utf8 Class Initialized
INFO - 2016-08-11 23:43:36 --> URI Class Initialized
INFO - 2016-08-11 23:43:36 --> Router Class Initialized
INFO - 2016-08-11 23:43:36 --> Output Class Initialized
INFO - 2016-08-11 23:43:36 --> Security Class Initialized
DEBUG - 2016-08-11 23:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:43:36 --> Input Class Initialized
INFO - 2016-08-11 23:43:36 --> Language Class Initialized
INFO - 2016-08-11 23:43:36 --> Loader Class Initialized
INFO - 2016-08-11 23:43:36 --> Helper loaded: url_helper
INFO - 2016-08-11 23:43:36 --> Helper loaded: date_helper
INFO - 2016-08-11 23:43:36 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:43:36 --> Database Driver Class Initialized
INFO - 2016-08-11 23:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:43:36 --> Email Class Initialized
INFO - 2016-08-11 23:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:43:36 --> Pagination Class Initialized
INFO - 2016-08-11 23:43:36 --> Model Class Initialized
INFO - 2016-08-11 23:43:36 --> Controller Class Initialized
INFO - 2016-08-11 23:43:36 --> Model Class Initialized
INFO - 2016-08-11 23:43:36 --> Helper loaded: text_helper
INFO - 2016-08-11 23:43:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:43:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\aqiqahsehati\application\views\post.php 176
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\post.php 176
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\aqiqahsehati\application\views\post.php 176
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\post.php 176
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\aqiqahsehati\application\views\post.php 177
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\post.php 177
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\aqiqahsehati\application\views\post.php 178
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\aqiqahsehati\application\views\post.php 178
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\aqiqahsehati\application\helpers\Tanggal_indonesia_helper.php 9
ERROR - 2016-08-11 23:43:36 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\aqiqahsehati\application\helpers\Tanggal_indonesia_helper.php 10
INFO - 2016-08-11 23:43:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:43:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:43:36 --> Final output sent to browser
DEBUG - 2016-08-11 23:43:36 --> Total execution time: 1.0505
INFO - 2016-08-11 23:44:01 --> Config Class Initialized
INFO - 2016-08-11 23:44:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:44:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:44:01 --> Utf8 Class Initialized
INFO - 2016-08-11 23:44:01 --> URI Class Initialized
INFO - 2016-08-11 23:44:01 --> Router Class Initialized
INFO - 2016-08-11 23:44:01 --> Output Class Initialized
INFO - 2016-08-11 23:44:01 --> Security Class Initialized
DEBUG - 2016-08-11 23:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:44:02 --> Input Class Initialized
INFO - 2016-08-11 23:44:02 --> Language Class Initialized
INFO - 2016-08-11 23:44:02 --> Loader Class Initialized
INFO - 2016-08-11 23:44:02 --> Helper loaded: url_helper
INFO - 2016-08-11 23:44:02 --> Helper loaded: date_helper
INFO - 2016-08-11 23:44:02 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:44:02 --> Database Driver Class Initialized
INFO - 2016-08-11 23:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:44:02 --> Email Class Initialized
INFO - 2016-08-11 23:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:44:02 --> Pagination Class Initialized
INFO - 2016-08-11 23:44:02 --> Model Class Initialized
INFO - 2016-08-11 23:44:02 --> Controller Class Initialized
INFO - 2016-08-11 23:44:02 --> Model Class Initialized
INFO - 2016-08-11 23:44:02 --> Helper loaded: text_helper
INFO - 2016-08-11 23:44:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:44:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:44:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:44:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:44:02 --> Final output sent to browser
DEBUG - 2016-08-11 23:44:02 --> Total execution time: 0.7702
INFO - 2016-08-11 23:45:01 --> Config Class Initialized
INFO - 2016-08-11 23:45:01 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:45:01 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:45:01 --> Utf8 Class Initialized
INFO - 2016-08-11 23:45:01 --> URI Class Initialized
INFO - 2016-08-11 23:45:01 --> Router Class Initialized
INFO - 2016-08-11 23:45:01 --> Output Class Initialized
INFO - 2016-08-11 23:45:01 --> Security Class Initialized
DEBUG - 2016-08-11 23:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:45:01 --> Input Class Initialized
INFO - 2016-08-11 23:45:01 --> Language Class Initialized
INFO - 2016-08-11 23:45:01 --> Loader Class Initialized
INFO - 2016-08-11 23:45:01 --> Helper loaded: url_helper
INFO - 2016-08-11 23:45:01 --> Helper loaded: date_helper
INFO - 2016-08-11 23:45:01 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:45:01 --> Database Driver Class Initialized
INFO - 2016-08-11 23:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:45:01 --> Email Class Initialized
INFO - 2016-08-11 23:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:45:01 --> Pagination Class Initialized
INFO - 2016-08-11 23:45:01 --> Model Class Initialized
INFO - 2016-08-11 23:45:01 --> Controller Class Initialized
INFO - 2016-08-11 23:45:01 --> Model Class Initialized
INFO - 2016-08-11 23:45:01 --> Helper loaded: text_helper
INFO - 2016-08-11 23:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:45:02 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:45:02 --> Final output sent to browser
DEBUG - 2016-08-11 23:45:02 --> Total execution time: 0.8016
INFO - 2016-08-11 23:45:07 --> Config Class Initialized
INFO - 2016-08-11 23:45:07 --> Hooks Class Initialized
DEBUG - 2016-08-11 23:45:07 --> UTF-8 Support Enabled
INFO - 2016-08-11 23:45:07 --> Utf8 Class Initialized
INFO - 2016-08-11 23:45:07 --> URI Class Initialized
INFO - 2016-08-11 23:45:07 --> Router Class Initialized
INFO - 2016-08-11 23:45:07 --> Output Class Initialized
INFO - 2016-08-11 23:45:07 --> Security Class Initialized
DEBUG - 2016-08-11 23:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 23:45:07 --> Input Class Initialized
INFO - 2016-08-11 23:45:07 --> Language Class Initialized
INFO - 2016-08-11 23:45:07 --> Loader Class Initialized
INFO - 2016-08-11 23:45:07 --> Helper loaded: url_helper
INFO - 2016-08-11 23:45:08 --> Helper loaded: date_helper
INFO - 2016-08-11 23:45:08 --> Helper loaded: tanggal_indonesia_helper
INFO - 2016-08-11 23:45:08 --> Database Driver Class Initialized
INFO - 2016-08-11 23:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 23:45:08 --> Email Class Initialized
INFO - 2016-08-11 23:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-08-11 23:45:08 --> Pagination Class Initialized
INFO - 2016-08-11 23:45:08 --> Model Class Initialized
INFO - 2016-08-11 23:45:08 --> Controller Class Initialized
INFO - 2016-08-11 23:45:08 --> Model Class Initialized
INFO - 2016-08-11 23:45:08 --> Helper loaded: text_helper
INFO - 2016-08-11 23:45:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-11 23:45:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-11 23:45:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\post.php
INFO - 2016-08-11 23:45:08 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-11 23:45:08 --> Final output sent to browser
DEBUG - 2016-08-11 23:45:08 --> Total execution time: 0.8461
