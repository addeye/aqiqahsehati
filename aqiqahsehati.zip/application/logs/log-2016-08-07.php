<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-07 19:54:56 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-07 19:54:56 --> Config Class Initialized
INFO - 2016-08-07 19:54:56 --> Hooks Class Initialized
INFO - 2016-08-07 19:54:56 --> Hooks Class Initialized
DEBUG - 2016-08-07 19:54:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-07 19:54:56 --> UTF-8 Support Enabled
INFO - 2016-08-07 19:54:56 --> Utf8 Class Initialized
INFO - 2016-08-07 19:54:56 --> Utf8 Class Initialized
INFO - 2016-08-07 19:54:56 --> URI Class Initialized
INFO - 2016-08-07 19:54:56 --> URI Class Initialized
DEBUG - 2016-08-07 19:54:56 --> No URI present. Default controller set.
DEBUG - 2016-08-07 19:54:56 --> No URI present. Default controller set.
INFO - 2016-08-07 19:54:56 --> Router Class Initialized
INFO - 2016-08-07 19:54:56 --> Router Class Initialized
INFO - 2016-08-07 19:54:56 --> Output Class Initialized
INFO - 2016-08-07 19:54:56 --> Output Class Initialized
INFO - 2016-08-07 19:54:57 --> Security Class Initialized
INFO - 2016-08-07 19:54:57 --> Security Class Initialized
DEBUG - 2016-08-07 19:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-07 19:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 19:54:57 --> Input Class Initialized
INFO - 2016-08-07 19:54:57 --> Input Class Initialized
INFO - 2016-08-07 19:54:57 --> Language Class Initialized
INFO - 2016-08-07 19:54:57 --> Language Class Initialized
INFO - 2016-08-07 19:54:57 --> Loader Class Initialized
INFO - 2016-08-07 19:54:57 --> Loader Class Initialized
INFO - 2016-08-07 19:54:57 --> Helper loaded: url_helper
INFO - 2016-08-07 19:54:57 --> Helper loaded: url_helper
INFO - 2016-08-07 19:54:57 --> Database Driver Class Initialized
INFO - 2016-08-07 19:54:57 --> Database Driver Class Initialized
INFO - 2016-08-07 19:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 19:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 19:54:58 --> Email Class Initialized
INFO - 2016-08-07 19:54:58 --> Email Class Initialized
INFO - 2016-08-07 19:54:58 --> Controller Class Initialized
INFO - 2016-08-07 19:54:58 --> Controller Class Initialized
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 19:54:58 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 19:54:58 --> Final output sent to browser
INFO - 2016-08-07 19:54:58 --> Final output sent to browser
DEBUG - 2016-08-07 19:54:58 --> Total execution time: 3.9577
DEBUG - 2016-08-07 19:54:58 --> Total execution time: 3.9576
INFO - 2016-08-07 19:58:39 --> Config Class Initialized
INFO - 2016-08-07 19:58:39 --> Hooks Class Initialized
DEBUG - 2016-08-07 19:58:39 --> UTF-8 Support Enabled
INFO - 2016-08-07 19:58:40 --> Utf8 Class Initialized
INFO - 2016-08-07 19:58:40 --> URI Class Initialized
INFO - 2016-08-07 19:58:40 --> Router Class Initialized
INFO - 2016-08-07 19:58:40 --> Output Class Initialized
INFO - 2016-08-07 19:58:40 --> Security Class Initialized
DEBUG - 2016-08-07 19:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 19:58:40 --> Input Class Initialized
INFO - 2016-08-07 19:58:40 --> Language Class Initialized
INFO - 2016-08-07 19:58:40 --> Loader Class Initialized
INFO - 2016-08-07 19:58:40 --> Helper loaded: url_helper
INFO - 2016-08-07 19:58:40 --> Database Driver Class Initialized
INFO - 2016-08-07 19:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 19:58:40 --> Email Class Initialized
INFO - 2016-08-07 19:58:40 --> Controller Class Initialized
INFO - 2016-08-07 19:58:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 19:58:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 19:58:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-07 19:58:40 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 19:58:40 --> Final output sent to browser
DEBUG - 2016-08-07 19:58:40 --> Total execution time: 0.3062
INFO - 2016-08-07 19:58:40 --> Config Class Initialized
INFO - 2016-08-07 19:58:40 --> Hooks Class Initialized
DEBUG - 2016-08-07 19:58:40 --> UTF-8 Support Enabled
INFO - 2016-08-07 19:58:40 --> Utf8 Class Initialized
INFO - 2016-08-07 19:58:40 --> URI Class Initialized
INFO - 2016-08-07 19:58:40 --> Router Class Initialized
INFO - 2016-08-07 19:58:40 --> Output Class Initialized
INFO - 2016-08-07 19:58:40 --> Security Class Initialized
DEBUG - 2016-08-07 19:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 19:58:40 --> Input Class Initialized
INFO - 2016-08-07 19:58:40 --> Language Class Initialized
ERROR - 2016-08-07 19:58:41 --> 404 Page Not Found: Assets/css
INFO - 2016-08-07 20:19:14 --> Config Class Initialized
INFO - 2016-08-07 20:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:14 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:14 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:14 --> URI Class Initialized
INFO - 2016-08-07 20:19:14 --> Router Class Initialized
INFO - 2016-08-07 20:19:14 --> Output Class Initialized
INFO - 2016-08-07 20:19:14 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:14 --> Input Class Initialized
INFO - 2016-08-07 20:19:14 --> Language Class Initialized
INFO - 2016-08-07 20:19:14 --> Loader Class Initialized
INFO - 2016-08-07 20:19:14 --> Helper loaded: url_helper
INFO - 2016-08-07 20:19:14 --> Database Driver Class Initialized
INFO - 2016-08-07 20:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:19:14 --> Email Class Initialized
INFO - 2016-08-07 20:19:14 --> Controller Class Initialized
INFO - 2016-08-07 20:19:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:19:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:19:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-07 20:19:14 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:19:14 --> Final output sent to browser
DEBUG - 2016-08-07 20:19:14 --> Total execution time: 0.2370
INFO - 2016-08-07 20:19:15 --> Config Class Initialized
INFO - 2016-08-07 20:19:15 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:15 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:15 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:15 --> URI Class Initialized
INFO - 2016-08-07 20:19:15 --> Router Class Initialized
INFO - 2016-08-07 20:19:15 --> Output Class Initialized
INFO - 2016-08-07 20:19:15 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:15 --> Input Class Initialized
INFO - 2016-08-07 20:19:15 --> Language Class Initialized
ERROR - 2016-08-07 20:19:15 --> 404 Page Not Found: Assets/css
INFO - 2016-08-07 20:19:17 --> Config Class Initialized
INFO - 2016-08-07 20:19:17 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:17 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:17 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:17 --> URI Class Initialized
DEBUG - 2016-08-07 20:19:17 --> No URI present. Default controller set.
INFO - 2016-08-07 20:19:17 --> Router Class Initialized
INFO - 2016-08-07 20:19:17 --> Output Class Initialized
INFO - 2016-08-07 20:19:17 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:17 --> Input Class Initialized
INFO - 2016-08-07 20:19:17 --> Language Class Initialized
INFO - 2016-08-07 20:19:17 --> Loader Class Initialized
INFO - 2016-08-07 20:19:17 --> Helper loaded: url_helper
INFO - 2016-08-07 20:19:17 --> Database Driver Class Initialized
INFO - 2016-08-07 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:19:17 --> Email Class Initialized
INFO - 2016-08-07 20:19:17 --> Controller Class Initialized
INFO - 2016-08-07 20:19:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:19:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:19:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-07 20:19:17 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:19:17 --> Final output sent to browser
DEBUG - 2016-08-07 20:19:17 --> Total execution time: 0.2418
INFO - 2016-08-07 20:19:33 --> Config Class Initialized
INFO - 2016-08-07 20:19:33 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:33 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:33 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:33 --> URI Class Initialized
INFO - 2016-08-07 20:19:33 --> Router Class Initialized
INFO - 2016-08-07 20:19:33 --> Output Class Initialized
INFO - 2016-08-07 20:19:33 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:33 --> Input Class Initialized
INFO - 2016-08-07 20:19:33 --> Language Class Initialized
INFO - 2016-08-07 20:19:33 --> Loader Class Initialized
INFO - 2016-08-07 20:19:33 --> Helper loaded: url_helper
INFO - 2016-08-07 20:19:33 --> Database Driver Class Initialized
INFO - 2016-08-07 20:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:19:33 --> Email Class Initialized
INFO - 2016-08-07 20:19:33 --> Controller Class Initialized
INFO - 2016-08-07 20:19:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:19:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:19:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-07 20:19:33 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:19:33 --> Final output sent to browser
DEBUG - 2016-08-07 20:19:33 --> Total execution time: 0.2405
INFO - 2016-08-07 20:19:35 --> Config Class Initialized
INFO - 2016-08-07 20:19:35 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:35 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:35 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:35 --> URI Class Initialized
INFO - 2016-08-07 20:19:35 --> Router Class Initialized
INFO - 2016-08-07 20:19:35 --> Output Class Initialized
INFO - 2016-08-07 20:19:35 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:35 --> Input Class Initialized
INFO - 2016-08-07 20:19:35 --> Language Class Initialized
INFO - 2016-08-07 20:19:35 --> Loader Class Initialized
INFO - 2016-08-07 20:19:35 --> Helper loaded: url_helper
INFO - 2016-08-07 20:19:35 --> Database Driver Class Initialized
INFO - 2016-08-07 20:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:19:35 --> Email Class Initialized
INFO - 2016-08-07 20:19:35 --> Controller Class Initialized
INFO - 2016-08-07 20:19:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:19:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:19:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-07 20:19:35 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:19:35 --> Final output sent to browser
DEBUG - 2016-08-07 20:19:35 --> Total execution time: 0.2771
INFO - 2016-08-07 20:19:45 --> Config Class Initialized
INFO - 2016-08-07 20:19:46 --> Config Class Initialized
INFO - 2016-08-07 20:19:46 --> Config Class Initialized
INFO - 2016-08-07 20:19:46 --> Config Class Initialized
INFO - 2016-08-07 20:19:46 --> Hooks Class Initialized
INFO - 2016-08-07 20:19:46 --> Hooks Class Initialized
INFO - 2016-08-07 20:19:46 --> Hooks Class Initialized
INFO - 2016-08-07 20:19:46 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-07 20:19:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-07 20:19:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-07 20:19:46 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:46 --> URI Class Initialized
INFO - 2016-08-07 20:19:46 --> URI Class Initialized
INFO - 2016-08-07 20:19:46 --> URI Class Initialized
INFO - 2016-08-07 20:19:46 --> URI Class Initialized
INFO - 2016-08-07 20:19:46 --> Router Class Initialized
INFO - 2016-08-07 20:19:46 --> Router Class Initialized
INFO - 2016-08-07 20:19:46 --> Router Class Initialized
INFO - 2016-08-07 20:19:46 --> Router Class Initialized
INFO - 2016-08-07 20:19:46 --> Output Class Initialized
INFO - 2016-08-07 20:19:46 --> Output Class Initialized
INFO - 2016-08-07 20:19:46 --> Output Class Initialized
INFO - 2016-08-07 20:19:46 --> Output Class Initialized
INFO - 2016-08-07 20:19:46 --> Security Class Initialized
INFO - 2016-08-07 20:19:46 --> Security Class Initialized
INFO - 2016-08-07 20:19:46 --> Security Class Initialized
INFO - 2016-08-07 20:19:46 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-07 20:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-07 20:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-07 20:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:46 --> Input Class Initialized
INFO - 2016-08-07 20:19:46 --> Input Class Initialized
INFO - 2016-08-07 20:19:46 --> Input Class Initialized
INFO - 2016-08-07 20:19:46 --> Language Class Initialized
INFO - 2016-08-07 20:19:46 --> Input Class Initialized
INFO - 2016-08-07 20:19:46 --> Language Class Initialized
INFO - 2016-08-07 20:19:46 --> Language Class Initialized
INFO - 2016-08-07 20:19:46 --> Language Class Initialized
ERROR - 2016-08-07 20:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-07 20:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-07 20:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-07 20:19:46 --> 404 Page Not Found: Assets/css
INFO - 2016-08-07 20:19:46 --> Config Class Initialized
INFO - 2016-08-07 20:19:46 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:19:46 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:19:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:19:46 --> URI Class Initialized
INFO - 2016-08-07 20:19:46 --> Router Class Initialized
INFO - 2016-08-07 20:19:46 --> Output Class Initialized
INFO - 2016-08-07 20:19:46 --> Security Class Initialized
DEBUG - 2016-08-07 20:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:19:46 --> Input Class Initialized
INFO - 2016-08-07 20:19:46 --> Language Class Initialized
INFO - 2016-08-07 20:19:46 --> Loader Class Initialized
INFO - 2016-08-07 20:19:46 --> Helper loaded: url_helper
INFO - 2016-08-07 20:19:46 --> Database Driver Class Initialized
INFO - 2016-08-07 20:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:19:46 --> Email Class Initialized
INFO - 2016-08-07 20:19:46 --> Controller Class Initialized
INFO - 2016-08-07 20:19:46 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-07 20:19:46 --> Final output sent to browser
DEBUG - 2016-08-07 20:19:46 --> Total execution time: 0.3211
INFO - 2016-08-07 20:20:27 --> Config Class Initialized
INFO - 2016-08-07 20:20:27 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:20:27 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:27 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:27 --> URI Class Initialized
INFO - 2016-08-07 20:20:27 --> Router Class Initialized
INFO - 2016-08-07 20:20:27 --> Output Class Initialized
INFO - 2016-08-07 20:20:27 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:27 --> Input Class Initialized
INFO - 2016-08-07 20:20:27 --> Language Class Initialized
INFO - 2016-08-07 20:20:27 --> Loader Class Initialized
INFO - 2016-08-07 20:20:27 --> Helper loaded: url_helper
INFO - 2016-08-07 20:20:27 --> Database Driver Class Initialized
INFO - 2016-08-07 20:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:20:27 --> Email Class Initialized
INFO - 2016-08-07 20:20:27 --> Controller Class Initialized
INFO - 2016-08-07 20:20:27 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-07 20:20:27 --> Final output sent to browser
DEBUG - 2016-08-07 20:20:27 --> Total execution time: 0.2216
INFO - 2016-08-07 20:20:31 --> Config Class Initialized
INFO - 2016-08-07 20:20:31 --> Config Class Initialized
INFO - 2016-08-07 20:20:31 --> Hooks Class Initialized
INFO - 2016-08-07 20:20:31 --> Config Class Initialized
INFO - 2016-08-07 20:20:31 --> Hooks Class Initialized
INFO - 2016-08-07 20:20:31 --> Hooks Class Initialized
INFO - 2016-08-07 20:20:31 --> Config Class Initialized
DEBUG - 2016-08-07 20:20:31 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:31 --> Utf8 Class Initialized
DEBUG - 2016-08-07 20:20:31 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:31 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:31 --> URI Class Initialized
DEBUG - 2016-08-07 20:20:31 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:31 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:31 --> Hooks Class Initialized
INFO - 2016-08-07 20:20:31 --> URI Class Initialized
INFO - 2016-08-07 20:20:31 --> Router Class Initialized
INFO - 2016-08-07 20:20:31 --> URI Class Initialized
INFO - 2016-08-07 20:20:31 --> Router Class Initialized
INFO - 2016-08-07 20:20:31 --> Output Class Initialized
DEBUG - 2016-08-07 20:20:31 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:31 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:31 --> Security Class Initialized
INFO - 2016-08-07 20:20:31 --> Router Class Initialized
INFO - 2016-08-07 20:20:31 --> Output Class Initialized
INFO - 2016-08-07 20:20:31 --> Output Class Initialized
INFO - 2016-08-07 20:20:31 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:31 --> URI Class Initialized
INFO - 2016-08-07 20:20:31 --> Input Class Initialized
INFO - 2016-08-07 20:20:31 --> Security Class Initialized
INFO - 2016-08-07 20:20:31 --> Router Class Initialized
INFO - 2016-08-07 20:20:31 --> Language Class Initialized
DEBUG - 2016-08-07 20:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-07 20:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:31 --> Output Class Initialized
INFO - 2016-08-07 20:20:31 --> Input Class Initialized
INFO - 2016-08-07 20:20:31 --> Input Class Initialized
INFO - 2016-08-07 20:20:31 --> Security Class Initialized
ERROR - 2016-08-07 20:20:31 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:31 --> Language Class Initialized
INFO - 2016-08-07 20:20:31 --> Language Class Initialized
DEBUG - 2016-08-07 20:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:31 --> Input Class Initialized
ERROR - 2016-08-07 20:20:31 --> 404 Page Not Found: Assets/images
ERROR - 2016-08-07 20:20:31 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:31 --> Language Class Initialized
ERROR - 2016-08-07 20:20:31 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:32 --> Config Class Initialized
INFO - 2016-08-07 20:20:32 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:20:32 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:32 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:32 --> URI Class Initialized
INFO - 2016-08-07 20:20:32 --> Router Class Initialized
INFO - 2016-08-07 20:20:32 --> Output Class Initialized
INFO - 2016-08-07 20:20:32 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:32 --> Input Class Initialized
INFO - 2016-08-07 20:20:32 --> Language Class Initialized
ERROR - 2016-08-07 20:20:32 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:32 --> Config Class Initialized
INFO - 2016-08-07 20:20:32 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:20:32 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:32 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:32 --> URI Class Initialized
INFO - 2016-08-07 20:20:32 --> Router Class Initialized
INFO - 2016-08-07 20:20:32 --> Output Class Initialized
INFO - 2016-08-07 20:20:32 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:32 --> Input Class Initialized
INFO - 2016-08-07 20:20:32 --> Language Class Initialized
ERROR - 2016-08-07 20:20:32 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:32 --> Config Class Initialized
INFO - 2016-08-07 20:20:32 --> Hooks Class Initialized
INFO - 2016-08-07 20:20:32 --> Config Class Initialized
INFO - 2016-08-07 20:20:32 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:20:32 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:32 --> Utf8 Class Initialized
DEBUG - 2016-08-07 20:20:32 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:32 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:32 --> URI Class Initialized
INFO - 2016-08-07 20:20:32 --> URI Class Initialized
INFO - 2016-08-07 20:20:32 --> Router Class Initialized
INFO - 2016-08-07 20:20:32 --> Router Class Initialized
INFO - 2016-08-07 20:20:32 --> Output Class Initialized
INFO - 2016-08-07 20:20:32 --> Security Class Initialized
INFO - 2016-08-07 20:20:32 --> Output Class Initialized
INFO - 2016-08-07 20:20:32 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:32 --> Input Class Initialized
DEBUG - 2016-08-07 20:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:32 --> Input Class Initialized
INFO - 2016-08-07 20:20:32 --> Language Class Initialized
INFO - 2016-08-07 20:20:32 --> Language Class Initialized
ERROR - 2016-08-07 20:20:32 --> 404 Page Not Found: Assets/images
ERROR - 2016-08-07 20:20:32 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:20:38 --> Config Class Initialized
INFO - 2016-08-07 20:20:38 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:20:38 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:20:38 --> Utf8 Class Initialized
INFO - 2016-08-07 20:20:38 --> URI Class Initialized
INFO - 2016-08-07 20:20:38 --> Router Class Initialized
INFO - 2016-08-07 20:20:38 --> Output Class Initialized
INFO - 2016-08-07 20:20:38 --> Security Class Initialized
DEBUG - 2016-08-07 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:20:38 --> Input Class Initialized
INFO - 2016-08-07 20:20:38 --> Language Class Initialized
ERROR - 2016-08-07 20:20:38 --> 404 Page Not Found: Assets/images
INFO - 2016-08-07 20:21:28 --> Config Class Initialized
INFO - 2016-08-07 20:21:28 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:21:28 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:21:28 --> Utf8 Class Initialized
INFO - 2016-08-07 20:21:28 --> URI Class Initialized
INFO - 2016-08-07 20:21:28 --> Router Class Initialized
INFO - 2016-08-07 20:21:29 --> Output Class Initialized
INFO - 2016-08-07 20:21:29 --> Security Class Initialized
DEBUG - 2016-08-07 20:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:21:29 --> Input Class Initialized
INFO - 2016-08-07 20:21:29 --> Language Class Initialized
INFO - 2016-08-07 20:21:29 --> Loader Class Initialized
INFO - 2016-08-07 20:21:29 --> Helper loaded: url_helper
INFO - 2016-08-07 20:21:29 --> Database Driver Class Initialized
INFO - 2016-08-07 20:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:21:29 --> Email Class Initialized
INFO - 2016-08-07 20:21:29 --> Controller Class Initialized
INFO - 2016-08-07 20:21:29 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\upload.php
INFO - 2016-08-07 20:21:29 --> Final output sent to browser
DEBUG - 2016-08-07 20:21:29 --> Total execution time: 0.2261
INFO - 2016-08-07 20:21:45 --> Config Class Initialized
INFO - 2016-08-07 20:21:45 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:21:45 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:21:45 --> Utf8 Class Initialized
INFO - 2016-08-07 20:21:45 --> URI Class Initialized
INFO - 2016-08-07 20:21:45 --> Router Class Initialized
INFO - 2016-08-07 20:21:45 --> Output Class Initialized
INFO - 2016-08-07 20:21:45 --> Security Class Initialized
DEBUG - 2016-08-07 20:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:21:45 --> Input Class Initialized
INFO - 2016-08-07 20:21:45 --> Language Class Initialized
INFO - 2016-08-07 20:21:45 --> Loader Class Initialized
INFO - 2016-08-07 20:21:45 --> Helper loaded: url_helper
INFO - 2016-08-07 20:21:45 --> Database Driver Class Initialized
INFO - 2016-08-07 20:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:21:45 --> Email Class Initialized
INFO - 2016-08-07 20:21:45 --> Controller Class Initialized
INFO - 2016-08-07 20:21:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:21:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:21:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\galeri.php
INFO - 2016-08-07 20:21:45 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:21:45 --> Final output sent to browser
DEBUG - 2016-08-07 20:21:45 --> Total execution time: 0.2498
INFO - 2016-08-07 20:21:46 --> Config Class Initialized
INFO - 2016-08-07 20:21:46 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:21:46 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:21:46 --> Utf8 Class Initialized
INFO - 2016-08-07 20:21:46 --> URI Class Initialized
INFO - 2016-08-07 20:21:46 --> Router Class Initialized
INFO - 2016-08-07 20:21:46 --> Output Class Initialized
INFO - 2016-08-07 20:21:46 --> Security Class Initialized
DEBUG - 2016-08-07 20:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:21:46 --> Input Class Initialized
INFO - 2016-08-07 20:21:46 --> Language Class Initialized
INFO - 2016-08-07 20:21:46 --> Loader Class Initialized
INFO - 2016-08-07 20:21:46 --> Helper loaded: url_helper
INFO - 2016-08-07 20:21:47 --> Database Driver Class Initialized
INFO - 2016-08-07 20:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:21:47 --> Email Class Initialized
INFO - 2016-08-07 20:21:47 --> Controller Class Initialized
INFO - 2016-08-07 20:21:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:21:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:21:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\kontak.php
INFO - 2016-08-07 20:21:47 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:21:47 --> Final output sent to browser
DEBUG - 2016-08-07 20:21:47 --> Total execution time: 0.2489
INFO - 2016-08-07 20:21:49 --> Config Class Initialized
INFO - 2016-08-07 20:21:49 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:21:49 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:21:49 --> Utf8 Class Initialized
INFO - 2016-08-07 20:21:49 --> URI Class Initialized
INFO - 2016-08-07 20:21:49 --> Router Class Initialized
INFO - 2016-08-07 20:21:49 --> Output Class Initialized
INFO - 2016-08-07 20:21:49 --> Security Class Initialized
DEBUG - 2016-08-07 20:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:21:49 --> Input Class Initialized
INFO - 2016-08-07 20:21:49 --> Language Class Initialized
INFO - 2016-08-07 20:21:49 --> Loader Class Initialized
INFO - 2016-08-07 20:21:49 --> Helper loaded: url_helper
INFO - 2016-08-07 20:21:49 --> Database Driver Class Initialized
INFO - 2016-08-07 20:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:21:49 --> Email Class Initialized
INFO - 2016-08-07 20:21:49 --> Controller Class Initialized
INFO - 2016-08-07 20:21:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:21:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:21:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\news.php
INFO - 2016-08-07 20:21:49 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:21:49 --> Final output sent to browser
DEBUG - 2016-08-07 20:21:49 --> Total execution time: 0.2787
INFO - 2016-08-07 20:22:03 --> Config Class Initialized
INFO - 2016-08-07 20:22:03 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:22:04 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:22:04 --> Utf8 Class Initialized
INFO - 2016-08-07 20:22:04 --> URI Class Initialized
DEBUG - 2016-08-07 20:22:04 --> No URI present. Default controller set.
INFO - 2016-08-07 20:22:04 --> Router Class Initialized
INFO - 2016-08-07 20:22:04 --> Output Class Initialized
INFO - 2016-08-07 20:22:04 --> Security Class Initialized
DEBUG - 2016-08-07 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:22:04 --> Input Class Initialized
INFO - 2016-08-07 20:22:04 --> Language Class Initialized
INFO - 2016-08-07 20:22:04 --> Loader Class Initialized
INFO - 2016-08-07 20:22:04 --> Helper loaded: url_helper
INFO - 2016-08-07 20:22:04 --> Database Driver Class Initialized
INFO - 2016-08-07 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:22:04 --> Email Class Initialized
INFO - 2016-08-07 20:22:04 --> Controller Class Initialized
INFO - 2016-08-07 20:22:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:22:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:22:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-07 20:22:04 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:22:04 --> Final output sent to browser
DEBUG - 2016-08-07 20:22:04 --> Total execution time: 0.2630
INFO - 2016-08-07 20:22:05 --> Config Class Initialized
INFO - 2016-08-07 20:22:05 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:22:05 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:22:05 --> Utf8 Class Initialized
INFO - 2016-08-07 20:22:05 --> URI Class Initialized
INFO - 2016-08-07 20:22:05 --> Router Class Initialized
INFO - 2016-08-07 20:22:05 --> Output Class Initialized
INFO - 2016-08-07 20:22:05 --> Security Class Initialized
DEBUG - 2016-08-07 20:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:22:05 --> Input Class Initialized
INFO - 2016-08-07 20:22:05 --> Language Class Initialized
INFO - 2016-08-07 20:22:05 --> Loader Class Initialized
INFO - 2016-08-07 20:22:05 --> Helper loaded: url_helper
INFO - 2016-08-07 20:22:05 --> Database Driver Class Initialized
INFO - 2016-08-07 20:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:22:05 --> Email Class Initialized
INFO - 2016-08-07 20:22:05 --> Controller Class Initialized
INFO - 2016-08-07 20:22:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:22:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:22:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\page.php
INFO - 2016-08-07 20:22:05 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:22:05 --> Final output sent to browser
DEBUG - 2016-08-07 20:22:05 --> Total execution time: 0.2561
INFO - 2016-08-07 20:36:36 --> Config Class Initialized
INFO - 2016-08-07 20:36:36 --> Hooks Class Initialized
DEBUG - 2016-08-07 20:36:36 --> UTF-8 Support Enabled
INFO - 2016-08-07 20:36:36 --> Utf8 Class Initialized
INFO - 2016-08-07 20:36:36 --> URI Class Initialized
DEBUG - 2016-08-07 20:36:36 --> No URI present. Default controller set.
INFO - 2016-08-07 20:36:36 --> Router Class Initialized
INFO - 2016-08-07 20:36:36 --> Output Class Initialized
INFO - 2016-08-07 20:36:36 --> Security Class Initialized
DEBUG - 2016-08-07 20:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-07 20:36:36 --> Input Class Initialized
INFO - 2016-08-07 20:36:36 --> Language Class Initialized
INFO - 2016-08-07 20:36:36 --> Loader Class Initialized
INFO - 2016-08-07 20:36:36 --> Helper loaded: url_helper
INFO - 2016-08-07 20:36:36 --> Database Driver Class Initialized
INFO - 2016-08-07 20:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-07 20:36:36 --> Email Class Initialized
INFO - 2016-08-07 20:36:36 --> Controller Class Initialized
INFO - 2016-08-07 20:36:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/head.php
INFO - 2016-08-07 20:36:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/nav.php
INFO - 2016-08-07 20:36:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\home.php
INFO - 2016-08-07 20:36:36 --> File loaded: D:\xampp\htdocs\aqiqahsehati\application\views\template/foot.php
INFO - 2016-08-07 20:36:36 --> Final output sent to browser
DEBUG - 2016-08-07 20:36:36 --> Total execution time: 0.5039
